# Workflows A–J

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Purpose | The ten end-to-end business workflows named in the master prompt Phase 11, each with actors, permissions, trigger, validations, commands, database updates, notifications, failure cases and financial effects. |
| Depends on | [api/API_SPECIFICATION.md](../api/API_SPECIFICATION.md), [database/FINANCIAL_DATA_MODEL.md](../database/FINANCIAL_DATA_MODEL.md), the SC-* scenario files |
| Status | PROPOSED — NOT APPROVED. All BDT figures HYPOTHETICAL. |

## WF-A — One-time online meal order
Actors: Customer, trusted backend, gateway. Permissions: `perm.order.place_own`. Trigger: checkout with online payment. Validations: stock, zone, quote freshness. Commands: `createQuote`→`confirmQuote`→`placeOneTimeOrder`→`initiatePayment`→`handleGatewayNotification`→`validateGatewayTransaction`. DB updates: FS order/obligation, PG payment intent/verification/journal. Notifications: order confirmed, supplier new-order. Failure cases: stock race (SC-20), gateway replay (SC-13). Financial effect: Dr cash_and_clearing / Cr customer_prepaid_obligation.
```mermaid
sequenceDiagram
  participant C as Customer
  participant BE as Backend
  participant GW as Gateway
  C->>BE: confirmQuote, placeOneTimeOrder
  C->>BE: initiatePayment
  GW->>BE: IPN + validate
  BE->>C: order confirmed
```
```mermaid
flowchart LR
  A[Browse] --> B[Quote] --> C[Checkout] --> D[Pay online] --> E[Verified] --> F[Order Pending]
```
```mermaid
stateDiagram-v2
  Pending --> PickedUp --> OnTheWay --> Delivered
```

## WF-B — One-time COD order
Actors: Customer, Rider, Accounts. Trigger: checkout with COD. Commands: `placeOneTimeOrder(COD)`→`recordCodCollection`→`submitCodRemittance`→`verifyCodRemittance`. Failure cases: SC-09 (mismatch), SC-10 (duplicate receipt). Financial effect: `codInvoiced` then remittance-verified journal (see SC-03 §7).
```mermaid
sequenceDiagram
  participant C as Customer
  participant R as Rider
  participant Ac as Accounts
  C->>R: order placed (COD)
  R->>Ac: deliver + collect + remit
  Ac->>R: verify
```

## WF-C — Monthly prepaid subscription
See SC-01 in full. Actors: Customer, Supplier, Accounts. Commands: the subscription-builder chain + `recognizeSupplierEarning` per fulfilled obligation. Failure case: SC-07 (kitchen discontinuity). Financial effect: prepaid obligation recognised incrementally, never all at once.

## WF-D — Weekly subscription
See SC-02. Actors: Customer, Supplier. Commands: `saveSubscriptionSchedule`→`generateMealObligations` weekly. Financial effect: per-obligation pricing, never a flattened weekly average.

## WF-E — One-day meal skip
See SC-04. Commands: `skipMeals`→`issueCredit`. Financial effect: Dr customer_prepaid_obligation / Cr customer_credit_liability, exactly once (INV-08).

## WF-F — Meal upgrade or downgrade
See SC-05, SC-06. Commands: `quoteScheduleChange`→`confirmScheduleChange`. Financial effect: a charge (upgrade) or credit (downgrade), never both items fulfilled.

## WF-G — Supplier payout
Actors: Supplier, Accounts Operator, Payout Approver. Commands: `requestPayout`→`reviewPayout`→`approvePayout`→`createPayoutBatch`→`releasePayoutBatch`→`recordPayoutResult`. Failure case: SC-11 (eligible-balance check), SC-16 (self-approval attempt). Financial effect: settlement_clearing in transit, then supplier_payable reduced on confirmed external transfer.
```mermaid
stateDiagram-v2
  Requested --> UnderReview --> Approved --> Processing --> Settled
  Processing --> Failed
```

## WF-H — Rider payout and COD settlement
See SC-12. Actors: Rider, Accounts. Commands: `requestPayout` (compensation only) run alongside, never merged with, the COD remittance chain. Financial effect: two independent balances, no automatic netting absent BR-026 approval.

## WF-I — Refund and dispute
See SC-14. Actors: Customer, Accounts Operator/Manager. Commands: `initiateRefund`→`recordRefundResult`, or `ent.Dispute` review→`placeHold`/`requestAdjustment`. Financial effect: reversing/adjusting journal, never a duplicate of an existing credit (INV-17).

## WF-J — Rider reassignment
See SC-08. Actors: Admin dispatcher, original rider, replacement rider. Commands: `reassignDelivery` (SAGA). Financial effect: `earningReversed` if premature recognition occurred, then one recognition for the completing rider only — **no double payment**.

## Cross-workflow rule

Every workflow above shares the same trusted-boundary, idempotent-command, outbox and double-entry-ledger foundation described in [architecture/BACKEND_DOMAIN_DESIGN.md](../architecture/BACKEND_DOMAIN_DESIGN.md) and [database/FINANCIAL_DATA_MODEL.md](../database/FINANCIAL_DATA_MODEL.md); none of them introduces a special-case bypass of INV-01…INV-20.
