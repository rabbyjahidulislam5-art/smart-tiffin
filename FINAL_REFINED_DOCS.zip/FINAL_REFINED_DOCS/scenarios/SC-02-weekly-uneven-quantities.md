# SC-02 — Weekly plan with uneven daily quantities

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | CUS, PAR-Supplier, BE |
| Depends on | [Custom subscription engine](../customer-app/CUSTOM_SUBSCRIPTION_ENGINE.md), [Pricing and billing](../payments/PRICING_AND_BILLING.md) |
| Authoritative policies | BR-001, BR-002, BR-007 — PENDING |
| Invariants exercised | INV-01, INV-18 |
| Status | Draft. HYPOTHETICAL figures. Nothing implemented. |

## 1. Domain situation
A customer wants 1 meal Monday, 3 portions Wednesday, none Friday, across a 7-day weekly subscription. Each obligation prices from its own menu version and portion count — never an assumed equal daily cost. Delivery grouping (BR-007) and discounts (BR-008) must be explicit per obligation.

## 2. Actors and permissions
Customer (own schedule); Supplier (own capacity, must see the correct per-day cooking count).

## 3. Sample data (HYPOTHETICAL)
Monday: 1 × 13,000 paisa. Wednesday: 3 × 13,000 = 39,000 paisa. Friday: 0. Weekly delivery fee (grouped, illustrative) 10,000 paisa flat regardless of day count. Week total: 62,000 paisa.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | Schedule draft built from per-day/slot selections |
| Command accepted | `saveSubscriptionSchedule` persists the recurrence + exceptions |
| Funds confirmed | Quote 62,000 paid; journal posted |
| Service delivered | Each day's obligation fulfilled independently; Wednesday's 3 portions tracked as 3 line items, not 1 |
| Liability extinguished | Week's prepaid obligation reduced per fulfilled obligation |

## 5. Sequence
```mermaid
sequenceDiagram
  participant C as Customer App
  participant BE as Trusted backend
  participant S as Supplier workspace
  C->>BE: saveSubscriptionSchedule(recurrence, exceptions)
  BE->>BE: generateMealObligations (Mon:1, Wed:3, Fri:0)
  S->>BE: read cooking requirements (correct per-day counts)
  C->>BE: edit schedule before cutoff (change Wednesday to 2)
  BE->>BE: quoteScheduleChange -> confirmScheduleChange
```

## 6. Commands, idempotency, transactions
`generateMealObligations` is idempotent per subscription-per-date; a mid-week edit before cutoff uses `quoteScheduleChange`/`confirmScheduleChange` exactly once per change.

## 7. Event and ledger trace
Journal: Dr cash_and_clearing 62,000 / Cr customer_prepaid_obligation 62,000. Supplier capacity forecast (NS-04) shows Monday=1, Wednesday=3 (or 2 after edit), Friday=0 — never a flattened "weekly average".

## 8. Acceptance tests (SCT-02-*)
SCT-02-N: generated obligations exactly match the uneven selection. SCT-02-P: a different customer attempts to read this schedule — denied. SCT-02-C: two concurrent edits to the same schedule — last-committed-with-version-check wins, no lost update silently. SCT-02-L: lost response on a schedule edit, retried — one version increment. SCT-02-X: capacity service returns an inconsistent count — supplier screen shows a staleness warning, not a guessed number. SCT-02-R: recovery after obligation-generation job partial failure — re-run is idempotent, no duplicate Wednesday obligations.

## 9. Screen states
NC-05 (weekly schedule editor) shows per-day-per-slot quantity; NS-04 (kitchen forecast) reflects the exact uneven counts.

## 10. Links
[BR-001, BR-002, BR-007, BR-008](../requirements/POLICY_DECISION_REGISTER.md); related SC-01, SC-22.

## 11. Unapproved assumptions
The flat weekly delivery fee and all per-meal prices are illustrative; BR-007/BR-008 values are PENDING.
