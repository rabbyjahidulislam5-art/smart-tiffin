# SC-18 — Bilingual screen and narrow device verification

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Scenario author S3 (documentation); product owner for the customer journey to be assigned |
| Purpose | Specify end to end what must remain true when a customer switches English to Bangla in the middle of a subscription draft on a small phone, so that no draft content, identifier, price or accessible control is lost or changed by the language switch. |
| Applies to | CUS (primary); BE (preferences, draft and quote commands); ADM (audit read only). PAR and ACC are not affected. |
| Depends on | [Scenario index and common conventions](SCENARIO_INDEX.md#common-conventions-for-all-scenarios), [time and cutoff policy](../architecture/TIME_AND_CUTOFF_POLICY.md), [commands: orders and subscriptions](../api/COMMANDS_ORDERS_AND_SUBSCRIPTIONS.md), [accessibility](../design/ACCESSIBILITY.md), [responsive layouts](../design/RESPONSIVE_LAYOUTS.md), [design system](../design/DESIGN_SYSTEM.md), [customer UI/UX](../customer-app/CUSTOMER_UI_UX.md) |
| Authoritative policies | BR-022 / DEC-032 (cutoff and service time, PENDING) for the displayed cutoff text only; FR-049 (localisation, accessibility); FR-050 (slot identifiers). No other policy is exercised. |
| Design reference | AU-02, SH-05, C-04, C-12, C-08, NC-04, NC-05, NC-08, NC-14 (screen IDs are OBSERVED for legacy, PROPOSED for `NC-`) |
| Commands | `savePreferences`, `saveSubscriptionSchedule`, `createQuote` (all existing or PROPOSED names from the register); `confirmQuote` and `initiatePayment` are deliberately **not** executed |
| Invariants exercised | INV-03 (integer minor units, display only formatting), INV-18 (quote total is language independent); INV-01/02/04 are proven **not triggered** (no journal) |
| Status | Draft for review. Nothing implemented, nothing tested, nothing approved. All BDT figures are HYPOTHETICAL. |

## 1. Domain situation

**Restated.** A customer is composing a custom subscription draft on a small Android phone (compact width class, 360 x 740 dp, text scale raised by the user). Mid-draft the customer changes the app language from English to Bangla. The draft (kitchen, dates, slots, quantities, address) and the displayed quote must survive; labels, dates, numerals and error text must re-render in Bangla without clipping, without moving the keyboard-covered field out of reach, and without any slot being mistaken for another after translation (a lunch must never read as dinner).

**Refined.**

1. Language is a **display preference**, not draft content. It is stored through `savePreferences` (locale `en` or `bn`) and applied immediately on the device; the server never uses the locale to compute a price, a cutoff, a slot or a date.
2. Slots are identifiers (`slot.breakfast`, `slot.lunch`, `slot.snack`, `slot.dinner`) and service dates are ISO dates in the Asia/Dhaka service calendar. Translation resources map identifier to label; the identifier is what is stored and compared.
3. A quote already created for the draft is an immutable server snapshot. Switching language re-renders the same quote; it must not create a new quote or change its expiry. An expired quote requires `createQuote` again, and the screen says so explicitly.
4. Money is an integer in paisa; the screen formats it with two decimals in the selected language (Bangla numerals are a presentation choice that must round-trip to the same integer).
5. The scenario ends at the payment review (NC-08). The money-moving steps belong to [SC-13](SC-13-gateway-callback-replay.md) and [WF-A / WF-C](WORKFLOWS_A_TO_J.md). **No monetary movement occurs in this scenario**, and section 7 proves it.

**Assumptions (labelled).**

- A1 (PROPOSED): a draft subscription is stored server-side as `ent.Subscription` in state Draft with a version number, so a second device sees the same draft.
- A2 (PROPOSED): the app ships English and Bangla resource bundles in the binary; remote override of strings is optional and, if present, must pass an integrity check (see SCT-18-X).
- A3 (PROPOSED): the minimum touch target and text scaling limits are those in [accessibility](../design/ACCESSIBILITY.md); no numeric benchmark is claimed here.

**PENDING policies touched.**

| Reference | Question | Effect on this scenario |
|---|---|---|
| BR-022 / DEC-032 | Cutoff per slot, time zone, cross-midnight | Cutoff text shown on the draft is a rendered policy value (`policy.cutoff.*`); its value is not defined here. The test asserts only that the Bangla and English texts denote the same instant. |
| BR-001 / DEC-004 | Pause/skip granularity | Not exercised; displayed only as a policy note if present. |

## 2. Actors, role claims and permissions outline

| Actor | Role claim | Permitted in this scenario | Source of authority |
|---|---|---|---|
| Customer (owner of the draft) | `role.customer` + resource ownership of the draft | Read and edit own draft, save preferences, create a quote, view payment review | Principal id equals `ent.Subscription.customerId` |
| Guest | none | Browse only. A draft is local to the device until sign-in; no server draft command is permitted | Fail closed for `saveSubscriptionSchedule` |
| Another customer | `role.customer` | **Denied** reading or editing the first customer's draft (ownership check fails) | Relationship check, not claim alone |
| Supplier (kitchen K1) | `role.supplier` | **Denied** editing the draft. May later see obligations only after confirmation and payment, never a draft | Draft is not a kitchen commitment |
| Admin (operations) | `role.admin.ops` | Read draft metadata and audit events for support under least privilege; no edit | [Authorization](../api/AUTHORIZATION.md) |
| Accounts staff | `role.acc.*` | No access; no financial record exists | Not applicable |

Denied actor for the abuse test: **another customer** (SCT-18-P).

## 3. Sample data (HYPOTHETICAL BDT; integers in paisa)

| Item | Detail | Qty | Unit price (paisa) | Line total (paisa) | Customer display |
|---|---|---|---|---|---|
| Kitchen | K1 (verified, zone Z-A) | | | | |
| Saturday 2026-11-07 `slot.dinner` | Dinner thali, price version PV-101 | 2 | 20000 | 40000 | BDT 400.00 |
| Sunday 2026-11-08 `slot.lunch` | Lunch box, price version PV-102 | 1 | 18000 | 18000 | BDT 180.00 |
| Delivery, 2 trips | Zone Z-A per-trip fee (BR-007 PENDING) | 2 | 3000 | 6000 | BDT 60.00 |
| Quote Q-HYP-1801 total | Expires at `quote.expiresAt` (policy parameter) | | | **64000** | **BDT 640.00** |
| Address label | Customer text "Home" / "বাসা"; zone Z-A (server validated) | | | | |
| Locale before / after | `en` then `bn` | | | | |
| Device | Small Android, 360 x 740 dp, text scale enlarged, on-screen keyboard visible during edit | | | | |

Integer check: 40000 + 18000 + 6000 = 64000. The identifier tuple of the draft is {2026-11-07, `slot.dinner`, qty 2}, {2026-11-08, `slot.lunch`, qty 1}. It must be bit-for-bit identical before and after the switch.

## 4. Decision table

### 4.1 Steps

| # | Actors | Role claims | Service trigger | Source record | Precondition | Expected change | External dependency | Reversible? |
|---|---|---|---|---|---|---|---|---|
| 1 | Customer | `role.customer` | `saveSubscriptionSchedule` (edit) | `ent.Subscription` Draft v3, `ent.SubscriptionSchedule` | Signed in, owner of draft | Draft v4 holds the two obligations above | None | Yes (new version) |
| 2 | Customer | `role.customer` | `createQuote` | Draft v4, price versions PV-101/102, policy version | Draft valid; both slots open per BR-022 evaluation | Immutable `ent.Quote` Q-HYP-1801, total 64000 | None | Quote expires; never edited |
| 3 | Customer | `role.customer` | `savePreferences` (locale = `bn`) | `ent.Customer` preferences | Signed in | Locale persisted; UI re-renders from resource keys; draft and quote untouched | None (optional remote string bundle, SCT-18-X) | Yes |
| 4 | Customer | `role.customer` | Open NC-08 payment review | Q-HYP-1801 | Quote not expired | Read model renders same totals in Bangla; no payment intent exists | None | Yes |
| 5 | Admin | `role.admin.ops` | Support read | `ent.AuditEvent` for steps 1-3 | Support ticket reference | Metadata visible, no edit | None | Not applicable |

### 4.2 Five observations and interface update moments

| Observation | What it means here | Customer | Supplier | Rider | Admin | Accounts |
|---|---|---|---|---|---|---|
| Request received | `savePreferences` or `saveSubscriptionSchedule` reaches the trusted boundary with `requestId` | Shows an in-progress state on the control; UI language already switched locally | Nothing | Nothing | Nothing | Nothing |
| Command accepted | Receipt written and new draft version or preference committed | Draft/preference saved indicator at commit; screen shows version unchanged for content after switch | Nothing (a draft is not a commitment) | Nothing | Audit view lists the event after outbox projection | Nothing |
| Funds externally confirmed | **Not applicable.** No payment intent, no gateway call | "No payment started" is implicit: payment button remains the only entry to payment | Nothing | Nothing | Nothing | Nothing |
| Service delivered | **Not applicable.** No obligation exists until payment and activation | No upcoming-meal rows are created | No forecast row (NS-04) | No assignment | Nothing | Nothing |
| Liability extinguished | **Not applicable.** No liability was created | None | None | None | None | No journal, no receivable, no credit |

## 5. Sequence

```mermaid
sequenceDiagram
    autonumber
    actor Cust as Customer
    participant App as Customer App
    participant Res as Local Resource Bundles
    participant BE as Trusted Command Boundary
    participant FS as Operational Store
    participant Aud as Audit and Outbox
    participant Adm as Admin Web
    participant Sup as Supplier Workspace
    participant Rid as Rider Workspace
    participant Acc as Accounts Web
    Cust->>App: Edit schedule Sat dinner x2, Sun lunch x1
    App->>BE: saveSubscriptionSchedule requestId R1, expectedVersion 3
    BE->>FS: Write draft v4 and receipt R1 atomically
    BE->>Aud: Audit event and outbox
    BE-->>App: Draft v4
    App->>BE: createQuote draft v4
    BE-->>App: Quote Q-HYP-1801 total 64000
    Cust->>App: Open settings, choose Bangla
    App->>Res: Load bn bundle and integrity check
    App->>App: Re-render from keys, keep draft state in memory
    App->>BE: savePreferences locale bn, requestId R2
    BE->>FS: Persist preference and receipt R2
    BE-->>App: Accepted
    Cust->>App: Continue to payment review
    App-->>Cust: Same quote Q-HYP-1801, Bangla text, two decimal total
    Aud-->>Adm: Audit read model updated
    Note over Sup,Rid: No update. A draft is not a commitment.
    Note over Acc: No update. No journal exists.
```

**Textual sequence.** (1) The customer edits the draft; the server writes version 4 and a receipt in one transaction. (2) The server returns quote Q-HYP-1801. (3) The customer switches language; the app swaps resource bundles, checks bundle integrity, re-renders from keys and keeps focus and scroll position. (4) `savePreferences` persists the locale. (5) The payment review shows the same quote. (6) Admin sees audit events; Supplier, Rider and Accounts see nothing.

**Human approval checkpoints.** None are required for the language switch or draft. The customer's explicit confirmation of the quote (`confirmQuote`) is the next checkpoint and belongs to [WF-C](WORKFLOWS_A_TO_J.md#wf-c--monthly-prepaid-subscription). No staff approval is involved.

## 6. Commands, idempotency and transaction boundaries

| Command | Stable logical operation id | Atomic boundary | Immutable before/after event | Duplicate handling |
|---|---|---|---|---|
| `saveSubscriptionSchedule` | `op.saveSubscriptionSchedule.<subscriptionId>.v<expectedVersion>` | Draft version row + schedule rows + `ent.RequestReceipt` + `ent.AuditEvent` + `ent.OutboxEvent` in one transaction | `DraftScheduleChanged` with before (v3) and after (v4) content hashes | Same `requestId` and same canonical fingerprint returns the stored v4 result. Same `requestId` with a different fingerprint is rejected |
| `createQuote` | `op.createQuote.<subscriptionId>.v<draftVersion>` | Quote snapshot + receipt in one transaction | `QuoteCreated` with price versions and policy version | Same key returns Q-HYP-1801 |
| `savePreferences` | `op.savePreferences.<customerId>.locale` | Preference document + receipt | `PreferenceChanged` from `en` to `bn` | Last write wins by version; harmless |

Rules specific to this scenario:

- **Pending versus retry versus compensation.** A failed `savePreferences` leaves the local language switched and the preference **pending**; the app retries with the same `requestId`. There is no compensating entry because no money or commitment changed.
- **Independent reconciliation of failed or duplicate external messages.** The only external input is the optional remote string bundle. A duplicate or stale bundle is ignored by version comparison; a bundle failing integrity is discarded in favour of the bundled one.
- **No mutable summary field for money liabilities.** None exists in this scenario. The quote total is a snapshot field (INV-18), never a running balance.

## 7. Event and ledger trace

| Seq | Event | Journal | INV reference |
|---|---|---|---|
| 1 | `DraftScheduleChanged` (v3 to v4) | none | INV-03 (amounts stored as integers) |
| 2 | `QuoteCreated` Q-HYP-1801 total 64000 | none | INV-18 (snapshot totals only) |
| 3 | `PreferenceChanged` en to bn | none | none |

**No monetary movement.** Proof obligations (all must hold in the acceptance test SCT-18-N):

1. The set of commands executed is {`saveSubscriptionSchedule`, `createQuote`, `savePreferences`}; none of them is in the money-moving set (`initiatePayment`, `handleGatewayNotification`, `recordCodCollection`, `postJournal`, `issueCredit`, `consumeCredit`, `requestPayout`, and similar).
2. The count of `ent.JournalEntry` rows with correlation id = the scenario's correlation id is 0 before and after.
3. No `ent.PaymentIntent`, `ent.PaymentAttempt`, `ent.Refund`, `ent.CreditTransaction` or `ent.Hold` row references the draft.
4. The quote total in the customer read model (64000) equals the quote snapshot, so a Bangla rendering is a pure function of the stored integer.

## 8. Acceptance tests (Given/When/Then; planned, none executed)

| ID | Type | Given | When | Then |
|---|---|---|---|---|
| SCT-18-N | Normal | Customer with draft v4 (two obligations) and quote Q-HYP-1801 on a 360 x 740 dp device, English | Customer switches to Bangla from SH-05 while on NC-04, then opens NC-08 | Draft content, identifiers, quantities, dates and address survive; Q-HYP-1801 unchanged with total 64000 displayed as two-decimal Bangla text; no label overflows or clips at the enlarged text scale; focus returns to the same control; every interactive control keeps an accessible label and the minimum touch target; the dinner row still carries `slot.dinner`; journals for the correlation id = 0; audit contains `PreferenceChanged`. |
| SCT-18-P | Insufficient permission / abuse | A second customer holds a valid token and knows the draft id | Calls `saveSubscriptionSchedule` and `createQuote` for the first customer's draft | Both fail closed with an authorisation error that discloses nothing about the draft; no version bump; an `AuthorizationDenied` audit event is written; no quote created. A supplier token and a guest session also fail. |
| SCT-18-C | Concurrent update | The same draft open on two devices; device A changes quantity of Sunday lunch to 2 (expectedVersion 4) while device B, simultaneously, saves the same expected version with a different quantity | Both commands arrive within the same moment | Exactly one commits (v5); the other receives a version-conflict error with the current content and a next-action message in the selected language; the locale change on either device never conflicts because preferences are not draft content. |
| SCT-18-L | Lost response, committed effect | `saveSubscriptionSchedule` commits v5 but the response is lost on a weak network | App retries with the same `requestId` | Server returns the stored v5 result without a second version; one receipt, one audit event, one outbox event; the screen shows saved. |
| SCT-18-X | Inconsistent third-party response | Optional remote string bundle returns a Bangla table whose version or hash does not match, or maps the label for `slot.lunch` to the word for dinner | App loads the bundle during the switch | The bundle is rejected, the shipped bundle is used, a non-blocking diagnostic is recorded, and the slot-to-label mapping check (identifier to label, bijective for the four slots) still passes; the screen never shows a wrong slot name. |
| SCT-18-R | Recovery after partial failure | The app is killed after the local language switch but before `savePreferences` was acknowledged | App restarts | The pending preference is retried with the original `requestId` or reconciled to the server value; the draft reloads at v5; if the quote expired meanwhile, the screen states "price needs refreshing" in Bangla and offers `createQuote`; no money state exists to repair. |

State constraints that must agree: draft version monotonic; quote bound to a draft version; receipt per command; notification count for customer unchanged (a language switch sends none); audit record count = commands executed; journal count = 0.

## 9. Screen states

| Screen | Mobile (360 x 740 dp, enlarged text) | Desktop / tablet | Accessible error text and next action | Offline fallback |
|---|---|---|---|---|
| SH-05 language | Segmented English / বাংলা control at full width; switch applies immediately; announces the new language to assistive technology | Same control in a settings pane | "Could not save your language. It is applied on this device and will sync when you are online." Action: Retry | Applies locally, queued `savePreferences` |
| NC-04 builder | Single column, rows stack label above value, sticky footer holds Save draft and Review; keyboard never hides the focused field (scroll into view) | Two columns, calendar plus summary | Version conflict: "Your draft changed on another device. Review the latest version." Action: Reload draft | Draft edits kept locally with a visible "not yet saved" state; no quote can be created offline |
| NC-08 plan review | Totals block wraps; Bangla numerals optional; line items remain tappable | Table layout | Quote expired: "This price has expired. Refresh the price to continue." Action: Refresh price | Read-only cached quote, payment action disabled with reason caption |
| Bottom navigation (C-01, C-10, C-16, C-23) | Labels may wrap to two lines or fall back to icon plus tooltip; icon meaning unchanged | Rail with labels | Not applicable | Navigation works offline |

## 10. Links

[Common conventions](SCENARIO_INDEX.md#common-conventions-for-all-scenarios) · [Scenario index](SCENARIO_INDEX.md) · [Time and cutoff policy](../architecture/TIME_AND_CUTOFF_POLICY.md) · [Orders and subscriptions commands](../api/COMMANDS_ORDERS_AND_SUBSCRIPTIONS.md) · [Authorization](../api/AUTHORIZATION.md) · [Error responses](../api/ERROR_RESPONSES.md) · [Accessibility](../design/ACCESSIBILITY.md) · [Responsive layouts](../design/RESPONSIVE_LAYOUTS.md) · [Custom subscription engine](../customer-app/CUSTOM_SUBSCRIPTION_ENGINE.md) · [Policy decision register](../requirements/POLICY_DECISION_REGISTER.md) · [Glossary](../requirements/GLOSSARY_AND_TERMINOLOGY.md) · [Financial test cases](../testing/FINANCIAL_TEST_CASES.md) · [Workflows A to J](WORKFLOWS_A_TO_J.md)

## 11. Unapproved assumptions flagged

1. Draft persistence on the server (A1) is PROPOSED; a local-only draft would change SCT-18-C.
2. Remote string bundles (A2) are optional and PROPOSED; if absent, SCT-18-X is satisfied trivially.
3. Bangla numerals in money display are a presentation option that is not approved; the integer is authoritative.
4. Quote lifetime (`quote.expiresAt`) is a policy parameter with no approved value.
5. No claim is made that any of these behaviours is implemented; a prototype toast showing the language changed is not evidence.
