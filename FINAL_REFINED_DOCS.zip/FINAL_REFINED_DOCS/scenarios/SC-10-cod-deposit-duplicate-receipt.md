# SC-10 — COD deposit verification and duplicate receipt

| Field | Value |
|---|---|
| Scenario ID | SC-10 |
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author S2 (scenarios); scenario owner for review: Accounts & Finance lead (to be identified) |
| Purpose | Specify, end to end, how a rider's cash-on-delivery (COD) deposit is submitted, independently verified by Accounts, and protected against a second operator (or a second submission) marking the same receipt twice. |
| Applies to | PAR-R (Rider workspace), ACC (Accounts Web), ADM (limited view), CUS (payment status), BE (trusted services), ledger store (PG) and operational store (FS) |
| Depends on | [COD payment workflow](../payments/COD_PAYMENT_WORKFLOW.md), [COD reconciliation](../accounts-web/COD_RECONCILIATION.md), [payments and COD commands](../api/COMMANDS_PAYMENTS_AND_COD.md), [ledger and governance commands](../api/COMMANDS_LEDGER_AND_GOVERNANCE.md), [financial data model](../database/FINANCIAL_DATA_MODEL.md), [glossary](../requirements/GLOSSARY_AND_TERMINOLOGY.md), [conventions](../analysis/CONVENTIONS_AND_ID_REGISTER.md) |
| Authoritative policies | [BR-003 / DEC-005](../requirements/BUSINESS_RULES.md) (verification authority and evidence), [BR-013 / DEC-023](../requirements/POLICY_DECISION_REGISTER.md) (remittance deadline, overdue, recovery), [BR-020 / DEC-030](../requirements/POLICY_DECISION_REGISTER.md) (approval limits, maker-checker), [BR-012 / DEC-022](../requirements/POLICY_DECISION_REGISTER.md) (COD eligibility, context only). All PENDING. |
| Invariants exercised | INV-01, INV-02, INV-03, INV-04, INV-10, INV-11, INV-12, INV-15, INV-20 |
| Design references | NR-03, NR-04, NR-05, NF-03, NF-04, NF-11, NF-13, NA-05, C-17, C-20, SH-01 (per app instance) |
| Status | Draft for review. Nothing here is implemented, tested or approved. All BDT figures are HYPOTHETICAL. Provenance: USER-REQ (scenario SC-10 of the master prompt), with PROPOSED engineering detail. |

## 1. Domain situation

**Restated.** A rider delivers several COD orders in one shift and collects customer cash. That cash belongs to the company, not to the rider (glossary: *rider-held COD cash*). The rider deposits the cash (or an approved transfer) and submits a remittance record with a deposit reference and receipt evidence. Accounts reviews the submission. A second Accounts operator, a manager, or the rider must not be able to cause the same receipt to be counted twice. An uploaded image is evidence to be examined; it is not proof that cash arrived. Mismatched and partial remittances must be representable without hiding the difference.

**Refinements adopted in this document (PROPOSED, not approved).**

1. A remittance is a claim by the rider. It has no accounting effect until Accounts verifies it against independent evidence (a bank statement line, an agent or counter acknowledgement, or an approved transfer record).
2. Verification is performed by one identity and, above a configurable threshold, approved by a second identity (INV-15, BR-020). The preparer of a verification cannot be its approver.
3. Verification is idempotent on two keys: the logical operation (one verification per remittance) and the external evidence (one verification per normalised deposit reference per channel, INV-12).
4. A partial deposit is verified for the evidenced amount only. The remainder stays in COD receivable, flagged as a discrepancy. It is never written off automatically, and rider compensation is never adjusted to hide it (INV-10).
5. Verification never changes delivery status, supplier earnings, or rider earnings. It only moves COD receivable to bank or cash.

**Assumptions.** The deposit channel (bank counter, mobile financial service, Accounts counter) and the evidence that counts as independent confirmation are not defined: BR-003 is PENDING. This document uses the parameter `policy.cod.verification_evidence` and shows a bank statement line as the example evidence only.

**Pending policies that affect this scenario.**

| Policy | Open question for SC-10 | Parameter used here |
|---|---|---|
| BR-003 / DEC-005 | Who may verify, what evidence is sufficient, how duplicates are detected | `policy.cod.verifier_roles`, `policy.cod.verification_evidence` |
| BR-013 / DEC-023 | Remittance deadline, partial remittance allowed or not, overdue and recovery steps | `policy.cod.remittance_deadline_hours`, `policy.cod.partial_remittance_allowed` |
| BR-020 / DEC-030 | Threshold above which a second approver is needed | `policy.finance.dual_approval_threshold_minor` |
| BR-026 / DEC-036 | Whether any shortage may be offset against rider payable | none: no netting is performed in this scenario |

## 2. Actors, role claims and permissions outline

Claim and permission names are PROPOSED and must be reconciled with [AUTHORIZATION](../api/AUTHORIZATION.md) when the matrix is updated. Every grant is a server-validated record plus claim, never a UI selection.

| Actor | Role claim | Permissions used (PROPOSED) | Denied in this scenario |
|---|---|---|---|
| Rider (depositor) | `role.rider` (approved, active) | `perm.cod.submit_remittance` (own collections only) | Verifying any remittance, editing amounts after submit, reading other riders' collections |
| Accounts Operator | `role.accounts.operator` | `perm.cod.verify` (prepare), `perm.cod.flag_discrepancy` | Approving own verification above the threshold; posting free-form journals |
| Accounts Manager | `role.accounts.manager` | `perm.cod.verify`, `perm.cod.approve_verification`, `perm.cod.resolve_discrepancy` | Approving a verification the same identity prepared |
| Financial Auditor | `role.accounts.auditor` | `perm.ledger.read`, `perm.audit.read` | All writes |
| Finance Viewer | `role.accounts.viewer` | `perm.ledger.read` (masked) | All writes (the denied actor in SCT-10-P) |
| Admin (operations) | `role.admin` | `perm.finance.overview.read` (NA-05 aggregates only) | Verifying, adjusting or reversing COD records |
| Customer | `role.customer` | Read own order payment state | Any access to remittance data |
| Supplier | `role.supplier` | Read own earnings summary | Any access to COD remittance data |
| Trusted backend | service principal | `postJournal` (internal only) | Cannot be invoked from any client |

## 3. Sample data definitions (HYPOTHETICAL BDT, integer paisa; display with two decimals)

None of these values is a price, fee, rate, limit or approved policy.

| Item | Identifier | Paisa | Customer or staff display |
|---|---|---|---|
| COD collection 1 (order O-HYP-501) | CC-HYP-0101 | 45,000 | BDT 450.00 |
| COD collection 2 (order O-HYP-502) | CC-HYP-0102 | 62,000 | BDT 620.00 |
| COD collection 3 (order O-HYP-503) | CC-HYP-0103 | 38,000 | BDT 380.00 |
| Total COD receivable for the rider shift | sum | 145,000 | BDT 1,450.00 |
| Rider confirmed compensation for the same 3 deliveries (illustrative, separate from COD) | RE-HYP-0201..0203 | 4,500 | BDT 45.00 |
| Remittance 1 | RM-HYP-0001, deposit reference `DEP-HYP-7781`, channel `bank_deposit` | 145,000 claimed | BDT 1,450.00 |
| Bank statement line (independent evidence) | BSL-HYP-5521, reference `DEP-HYP-7781` | 145,000 | BDT 1,450.00 |
| Partial-variant statement line | BSL-HYP-5522 | 120,000 | BDT 1,200.00 |
| Partial-variant shortfall | derived | 25,000 | BDT 250.00 |
| Next-day collection (duplicate attempt) | CC-HYP-0104 | 20,000 | BDT 200.00 |
| Remittance 2 (attempts to reuse the reference) | RM-HYP-0002, `DEP-HYP-7781` | 20,000 claimed | BDT 200.00 |
| Dual-approval threshold (illustrative only) | `policy.finance.dual_approval_threshold_minor` | 100,000 | BDT 1,000.00 |

Context journal already posted when the three deliveries completed (owned by the SC-03 flow, shown only so that INV-11 can be followed): `JE-CTX-0501`: Dr `acct.cod_receivable` 145,000; Cr `acct.supplier_payable` 105,000; Cr `acct.rider_payable` 4,500; Cr `acct.platform_revenue` 35,500 (split HYPOTHETICAL, governed by BR-009, BR-010, BR-011). Total debits 145,000 = total credits 145,000.

Principals: rider `PR-RIDER-02`, operators `PR-ACC-OP-01` and `PR-ACC-OP-02`, manager `PR-ACC-MGR-01`, viewer `PR-ACC-VW-01`, admin `PR-ADM-03`. All are synthetic.

## 4. Decision table

### 4.1 Observations and their effects

The five observations are distinct events. Request received is not command accepted, and neither is funds externally confirmed.

| # | Observation | Actors and role claims | Service trigger | Source record | Precondition | Expected change | External dependency | Reversible? |
|---|---|---|---|---|---|---|---|---|
| O1 | Request received | Rider, `role.rider` | `submitCodRemittance` call from NR-04 reaches the trusted boundary | Client envelope `{command, requestId, payload}` | Authenticated principal, active rider grant, collections in state Due for Remittance owned by the rider | None yet: the envelope is authenticated and fingerprinted. No financial or status change. | None | Yes: a rejected or abandoned request leaves no trace beyond the receipt/audit entry |
| O2 | Command accepted | Trusted backend on behalf of the rider | Validation passes, idempotency receipt written, remittance recorded | `ent.CodCollection` lines, new `ent.CodRemittance` RM-HYP-0001 | Unique deposit reference for the channel (INV-12), claimed amount ≤ outstanding due, rider owns all lines, receipt evidence stored | Remittance status Submitted (pending verification). Collections move Due for Remittance → Remitted (pending verification). **No journal.** COD receivable is unchanged (INV-11). | Object storage for the receipt image (evidence only) | Yes, by an explicit withdrawal or rejection command while unverified; never by deleting the record |
| O3 | Funds externally confirmed | Accounts Operator prepares, Accounts Manager approves when amount ≥ threshold. `role.accounts.operator`, `role.accounts.manager` | `verifyCodRemittance` | `ent.CodRemittance`, independent evidence (BSL-HYP-5521), `ent.ReconciliationItem` | Remittance Submitted; evidence amount and reference match or are recorded as variance; preparer ≠ approver (INV-15); no earlier verification for the same reference (INV-12) | Remittance Verified for the evidenced amount; one balanced journal `JE-HYP-1001`; reconciliation item matched; discrepancy case opened for any shortfall | Bank or counter evidence (statement line, acknowledgement) | Only by a compensating `reverseJournal` plus status reopening with reason and approval; the original journal is never edited (INV-02) |
| O4 | Service delivered | Not an actor in this step. Delivery was completed earlier by the rider (`role.rider`) | Delivery completion, recognised in the SC-03 flow before this scenario starts | `ent.DeliveryEvent`, `ent.SupplierEarning`, `ent.RiderEarning` | Delivered | **No change.** Verification must not alter delivery state, supplier earning, or rider earning (INV-10, INV-19). Shown as a row because the interfaces must prove that nothing moved. | None | Not applicable here |
| O5 | Liability extinguished | Trusted backend | Posting of `JE-HYP-1001` | `ent.JournalEntry`, `ent.JournalLine` | O3 completed | COD receivable falls by the verified amount. The rider's remittance obligation for those lines closes (Verified). Any shortfall remains as an open, flagged receivable (Partially Remitted → Disputed or Overdue per policy). | None | Compensating reversal only |

### 4.2 Interface update moments

"Updates" means the first moment the interface's read model changes. A read model is refreshed only after the authoritative commit and its outbox event; no latency figure is approved. Interfaces that do not participate still have a defined behaviour.

| # | Customer app (C-17, C-20) | Supplier workspace (S-08, NS-01) | Rider workspace (NR-03, NR-04, NR-05, NR-01) | Admin web (NA-05) | Accounts web (NF-03, NF-04, NF-13, NF-11) |
|---|---|---|---|---|---|
| O1 | No change. Customer order still shows "Delivered, paid in cash". | No change. | Submit button disabled with "Submitting" and local pending marker. The rider screen shows a client-side pending state only, never "Remitted". | No change. | No change. |
| O2 | No change. The customer never sees remittance data. | No change. Supplier earning figures unchanged. | On receipt: NR-04 shows Remitted, pending Accounts verification, with the stable receipt reference. NR-03 lines show "Awaiting verification". | Aggregate "COD awaiting verification" count may rise at the next aggregate refresh (counts only, no rider detail). | NF-03 row moves to "Submitted"; NF-04 queue gains RM-HYP-0001 with evidence thumbnail marked "Evidence, not confirmation". |
| O3 | No change. | No change. | NR-04 shows Verified (or Partially verified with the shortfall amount) only after the authoritative commit and projection event. The rider is notified (`ntf.cod.remittance_verified`). | Aggregate "awaiting verification" count falls; no ledger access. | NF-04 shows Verified with verifier and approver identities; NF-11 shows `JE-HYP-1001`; NF-03 outstanding falls; the matched statement line leaves the NF-13 unmatched list. |
| O4 | Unchanged (proof that verification does not alter delivery or payment state). | Earning unchanged. | Earnings unchanged: NR-01 shows no change in compensation. | Unchanged. | Rider payable and supplier payable lines unchanged in NF-05 and NF-06. |
| O5 | Order stays "Paid". Receipt (C-21) is available only if the receipt policy issues one for COD, which is PENDING. | Unchanged. | NR-04 and NR-03 show the obligation closed for the verified lines. A partial verification shows "BDT 250.00 still due" and an open discrepancy (NR-05). | Aggregate COD receivable falls. | NF-01 COD receivable metric falls by the journal amount; any shortfall appears in NF-13 as an open discrepancy. |

## 5. Sequence diagram

```mermaid
sequenceDiagram
    autonumber
    participant CA as Customer app
    participant PA as Partner app Rider
    participant AW as Admin web
    participant ACW as Accounts web
    participant BE as Trusted backend
    participant FS as Firestore
    participant LS as Ledger store
    participant GW as Bank or deposit channel
    participant NT as Notification service

    PA->>BE: submitCodRemittance requestId R1 reference DEP-HYP-7781 amount 145000
    BE->>BE: authenticate, check grant, fingerprint, check ownership of lines
    BE->>LS: one transaction - receipt R1, remittance Submitted, unique reference, audit, outbox
    LS-->>BE: committed
    BE-->>PA: receipt reference RC-HYP-9001 status Submitted
    BE->>FS: outbox projects remittance and line status
    BE->>NT: ntf.cod.remittance_submitted to Accounts queue
    NT-->>ACW: queue item
    ACW->>BE: verifyCodRemittance requestId V1 prepared by Operator 1
    BE->>LS: read remittance and evidence match, check no prior verification for reference
    GW-->>BE: bank statement line BSL-HYP-5521 imported by reconcile job
    Note over ACW,BE: Human checkpoint - amount at or above threshold needs Manager approval
    ACW->>BE: approveVerification requestId V2 by Manager
    BE->>LS: one transaction - Verified, ReconciliationItem matched, JE-HYP-1001 balanced, audit, outbox
    LS-->>BE: committed
    BE->>FS: outbox projects Verified to rider and Accounts read models
    BE->>NT: ntf.cod.remittance_verified to rider
    NT-->>PA: notification
    ACW->>BE: verifyCodRemittance requestId V3 by Operator 2 same remittance
    BE->>LS: unique reference and state check fails
    BE-->>ACW: ALREADY_VERIFIED with original receipt reference
    Note over CA,AW: Customer and Admin read models change only through counts or are untouched
```

**Short text sequence.**

1. The rider submits the remittance (O1). The backend writes the receipt, remittance, uniqueness reservation, audit event and outbox event in one ledger-store transaction (O2) and returns a receipt reference.
2. Accounts sees the item in NF-04. The bank statement line arrives by the reconciliation import, independent of the rider.
3. Operator 1 prepares the verification. The Manager approves (human checkpoint). The backend commits the verification, reconciliation match, and balanced journal atomically (O3, O5).
4. Operator 2's later attempt on the same remittance (or the same reference) is rejected with the original receipt reference. No second journal is possible.

**Human approval checkpoints.** (a) Independent evidence review by the Operator. (b) Manager approval at or above `policy.finance.dual_approval_threshold_minor`. (c) Manager decision on any discrepancy resolution. No automatic write-off exists.

## 6. Commands, idempotency and transaction boundaries

| Command | Logical operation id (stable, derived from business keys) | Atomic boundary | Duplicate defence | Failure class |
|---|---|---|---|---|
| `submitCodRemittance` | `op:cod-remit:{riderId}:{channel}:{normalisedDepositReference}` | Receipt, `ent.CodRemittance`, line status changes, uniqueness row, audit event, outbox event, one ledger-store transaction | Unique `(channel, normalised_reference)`; client `requestId` per principal returns the stored receipt on retry | Retry safe (same requestId); different requestId with same reference returns `DUPLICATE_DEPOSIT_REFERENCE` |
| `verifyCodRemittance` (prepare and approve steps) | `op:cod-verify:{remittanceId}` | Verification record, reconciliation item, journal header and lines, remittance and line state, audit, outbox, one transaction | Unique `(remittanceId)` verification row; state guard Submitted → Verified; expected version | Retry safe; a second operator receives `ALREADY_VERIFIED` plus the original receipt |
| `flagCodDiscrepancy` | `op:cod-flag:{remittanceId}:{evidenceLineId}` | Discrepancy case, state change, audit, outbox | Unique case per remittance and evidence line | Retry safe |
| `resolveCodDiscrepancy` | `op:cod-resolve:{caseId}` | Case closure, optional journal via `postJournal`, audit | Unique resolution per case | Compensating entry for errors |
| `reverseJournal` | `op:reverse:{journalId}` | Reversal journal linked to the original, status Reversed on the original header only as a marker, audit | Unique reversal per journal (INV-02, INV-04) | Compensating by definition |

**Rules applied to every command above.**

- *Stable logical operation id.* The client `requestId` identifies a retry of one client call. The logical operation id identifies the business action. Both are stored; the second prevents a different client call (a second operator) from repeating the action.
- *Immutable before and after.* Each state change writes an immutable `ent.AuditEvent` containing the before state hash, after state hash, actor, role grant version, reason code and the receipt reference.
- *Independent reconciliation of external messages.* Bank statement lines are imported by a trusted job into `ent.ReconciliationItem` independently of any user action. A line can be matched to at most one remittance. A statement line that is imported twice is deduplicated by statement identifier and line number. A line that matches nothing is routed to NF-13 as unmatched.
- *Pending versus retry versus compensating entry.* Pending = a submitted or awaiting-approval state with no journal. Retry = re-sending the same command with the same requestId after a lost response (never creates new effect). Compensating = a reversing journal plus a new state transition, used only after a posted journal is found to be wrong.
- *No mutable money summary.* COD receivable, rider remittance liability and every dashboard total are derived from posted journal lines and immutable events (INV-20). No field such as `rider.cod_balance` exists to be edited.
- *Cross-store consistency.* The ledger store is authoritative for the verification and journal. The operational store receives status projections through the outbox, consumed idempotently by event id. A projection failure never changes the ledger and is retried.

## 7. Event and ledger trace

### 7.1 Events (immutable, in order)

| Seq | Event | Actor | Before → after | Journal |
|---|---|---|---|---|
| 1 | `evt.cod.remittance_submitted` | `PR-RIDER-02` | Lines Due for Remittance → Remitted (pending verification); remittance none → Submitted | none |
| 2 | `evt.recon.statement_line_imported` | system | line absent → BSL-HYP-5521 Unmatched | none |
| 3 | `evt.cod.verification_prepared` | `PR-ACC-OP-01` | Submitted → Verification prepared (match found, variance 0) | none |
| 4 | `evt.cod.verification_approved` | `PR-ACC-MGR-01` | Verification prepared → Verified; BSL-HYP-5521 Unmatched → Matched | `JE-HYP-1001` |
| 5 | `evt.cod.duplicate_verification_rejected` | `PR-ACC-OP-02` | no state change | none |
| 6 | `evt.cod.duplicate_reference_rejected` | `PR-RIDER-02` | no state change (RM-HYP-0002) | none |

### 7.2 Journals

**JE-HYP-1001** (effective at verification; source remittance RM-HYP-0001; INV-01, INV-11, INV-12)

| Line | Account (PROPOSED chart name) | Debit (paisa) | Credit (paisa) |
|---|---|---|---|
| 1 | `acct.bank_cash` | 145,000 | |
| 2 | `acct.cod_receivable` | | 145,000 |
| | **Totals** | **145,000** | **145,000** |

**Partial variant, JE-HYP-1002** (evidence BSL-HYP-5522 = 120,000): Dr `acct.bank_cash` 120,000; Cr `acct.cod_receivable` 120,000. Remaining COD receivable 25,000 stays open and flagged. No journal is created for the shortfall until a resolution is approved. Rider payable (4,500 in the sample) is not touched.

**Compensating example (only if verification is later proven wrong), JE-HYP-1003:** Dr `acct.cod_receivable` 145,000; Cr `acct.bank_cash` 145,000, referencing `JE-HYP-1001`.

Closing positions after JE-HYP-1001 (derived, not stored): COD receivable for the three collections = 145,000 − 145,000 = 0. Rider payable remains 4,500. INV-10 holds.

## 8. Acceptance and integration tests

All tests below are planned; none has been executed. IDs are `SCT-10-<type>-<n>`. The abuse tests are SCT-10-P and SCT-10-X.

### SCT-10-N — Normal verification

- **Given** RM-HYP-0001 is Submitted for 145,000 with reference `DEP-HYP-7781`, statement line BSL-HYP-5521 for 145,000 is imported, and `PR-ACC-OP-01` prepared the verification.
- **When** `PR-ACC-MGR-01` approves (amount 145,000 ≥ 100,000 hypothetical threshold).
- **Then** exactly one journal `JE-HYP-1001` exists with debits = credits = 145,000 (INV-01); remittance and the three collections are Verified; the statement line is Matched; the rider receives `ntf.cod.remittance_verified`; NF-01 COD receivable falls by 145,000; rider payable and supplier payable are unchanged.

### SCT-10-P — Insufficient permission and maker-checker (abuse test)

- **Given** `PR-ACC-OP-01` prepared the verification, and `PR-ACC-VW-01` (Finance Viewer) and `PR-ADM-03` (Admin) exist.
- **When** (a) `PR-ACC-OP-01` attempts to approve its own preparation; (b) the Viewer calls `verifyCodRemittance`; (c) the Admin calls it; (d) the rider calls it for their own remittance.
- **Then** each call is rejected with `SEGREGATION_OF_DUTIES` or `PERMISSION_DENIED` before any write; no journal; remittance remains Submitted; a denied-attempt `ent.AuditEvent` records actor, claim version, command and reason; Accounts Manager security view shows the attempts; hiding the button in the UI is not relied on.

### SCT-10-C — Concurrent verification

- **Given** RM-HYP-0001 awaits approval and two approvers (`PR-ACC-MGR-01` and a second manager) press Approve within the same moment.
- **When** both `verifyCodRemittance` approvals reach the backend concurrently.
- **Then** exactly one transaction commits; the other returns `ALREADY_VERIFIED` with the winner's receipt; one journal exists; the unique `(remittanceId)` verification row and the unique reference reservation hold; the loser's attempt is audited but changes nothing.

### SCT-10-L — Lost response, successful server commit

- **Given** the Manager's approval committed JE-HYP-1001, but the response never reached the browser.
- **When** the browser retries with the same `requestId`, and separately a second manager issues the approval with a new `requestId`.
- **Then** the same-requestId retry returns the stored receipt and no new effect; the new-requestId call returns `ALREADY_VERIFIED` referencing the same receipt; still one journal; Accounts UI shows Verified after refresh and never shows a second success.

### SCT-10-X — Inconsistent evidence and duplicate receipt (abuse test)

- **Given** RM-HYP-0001 is Verified. The rider submits RM-HYP-0002 for 20,000 reusing `DEP-HYP-7781` and attaches the same receipt image. In a second case the statement line for a new remittance shows 120,000 while the rider claims 145,000.
- **When** `submitCodRemittance` runs for RM-HYP-0002, and later the operator prepares the 145,000 claim against the 120,000 line.
- **Then** RM-HYP-0002 is rejected with `DUPLICATE_DEPOSIT_REFERENCE`, referencing the original remittance; an exception appears in NF-13; no journal; for the mismatch, the verification can only be prepared for 120,000, the 25,000 remainder opens a discrepancy (NR-05, NF-13), the receipt image is shown as evidence only, and an image alone never produces Verified.

### SCT-10-R — Recovery after partial failure

- **Given** the verification committed in the ledger store, but the outbox consumer that updates Firestore failed and the notification provider timed out.
- **When** the outbox retry runs, and the operations team runs the reconciliation check between ledger and projection.
- **Then** the Firestore projection and the notification are delivered once (event id dedupe); no second journal; if the projection still disagrees after retries, a reconciliation exception is raised rather than the ledger being edited; rider and Accounts views converge to Verified.

### 8.1 What must agree after every test

| Layer | Must agree |
|---|---|
| Database constraints | Unique deposit reference per channel; unique verification per remittance; journal debits = credits; closed or posted lines immutable |
| Notifications | One `ntf.cod.remittance_verified` per verification event id; none for rejected attempts to the rider except a safe rejection message for the rider's own duplicate |
| Audit records | One event per accepted command and per denied attempt, with actor, grant version, reason, receipt reference |
| Journals | Exactly one posted journal per verified amount; reversal only through a linked compensating journal |
| Read models | NR-04, NF-03, NF-04, NF-01 totals equal sums derivable from posted lines (INV-20) |

## 9. Screen states

| Screen | App | State | Accessible error or status text (translation key) | Next action | Safe offline fallback |
|---|---|---|---|---|---|
| NR-04 COD remittance submission | PAR-R | Duplicate reference | "This deposit reference was already used. Check the receipt or contact Accounts." (`err.cod.duplicate_deposit`) | Edit reference, or open NR-05 to ask for review | Form saved as a local draft; submission is queued only as an unsent draft, never shown as Remitted until a receipt reference returns |
| NR-04 | PAR-R | Pending verification | "Submitted. Accounts has not confirmed this deposit yet." (`status.cod.pending_verification`) | Wait; view receipt reference | Last known status shown with an "as of" time and an offline marker |
| NR-05 COD discrepancy | PAR-R | Partial amount | "Accounts confirmed BDT 1,200.00. BDT 250.00 is still due." (`status.cod.partial`) | Respond with evidence; submit the remainder | Read-only last known state; responses queued as drafts |
| NF-04 COD deposit verification | ACC | Already verified | "This remittance was already verified by another user. Reference RC-HYP-9001." (`err.cod.already_verified`) | Open the original verification | Read-only cache; verification actions disabled offline with the reason shown |
| NF-04 | ACC | Self-approval blocked | "You prepared this verification. A different approver is required." (`err.sod.same_identity`) | Assign to another approver | Not applicable |
| NF-13 Reconciliation exceptions | ACC | Unmatched statement line | "This bank line matches no remittance." (`status.recon.unmatched`) | Link to a remittance or mark for investigation | Read-only |
| NA-05 Accounts oversight | ADM | Restricted | "You can see summary figures only." (`status.admin.limited`) | Request access through governance | Aggregates cached with timestamp |
| C-17 / C-20 | CUS | Paid in cash | "Paid in cash on delivery." No remittance data | None | Cached order state |

Layout expectations follow [ACCOUNTS_SCREENS](../design/screens/ACCOUNTS_SCREENS.md) and [RIDER_SCREENS](../design/screens/RIDER_SCREENS.md). Error text must be programmatically associated with its field, never colour-only, and readable at large text scale and in Bangla. A prototype toast that says "Recorded" is not evidence of a verified deposit (compare legacy S-09 note).

## 10. Links

| Kind | Link |
|---|---|
| Business rules | [BR-003, BR-013, BR-020, BR-026](../requirements/POLICY_DECISION_REGISTER.md), [BUSINESS_RULES](../requirements/BUSINESS_RULES.md) |
| API commands | [COMMANDS_PAYMENTS_AND_COD](../api/COMMANDS_PAYMENTS_AND_COD.md), [COMMANDS_LEDGER_AND_GOVERNANCE](../api/COMMANDS_LEDGER_AND_GOVERNANCE.md) |
| Entities | `ent.CodCollection`, `ent.CodRemittance`, `ent.ReconciliationItem`, `ent.ReconciliationException`, `ent.JournalEntry`, `ent.JournalLine`, `ent.RequestReceipt`, `ent.AuditEvent`, `ent.OutboxEvent`; see [FINANCIAL_DATA_MODEL](../database/FINANCIAL_DATA_MODEL.md) |
| Permissions | [AUTHORIZATION](../api/AUTHORIZATION.md), [USER_ROLES](../requirements/USER_ROLES.md) |
| Workflow and finance docs | [COD_PAYMENT_WORKFLOW](../payments/COD_PAYMENT_WORKFLOW.md), [COD_RECONCILIATION](../accounts-web/COD_RECONCILIATION.md), [FINANCIAL_LEDGER](../accounts-web/FINANCIAL_LEDGER.md), [COD_COLLECTION](../partner-app/COD_COLLECTION.md) |
| Tests | [FINANCIAL_TEST_CASES](../testing/FINANCIAL_TEST_CASES.md), [INTEGRATION_TEST_CASES](../testing/INTEGRATION_TEST_CASES.md) (SCT-10-N/P/C/L/X/R) |
| Runbooks | [COD_DISCREPANCY_RUNBOOK](../operations/COD_DISCREPANCY_RUNBOOK.md), [SETTLEMENT_AND_RECONCILIATION_RUNBOOK](../operations/SETTLEMENT_AND_RECONCILIATION_RUNBOOK.md) |
| Traceability | [REQUIREMENTS_TRACEABILITY_MATRIX](../requirements/REQUIREMENTS_TRACEABILITY_MATRIX.md) (FR-034, FR-041, FR-040, INV-11, INV-12) |
| Related scenarios | SC-03 (COD purchase), SC-09 (cash mismatch), SC-12 (rider payout while COD owed) |

## 11. Unapproved assumptions flagged

1. The evidence that counts as independent confirmation of a deposit (BR-003) is not decided; bank statement matching is an example only.
2. Whether partial remittances are allowed and how overdue cash is handled (BR-013) is not decided.
3. The dual-approval threshold (BR-020) and the 100,000 illustration are not policy.
4. The verification role set (`policy.cod.verifier_roles`) is not approved; Admin is deliberately excluded here because Admin must not hold balance authority.
5. Whether a receipt is issued to the customer for COD is not decided.
6. The chart-of-accounts names (`acct.*`) are PROPOSED until the financial data model is final.
7. No timing of projections, notifications or deadlines is approved.
8. Nothing here is implemented or tested, and a screen or toast that appears successful is never evidence that the deposit is verified or the ledger is correct.
