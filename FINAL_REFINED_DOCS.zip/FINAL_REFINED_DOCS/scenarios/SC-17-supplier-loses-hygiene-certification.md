# SC-17 — Supplier loses hygiene certification

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | PAR-Supplier, ADM, CUS, BE |
| Depends on | [Approval workflows](../admin-web/APPROVAL_WORKFLOWS.md), [ADR-014](../adr/014-subscription-agreement-and-meal-obligations.md) |
| Authoritative policies | BR-024 — PENDING |
| Invariants exercised | INV-06 |
| Status | Draft. HYPOTHETICAL. Nothing implemented. |

## 1. Domain situation
A kitchen's verified food-safety documentation expires. New orders may need blocking under approved policy while already-paid service commitments require managed resolution. Partner notice, an admin review queue, possible temporary hold, customer continuity support and financial liability must all be handled. The "verified" badge is never a client-side toggle — it reflects real document state, checked server-side.

## 2. Actors and permissions
Supplier (notified, can re-upload documents); Admin (`perm.admin.manage_continuity`, reviews and decides); customer (notified if affected).

## 3. Sample data (HYPOTHETICAL)
Hygiene certificate expiry date reached; 18 affected future obligations.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | Scheduled check detects `ent.ApplicationDocument` expiry |
| Command accepted | Kitchen's `verificationStatus` set to "documentation expired"; new orders blocked |
| Funds externally confirmed | N/A |
| Service delivered | Already-fulfilled obligations unaffected |
| Liability extinguished | Per Admin decision: hold, replacement kitchen (SC-07 pattern), or cancel+credit for the 18 affected obligations |

## 5. Sequence
```mermaid
sequenceDiagram
  participant Job as Scheduled job
  participant S as Supplier workspace
  participant A as Admin Web
  participant BE as Trusted backend
  Job->>BE: detect expired hygiene certificate
  BE->>BE: kitchen.verificationStatus = expired; block new orders
  BE->>S: notify supplier (re-upload required)
  BE->>A: incident raised (18 affected obligations)
  A->>BE: decide continuity (hold / replace / cancel+credit)
```

## 6. Commands, idempotency, transactions
The expiry check is idempotent (re-running it on an already-expired kitchen is a no-op); the continuity decision uses the same per-obligation resolution mechanism as SC-07, never a bulk silent edit.

## 7. Event and ledger trace
Same shape as SC-07 §7, applied to the 18 affected obligations if cancel+credit is chosen.

## 8. Acceptance tests (SCT-17-*)
SCT-17-N: expiry detected, new orders blocked, existing obligations resolved per Admin decision. SCT-17-P: the supplier cannot bypass the block by directly editing `verificationStatus` (no client write path exists for that field). SCT-17-C: a new order attempt races with the expiry detection — the order is rejected if the block landed first, accepted (then flagged for review) if it was already in flight. SCT-17-X: the supplier re-uploads a document that itself fails validation — status remains expired, no false re-verification. SCT-17-R: recovery after the incident-raising step fails to notify Admin — retried via the outbox, kitchen stays blocked in the meantime (fail-safe default).

## 9. Screen states
S-11/NS screens show "Documentation expired — re-upload required" with no way to self-restore verification; NA-03 (verification queue) shows the re-submitted documents for review.

## 10. Links
[BR-024](../requirements/POLICY_DECISION_REGISTER.md); related SC-07.

## 11. Unapproved assumptions
Whether the block is immediate or has a grace period is PENDING (BR-024).
