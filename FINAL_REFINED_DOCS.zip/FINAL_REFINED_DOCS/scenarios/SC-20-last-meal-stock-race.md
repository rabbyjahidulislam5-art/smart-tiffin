# SC-20 — Two customers compete for the last portion of a meal

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Scenario author S3 (documentation); business owner for BR-005, BR-022 to be identified |
| Purpose | Specify atomic stock reservation, explicit reservation expiry, server capacity authority and safe refund when a payment succeeds after the stock is gone, so that a kitchen is never oversold and no customer pays for a meal that cannot be made. |
| Applies to | CUS, PAR-S, ADM, ACC, BE |
| Depends on | [Scenario index and common conventions](SCENARIO_INDEX.md#common-conventions-for-all-scenarios), [time and cutoff policy](../architecture/TIME_AND_CUTOFF_POLICY.md), [commands: orders and subscriptions](../api/COMMANDS_ORDERS_AND_SUBSCRIPTIONS.md), [commands: payments and COD](../api/COMMANDS_PAYMENTS_AND_COD.md), [SSLCOMMERZ integration plan](../payments/SSLCOMMERZ_INTEGRATION_PLAN.md), [data consistency](../database/DATA_CONSISTENCY.md) |
| Authoritative policies | FR-046 (capacity, reservation, oversell protection); BR-005/DEC-007 (cancellation and refunds, PENDING); BR-022/DEC-032 (cutoff, PENDING); BR-003/DEC-005 (verification authority, PENDING). Reservation lifetime is the named parameter `policy.stock.reservation_ttl_minutes` with **no approved value**. |
| Design reference | C-05, C-07, C-08, C-09, NC-03, NC-14, S-04, NS-04, NS-05, NF-02, NF-13 |
| Commands | `createQuote`, `confirmQuote`, `placeOneTimeOrder`, `reserveStock`, `releaseStock`, `initiatePayment`, `handleGatewayNotification`, `validateGatewayTransaction`, `cancelOrder`, `initiateRefund`, `recordRefundResult`, `saveCapacity` |
| Invariants exercised | INV-01, INV-04, INV-05, INV-06, INV-17, INV-18, INV-20 |
| Status | Draft for review. Nothing implemented, tested or approved. All BDT figures are HYPOTHETICAL; the gateway is planned, not connected. |

## 1. Domain situation

**Restated.** Kitchen K1 has exactly one portion left of "Special Khichuri set" (variant V-HYP-2001) for dinner on 2026-11-05. Customer A and customer B both open checkout and both see "1 left". They proceed at nearly the same moment. Payment confirmations come back asynchronously from the gateway, possibly after a reservation has expired. The server alone decides who gets the portion; a client count is advisory. If a payment succeeds for an order whose stock is no longer available, the money is returned safely and the customer is told clearly.

**Refined.**

1. **Stock authority.** `ent.KitchenCapacity` is the single authority for each kitchen, slot and date. Available = capacity - committed - held. The browse count is a hint.
2. **Reservation.** `reserveStock` runs inside the same transaction that creates the order in PendingPayment. It creates an `ent.StockReservation` (Held) with an explicit `expiresAt`. A reservation is released by expiry, by payment failure/cancellation, or by order cancellation; it is committed when payment is verified and the order is confirmed.
3. **No hold without an expiry.** A held reservation without an expiry is invalid state. The lifetime is `policy.stock.reservation_ttl_minutes` (PENDING value); it must be evaluated against canonical timestamps, not the device clock.
4. **Late success.** If the gateway later reports success for an order whose reservation expired and whose stock has since been committed to someone else, the order is not confirmed. The verified money is booked, then returned through a refund (cash refund is the proposed default for this case because the customer received nothing; BR-005 approval is still required before it is enabled). If stock is still free at that moment, the server may re-reserve and confirm instead (policy `policy.stock.revive_expired_reservation`, PENDING, default disabled).
5. **Supplier consistency.** Menu availability (S-04), forecast (NS-04) and the order list never show more committed portions than capacity.

**PENDING policies.** BR-005 (refund versus credit and who approves), BR-022 (the cutoff after which no reservation is accepted), `policy.stock.reservation_ttl_minutes`, `policy.stock.revive_expired_reservation`, BR-009 (whether a gateway fee on a refunded payment is borne by the platform; treated here as a platform expense line for arithmetic only).

## 2. Actors, role claims and permissions outline

| Actor | Role claim | Permitted | Notes |
|---|---|---|---|
| Customer A | `role.customer` + ownership of own order | Reserve, pay, cancel own order | |
| Customer B | `role.customer` + ownership of own order | Same; sees "unavailable" when the last portion is held or sold | |
| Supplier K1 | `role.supplier` + `kitchenId = K1` | `saveCapacity`, `setSlotAvailability` for own kitchen; read reservations as counts | **Cannot** read customer identities for held reservations; cannot release a customer's hold |
| Rider | `role.rider` | None; no assignment exists for the failed order | |
| Admin (ops) | `role.admin.ops` | View capacity and exception queue; cannot change money | |
| Accounts Operator | `role.acc.operator` | View unmatched/late payments (NF-13), prepare refund | |
| Accounts Manager | `role.acc.manager` | Approve refund within limit (BR-020) | Maker not equal to checker (INV-15) |
| System | `role.system` | Expiry sweep, `releaseStock`, auto-refund initiation per policy | |

Denied actor for the abuse test: **Customer B** (or any customer) calling `releaseStock` or `cancelOrder` for A's reservation or order in order to free the last portion; and **Supplier K1** calling `saveCapacity` for another kitchen.

## 3. Sample data (HYPOTHETICAL BDT; integers in paisa)

| Item | Value | Display |
|---|---|---|
| Meal / variant | Special Khichuri set, V-HYP-2001, price version PV-201 | |
| Capacity for 2026-11-05 `slot.dinner` | 1 remaining (committed 0, held 0) | |
| Food price | 25000 | BDT 250.00 |
| Delivery fee (BR-007 PENDING) | 3000 | BDT 30.00 |
| Order total per customer (quote) | **28000** | **BDT 280.00** |
| Customer A order | ORD-HYP-2001, quote Q-HYP-2001, payment PAY-HYP-2001 | |
| Customer B order | ORD-HYP-2002, quote Q-HYP-2002, payment PAY-HYP-2002 | |
| Reservation lifetime | `policy.stock.reservation_ttl_minutes` (no value; the example uses "T + ttl") | |
| Gateway fee on a refunded payment (hypothetical, platform expense) | 560 | BDT 5.60 |

Integer check: 25000 + 3000 = 28000 for both orders (INV-18).

## 4. Decision table

### 4.1 Steps (main path and late-success branch)

| # | Actors | Role claims | Service trigger | Source record | Precondition | Expected change | External dependency | Reversible? |
|---|---|---|---|---|---|---|---|---|
| 1 | A | `role.customer` | `placeOneTimeOrder` (includes `reserveStock`) | `ent.KitchenCapacity` (free 1), Q-HYP-2001 | Quote valid, slot open per BR-022 | ORD-HYP-2001 PendingPayment; reservation SR-A Held until T+ttl; free 0 | None | Yes (expiry, cancel) |
| 2 | B | `role.customer` | `placeOneTimeOrder` | Same capacity row | Request reaches boundary after step 1 commits | Rejected `STOCK_UNAVAILABLE`; no order, no reservation | None | Not applicable |
| 3 | A | `role.customer` | `initiatePayment` | ORD-HYP-2001 | Order PendingPayment and reservation unexpired | `ent.PaymentIntent` Initiated, redirect URL returned | Gateway (planned SSLCOMMERZ) | Intent expires |
| 4 | Gateway / system | `role.system` | `handleGatewayNotification` then `validateGatewayTransaction` | `ent.GatewayEvent`, `ent.GatewayVerification` | Server-to-server validation returns valid and amount 28000 equals quote | Payment Verified; order Confirmed; reservation Committed; journal J-1 | Gateway validation API | No (refund only) |
| 5 | Supplier | `role.supplier` | Read | Forecast projection | Step 4 committed | S-04 shows 0 left; NS-04 shows 1 portion | None | Not applicable |
| 6 (late branch) | System | `role.system` | Expiry sweep | SR-A Held, expired | T + ttl elapsed without verified payment | SR-A Released; free 1; order ORD-HYP-2001 Expired | None | Yes |
| 7 (late branch) | B | `role.customer` | `placeOneTimeOrder` then payment | Capacity free 1 | Step 6 committed | ORD-HYP-2002 reserved, paid, Confirmed, Committed | Gateway | No |
| 8 (late branch) | Gateway / system | `role.system` | `handleGatewayNotification` for PAY-HYP-2001 (success arrives late) | Order ORD-HYP-2001 Expired, capacity free 0 | Validation valid, amount 28000 | Money booked (J-2), order not confirmed, cancelled for stock (J-3); refund proposed | Gateway | Refund is the compensating path |
| 9 (late branch) | Accounts Operator then Manager | `role.acc.operator`, `role.acc.manager` | `initiateRefund` then `recordRefundResult` | `ent.Refund`, original payment | Policy enabled; approval within limit | Refund Pending then Refunded after provider confirmation (J-4) | Gateway refund API | No |

### 4.2 Five observations and interface update moments

| Observation | Meaning | Customer A | Customer B | Supplier | Rider | Admin | Accounts |
|---|---|---|---|---|---|---|---|
| Request received | `placeOneTimeOrder` or gateway notification arrives | Progress state | Progress state; later "just sold out" | Nothing | Nothing | Nothing | Nothing |
| Command accepted | Reservation committed (A) or `STOCK_UNAVAILABLE` returned (B) | Order shows "Awaiting payment, held until <time>" | Message at response time; meal shows unavailable | Capacity projection shows held 1 after outbox | Nothing | Capacity view updated | Nothing |
| Funds externally confirmed | `validateGatewayTransaction` valid | Order Confirmed, receipt available (C-09 success only now, never at redirect) | Nothing in main path | Order appears in queue (S-06) and forecast | Assignment can be offered later | Order monitor updated | Payment in reconciliation (NF-02); J-1 visible |
| Service delivered | Delivery completed (outside this scenario's trace; see WF-A) | Delivered status | Not applicable | Earning recognised at event (BR-010 PENDING) | Earning recognised (BR-011 PENDING) | Order closed | Recognition journal |
| Liability extinguished | Prepaid obligation recognised on delivery; in the late branch, refund confirmed | Branch: refund status Refunded only after provider confirmation (NC-17) | Normal | Nothing | Nothing | Exception closed | LA-250 extinguished by J-4, exception resolved |

## 5. Sequence

```mermaid
sequenceDiagram
    autonumber
    actor A as Customer A
    actor B as Customer B
    participant AppA as Customer App A
    participant AppB as Customer App B
    participant BE as Trusted Command Boundary
    participant Cap as Capacity and Reservation
    participant GW as Payment Gateway
    participant Led as Ledger Store
    participant Sup as Supplier Workspace
    participant Rid as Rider Workspace
    participant Adm as Admin Web
    participant Acc as Accounts Web
    A->>AppA: Place order, last portion shown
    B->>AppB: Place order, last portion shown
    AppA->>BE: placeOneTimeOrder requestId RA
    AppB->>BE: placeOneTimeOrder requestId RB
    BE->>Cap: reserveStock for A, atomic compare and set
    Cap-->>BE: Held until T plus ttl, free 0
    BE-->>AppA: Order awaiting payment
    BE->>Cap: reserveStock for B
    Cap-->>BE: Unavailable
    BE-->>AppB: STOCK_UNAVAILABLE, choose another meal
    AppA->>BE: initiatePayment ORD A
    BE-->>AppA: Redirect to gateway
    Note over A,GW: Customer A is slow. Reservation expires.
    BE->>Cap: Expiry sweep releases reservation A
    B->>AppB: Retry order
    AppB->>BE: placeOneTimeOrder RB2
    BE->>Cap: reserveStock for B succeeds
    BE->>GW: initiatePayment B
    GW-->>BE: handleGatewayNotification B
    BE->>GW: validateGatewayTransaction B
    BE->>Led: Post J-1 for B, commit reservation
    GW-->>BE: handleGatewayNotification A, late
    BE->>GW: validateGatewayTransaction A
    BE->>Led: Post receipt, cancel for stock, refund payable
    BE-->>AppA: Order not confirmed, refund started
    Led-->>Acc: Late payment exception and refund queue
    BE-->>Sup: Forecast shows B only
    Note over Rid: No assignment for A. B assignment follows WF-A.
    BE-->>Adm: Capacity and exception view
```

**Textual sequence.** Both orders race to `reserveStock`; the atomic compare-and-set gives the portion to A and rejects B. A leaves the gateway page open, the reservation expires, B retries and wins, pays and is confirmed. A's gateway success arrives late: it validates, the money is booked, the order is cancelled for lack of stock, and a refund request is raised for Accounts approval. No portion is ever sold twice.

**Human approval checkpoints.** (1) Accounts Manager approves the refund within the BR-020 limit (the preparer is not the approver). (2) A customer-support contact is offered but is not required for the system to protect stock. (3) Changing `policy.stock.*` parameters requires a policy version (NA-02).

## 6. Commands, idempotency and transaction boundaries

| Command | Stable logical operation id | Atomic boundary | Immutable event | Duplicate / failure handling |
|---|---|---|---|---|
| `placeOneTimeOrder` / `reserveStock` | `op.reserveStock.<orderId>` | Order row + reservation row + capacity update (compare-and-set on version) + receipt in one transaction | `StockReserved` (before free, after free, expiresAt) | Same request id returns the same reservation; the expiry is **not** extended by a retry |
| `releaseStock` | `op.releaseStock.<reservationId>.<reason>` | Reservation state + capacity increment | `StockReleased` | Releasing a Committed or already Released reservation is a no-op; a caller who does not own the order is denied |
| `handleGatewayNotification` | `op.gwevent.<gatewayTransactionId>.<eventId>` | Store raw event (insert if absent) + enqueue validation | `GatewayEventReceived` | Replays of the same event id create no second effect |
| `validateGatewayTransaction` | `op.validate.<gatewayTransactionId>` | Verification record + payment state + journal + order/stock transition | `PaymentVerified` | Exactly one verification result per transaction id (INV-05) |
| `cancelOrder` (system, reason stock) | `op.cancelOrder.<orderId>.stock` | Order state + reclass journal | `OrderCancelledForStock` | Idempotent |
| `initiateRefund` / `recordRefundResult` | `op.refund.<paymentId>.<refundSeq>` / `op.refundresult.<providerRefundId>` | Refund row + journal | `RefundInitiated`, `RefundSettled` | A repeated provider message does not repeat J-4 |

Reconciliation of duplicate or failed external messages is independent of the callback path: a periodic comparison of gateway settlement records against `ent.GatewayVerification` creates a `ent.ReconciliationException` for any transaction without a matching order outcome. Pending (awaiting validation), retry (the same operation id after failure) and compensating entry (J-3 and J-4 reversing the effect of J-2) are distinct states; the refund status is never inferred from the order status. No mutable balance field exists: refund exposure is the sum of LA-250 lines for the payment.

## 7. Event and ledger trace

| Seq | Event | Journal | INV |
|---|---|---|---|
| 1 | `StockReserved` SR-A, free 1 to 0 | none | none (not money) |
| 2 | `StockReserveRejected` for B | none | none |
| 3 | `StockReleased` SR-A by expiry | none | none |
| 4 | `PaymentVerified` PAY-HYP-2002 (B) | J-1 | INV-01, 05, 06, 18 |
| 5 | `PaymentVerified` PAY-HYP-2001 (A, late) | J-2 | INV-01, 05 |
| 6 | `OrderCancelledForStock` ORD-HYP-2001 | J-3 | INV-17 |
| 7 | `RefundSettled` after provider confirmation | J-4 | INV-01, 17 |

| Journal | Account | Debit (paisa) | Credit (paisa) |
|---|---|---|---|
| J-1 (B verified) | LA-110 Gateway clearing | 28000 | |
| | LA-200 Customer prepaid obligation | | 28000 |
| J-2 (A verified, late) | LA-110 Gateway clearing | 28000 | |
| | LA-200 Customer prepaid obligation | | 28000 |
| J-3 (A cancelled for stock) | LA-200 Customer prepaid obligation | 28000 | |
| | LA-250 Refunds payable | | 28000 |
| J-4 (A refund confirmed by provider) | LA-250 Refunds payable | 28000 | |
| | LA-110 Gateway clearing | | 28000 |
| J-5 (hypothetical gateway fee retained on the refunded payment, BR-009/BR-005 PENDING) | LA-400 Gateway fees | 560 | |
| | LA-110 Gateway clearing | | 560 |

Every journal balances (INV-01). Net for A: receipts 28000, refund 28000, plus fee 560 borne by the platform (hypothetical); customer net zero. LA-200 retains only B's 28000 until delivery. After B's delivery the recognition journal follows WF-A (not repeated here).

## 8. Acceptance tests (Given/When/Then; planned, none executed)

| ID | Type | Given | When | Then |
|---|---|---|---|---|
| SCT-20-N | Normal | One free portion; A and B each have a valid 28000 quote | Both submit `placeOneTimeOrder` within the same instant, A commits first, A pays and gateway validates | A holds the portion, then Confirmed with Committed reservation; B receives `STOCK_UNAVAILABLE` and an alternative-meal action; capacity never below zero; S-04 shows 0 left; one order confirmed; J-1 exists once; notifications: A order confirmed, supplier new order, B none beyond the in-screen message. |
| SCT-20-P | Insufficient permission / abuse | A holds the reservation | B calls `releaseStock` or `cancelOrder` with A's ids; supplier K1 calls `saveCapacity` for kitchen K2 | Both denied with no state change and `AuthorizationDenied` audit events; capacity and reservation unchanged. |
| SCT-20-C | Concurrent update | Free = 1 | 50 parallel `reserveStock` attempts for different customers | Exactly one succeeds; others get `STOCK_UNAVAILABLE`; committed + held <= capacity at every observable instant; no negative free count. |
| SCT-20-L | Lost response, committed effect | A's `placeOneTimeOrder` committed, response lost | A retries with the same `requestId` | Same reservation and expiry returned; no second reservation; capacity unchanged; one receipt. |
| SCT-20-X | Inconsistent third-party response | Gateway notification for A claims valid but amount 22000 differs from quote 28000, or references the order of B | `validateGatewayTransaction` | Order is not confirmed; payment marked Unknown or mismatch with an exception in NF-13; reservation follows normal expiry; no journal posted until the amount is resolved; customer sees "payment under verification" (not success). A browser redirect alone never confirms. |
| SCT-20-R | Recovery after partial failure | Late success J-2 and J-3 posted; the process crashes before `initiateRefund` | Recovery job runs | Refund candidate is re-derived from LA-250 lines and the unrefunded payment; one refund record is created; after provider confirmation J-4 posts once; sum of LA-250 for PAY-HYP-2001 is zero; order shows Cancelled with the reason in the customer's language. |

State constraints that must agree: capacity row = reservations (Held + Committed); order state = payment state = reservation state; LA-200 for B = quote total; refund state = LA-250 balance; audit events carry the same order id; notifications are deduplicated per operation id.

## 9. Screen states

| Screen | Mobile | Desktop | Accessible error text and next action | Offline fallback |
|---|---|---|---|---|
| C-05 / NC-03 meal | "1 left" label with the note "availability is confirmed when you place the order" | Same | Sold-out: "This meal is no longer available for that day. Choose another meal." Action: See similar meals | Last known availability marked with its age |
| C-08 / NC-14 checkout | Countdown text showing the hold end time in words (not colour only) | Side summary | "Your hold has ended. We are checking whether the meal is still available." Actions: Check again, Choose another meal | Cannot place; reason caption |
| C-09 payment result | States: Awaiting confirmation, Confirmed, Not confirmed (refund started). Success appears only after server validation | Same | "We received your payment but the meal sold out. A refund has started and you will be notified when it is confirmed." Action: View refund (NC-17) | Cached state with time stamp |
| S-04 / NS-05 supplier | Count with held and committed shown separately | Table with filters | "Stock changed by another order." Action: Refresh | Cached, labelled |
| NF-13 exceptions (Accounts) | Not primary on mobile | Table: late payment, amount, order, reason, reviewer | "Payment received for an order that is not confirmed" Action: Approve refund | Read-only |

## 10. Links

[Common conventions](SCENARIO_INDEX.md#common-conventions-for-all-scenarios) · [Scenario index](SCENARIO_INDEX.md) · [Time and cutoff policy](../architecture/TIME_AND_CUTOFF_POLICY.md) · [Orders and subscriptions commands](../api/COMMANDS_ORDERS_AND_SUBSCRIPTIONS.md) · [Payments and COD commands](../api/COMMANDS_PAYMENTS_AND_COD.md) · [Delivery commands](../api/COMMANDS_DELIVERY.md) · [SSLCOMMERZ integration plan](../payments/SSLCOMMERZ_INTEGRATION_PLAN.md) · [Payment architecture](../payments/PAYMENT_ARCHITECTURE.md) · [Payment reconciliation](../accounts-web/PAYMENT_RECONCILIATION.md) · [Refunds and adjustments](../accounts-web/REFUNDS_AND_ADJUSTMENTS.md) · [Data consistency](../database/DATA_CONSISTENCY.md) · [Financial data model](../database/FINANCIAL_DATA_MODEL.md) · [Policy decision register](../requirements/POLICY_DECISION_REGISTER.md) · [Gateway outage runbook](../operations/GATEWAY_OUTAGE_RUNBOOK.md) · [Financial test cases](../testing/FINANCIAL_TEST_CASES.md) · Related: [SC-13](SC-13-gateway-callback-replay.md), [SC-14](SC-14-refund-partial-fulfilment.md), [WF-A and WF-I](WORKFLOWS_A_TO_J.md)

## 11. Unapproved assumptions flagged

1. Reservation lifetime, the optional revival of an expired reservation and the cutoff for accepting reservations have no approved value.
2. Cash refund for the late-success case is PROPOSED; credit or other remedy needs BR-005 approval.
3. Treatment of the gateway fee on a refunded payment is hypothetical and not approved (BR-009).
4. The hybrid operational/ledger store split is PROPOSED; atomicity across stores relies on the outbox and idempotent posting described in section 6.
5. The planned SSLCOMMERZ behaviour (validation API, notification fields) must be verified against current official documentation before implementation; nothing here asserts a live integration.
