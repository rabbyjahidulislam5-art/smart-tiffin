# Scenario index

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation lead (primary agent, integrating authors S1/S2/S3) |
| Purpose | Index all 25 end-to-end scenarios and the 10 workflows, with their apps, policy dependencies, invariants and primary commands. |
| Status | All 25 scenario files exist. See each file for full detail; this is a navigation aid, not a duplicate. |

| ID | Title | File | Apps | BR/DEC | INV exercised | Primary commands |
|---|---|---|---|---|---|---|
| SC-01 | Monthly prepaid service before fulfilment | [SC-01-monthly-prepaid-service.md](SC-01-monthly-prepaid-service.md) | CUS, PAR-S, ACC | BR-002, BR-006, BR-009, BR-010 | 01,06,09,13,18 | confirmQuote, recognizeSupplierEarning, skipMeals |
| SC-02 | Weekly plan, uneven quantities | [SC-02-weekly-uneven-quantities.md](SC-02-weekly-uneven-quantities.md) | CUS, PAR-S | BR-001, BR-002, BR-007 | 01,18 | saveSubscriptionSchedule, generateMealObligations |
| SC-03 | Breakfast-only COD purchase | [SC-03-breakfast-cod-purchase.md](SC-03-breakfast-cod-purchase.md) | CUS, PAR-R, PAR-S, ACC | BR-010,011,012 | 09,10,11,19 | placeOneTimeOrder, recordCodCollection, verifyCodRemittance |
| SC-04 | Attempted double skip credit | [SC-04-double-skip-credit.md](SC-04-double-skip-credit.md) | CUS | BR-006 | 04,08 | skipMeals |
| SC-05 | Change to more expensive dinner | [SC-05-change-to-expensive-dinner.md](SC-05-change-to-expensive-dinner.md) | CUS | BR-006, BR-017 | 17,18 | quoteScheduleChange, confirmScheduleChange |
| SC-06 | Change to cheaper lunch | [SC-06-change-to-cheaper-lunch.md](SC-06-change-to-cheaper-lunch.md) | CUS, PAR-S | BR-006,017 | 08,17 | quoteScheduleChange, issueCredit |
| SC-07 | Kitchen stops accepting orders | [SC-07-kitchen-stops-accepting-orders.md](SC-07-kitchen-stops-accepting-orders.md) | CUS, PAR-S, ADM, ACC | BR-024 | 06,09 | setSlotAvailability, cancelSubscription |
| SC-08 | Rider replacement after delay | [SC-08-rider-replacement-after-delay.md](SC-08-rider-replacement-after-delay.md) | PAR-R, PAR-S, CUS, ADM | BR-011 | 19 | reassignDelivery |
| SC-09 | Rider COD cash mismatch | [SC-09-rider-cod-cash-mismatch.md](SC-09-rider-cod-cash-mismatch.md) | PAR-R, ACC, CUS | BR-013,020 | 10,11 | recordCodCollection, resolveCodDiscrepancy |
| SC-10 | COD deposit duplicate receipt | [SC-10-cod-deposit-duplicate-receipt.md](SC-10-cod-deposit-duplicate-receipt.md) | PAR-R, ACC | BR-003,013,020,012,026 | 01,02,03,04,10,11,12,15,20 | verifyCodRemittance |
| SC-11 | Supplier withdrawal | [SC-11-supplier-withdrawal.md](SC-11-supplier-withdrawal.md) | PAR-S, ACC | BR-014 | 09,14,15 | requestPayout, approvePayout |
| SC-12 | Rider payout while COD owed | [SC-12-rider-payout-while-cod-owed.md](SC-12-rider-payout-while-cod-owed.md) | PAR-R, ACC | BR-011,026 | 10,14 | requestPayout |
| SC-13 | Gateway callback replay | [SC-13-gateway-callback-replay.md](SC-13-gateway-callback-replay.md) | CUS, ACC | BR-003 | 04,05 | handleGatewayNotification |
| SC-14 | Refund during partial fulfilment | [SC-14-refund-partial-fulfilment.md](SC-14-refund-partial-fulfilment.md) | CUS, ACC | BR-005,006,015 | 06,17 | initiateRefund |
| SC-15 | Period close, late event | [SC-15-period-close-late-event.md](SC-15-period-close-late-event.md) | ACC | BR-020 | 16 | closePeriod |
| SC-16 | Admin finance override attempt | [SC-16-admin-finance-override-attempt.md](SC-16-admin-finance-override-attempt.md) | ADM, ACC | BR-020 | 15 | approvePayout |
| SC-17 | Supplier loses hygiene certification | [SC-17-supplier-loses-hygiene-certification.md](SC-17-supplier-loses-hygiene-certification.md) | PAR-S, ADM, CUS | BR-024 | 06 | setSlotAvailability |
| SC-18 | Bilingual, narrow device | [SC-18-bilingual-narrow-device.md](SC-18-bilingual-narrow-device.md) | CUS | — | — | n/a (UI state) |
| SC-19 | Address outside zone | [SC-19-address-outside-zone.md](SC-19-address-outside-zone.md) | CUS | — | — | saveAddress, createQuote |
| SC-20 | Last meal stock race | [SC-20-last-meal-stock-race.md](SC-20-last-meal-stock-race.md) | CUS, PAR-S | — | — | reserveStock |
| SC-21 | Missing customer after arrival | [SC-21-missing-customer-after-arrival.md](SC-21-missing-customer-after-arrival.md) | PAR-R, CUS | BR-011, DEC-014 | 19 | reportDeliveryFailure |
| SC-22 | Multi-kitchen custom schedule | [SC-22-multi-kitchen-custom-schedule.md](SC-22-multi-kitchen-custom-schedule.md) | CUS, PAR-S, ACC | BR-021 | 18 | saveSubscriptionSchedule |
| SC-23 | Promotional vs service credit | [SC-23-promotional-vs-service-credit.md](SC-23-promotional-vs-service-credit.md) | CUS | BR-006,008,019,025 | 07,08 | consumeCredit, voidCredit |
| SC-24 | Adjustment after external payout | [SC-24-adjustment-after-external-payout.md](SC-24-adjustment-after-external-payout.md) | ACC, PAR-S | BR-020 | 02,15 | requestAdjustment, approveAdjustment |
| SC-25 | Role switching, one partner device | [SC-25-role-switching-partner-device.md](SC-25-role-switching-partner-device.md) | PAR-S, PAR-R | BR-023 | — | workspace-scoped commands |

## Workflows A–J

See [WORKFLOWS_A_TO_J.md](WORKFLOWS_A_TO_J.md) for the full ten-workflow catalogue (one-time online order, one-time COD order, monthly subscription, weekly subscription, meal skip, upgrade/downgrade, supplier payout, rider payout/COD settlement, refund/dispute, rider reassignment).

## Counts

25 scenarios, 10 workflows, 4 applications represented, 26 business rules referenced across the set, 20 financial invariants exercised at least once.
