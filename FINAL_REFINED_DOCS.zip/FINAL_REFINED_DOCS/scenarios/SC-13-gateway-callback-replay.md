# SC-13 — Gateway callback replay and customer redirect

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | CUS, BE, ACC |
| Depends on | [SSLCOMMERZ integration plan](../payments/SSLCOMMERZ_INTEGRATION_PLAN.md), [api/COMMANDS_PAYMENTS_AND_COD.md](../api/COMMANDS_PAYMENTS_AND_COD.md) |
| Authoritative policies | BR-003 (context) |
| Invariants exercised | INV-04, INV-05 |
| Status | Draft. HYPOTHETICAL. Nothing implemented; no real gateway connected. |

## 1. Domain situation
A hosted payment page redirects the user before server verification completes; duplicate IPN notifications arrive late and out of order. The app shows pending verification without premature activation. Only server-to-server validation confirms payment. Replayed callbacks must never create multiple orders, credits or journals. Handle: browser closed before redirect, callback timeout, eventual reconciliation.

## 2. Actors and permissions
Customer (passive, sees status only); Gateway (untrusted until validated); Trusted backend (sole authority).

## 3. Sample data (HYPOTHETICAL)
Quote 50,000 paisa; gateway transaction id `TXN-HYP-9001`.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | Browser redirect to success URL (cosmetic only) |
| Command accepted | `handleGatewayNotification` persists the raw event |
| Funds externally confirmed | `validateGatewayTransaction` confirms amount/currency/status match |
| Service delivered | N/A yet |
| Liability extinguished | Order/subscription activates; journal posted exactly once per `TXN-HYP-9001` |

## 5. Sequence
```mermaid
sequenceDiagram
  participant C as Customer App
  participant GW as Gateway (sandbox)
  participant BE as Trusted backend
  C->>GW: complete payment
  GW-->>C: browser redirect (success) — NOT trusted
  GW->>BE: IPN #1 (TXN-HYP-9001)
  BE->>BE: validateGatewayTransaction -> Verified, journal posted
  GW->>BE: IPN #2 (duplicate, same TXN-HYP-9001)
  BE-->>GW: 200 OK, no new effect (deduped)
```

## 6. Commands, idempotency, transactions
`handleGatewayNotification` keyed by `gwevt:{gateway}:{eventKey}` (INV-05); `validateGatewayTransaction` posts at most one journal per gateway transaction id.

## 7. Event and ledger trace
One journal only: Dr cash_and_clearing 50,000 / Cr customer_prepaid_obligation 50,000, regardless of how many IPNs arrive.

## 8. Acceptance tests (SCT-13-*)
SCT-13-N: IPN arrives once, order activates, one journal. SCT-13-P: a forged IPN without valid signature is rejected and never applied. SCT-13-C: two IPNs for the same transaction arrive within milliseconds — one commits, one deduped. SCT-13-L: customer closes the browser before redirect — IPN alone still activates the order when it arrives. SCT-13-X: IPN reports an amount that doesn't match the quote — `amount_mismatch`, order stays pending, Accounts notified. SCT-13-R: IPN delayed by an hour — order correctly activates on arrival, not timed out into a false failure.

## 9. Screen states
C-09/NC-14: shows "Awaiting confirmation" immediately after redirect, never a premature success; updates to "Confirmed" only on the backend's actual state change (via outbox-driven read model refresh).

## 10. Links
[BR-003](../requirements/POLICY_DECISION_REGISTER.md); [SSLCOMMERZ_INTEGRATION_PLAN](../payments/SSLCOMMERZ_INTEGRATION_PLAN.md); related SC-20.

## 11. Unapproved assumptions
Exact SSLCOMMERZ IPN field names and signature mechanism are marked "to verify" in the integration plan; this scenario describes the required behaviour, not a confirmed API contract.
