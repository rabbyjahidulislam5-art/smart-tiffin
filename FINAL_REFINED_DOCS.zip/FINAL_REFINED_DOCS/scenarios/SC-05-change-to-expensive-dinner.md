# SC-05 — Change to a more expensive dinner

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | CUS, BE |
| Depends on | [ADR-009](../adr/009-quote-and-price-snapshots.md), [Customer credits](../customer-app/CUSTOMER_CREDITS.md) |
| Authoritative policies | BR-006, BR-017 — PENDING |
| Invariants exercised | INV-17, INV-18 |
| Status | Draft. HYPOTHETICAL figures. Nothing implemented. |

## 1. Domain situation
A customer who prepaid for a basic dinner (18,000 paisa) chooses a premium replacement (26,000 paisa) before cutoff. A fresh quotation preserves the historic price and the latest kitchen price; eligible credit is applied; the remaining additional amount requires explicit payment confirmation. If payment fails, the old meal stays valid, or a clearly defined reserved transition applies — never both items fulfilled.

## 2. Actors and permissions
Customer (own obligation, `perm.sub.replace_own`).

## 3. Sample data (HYPOTHETICAL)
Old price 18,000; new price 26,000; difference 8,000 paisa (80.00 BDT) payable.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | `quoteScheduleChange` for a replacement |
| Command accepted | Adjustment quote created: difference 8,000, direction "charge" |
| Funds externally confirmed | Additional 8,000 verified via gateway/COD top-up |
| Service delivered | N/A yet (future obligation) |
| Liability extinguished | Obligation's price snapshot updated to 26,000 only after the 8,000 is confirmed |

## 5. Sequence
```mermaid
sequenceDiagram
  participant C as Customer App
  participant BE as Trusted backend
  C->>BE: quoteScheduleChange(replace, new meal)
  BE-->>C: adjustmentQuote { direction: charge, amount: 8000 }
  C->>BE: pay 8000 (gateway)
  alt payment succeeds
    C->>BE: confirmScheduleChange(adjustmentQuoteId)
    BE->>BE: obligation updated to new meal, old meal never fulfilled
  else payment fails
    BE->>BE: obligation stays on the old meal; no change applied
  end
```

## 6. Commands, idempotency, transactions
`confirmScheduleChange` is unique per `adjustmentQuoteId`; it is only called after the additional payment is verified, never before, preventing a half-applied state.

## 7. Event and ledger trace
Journal (on confirmed change): Dr cash_and_clearing 8,000 / Cr customer_prepaid_obligation 8,000 (the additional prepayment, now covering the upgraded obligation).

## 8. Acceptance tests (SCT-05-*)
SCT-05-N: upgrade confirmed only after the extra 8,000 is verified; obligation shows the new meal. SCT-05-P: a different customer cannot quote a change for this obligation. SCT-05-C: two devices attempt the upgrade concurrently — one commits. SCT-05-L: payment confirmation response lost, client retries — one charge, one change. SCT-05-X: gateway reports an inconsistent status for the top-up — obligation stays on the old meal, change not applied. SCT-05-R: recovery after the payment-verified event but before `confirmScheduleChange` is called — outbox/consumer flow completes it idempotently, not left in limbo.

## 9. Screen states
NC-10 (replacement quotation): shows old price, new price, and the exact payable difference before any charge; after a failed payment, shows the old meal as still confirmed.

## 10. Links
[BR-006, BR-017](../requirements/POLICY_DECISION_REGISTER.md); [ADR-009](../adr/009-quote-and-price-snapshots.md); related SC-06.

## 11. Unapproved assumptions
The exact substitution eligibility window and fee treatment are PENDING (BR-017).
