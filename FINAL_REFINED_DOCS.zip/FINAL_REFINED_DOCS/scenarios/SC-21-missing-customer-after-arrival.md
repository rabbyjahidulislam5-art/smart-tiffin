# SC-21 — Missing customer after rider arrival

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | PAR-Rider, CUS, BE |
| Depends on | [Rider modules](../partner-app/RIDER_MODULES.md), [api/COMMANDS_DELIVERY.md](../api/COMMANDS_DELIVERY.md) |
| Authoritative policies | BR-011, DEC-014 — PENDING |
| Invariants exercised | INV-19 |
| Status | Draft. HYPOTHETICAL. Nothing implemented. |

## 1. Domain situation
A rider arrives but cannot reach the customer. A visible escalation path with privacy-preserving call/message, time-stamped evidence, a policy waiting time, safe return instructions, and support escalation are required. Failed delivery is distinct from fulfilment for COD, supplier compensation, rider compensation and customer credits.

## 2. Actors and permissions
Rider (`perm.delivery.report_failure`); Customer (notified); Admin (sees the incident if escalated).

## 3. Sample data (HYPOTHETICAL)
Waiting policy (illustrative) 10 minutes; order value 22,000 paisa COD.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | Rider attempts contact (masked call/message) |
| Command accepted | `reportDeliveryFailure` after the waiting period elapses |
| Funds externally confirmed | N/A — no COD collected |
| Service delivered | Not delivered |
| Liability extinguished | Supplier earning recognised per its own milestone (handoff may already have occurred); rider compensation per BR-011's failed-delivery rule (not simply zero by default — explicit policy needed); no COD collection recorded |

## 5. Sequence
```mermaid
sequenceDiagram
  participant R as Rider
  participant BE as Trusted backend
  participant C as Customer
  R->>BE: contact attempt (masked)
  R->>C: call/message
  Note over R: waits policy.delivery.missing_customer_wait_minutes
  R->>BE: reportDeliveryFailure(reason: customer_unreachable)
  BE->>BE: order -> Failed; no COD recorded; rider compensation per policy
```

## 6. Commands, idempotency, transactions
`reportDeliveryFailure` is idempotent per assignment (one failure record per delivery); it never retroactively marks a previously-Delivered order as failed.

## 7. Event and ledger trace
No COD journal. Rider compensation treatment depends on BR-011 (illustratively: a reduced "attempted delivery" fee, not the full delivery fee, not zero) — no value approved.

## 8. Acceptance tests (SCT-21-*)
SCT-21-N: waiting period observed, failure recorded with timestamped contact attempts. SCT-21-P: the rider cannot mark Delivered without proof, even if claiming the customer eventually appeared. SCT-21-C: the customer's app shows the delivery arriving while the rider's failure report is also in flight — the failure report, once committed, is authoritative; a late "I'm here now" from the customer does not retroactively fix a closed failure. SCT-21-L: the failure report's response is lost, retried — one failure record. SCT-21-X: the rider's location data is inconsistent with the delivery address at the time of the report — flagged for review, not auto-rejected. SCT-21-R: recovery after the notification to the customer fails — retried via outbox.

## 9. Screen states
NR-06 (delivery dispute): shows the waiting countdown and contact log; CUS order detail shows "Delivery attempted — customer unreachable" with next steps (reschedule, support).

## 10. Links
[BR-011, DEC-014](../requirements/POLICY_DECISION_REGISTER.md); related SC-08.

## 11. Unapproved assumptions
The waiting-time value and the failed-delivery compensation rule are both PENDING.
