# SC-22 — Multi-kitchen custom schedule with separate deliveries

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | CUS, PAR-Supplier, ACC, BE |
| Depends on | [Custom subscription engine](../customer-app/CUSTOM_SUBSCRIPTION_ENGINE.md), [Pricing and billing](../payments/PRICING_AND_BILLING.md) |
| Authoritative policies | BR-021 — PENDING |
| Invariants exercised | INV-18 |
| Status | Draft. HYPOTHETICAL. Nothing implemented. |

## 1. Domain situation
A customer asks for breakfast from one kitchen and dinner from another. Whether approved business rules allow this is BR-021, PENDING. If approved: kitchen-scoped obligations, separate preparation windows, and potentially separate delivery charges. If not approved: the restriction is explained before payment, never a silently discarded kitchen selection. Clear invoice allocation and separate supplier settlement evidence either way.

## 2. Actors and permissions
Customer (own schedule); two Suppliers (each sees only their own obligations).

## 3. Sample data (HYPOTHETICAL)
Breakfast (Kitchen A) 10,000 paisa + delivery 4,000; Dinner (Kitchen B) 16,000 + delivery 4,000. Combined quote 34,000 if separate deliveries are charged.

## 4. Decision table (approved-case branch)
| Observation | Expected change |
|---|---|
| Request received | Customer selects Kitchen A for breakfast, Kitchen B for dinner in the builder |
| Command accepted | `saveSubscriptionSchedule` validated against BR-021's current value |
| Funds confirmed | 34,000 paid, itemised per kitchen |
| Service delivered | Each kitchen fulfils its own obligations independently |
| Liability extinguished | Settlement to Kitchen A and Kitchen B computed from their own recognised earnings, never mixed |

## 5. Sequence
```mermaid
sequenceDiagram
  participant C as Customer App
  participant BE as Trusted backend
  C->>BE: saveSubscriptionSchedule(kitchenA: breakfast, kitchenB: dinner)
  BE->>BE: check policy.multi_kitchen.enabled
  alt enabled
    BE->>BE: create obligations scoped per kitchen; separate delivery fee lines
  else not enabled
    BE-->>C: UNSUPPORTED_COMBINATION, explained before payment
  end
```

## 6. Commands, idempotency, transactions
`saveSubscriptionSchedule` validates the multi-kitchen rule before creating any obligation; rejection happens before payment is ever requested, not after.

## 7. Event and ledger trace
If approved: two independent recognition chains (Kitchen A's breakfast obligations, Kitchen B's dinner obligations), each posting its own `supplierEarningRecognized` journal, never combined into one supplier's balance.

## 8. Acceptance tests (SCT-22-*)
SCT-22-N (policy enabled): both kitchens' obligations generated correctly, invoice itemises both, each settles independently. SCT-22-P: Kitchen A cannot view Kitchen B's obligations for this customer. SCT-22-C: both kitchens' obligation-generation jobs run concurrently — no interference. SCT-22-L: schedule-save response lost, retried — one schedule. SCT-22-X: the policy flag changes between quote and confirmation — the quote's snapshot (per ADR-009) governs, not the newer flag value, for that specific checkout. SCT-22-N2 (policy disabled): the attempt is rejected before payment with a clear explanation, never silently dropping Kitchen B's selection.

## 9. Screen states
NC-04 (builder): if disabled, shows "One kitchen per plan right now" before the customer reaches checkout, not after.

## 10. Links
[BR-021](../requirements/POLICY_DECISION_REGISTER.md); related SC-02.

## 11. Unapproved assumptions
BR-021's value (enabled or not, and any delivery-fee implication) is entirely PENDING; this scenario documents both branches.
