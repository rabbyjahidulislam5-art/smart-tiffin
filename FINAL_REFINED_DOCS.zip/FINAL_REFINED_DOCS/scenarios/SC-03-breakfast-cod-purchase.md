# SC-03 — Breakfast-only one-time COD purchase

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | CUS, PAR-Rider, PAR-Supplier, ACC, BE |
| Depends on | [COD payment workflow](../payments/COD_PAYMENT_WORKFLOW.md), [Order management](../customer-app/ORDER_MANAGEMENT.md) |
| Authoritative policies | BR-010, BR-011, BR-012 — PENDING |
| Invariants exercised | INV-09, INV-10, INV-11, INV-19 |
| Status | Draft. HYPOTHETICAL figures. Nothing implemented. |

## 1. Domain situation
A guest searches breakfast, opens a kitchen, authenticates, and pays COD after zone eligibility is confirmed. The server creates an unpaid COD receivable and an authorised delivery commitment. The rider collects the exact amount at drop-off and must remit it. Supplier and rider compensation accrue at separate milestones. Failure case: the rider marks delivered but no collection confirmation follows.

## 2. Actors and permissions
Guest→Customer (after sign-in, `perm.order.place_own`); Rider (`perm.delivery.advance_own`, `perm.cod.collect_own`); Supplier (`perm.order.prepare_own`).

## 3. Sample data (HYPOTHETICAL)
Breakfast order total 18,000 paisa (180.00 BDT). Illustrative supplier share 16,200, platform 1,800.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | Guest opens kitchen, zone validated |
| Command accepted | `placeOneTimeOrder` with `paymentMethod: COD`; `codInvoiced` journal: Dr cod_receivable 18,000 / Cr customer_prepaid_obligation 18,000 |
| Funds confirmed | N/A until delivery — COD is confirmed only at collection+remittance |
| Service delivered | `submitDeliveryProof` → `recognizeRiderEarning`, `recognizeSupplierEarning` |
| Liability extinguished | `recordCodCollection` → `submitCodRemittance` → `verifyCodRemittance` closes `cod_receivable` |

## 5. Sequence
```mermaid
sequenceDiagram
  participant G as Guest/Customer
  participant BE as Trusted backend
  participant R as Rider
  participant Ac as Accounts
  G->>BE: placeOneTimeOrder(COD)
  BE->>BE: post codInvoiced journal
  R->>BE: submitDeliveryProof
  BE->>BE: recognizeSupplierEarning, recognizeRiderEarning
  R->>BE: recordCodCollection(18000)
  R->>BE: submitCodRemittance
  Ac->>BE: verifyCodRemittance
```

## 6. Commands, idempotency, transactions
`placeOneTimeOrder` idempotent per quote; `submitDeliveryProof` one Delivered transition per assignment; `recordCodCollection`/`submitCodRemittance` per earlier COD workflow rules (INV-12).

## 7. Event and ledger trace
Journal A (invoice): Dr cod_receivable 18,000 / Cr customer_prepaid_obligation 18,000. Journal B (earnings, on delivery): Dr customer_prepaid_obligation 18,000 / Cr supplier_payable 16,200 / Cr platform_revenue 1,800 / Cr rider_payable (delivery fee, separate account, illustrative 2,000 added, not subtracted from the above split for clarity — exact split PENDING BR-009/BR-011). Journal C (remittance verified): Dr cash_and_clearing 18,000 / Cr cod_receivable 18,000.

## 8. Acceptance tests (SCT-03-*)
SCT-03-N: full flow completes, cod_receivable reaches zero, earnings recognised once each. SCT-03-P: an uninvolved rider attempts to collect/remit — denied. SCT-03-C: two remittance submissions race for the same order — one wins (SC-10 pattern). SCT-03-L: lost response on delivery proof, retried — one Delivered transition. SCT-03-X: rider marks delivered but never submits collection — order shows "Delivered, COD pending collection confirmation", never silently marked paid (the named failure case). SCT-03-R: recovery after remittance verification's outbox step fails — read models eventually consistent, no duplicate journal.

## 9. Screen states
C-09/NC-14 (checkout): COD eligibility shown from server zone/limit check, not a static chip. NR-03 (collection): explicit acknowledgement step.

## 10. Links
[BR-010, BR-011, BR-012](../requirements/POLICY_DECISION_REGISTER.md); [COD_PAYMENT_WORKFLOW](../payments/COD_PAYMENT_WORKFLOW.md); related SC-09, SC-10.

## 11. Unapproved assumptions
All splits and the COD eligibility limit are illustrative/PENDING. The "delivered but uncollected" state's exact UI wording is PROPOSED.
