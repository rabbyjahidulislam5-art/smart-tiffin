# SC-12 — Rider payout while COD cash is owed

| Field | Value |
|---|---|
| Scenario ID | SC-12 |
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author S2 (scenarios); scenario owner for review: Accounts & Finance lead (to be identified) |
| Purpose | Specify how a rider who has both earned compensation and unremitted customer cash is shown two independent balances, how a payout is handled without implying that COD cash is compensation, and when (and only when) an explicitly approved hold or offset may link the two. |
| Applies to | PAR-R (Rider workspace), ACC (Accounts Web), ADM (limited view), BE, ledger store (PG), operational store (FS), payout processor or bank |
| Depends on | [Rider earnings](../partner-app/RIDER_EARNINGS.md), [Rider settlement](../accounts-web/RIDER_SETTLEMENT.md), [COD reconciliation](../accounts-web/COD_RECONCILIATION.md), [Payout management](../accounts-web/PAYOUT_MANAGEMENT.md), [Earnings and payouts commands](../api/COMMANDS_EARNINGS_AND_PAYOUTS.md), [COD payment workflow](../payments/COD_PAYMENT_WORKFLOW.md), [glossary](../requirements/GLOSSARY_AND_TERMINOLOGY.md), [conventions](../analysis/CONVENTIONS_AND_ID_REGISTER.md) |
| Authoritative policies | [BR-026 / DEC-036](../requirements/POLICY_DECISION_REGISTER.md) (netting COD against rider payable), [BR-013 / DEC-023](../requirements/POLICY_DECISION_REGISTER.md) (COD deadlines, overdue, whether it blocks payouts), [BR-011 / DEC-021](../requirements/POLICY_DECISION_REGISTER.md) (rider compensation), [BR-014 / DEC-024](../requirements/POLICY_DECISION_REGISTER.md) (payout thresholds, holds), [BR-020 / DEC-030](../requirements/POLICY_DECISION_REGISTER.md) (approval limits). All PENDING. |
| Invariants exercised | INV-01, INV-04, INV-10, INV-11, INV-14, INV-15, INV-19, INV-20 |
| Design references | R-08 (legacy, prototype status U), NR-01, NR-02, NR-03, NR-04, NR-05, NF-03, NF-06, NF-07, NF-08, NF-13, SH-01 |
| Status | Draft for review. Nothing implemented, tested or approved. All BDT figures are HYPOTHETICAL. Provenance: USER-REQ (SC-12) plus PROPOSED engineering detail. |

## 1. Domain situation

**Restated.** A rider has confirmed delivery compensation waiting to be paid and, at the same time, holds customer cash that must be remitted to the company. The two amounts have different owners. Compensation is a platform liability to the rider (rider payable). Held cash is a company asset in the rider's custody (COD receivable and remittance obligation). The product must show both amounts without implying that one is the other, allow only governed holds, and net the two only when a specific approval exists. Each balance has its own settlement path and its own audit reference (INV-10).

**Refinements adopted (PROPOSED, not approved).**

1. *Default behaviour is independence.* Payout eligibility is computed only from rider payable minus holds minus open reservations. Outstanding COD is displayed beside it but is never subtracted automatically.
2. *Any link between the two balances is an explicit, approved action*: either a `placeHold` on rider payable with a reason (for example an overdue COD case) or an approved offset journal. Both require an authorised Accounts identity and a second approver; both are impossible while `policy.cod.netting_allowed` is unset or false.
3. *Whether overdue COD blocks payouts* is `policy.cod.overdue_blocks_payout` (BR-013, no default value). Until decided, blocking is not applied. The test suite covers both settings as configuration cases without choosing one.
4. *A rider cannot request COD cash as earnings.* The payout request amount is validated against the earnings balance only.
5. *Assignment never creates a withdrawable balance* (INV-19). Only confirmed compensation counts.

| Policy | Open question for SC-12 | Parameter |
|---|---|---|
| BR-026 | Is any offset permitted, with what approval and consent | `policy.cod.netting_allowed`, `policy.cod.offset_requires_rider_consent` |
| BR-013 | Does overdue COD block payout or assignment | `policy.cod.overdue_blocks_payout`, `policy.cod.remittance_deadline_hours` |
| BR-011 | What makes compensation "confirmed" | `policy.earning.rider_confirmation_event` |
| BR-014 | Payout minimum, holds, fee bearer | `policy.payout.min_amount_minor`, `policy.payout.fee_bearer` |

## 2. Actors, role claims and permissions outline

| Actor | Role claim | Permissions used (PROPOSED) | Denied in this scenario |
|---|---|---|---|
| Rider | `role.rider` (approved, active) | `perm.payout.request` (own), `perm.cod.submit_remittance` (own), read own earnings and own COD lines | Requesting COD cash as earnings, approving anything, seeing other riders |
| Accounts Operator | `role.accounts.operator` | `perm.payout.review`, `perm.cod.flag_discrepancy` | Placing an offset or approving its own work |
| Payout Approver | `role.accounts.payout_approver` | `perm.payout.approve` | Approving where reviewer or maker |
| Accounts Manager | `role.accounts.manager` | `perm.hold.place`, `perm.hold.release`, `perm.payout.release_batch`, `perm.adjustment.approve` (second approver) | Approving an adjustment it requested |
| Admin (operations) | `role.admin` | Aggregates only (NA-05), dispatch reads | Placing holds, netting, approving payouts (the denied actor in SCT-12-P) |
| Financial Auditor | `role.accounts.auditor` | Read | All writes |
| Customer, Supplier | `role.customer`, `role.supplier` | Not involved | Any access to rider balances |
| Trusted backend | service principal | `postJournal`, processor client | Not invocable from clients |

## 3. Sample data definitions (HYPOTHETICAL BDT, integer paisa)

| Item | Identifier | Paisa | Display |
|---|---|---|---|
| Confirmed compensation: 12 deliveries at an illustrative 1,500 each | `ent.RiderEarning` RE-HYP-0301..0312 | 18,000 | BDT 180.00 |
| Previously settled payouts | none | 0 | BDT 0.00 |
| Holds on rider payable (default case) | none | 0 | BDT 0.00 |
| **Rider payable (available) in the default case** | derived | **18,000** | **BDT 180.00** |
| Customer cash held by the rider, within deadline | `ent.CodCollection` CC-HYP-0301..0303 | 60,000 | BDT 600.00 |
| Same cash, overdue variant | same lines, state Overdue | 60,000 | BDT 600.00 |
| Payout request | PO-HYP-0301 | 18,000 | BDT 180.00 |
| Invalid request mixing COD (rejected) | attempt | 78,000 | BDT 780.00 |
| Processor net amount in the inconsistent-response test | PRC-HYP-4410 | 17,750 | BDT 177.50 |
| Illustrative processor fee | derived | 250 | BDT 2.50 |
| Conditional approved-offset variant (only if BR-026 approves) | ADJ-HYP-0301 | 18,000 | BDT 180.00 |
| Dual-approval threshold (illustration only) | `policy.finance.dual_approval_threshold_minor` | 10,000 | BDT 100.00 |

Principals: rider `PR-RIDER-05`, operator `PR-ACC-OP-01`, approver `PR-ACC-PA-01`, manager `PR-ACC-MGR-01`, second manager `PR-ACC-MGR-02`, admin `PR-ADM-03`. All synthetic.

Context postings (already made by other flows, listed so that INV-10 and INV-11 are traceable): `JE-CTX-0301`: Dr `acct.cod_receivable` 60,000 / Cr (recognition accounts per SC-03) 60,000. `JE-CTX-0302`: Dr (platform delivery cost or customer delivery charge accounts) 18,000 / Cr `acct.rider_payable` 18,000. Neither is part of this scenario.

## 4. Decision table

### 4.1 Observations and their effects

| # | Observation | Actors and role claims | Service trigger | Source record | Precondition | Expected change | External dependency | Reversible? |
|---|---|---|---|---|---|---|---|---|
| O1 | Request received | Rider, `role.rider` | `requestPayout` from NR-02 | Client envelope | Authenticated, active grant | None | None | Yes |
| O2 | Command accepted | Trusted backend | Eligibility computed from rider payable and holds only, amount reserved | `ent.PayoutRequest` PO-HYP-0301, balance snapshot at ledger sequence S1 | Amount ≤ rider payable available; amount ≥ minimum; destination verified; `policy.cod.overdue_blocks_payout` not set to block (if set, `COD_OVERDUE_BLOCK` is returned and no reservation is made) | PayoutRequest Requested, reservation of 18,000. COD lines unchanged. **No journal.** | None | Yes (cancel, reject, expiry) |
| O2b | Review, approval, release | Operator reviews, Approver approves, Manager releases | `reviewPayout`, `approvePayout`, `releasePayoutBatch` | `ent.PayoutApproval`, `ent.SettlementBatch` | Balance rechecked at approval (INV-14); maker ≠ checker (INV-15); any hold or approved offset considered; COD status displayed to the reviewer as information | Approved, then Processing; JE-HYP-3001 moves 18,000 from rider payable to settlement clearing | Processor instruction with stable reference | Before release yes; after release by compensating reversal |
| O3 | Funds externally confirmed | Trusted backend, Operator | `recordPayoutResult` | `ent.PayoutResult`, bank or processor confirmation | Confirmation matches batch amount and beneficiary | Settled; JE-HYP-3002 clears settlement clearing against cash. A variance opens an exception (see SCT-12-X) | Processor or bank | Compensating only |
| O3b | COD funds externally confirmed (independent track) | Operator and Manager (see SC-10) | `verifyCodRemittance` | `ent.CodRemittance` | Independent deposit evidence | COD receivable falls by the verified amount. **Rider payable unchanged.** | Bank or counter | Compensating only |
| O4 | Service delivered | No actor. The rider's deliveries were completed and compensation confirmed earlier | Earlier recognition (INV-19) | `ent.RiderEarning` | Confirmed | **No change.** | None | Not applicable |
| O5 | Liability extinguished | Trusted backend | JE-HYP-3002 posted; separately, JE for COD verification | `ent.JournalEntry` | O3 or O3b | Rider payable falls by the paid amount; COD receivable is extinguished only by verified remittance (or an approved offset). The two extinguishments are separate events. | None | Compensating only |

### 4.2 Interface update moments

| # | Customer app | Supplier workspace | Rider workspace (NR-01, NR-02, NR-03, NR-04, NR-05) | Admin web (NA-05) | Accounts web (NF-03, NF-06, NF-07, NF-08, NF-11) |
|---|---|---|---|---|---|
| O1 | No change. | No change. | Local "Sending" state only. Both balance cards unchanged. | No change. | No change. |
| O2 | No change. | No change. | NR-02 shows Requested with receipt reference. Card A "Earned compensation, available" shows BDT 0.00 with "Reserved BDT 180.00". Card B "Cash you owe the company (COD)" is unchanged at BDT 600.00 with the text "This is company money, not your earnings." No combined or net figure is shown. | Aggregate "payout requests pending" may rise; no rider detail. | NF-07 queue shows the request with a side panel showing rider payable and, separately, COD outstanding and its aging. NF-06 shows the reservation. |
| O2b | No change. | No change. | Status moves through Under Review, Approved, Processing. Card B unchanged. | Aggregates only. | Each step displays actor identities. NF-08 batch Processing. NF-11 shows JE-HYP-3001. |
| O3 | No change. | No change. | NR-02 shows Settled after the confirmation commit, with notification `ntf.payout.settled`. Card B still BDT 600.00. | Aggregates fall. | NF-08 Settled with references. NF-11 shows JE-HYP-3002. NF-03 COD outstanding still 60,000. |
| O3b | No change. | No change. | NR-04 and Card B fall only after COD verification commits. Card A unchanged. | COD aggregate falls. | NF-03 and NF-11 show the COD journal. NF-06 unchanged. |
| O4 | Unchanged. | Unchanged. | NR-01 delivery-level compensation lines unchanged. | Unchanged. | Unchanged. |
| O5 | Unchanged. | Unchanged. | Both cards reflect their own extinguishing events at different times. | Aggregates. | NF-01 rider payables and COD receivable move independently. |

## 5. Sequence diagram

```mermaid
sequenceDiagram
    autonumber
    participant CA as Customer app
    participant PA as Partner app Rider
    participant AW as Admin web
    participant ACW as Accounts web
    participant BE as Trusted backend
    participant FS as Firestore
    participant LS as Ledger store
    participant GW as Payout processor and bank
    participant NT as Notification service

    PA->>BE: requestPayout requestId P1 amount 18000
    BE->>LS: derive rider payable and holds at sequence S1, COD outstanding read only for display
    BE->>LS: one transaction - receipt, PayoutRequest Requested, reservation, audit, outbox
    LS-->>BE: committed
    BE-->>PA: receipt and status Requested
    BE->>FS: outbox projects Card A reserved and Card B unchanged
    BE->>NT: ntf.payout.requested to Accounts queue
    ACW->>BE: reviewPayout - operator sees payable and COD aging side by side
    Note over ACW,BE: Human checkpoint - any hold or offset needs Manager plus second approver and an approved policy
    ACW->>BE: approvePayout by Approver and releasePayoutBatch by Manager
    BE->>LS: one transaction - Processing, JE-HYP-3001, audit, outbox
    BE->>GW: transfer instruction reference SB-HYP-0301
    GW-->>BE: confirmation amount 18000 PRC-HYP-4410
    BE->>LS: recordPayoutResult - Settled, JE-HYP-3002, audit, outbox
    BE->>FS: outbox projects Settled
    BE->>NT: ntf.payout.settled to rider
    NT-->>PA: notification
    PA->>BE: submitCodRemittance later, separate track, see SC-10
    Note over CA,AW: Customer app untouched, Admin web aggregates only
```

**Short text sequence.** (1) The rider requests 18,000 and the backend checks only the earnings balance. (2) The reviewer sees both balances side by side. (3) Approval, release and external confirmation follow the supplier-payout path (SC-11). (4) COD cash is remitted and verified on its own track (SC-10). (5) Linking them requires an approved policy plus an explicit hold or adjustment with two approvers.

**Human approval checkpoints.** (a) Reviewer inspects both balances. (b) Payout Approver differs from reviewer and batch creator. (c) If a hold or offset is ever proposed: Manager requests, a second Manager approves, and the case cites the approved BR-026 policy version.

## 6. Commands, idempotency and transaction boundaries

| Command | Logical operation id | Atomic boundary | Duplicate defence | Failure class |
|---|---|---|---|---|
| `requestPayout` | `op:payout-req:{riderId}:{clientRequestId}` and reservation keyed on `{riderId, ledgerSequence}` | Receipt, PayoutRequest, reservation, audit, outbox | Same-requestId returns stored receipt; sequence check rejects a competing overdraw | Retry safe |
| `approvePayout` | `op:payout-approve:{payoutId}` | Approval row with sequence used, state, audit | Unique approval per payout | Retry safe; `STALE_BALANCE` forces re-review |
| `releasePayoutBatch` | `op:batch-release:{batchId}` | State, JE-HYP-3001, outbox for instruction | Unique release; processor reference = batch id | Pending then retry after querying processor |
| `recordPayoutResult` | `op:payout-result:{batchId}:{processorEventId}` | Result, state, journal, audit | Unique processor event id | Retry safe; variance becomes an exception, not a silent edit |
| `placeHold` (only if policy approved) | `op:hold:{riderId}:{reasonCode}:{caseId}` | Hold row, audit, outbox | Unique per case | Retry safe |
| `requestAdjustment` / `approveAdjustment` (offset, only if policy approved) | `op:adjust:{caseId}` | Adjustment row, two approvals, journal via `postJournal`, audit | Unique adjustment per case; requester ≠ approver (INV-15) | Compensating reversal |
| `verifyCodRemittance` | `op:cod-verify:{remittanceId}` (see SC-10) | Independent of payout commands | Unique per remittance | Retry safe |

**Rules.**

- *Stable logical operation id*, immutable before and after audit events, and independent reconciliation of processor and bank messages are as in SC-11.
- *Pending, retry, compensating*: an unconfirmed Processing batch is pending. A repeated call with the same requestId is a retry. A mis-posted offset is reversed by a linked compensating journal.
- *No netting field*: there is no `rider.net_balance` or `rider.cod_deducted` column. Net exposure, if ever shown to staff, is a derived report line that names both source balances. Customers and riders see two cards.
- *Order independence*: COD verification and payout settlement may complete in either order; neither requires the other, and each posts its own journal exactly once.

## 7. Event and ledger trace

### 7.1 Events

| Seq | Event | Actor | Before → after | Journal |
|---|---|---|---|---|
| 1 | `evt.payout.requested` | `PR-RIDER-05` | none → Requested; reservation 18,000 | none |
| 2 | `evt.payout.review_completed` | `PR-ACC-OP-01` | Requested → Under Review; COD aging read | none |
| 3 | `evt.payout.approved` | `PR-ACC-PA-01` | Under Review → Approved | none |
| 4 | `evt.payout.batch_released` | `PR-ACC-MGR-01` | Approved → Processing | JE-HYP-3001 |
| 5 | `evt.payout.settled` | system on confirmation | Processing → Settled | JE-HYP-3002 |
| 6 | `evt.cod.remittance_verified` (separate track) | see SC-10 | COD lines → Verified | COD journal |

### 7.2 Journals

**JE-HYP-3001** (release)

| Line | Account | Debit | Credit |
|---|---|---|---|
| 1 | `acct.rider_payable` | 18,000 | |
| 2 | `acct.settlement_clearing` | | 18,000 |
| | **Totals** | **18,000** | **18,000** |

**JE-HYP-3002** (confirmed settlement)

| Line | Account | Debit | Credit |
|---|---|---|---|
| 1 | `acct.settlement_clearing` | 18,000 | |
| 2 | `acct.bank_cash` | | 18,000 |
| | **Totals** | **18,000** | **18,000** |

The COD receivable of 60,000 is untouched by both journals (INV-11).

**Conditional variants (apply only if the stated policy is approved).**

- *Processor variance (SCT-12-X)*, JE-HYP-3003 recorded from bank evidence: Dr `acct.settlement_clearing` 17,750; Dr `acct.fees_and_expenses` 250; Cr `acct.bank_cash` 18,000 (totals 18,000 = 18,000). The 250 credit still left in settlement clearing is a pending item. If `policy.payout.fee_bearer` makes the rider bear the fee: Dr `acct.settlement_clearing` 250; Cr `acct.fees_and_expenses` 250. If the platform bears it: a 250 top-up transfer is released later and settled through the normal path. Neither choice is approved.
- *Approved offset (BR-026 approved)*, JE-HYP-3004: Dr `acct.rider_payable` 18,000; Cr `acct.cod_receivable` 18,000, referencing ADJ-HYP-0301, two approvers, and the policy version. Remaining COD owed = 60,000 − 18,000 = 42,000; rider payable available = 0; no payout.
- *Approved hold (policy permits)*: `ent.Hold` of 18,000 with reason `cod_overdue_review`; no journal; available = 0 until released.

## 8. Acceptance and integration tests

All planned, none executed. Abuse tests: SCT-12-P and SCT-12-X. Tests that depend on an undecided policy are marked "configuration case" and must be run once per setting; they do not choose the policy.

### SCT-12-N — Independent balances, payout proceeds

- **Given** rider payable 18,000 (BDT 180.00), COD outstanding 60,000 within deadline, `policy.cod.netting_allowed` false or unset, no hold.
- **When** the rider requests 18,000 and the standard approval, release and confirmation run.
- **Then** payout is Settled with JE-HYP-3001 and JE-HYP-3002; COD receivable still 60,000; NR-02 shows two cards and no net figure; rider payable 0; no offset journal exists; supplier and customer interfaces are unchanged.

### SCT-12-P — Permission and category abuse

- **Given** `PR-ADM-03` (Admin), `PR-ACC-OP-01` (Operator) and `PR-RIDER-05`.
- **When** the rider requests 78,000 expecting COD cash to count; the Admin calls `placeHold` or `approveAdjustment`; the Operator requests an offset while `policy.cod.netting_allowed` is unset.
- **Then** each is rejected before any write (`AMOUNT_EXCEEDS_EARNINGS`, `PERMISSION_DENIED`, `POLICY_NOT_APPROVED`); no hold, no journal, no reservation; each attempt is audited; hiding a UI control is not relied upon.

### SCT-12-C — Concurrent COD verification and payout approval

- **Given** a payout awaiting approval and, at the same moment, a Manager placing an approved hold or an adjustment changing rider payable.
- **When** `approvePayout` and the hold or adjustment commit concurrently.
- **Then** the approval records the ledger sequence it used; if the hold committed first, approval fails with `STALE_BALANCE` and re-review is required; if approval committed first, the hold applies to the remaining balance; total paid never exceeds payable at the time of approval (INV-14); one journal per command.

### SCT-12-L — Lost response, successful server commit

- **Given** `recordPayoutResult` committed Settled but the response and notification were lost.
- **When** the job retries and the rider reopens NR-02.
- **Then** the retry returns the stored result; one JE-HYP-3002; NR-02 shows Settled after projection; no duplicate notification (event id dedupe).

### SCT-12-X — Inconsistent third-party response (abuse test)

- **Given** a batch for 18,000 in Processing.
- **When** the processor confirms 17,750 net of a 250 fee, or confirms to an account that differs from the verified destination.
- **Then** the batch is not marked Settled for 18,000; an exception is raised in NF-13; JE-HYP-3003 reflects bank evidence only; the 250 residual remains in settlement clearing until `policy.payout.fee_bearer` is decided and an authorised resolution is posted; the rider sees "Transfer completed for BDT 177.50, BDT 2.50 under review"; no rider compensation record is edited.

### SCT-12-R — Recovery after partial failure

- **Given** an approved offset (configuration case, policy approved) where JE-HYP-3004 committed but the hold-release step failed and the projection lagged.
- **When** the retry and reconciliation run.
- **Then** the hold is released exactly once; the offset journal is not duplicated; rider payable 0, COD owed 42,000 in all views; if the offset proves wrong, a compensating journal restores 18,000 payable and 60,000 COD with a new audit chain.

### 8.1 What must agree

| Layer | Must agree |
|---|---|
| Database constraints | Unique approval and release; unique processor event id; unique adjustment per case; maker ≠ checker; balanced journals |
| Notifications | One per transition; no notification claims "deducted" unless an approved offset exists |
| Audit | Every accepted and denied attempt, including policy-not-approved rejections |
| Journals | Payout journals touch only rider payable, settlement clearing and cash; COD receivable changes only through COD verification or an approved offset |
| Read models | Two separate cards; staff reports name both source balances (INV-20) |

## 9. Screen states

| Screen | App | State | Accessible text (key) | Next action | Offline fallback |
|---|---|---|---|---|---|
| NR-02 Rider payout request | PAR-R | Two balances | "Earned compensation you can withdraw: BDT 180.00." and "Cash you owe the company: BDT 600.00. This is not your income." (`info.rider.two_balances`) | Request payout or open NR-04 | Last known values with an as-of time; submit disabled offline |
| NR-02 | PAR-R | Blocked by policy (configuration case) | "Payout is paused until overdue cash is resolved." (`err.payout.cod_overdue_block`) | Open NR-04 to remit | Read-only |
| NR-02 | PAR-R | Amount mixing COD | "You can request up to BDT 180.00. Customer cash is not part of your earnings." (`err.payout.over_earnings`) | Change amount | Draft kept locally |
| NR-04 COD remittance | PAR-R | Pending verification | "Submitted. Accounts has not confirmed this deposit yet." | Wait | As-of marker |
| NR-05 Discrepancy | PAR-R | Offset applied (only if approved) | "BDT 180.00 of your earnings was applied to your cash balance by Accounts. Reference ADJ-HYP-0301." (`info.rider.offset_applied`) | View details, dispute | Read-only |
| NF-07 Payout request review | ACC | Side panel | Shows payable, holds, COD aging; no combined figure | Approve, reject, request information | Read-only |
| NF-06 Rider payable ledger | ACC | Hold present | "Hold reason: COD review. Approved by two users." | Release when resolved | Read-only |
| NA-05 | ADM | Limited | "Summary only." | Request access | Cached aggregates |

Layouts follow [RIDER_SCREENS](../design/screens/RIDER_SCREENS.md) and [ACCOUNTS_SCREENS](../design/screens/ACCOUNTS_SCREENS.md). The legacy R-08 statistics are static samples and must not be reused as balances. Text is announced to assistive technology, never colour-only, and tolerates Bangla expansion.

## 10. Links

| Kind | Link |
|---|---|
| Business rules | [POLICY_DECISION_REGISTER](../requirements/POLICY_DECISION_REGISTER.md) (BR-011, BR-013, BR-014, BR-020, BR-026) |
| API commands | [COMMANDS_EARNINGS_AND_PAYOUTS](../api/COMMANDS_EARNINGS_AND_PAYOUTS.md), [COMMANDS_PAYMENTS_AND_COD](../api/COMMANDS_PAYMENTS_AND_COD.md), [COMMANDS_LEDGER_AND_GOVERNANCE](../api/COMMANDS_LEDGER_AND_GOVERNANCE.md) |
| Entities | `ent.RiderEarning`, `ent.CodCollection`, `ent.CodRemittance`, `ent.Hold`, `ent.PayoutRequest`, `ent.PayoutApproval`, `ent.SettlementBatch`, `ent.PayoutResult`, `ent.Adjustment`, `ent.JournalEntry` ([FINANCIAL_DATA_MODEL](../database/FINANCIAL_DATA_MODEL.md)) |
| Permissions | [AUTHORIZATION](../api/AUTHORIZATION.md), [USER_ROLES](../requirements/USER_ROLES.md) |
| Specifications | [RIDER_EARNINGS](../partner-app/RIDER_EARNINGS.md), [RIDER_SETTLEMENT](../accounts-web/RIDER_SETTLEMENT.md), [COD_RECONCILIATION](../accounts-web/COD_RECONCILIATION.md), [PAYOUT_MANAGEMENT](../accounts-web/PAYOUT_MANAGEMENT.md) |
| Tests | [FINANCIAL_TEST_CASES](../testing/FINANCIAL_TEST_CASES.md), [INTEGRATION_TEST_CASES](../testing/INTEGRATION_TEST_CASES.md) (SCT-12-N/P/C/L/X/R) |
| Runbooks | [COD_DISCREPANCY_RUNBOOK](../operations/COD_DISCREPANCY_RUNBOOK.md), [SETTLEMENT_AND_RECONCILIATION_RUNBOOK](../operations/SETTLEMENT_AND_RECONCILIATION_RUNBOOK.md) |
| Traceability | [REQUIREMENTS_TRACEABILITY_MATRIX](../requirements/REQUIREMENTS_TRACEABILITY_MATRIX.md) (FR-034, FR-037, FR-038, INV-10, INV-11) |
| Related scenarios | SC-09 (cash mismatch), SC-10 (COD deposit), SC-11 (supplier withdrawal), SC-16 (override attempt) |

## 11. Unapproved assumptions flagged

1. Whether any COD offset against rider payable is allowed, and under what consent and approval (BR-026), is not decided. The default shown here (no netting) is a safe PROPOSED state, not an approved rule.
2. Whether overdue COD blocks payout or assignment (BR-013) is not decided.
3. The per-delivery compensation of 1,500, the 250 fee and the 10,000 threshold are illustrations only.
4. Fee bearer and processor behaviour (BR-014) are undefined.
5. The reason codes, hold taxonomy and chart-of-accounts names are PROPOSED.
6. Nothing is implemented or tested. A prototype earnings screen (legacy R-08) or a "payout recorded" message never demonstrates that balances are separate or that money moved.
