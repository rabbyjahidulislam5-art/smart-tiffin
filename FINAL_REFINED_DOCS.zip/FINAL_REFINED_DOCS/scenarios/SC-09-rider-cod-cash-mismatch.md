# SC-09 — Rider COD cash mismatch

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | PAR-Rider, ACC, CUS, BE |
| Depends on | [COD payment workflow](../payments/COD_PAYMENT_WORKFLOW.md), [COD reconciliation](../accounts-web/COD_RECONCILIATION.md) |
| Authoritative policies | BR-013, BR-020 — PENDING |
| Invariants exercised | INV-10, INV-11 |
| Status | Draft. HYPOTHETICAL figures. Nothing implemented. |

## 1. Domain situation
A rider reports that a customer handed over less cash than the invoiced COD amount. The platform must distinguish: what was invoiced, what was actually collected, what the customer still owes, and what the rider owes Accounts. The order is never marked fully paid on a shortfall. Evidence, exception review and an approved resolution are required — rider earnings are never adjusted to disguise the discrepancy.

## 2. Actors and permissions
Rider (`perm.cod.flag`); Accounts Operator/Manager (`perm.cod.resolve_discrepancy`).

## 3. Sample data (HYPOTHETICAL)
Invoiced 20,000 paisa; collected 15,000; shortfall 5,000.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | `recordCodCollection` for 15,000 against a 20,000 invoice |
| Command accepted | Collection recorded at 15,000; `flagCodDiscrepancy` raised automatically or by the rider |
| Funds externally confirmed | Remittance of 15,000 verified; shortfall 5,000 remains open |
| Service delivered | Unaffected — delivery already completed |
| Liability extinguished | Only the verified 15,000 portion of `cod_receivable` is cleared; 5,000 remains until `resolveCodDiscrepancy` |

## 5. Sequence
```mermaid
sequenceDiagram
  participant R as Rider
  participant BE as Trusted backend
  participant Ac as Accounts
  R->>BE: recordCodCollection(15000) against invoice 20000
  BE->>BE: flagCodDiscrepancy (shortfall 5000)
  R->>BE: submitCodRemittance(15000)
  Ac->>BE: verifyCodRemittance(15000)
  Ac->>BE: resolveCodDiscrepancy(case, decision)
```

## 6. Commands, idempotency, transactions
`flagCodDiscrepancy` creates exactly one open case per collection shortfall; `resolveCodDiscrepancy` closes it exactly once, posting either `codWrittenOff` (approved loss) or `adjustmentPosted` (recovery pursued from the customer).

## 7. Event and ledger trace
Journal 1 (remittance verified): Dr cash_and_clearing 15,000 / Cr cod_receivable 15,000. The remaining 5,000 stays in `cod_receivable` until resolution; resolution journal (illustrative write-off): Dr refunds_and_adjustments 5,000 / Cr cod_receivable 5,000.

## 8. Acceptance tests (SCT-09-*)
SCT-09-N: shortfall correctly flagged, remittance verified for 15,000 only, resolution closes the remaining 5,000 with an auditable decision. SCT-09-P: the rider attempts to resolve its own discrepancy — denied (Accounts-only). SCT-09-C: rider and Accounts both act on the case concurrently — version-checked, no lost update. SCT-09-L: discrepancy-flag response lost, retried — one case, not two. SCT-09-X: the customer disputes the rider's account of the shortfall — case routes to an evidence-review state, order still not marked fully paid. SCT-09-R: recovery after the write-off journal posts but the case-closure projection fails — projection retried, journal unaffected.

## 9. Screen states
NR-05 (COD discrepancy): shows invoiced vs collected vs remitted vs still-owed, never collapsed into one number. NF-13 (reconciliation exceptions): the case appears until resolved.

## 10. Links
[BR-013, BR-020](../requirements/POLICY_DECISION_REGISTER.md); related SC-10, SC-03.

## 11. Unapproved assumptions
Whether the shortfall is pursued from the customer, written off, or deducted from the rider is entirely PENDING policy (BR-013/BR-020); this scenario only proves it is never silently absorbed into rider earnings.
