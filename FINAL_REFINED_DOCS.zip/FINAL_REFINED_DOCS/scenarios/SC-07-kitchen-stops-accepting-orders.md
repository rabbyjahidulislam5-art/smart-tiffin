# SC-07 — Supplier kitchen stops accepting orders

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | CUS, PAR-Supplier, ADM, ACC, BE |
| Depends on | [Admin operations management](../admin-web/OPERATIONS_MANAGEMENT.md), [ADR-014](../adr/014-subscription-agreement-and-meal-obligations.md) |
| Authoritative policies | BR-024 — PENDING |
| Invariants exercised | INV-06, INV-09 |
| Status | Draft. HYPOTHETICAL figures. Nothing implemented. |

## 1. Domain situation
A verified kitchen turns its availability off while carrying future recurring commitments. This requires an explicit continuity/incident decision, never silent deletion. Options: fulfil remaining commitments elsewhere, temporary hold, customer contact, authorised replacement kitchen (with consent), or cancellation+credit. Admin's review queue manages the decision; payments, earnings, rider assignments and support messages must reconcile.

## 2. Actors and permissions
Supplier (own availability toggle, `perm.catalogue.manage_own`); Admin (`perm.admin.manage_continuity`, NA-04); Accounts (reads impact only, no unilateral refund without a request).

## 3. Sample data (HYPOTHETICAL)
50 affected obligations across 12 customers, total unfulfilled prepaid value 650,000 paisa.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | `setSlotAvailability` (kitchen off) or `saveCapacity` (zero) |
| Command accepted | Kitchen marked unavailable; new orders blocked |
| Funds externally confirmed | N/A (existing prepayments already confirmed) |
| Service delivered | N/A for affected future obligations |
| Liability extinguished | Per Admin-approved resolution: either reassigned to a replacement kitchen (with customer consent) or cancelled with credit/refund (BR-005/BR-024) |

## 5. Sequence
```mermaid
sequenceDiagram
  participant S as Supplier workspace
  participant BE as Trusted backend
  participant A as Admin Web
  participant C as Customer App
  S->>BE: setSlotAvailability(off)
  BE->>A: incident raised (affected obligations listed)
  A->>BE: decide continuity (replace / hold / cancel+credit)
  alt replacement kitchen approved by customer
    BE->>C: consent request
    C->>BE: accept replacement
  else cancel+credit
    BE->>BE: issueCredit per unfulfilled obligation
  end
```
Human checkpoint: Admin's continuity decision; customer's explicit consent for any replacement kitchen.

## 6. Commands, idempotency, transactions
Each affected obligation's resolution is applied exactly once via its own `confirmScheduleChange` or `cancelSubscription` call, never a bulk silent edit.

## 7. Event and ledger trace
Per cancelled obligation: Dr customer_prepaid_obligation / Cr customer_credit_liability (or Cr cash_and_clearing for a gateway refund, per BR-005).

## 8. Acceptance tests (SCT-07-*)
SCT-07-N: kitchen goes offline, Admin resolves via approved replacement, customers' obligations continue uninterrupted. SCT-07-P: the supplier itself cannot unilaterally cancel a customer's paid subscription. SCT-07-C: two obligations resolved concurrently — both succeed independently. SCT-07-L: Admin's decision command times out, retried — one resolution per obligation. SCT-07-X: a customer doesn't respond to the replacement-consent prompt — obligation defaults to the documented fallback (cancel+credit), never left silently unresolved. SCT-07-R: recovery after a partial batch resolution failure — remaining obligations correctly identified and resolved.

## 9. Screen states
NA-04 (incident dispatcher): lists every affected obligation with its resolution status. NC-15 (change history): shows the kitchen-discontinuity reason on affected obligations.

## 10. Links
[BR-024](../requirements/POLICY_DECISION_REGISTER.md); related SC-17, SC-24.

## 11. Unapproved assumptions
Whether replacement requires customer consent in all cases, and the default fallback, are both PENDING (BR-024).
