# SC-15 — Accounts period close and late event

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | ACC, BE |
| Depends on | [Financial ledger](../accounts-web/FINANCIAL_LEDGER.md), [database/FINANCIAL_DATA_MODEL.md](../database/FINANCIAL_DATA_MODEL.md) |
| Authoritative policies | BR-020 — PENDING |
| Invariants exercised | INV-16 |
| Status | Draft. HYPOTHETICAL. Nothing implemented. |

## 1. Domain situation
Finance closes a reporting period after reconciling gateway clearing, COD deposits, payables, credits and bank statements. A late delivery-completion event arrives afterward. Posted journals, effective business dates, approved adjusting entries and immutable period-close evidence are required. No silent backdating or overwriting of closed balances. Reopening is governed, not routine.

## 2. Actors and permissions
Accounts Operator (begins close); Accounts Manager (finalises, not the initiator); the late event's actor (e.g. rider submitting proof) is unaware of the period boundary.

## 3. Sample data (HYPOTHETICAL)
Period October 2026 closed 2026-11-01. A delivery completed 2026-10-31 23:58 Asia/Dhaka has its proof submitted 2026-11-01 00:05 (after close).

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | AcOp begins `closePeriod` for October |
| Command accepted | Checklist validated, period → Closed |
| Funds externally confirmed | N/A |
| Service delivered | The late delivery's proof arrives after close |
| Liability extinguished | Earning recognised, journal posted to **November** (the open period), with an adjusting reference noting the October service date |

## 5. Sequence
```mermaid
sequenceDiagram
  participant Ac as Accounts Web
  participant BE as Trusted backend
  participant R as Rider
  Ac->>BE: closePeriod(October) -- AcOp begins
  Ac->>BE: finalise close -- AcMgr (different principal)
  BE->>BE: October -> Closed
  R->>BE: submitDeliveryProof (service date October 31)
  BE->>BE: recognizeRiderEarning -> journal posted to November (open period) with adjusting note
```

## 6. Commands, idempotency, transactions
`closePeriod` is a two-step maker-checker action; any journal attempted against a Closed period is rejected by `postJournal`'s internal period-open check and automatically retargeted to the current open period with an adjusting reference, never silently dropped or backdated.

## 7. Event and ledger trace
Journal posted November: Dr customer_prepaid_obligation / Cr rider_payable, with a note `service_period: 2026-10`, `posted_period: 2026-11`.

## 8. Acceptance tests (SCT-15-*)
SCT-15-N: the late event posts correctly to the open period with the adjusting note; October's closed totals remain unchanged. SCT-15-P: AcOp attempts to finalise the close it itself began — rejected (maker-checker). SCT-15-C: two late events for different deliveries arrive concurrently — both post correctly to November. SCT-15-L: the late event's command times out, retried — one posting. SCT-15-X: a reconciliation exception is discovered mid-close — close is blocked until resolved. SCT-15-R: recovery after a crash during close finalisation — period status resolves to either still-open (retry) or fully-closed, never an ambiguous state.

## 9. Screen states
NF-12 (period close workspace): checklist blocks close until every item is satisfied; shows closed periods as read-only with a visible "late postings" indicator for any period that received adjusting entries after close.

## 10. Links
[BR-020](../requirements/POLICY_DECISION_REGISTER.md); related SC-01.

## 11. Unapproved assumptions
The exact period-close checklist items beyond those named in [FINANCIAL_LEDGER.md](../accounts-web/FINANCIAL_LEDGER.md) are PROPOSED.
