# SC-24 — Financial adjustment after external payout

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | ACC, PAR-Supplier, BE |
| Depends on | [Refunds and adjustments](../accounts-web/REFUNDS_AND_ADJUSTMENTS.md), [ADR-006](../adr/006-double-entry-ledger.md) |
| Authoritative policies | BR-020 — PENDING |
| Invariants exercised | INV-02, INV-15 |
| Status | Draft. HYPOTHETICAL. Nothing implemented. |

## 1. Domain situation
Accounts discovers that a partner was overpaid after a confirmed bank transfer. The settled transfer and its history are never deleted or edited. An authorised adjustment or recoverable balance is created with evidence and documented legal/business constraints. If a recovery method is not approved, the case is marked unresolved and routed to review. Partner statements and financial reports remain reconcilable.

## 2. Actors and permissions
Accounts Operator (discovers, prepares adjustment); Accounts Manager/Payout Approver (approves, ≠ preparer).

## 3. Sample data (HYPOTHETICAL)
Payout PR-HYP-55 settled for 60,000 paisa; correct eligible amount was 48,000; overpayment 12,000.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | AcOp discovers the discrepancy during a later review |
| Command accepted | `requestAdjustment` for 12,000 against the supplier's payable, with evidence (the original settled PR-HYP-55, untouched) |
| Funds externally confirmed | N/A — no new external transfer in this scenario unless recovery is executed |
| Service delivered | N/A |
| Liability extinguished | `approveAdjustment` posts a correcting journal reducing future eligible balance by 12,000; PR-HYP-55's own record is never edited |

## 5. Sequence
```mermaid
sequenceDiagram
  participant Ac1 as Accounts Operator
  participant Ac2 as Accounts Manager
  participant BE as Trusted backend
  Ac1->>BE: requestAdjustment(supplierId, -12000, evidence: PR-HYP-55)
  Ac2->>BE: approveAdjustment (different principal)
  BE->>BE: post adjustmentPosted journal; PR-HYP-55 untouched
```

## 6. Commands, idempotency, transactions
`requestAdjustment`/`approveAdjustment` never touch the original `ent.PayoutResult`; they create a new, linked correction record and journal (INV-02).

## 7. Event and ledger trace
Journal: Dr supplier_payable 12,000 / Cr refunds_and_adjustments 12,000 (reducing the supplier's future eligible balance; recovery of the actual cash, if pursued, is a separate, unapproved process per BR-020/legal review).

## 8. Acceptance tests (SCT-24-*)
SCT-24-N: adjustment correctly reduces future eligible balance; PR-HYP-55's history is untouched and still shows Settled for 60,000. SCT-24-P: AcOp cannot approve its own adjustment request. SCT-24-C: two adjustment requests for the same overpayment race — one is accepted, the duplicate is rejected or merged, never double-deducted. SCT-24-L: approval response lost, retried — one adjustment. SCT-24-X: the supplier disputes the overpayment finding — case routes to a review state, adjustment held pending resolution. SCT-24-R: recovery after the adjustment journal posts but the supplier-facing notification fails — retried via outbox, journal unaffected.

## 9. Screen states
NF-16 (adjustment approval): shows the original settled payout as read-only evidence, with the new adjustment as a clearly separate, linked record.

## 10. Links
[BR-020](../requirements/POLICY_DECISION_REGISTER.md); related SC-11, SC-16.

## 11. Unapproved assumptions
Whether and how actual cash recovery from the supplier is pursued is entirely unapproved and may require legal review (see [security/AUDIT_AND_COMPLIANCE.md](../security/AUDIT_AND_COMPLIANCE.md)).
