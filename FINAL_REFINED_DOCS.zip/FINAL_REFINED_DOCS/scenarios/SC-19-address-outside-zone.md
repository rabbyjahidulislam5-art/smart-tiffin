# SC-19 — Subscriber changes delivery address to a location outside the service zone

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Scenario author S3 (documentation); business owner for BR-005, BR-006, BR-021, BR-022 to be identified |
| Purpose | Define how a prepaid subscription with twenty future meal obligations behaves when the customer moves delivery to an address the kitchen does not serve, so that the change is never silently accepted, paid-for service is not lost, and any remedy follows approved policy. |
| Applies to | CUS, PAR-S (forecast), ADM (zones, exceptions), ACC (only if a remedy posts), BE |
| Depends on | [Scenario index and common conventions](SCENARIO_INDEX.md#common-conventions-for-all-scenarios), [time and cutoff policy](../architecture/TIME_AND_CUTOFF_POLICY.md), [commands: orders and subscriptions](../api/COMMANDS_ORDERS_AND_SUBSCRIPTIONS.md), [customer credit rules](../payments/CUSTOMER_CREDIT_RULES.md), [kitchen capacity](../customer-app/KITCHEN_AND_MEAL_SYSTEM.md) |
| Authoritative policies | BR-001/DEC-004 (change cutoff), BR-005/DEC-007 (cancellation and refunds), BR-006/DEC-016 (credit), BR-007/DEC-017 (delivery charges), BR-021/DEC-031 (multi-kitchen), BR-022/DEC-032 (cutoff). All PENDING. |
| Design reference | C-02, C-03, NC-04, NC-06, NC-07, NC-09, NC-15, S-07, NS-04, NS-05, A-06 area (zones via NA-02) |
| Commands | `saveAddress`, `quoteScheduleChange`, `confirmScheduleChange`, `cancelSubscription`, `skipMeals`, `issueCredit`, `releaseStock`, `initiateRefund` |
| Invariants exercised | INV-01, INV-04, INV-06, INV-07, INV-08, INV-17, INV-18 |
| Status | Draft for review. Nothing implemented, tested or approved. All BDT figures are HYPOTHETICAL. |

## 1. Domain situation

**Restated.** A customer has a paid subscription with kitchen K1 (zone Z-A) covering twenty future meal obligations (ten lunches, ten dinners over two weeks). The customer adds a new address in zone Z-X, which K1 does not serve, and tries to use it for the remaining obligations. The system must not accept it silently. It must explain which addresses are valid, offer the choices that approved policy permits, protect already paid service, release kitchen capacity correctly if service ends, and never let a free-text label such as "Home" bypass zone validation.

**Refined.**

1. The address record may be saved (it is the customer's data) but carries a server-computed `serviceability` result per kitchen. The label, the map pin and any client check are advisory; only the server decision counts. When the zone lookup cannot give a certain answer, the result is `unknown` and is treated as not serviceable (fail closed).
2. Applying an address to an agreement is a **schedule change**: it goes through `quoteScheduleChange` and `confirmScheduleChange`, with an explicit outcome for each of the twenty obligations (kept at old address, moved, cancelled, replaced, or blocked).
3. A conditional quotation is shown: it states what each option would cost or return **if** the option is approved and available, labelled non-binding until `confirmScheduleChange` succeeds.
4. Available options in this scenario, each subject to approved policy:
   - (A) Keep the current address (no change).
   - (B) Move to the new address: **blocked** for K1 because Z-X is unserved. No override by the customer or by support.
   - (C) Cancel the affected obligations and receive the remedy that BR-005/BR-006 approve (service credit, refund, or neither). The remedy value cannot be computed until those rules are approved; section 7 shows the PROPOSED credit path with hypothetical arithmetic.
   - (D) Replace with a kitchen that serves Z-X (a new agreement, new quote, customer consent). Allowed only if BR-021 permits; under the PROPOSED default (one kitchen per agreement, several agreements allowed) it is a new agreement, not a modification.
5. Obligations whose change cutoff has passed (BR-001, BR-022) are not changeable; the plan shows them as "will be delivered to the old address" or "needs support".
6. Kitchen capacity and ingredient commitments are released only when the cancellation commits, never at quotation (FR-046).

**Assumptions (labelled).** A1 PROPOSED: serviceability is evaluated per kitchen and per zone with a versioned zone table (NA-02). A2 PROPOSED: no partial-day or distance exceptions exist. A3: the twenty obligations are all paid and none is dispatched.

**PENDING policies.**

| Reference | Question | Effect |
|---|---|---|
| BR-005 / DEC-007 | Who may cancel, scope, charges, refund entitlement | Whether option (C) returns cash, credit or nothing |
| BR-006 / DEC-016 | Credit eligibility and amount | Credit amount for option (C) |
| BR-007 / DEC-017 | Delivery charges | Whether the delivery component of each trip is part of the remedy and what option (D) charges |
| BR-021 / DEC-031 | Multi-kitchen | Whether (D) may be a modification of the same agreement |
| BR-001 / BR-022 | Change cutoff, time zone | Which obligations are still changeable on the request date |

## 2. Actors, role claims and permissions outline

| Actor | Role claim | Permitted | Notes |
|---|---|---|---|
| Customer (subscription owner) | `role.customer` + ownership | Save address, request quotation, confirm or abandon change, cancel eligible obligations | Cannot force an unserved address |
| Supplier K1 | `role.supplier` + `kitchenId = K1` | Read the changed forecast (NS-04) after commit; edit zone coverage of own kitchen only through an approved profile change (FR-026/FR-027) | **Cannot** edit a customer's subscription or address |
| Rider | `role.rider` | None until a delivery assignment exists | No access to address history beyond an assigned delivery |
| Admin (operations) | `role.admin.ops` | Manage service zones with versioned policy approval (NA-02), view exception queue | **Cannot** override serviceability for one customer to bypass zone rules; cannot post credits |
| Accounts Operator / Manager | `role.acc.operator`, `role.acc.manager` | View credit/refund postings produced by option (C) | Cannot cancel a subscription |
| System | `role.system` | Issues credits from the approved adjustment, releases stock | Triggered only by `confirmScheduleChange` |

Denied actor for abuse test: **Admin support user** attempting to mark Z-X as serviceable for one customer, and **a customer** setting a tampered `serviceability = ok` field in the payload (SCT-19-P).

## 3. Sample data (HYPOTHETICAL BDT; integers in paisa)

| Item | Detail | Qty | Unit (paisa) | Line total (paisa) | Display |
|---|---|---|---|---|---|
| Subscription SUB-HYP-1901 | Kitchen K1, zone Z-A, state Active | | | | |
| Lunch obligations | 2026-11-02 to 2026-11-13, weekdays, `slot.lunch` | 10 | 18000 | 180000 | BDT 1,800.00 |
| Dinner obligations | Same dates, `slot.dinner` | 10 | 20000 | 200000 | BDT 2,000.00 |
| Delivery (per trip, per obligation) | BR-007 PENDING | 20 | 2000 | 40000 | BDT 400.00 |
| Total paid and verified | Invoice INV-HYP-1901 = payment PAY-HYP-1901 | | | **420000** | **BDT 4,200.00** |
| Prepaid obligation (LA-200) | After payment, before any delivery | | | 420000 | |
| New address | "Home 2", zone Z-X (unserved by K1) | | | | |
| Request time | 2026-11-01 Asia/Dhaka | | | | |
| Per-obligation credit under PROPOSED BR-006(a) incl. delivery trip avoided (option C) | Lunch 18000 + 2000 = 20000, dinner 20000 + 2000 = 22000 | 10 + 10 | | 200000 + 220000 = 420000 | |
| Candidate kitchen K2 (serves Z-X) | Lunch 19000, dinner 21000, delivery 2500 per trip | | | 10 x 21500 + 10 x 23500 = 450000 | BDT 4,500.00 |

## 4. Decision table

### 4.1 Steps

| # | Actors | Role claims | Service trigger | Source record | Precondition | Expected change | External dependency | Reversible? |
|---|---|---|---|---|---|---|---|---|
| 1 | Customer | `role.customer` | `saveAddress` (Home 2) | `ent.Address`, `ent.ServiceZone` v. current | Signed in | Address saved with `serviceability(K1) = not_serviceable`; no agreement changed | Optional map/geocoding provider | Yes (edit or delete address) |
| 2 | Customer | `role.customer` | `quoteScheduleChange` type address | SUB-HYP-1901 v7, 20 `ent.MealObligation` rows | Subscription Active; change cutoffs evaluated per obligation | Response lists per-obligation outcome; option (B) blocked; (A), (C), (D) conditional | None | Quote expires; no commitment |
| 3 | Customer | `role.customer` | `confirmScheduleChange` option (C) for all 20 | Quote Q-HYP-1902, obligations | Quote valid and unexpired; cutoffs still open for all 20; BR-005/BR-006 approved (otherwise command returns `failed-precondition`) | Agreement to Partially Modified or Cancelled; 20 obligations to Cancelled; 20 credits issued with unique origin; stock released | None | Credits voidable only by governed adjustment; cancellation not reversible |
| 4 | System | `role.system` | `issueCredit` x20, `releaseStock` x20 | Obligation ids | Step 3 committed | `ent.CreditTransaction` per obligation; capacity restored | None | Compensating entries only |
| 5 | Supplier | `role.supplier` | Read | Forecast projection | Step 3 committed | Forecast and capacity updated (NS-04, NS-05) | None | Not applicable |
| 6 | Customer (option D) | `role.customer` | `createSubscriptionDraft` with K2, `createQuote`, `confirmQuote`, payment | New agreement | Customer consent; BR-021 allows; K2 serves Z-X | New agreement and payment (WF-C); old agreement handled per step 3 or left unchanged | Gateway (see SC-13) | Per WF-C |

### 4.2 Five observations and interface update moments (option C path)

| Observation | Meaning here | Customer | Supplier | Rider | Admin | Accounts |
|---|---|---|---|---|---|---|
| Request received | `quoteScheduleChange` or `confirmScheduleChange` arrives | Spinner on the review button; address list shows the saved address with a "not served by this kitchen" badge once step 1 commits | Nothing | Nothing | Exception queue unchanged | Nothing |
| Command accepted | Cancellation and credits committed in one transaction (or per-obligation batches, section 6) | Obligations switch to Cancelled, credit rows appear in NC-11, change history in NC-15 | Forecast and capacity updated after outbox projection; notice that portions were released | No assignment existed; nothing | Audit event and change record visible | Credit liability line appears in credit liability view (NF-09) |
| Funds externally confirmed | **Not applicable for credit**; for a cash refund variant the gateway confirms later | Credit is usable immediately; a refund (if approved) shows Pending then Refunded only after provider confirmation (NC-17) | Nothing | Nothing | Nothing | Refund appears in reconciliation only after confirmation |
| Service delivered | **Not applicable.** Cancelled obligations are never delivered; no earning recognised | Nothing | No supplier earning for cancelled meals | No rider earning | Nothing | No recognition journal |
| Liability extinguished | Prepaid obligation (LA-200) is replaced by service-credit liability (LA-210); extinguished only when credit is consumed or voided | Credit balance shown as available | Nothing | Nothing | Nothing | LA-200 reduced by 420000, LA-210 increased by 420000 |

## 5. Sequence

```mermaid
sequenceDiagram
    autonumber
    actor Cust as Customer
    participant App as Customer App
    participant BE as Trusted Command Boundary
    participant Zone as Zone Service
    participant FS as Operational Store
    participant Led as Ledger Store
    participant Sup as Supplier Workspace
    participant Rid as Rider Workspace
    participant Adm as Admin Web
    participant Acc as Accounts Web
    Cust->>App: Add address Home 2
    App->>BE: saveAddress requestId R1
    BE->>Zone: Evaluate serviceability for K1
    Zone-->>BE: Z-X not served by K1
    BE->>FS: Save address with not serviceable flag and receipt R1
    BE-->>App: Saved, not serviceable for K1
    Cust->>App: Apply to subscription
    App->>BE: quoteScheduleChange SUB-HYP-1901 address Home 2
    BE->>FS: Read 20 obligations and cutoffs
    BE-->>App: Option B blocked, options A C D conditional, quote Q-HYP-1902
    Cust->>App: Choose cancel with remedy and confirm
    App->>BE: confirmScheduleChange Q-HYP-1902 requestId R2 expectedVersion 7
    BE->>FS: Re-evaluate cutoffs and cancel obligations
    BE->>Led: Post credit journals via issueCredit
    BE->>FS: Release stock, write audit and outbox
    BE-->>App: Accepted with receipt R2
    FS-->>Sup: Forecast and capacity projection
    FS-->>Adm: Change record and audit
    Led-->>Acc: Credit liability view
    Note over Rid: No assignment existed. No update.
```

**Textual sequence.** Save address, server marks it unserved for K1. Customer asks to apply it; server answers with per-obligation outcomes and blocks option B. Customer picks option C and confirms; server re-evaluates cutoffs, cancels, issues twenty credits with unique origin, releases stock, and writes audit and outbox in committed steps. Supplier, Admin and Accounts read models update after the outbox projection.

**Human approval checkpoints.** (1) Customer explicit confirmation of the conditional quote. (2) Policy approval of BR-005/BR-006 before option C can be enabled (a configuration gate, not a per-case approval). (3) If option C would exceed an approval limit or involves cash refund, Accounts approval under BR-020 (maker not equal to checker). (4) Admin approval of any zone-table change (NA-02) is a separate governance event and never a per-customer override.

## 6. Commands, idempotency and transaction boundaries

| Command | Stable logical operation id | Atomic boundary | Immutable event | Duplicate / failure handling |
|---|---|---|---|---|
| `saveAddress` | `op.saveAddress.<customerId>.<addressFingerprint>` | Address + serviceability result + receipt + audit | `AddressSaved` (zone table version recorded) | Same request id returns same result |
| `quoteScheduleChange` | `op.quoteScheduleChange.<subId>.<v7>.<changeHash>` | Quote snapshot + receipt | `ScheduleChangeQuoted` | Re-run yields same quote or a new one if inputs changed |
| `confirmScheduleChange` | `op.confirmScheduleChange.<quoteId>` | Subscription version bump + obligation transitions + receipt in the operational store; ledger writes keyed by `op.issueCredit.<obligationId>` | `ScheduleChanged` with before and after obligation states and quote id | Same key returns stored result; a stale quote (cutoff or version changed) returns `QUOTE_STALE` and writes nothing |
| `issueCredit` | `op.issueCredit.<obligationId>.skip_or_cancel` | One journal + one `ent.CreditTransaction` with unique origin (obligationId, reason) | `CreditIssued` | Unique origin constraint makes a repeat a no-op (INV-08) |
| `releaseStock` | `op.releaseStock.<obligationId>` | Capacity row decrement guarded by reservation id | `StockReleased` | Idempotent |

Cross-store consistency: the operational store (Firestore) commits obligation transitions and an outbox row; a worker performs the ledger posting (PostgreSQL) per obligation using the operation ids above. Until a credit journal exists, the customer sees the obligation as Cancelled and the credit as **pending posting**, not as an available balance. A failed posting is retried with the same id (retry), never compensated unless the cancellation itself is reversed by a governed adjustment (compensating entry). There is no mutable "credit balance" field; the balance is derived from `ent.CreditTransaction` and journals (INV-07, INV-20).

## 7. Event and ledger trace

Pre-state (from the earlier payment, shown for context): Dr LA-110 gateway clearing 420000, Cr LA-200 prepaid obligation 420000.

**Option A, B (blocked), D-start:** no journal.

**Option C, PROPOSED credit path (conditional on approval of BR-005/BR-006; amounts HYPOTHETICAL).** One journal per obligation; the first lunch and first dinner shown, the other eighteen are identical in form.

| Journal | Account | Debit (paisa) | Credit (paisa) |
|---|---|---|---|
| J-1 (lunch 2026-11-02, origin OBL-L01) | LA-200 Customer prepaid obligation | 20000 | |
| | LA-210 Customer service-credit liability | | 20000 |
| J-2 (dinner 2026-11-02, origin OBL-D01) | LA-200 Customer prepaid obligation | 22000 | |
| | LA-210 Customer service-credit liability | | 22000 |
| J-3 to J-20 | Same pattern per obligation | 10 x 20000 + 10 x 22000 total across all 20 = 420000 | 420000 |

Check: sum of debits across J-1..J-20 = sum of credits = 420000 (INV-01). LA-200 for this subscription goes from 420000 to 0; LA-210 increases by 420000 (INV-06, INV-07). No supplier earning, rider earning or platform revenue is recognised because no meal was delivered (INV-13, INV-19).

**Cash-refund alternative (only if BR-005 approves):** replace LA-210 with LA-250 refunds payable on the credit side; on provider confirmation Dr LA-250, Cr LA-110. A customer receives either credit or refund for one obligation, never both (INV-17).

**Option D:** a new agreement with K2 posts per WF-C: Dr LA-110 450000, Cr LA-200 450000 after verified payment. The customer may use credit from option C against it (reserve and consume, see [SC-23](SC-23-promotional-vs-service-credit.md)); the application does not occur automatically.

## 8. Acceptance tests (Given/When/Then; planned, none executed)

| ID | Type | Given | When | Then |
|---|---|---|---|---|
| SCT-19-N | Normal | SUB-HYP-1901 Active with 20 paid obligations; Z-X not served by K1; BR-005/BR-006 approved with PROPOSED parameters in a test policy version | Customer saves Home 2, requests the change, confirms option C | Address saved with not-serviceable flag; option B blocked with explanation naming valid zones; 20 obligations Cancelled; 20 credits with distinct origins totalling 420000; stock released; LA-200 down 420000, LA-210 up 420000; Supplier forecast reduced; customer notified once; audit has quote id, before and after states. |
| SCT-19-P | Insufficient permission / abuse | Admin support user and a tampered client payload | Admin tries to set Z-X serviceable for this customer; customer sends `serviceability = ok` | Both rejected; no zone or agreement change; `AuthorizationDenied` / `ValidationRejected` audit events; the server recomputes serviceability and ignores client fields. A supplier editing the customer's subscription also fails. |
| SCT-19-C | Concurrent update | Quote Q-HYP-1902 exists; between quote and confirm, obligation 2026-11-02 lunch passes its cutoff (BR-022) and a second device confirms the same quote | Both confirmations arrive | At most one commits; evaluation uses the server clock at acceptance; the stale case returns `QUOTE_STALE` with a fresh option list; no partially changed state; no duplicate credits. |
| SCT-19-L | Lost response, committed effect | `confirmScheduleChange` commits and credits post, response lost | App retries with same `requestId` | Stored result returned; credit count still 20; receipt count 1; no second stock release. |
| SCT-19-X | Inconsistent third-party response | Geocoding provider returns a coordinate inside Z-A for a typed address whose administrative area is Z-X, or times out | `saveAddress` | Server treats the result as `unknown`, not serviceable; message asks the customer to confirm the area or choose another address; the customer's free-text label is not used; no obligation changes. |
| SCT-19-R | Recovery after partial failure | Cancellation committed for 20 obligations; ledger worker has posted 12 credit journals then crashed | Worker restarts | Remaining 8 are posted with the same operation ids; no duplicate for the first 12 (unique origin); customer's credit shows pending then available; reconciliation finds 20 journals and totals 420000; if cancellation had not committed, no credit would exist. |

Constraints that must agree: obligation states, `ent.CreditTransaction` count, journal count and sum, capacity rows, notification count, audit events (quote id common to all).

## 9. Screen states

| Screen | Mobile | Desktop | Accessible error text and next action | Offline fallback |
|---|---|---|---|---|
| C-02 / C-03 address | Saved address shows badge "Not available from this kitchen" with text, not colour alone | Same in a list with detail pane | "This area is outside the kitchen's delivery zone. Choose another address, another kitchen, or contact support." Actions: Choose address, Browse kitchens, Support (SH-04) | Address can be saved offline as local draft; serviceability shown as "to be checked" |
| NC-04 / NC-06 change review | Per-obligation list grouped by week, outcome chips with text labels | Calendar with side summary | "Some meals can no longer be changed because the cutoff has passed." Action: View affected meals | Review read-only from cache; confirm disabled with reason |
| NC-07 / NC-09 conditional quote | Banner "Not final until you confirm" | Table | "This price has changed. Refresh to see current options." Action: Refresh | Cannot confirm offline |
| NC-11 credit ledger | Credit rows labelled "pending posting" or "available" | Table | "Your credit is being recorded. It will appear shortly." Action: Check again | Cached balance marked "may be out of date" |
| NS-04 / NS-05 (supplier) | Forecast portions reduced with change reason | Table | "Order count changed." | Cached forecast labelled with time |

## 10. Links

[Common conventions](SCENARIO_INDEX.md#common-conventions-for-all-scenarios) · [Scenario index](SCENARIO_INDEX.md) · [Time and cutoff policy](../architecture/TIME_AND_CUTOFF_POLICY.md) · [Orders and subscriptions commands](../api/COMMANDS_ORDERS_AND_SUBSCRIPTIONS.md) · [Payments and COD commands](../api/COMMANDS_PAYMENTS_AND_COD.md) · [Customer credit rules](../payments/CUSTOMER_CREDIT_RULES.md) · [Pricing and billing](../payments/PRICING_AND_BILLING.md) · [Customer credits](../customer-app/CUSTOMER_CREDITS.md) · [Meal scheduling](../customer-app/MEAL_SCHEDULING.md) · [Financial data model](../database/FINANCIAL_DATA_MODEL.md) · [Policy decision register](../requirements/POLICY_DECISION_REGISTER.md) · [Business rules](../requirements/BUSINESS_RULES.md) · [Financial test cases](../testing/FINANCIAL_TEST_CASES.md) · Related: [SC-22](SC-22-multi-kitchen-custom-schedule.md), [SC-23](SC-23-promotional-vs-service-credit.md), [SC-07](SC-07-kitchen-stops-accepting-orders.md), [WF-C and WF-F](WORKFLOWS_A_TO_J.md)

## 11. Unapproved assumptions flagged

1. Per-kitchen serviceability and the fail-closed rule for `unknown` are PROPOSED.
2. Option C amounts follow PROPOSED BR-006(a) with the delivery component credited because the trip is avoided; BR-007 is PENDING and could exclude it.
3. Cash refund versus credit choice is not approved (BR-005); the credit path is shown only to make arithmetic checkable.
4. Option D as a new agreement relies on the PROPOSED BR-021 default.
5. Nothing here is implemented or verified; a toast in the prototype (C-03 "not saved") is not evidence of address handling.
