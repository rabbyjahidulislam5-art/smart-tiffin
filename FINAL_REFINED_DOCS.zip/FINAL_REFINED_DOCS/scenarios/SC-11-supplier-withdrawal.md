# SC-11 — Supplier asks to withdraw earnings

| Field | Value |
|---|---|
| Scenario ID | SC-11 |
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author S2 (scenarios); scenario owner for review: Accounts & Finance lead (to be identified) |
| Purpose | Specify how a supplier sees expected, earned, held and available balances, requests a payout, and how Accounts reviews, approves, releases and externally confirms it, so that a request is never treated as a payment. |
| Applies to | PAR-S (Supplier workspace), ACC (Accounts Web), ADM (limited view), BE, ledger store (PG), operational store (FS), payout processor or bank |
| Depends on | [Supplier earnings](../partner-app/SUPPLIER_EARNINGS.md), [Supplier settlement](../accounts-web/SUPPLIER_SETTLEMENT.md), [Payout management](../accounts-web/PAYOUT_MANAGEMENT.md), [Earnings and payouts commands](../api/COMMANDS_EARNINGS_AND_PAYOUTS.md), [financial data model](../database/FINANCIAL_DATA_MODEL.md), [glossary](../requirements/GLOSSARY_AND_TERMINOLOGY.md), [conventions](../analysis/CONVENTIONS_AND_ID_REGISTER.md) |
| Authoritative policies | [BR-010 / DEC-020](../requirements/POLICY_DECISION_REGISTER.md) (supplier earning recognition event), [BR-014 / DEC-024](../requirements/POLICY_DECISION_REGISTER.md) (thresholds, frequency, holds, destinations), [BR-015 / DEC-025](../requirements/POLICY_DECISION_REGISTER.md) (disputes), [BR-020 / DEC-030](../requirements/POLICY_DECISION_REGISTER.md) (approval limits, maker-checker), [BR-009 / DEC-019](../requirements/POLICY_DECISION_REGISTER.md) (commission, context). All PENDING. |
| Invariants exercised | INV-01, INV-02, INV-03, INV-04, INV-09, INV-14, INV-15, INV-20 |
| Design references | S-08, S-09 (legacy, prototype status U), NS-01, NS-02, NS-03, NF-05, NF-07, NF-08, NF-13, NA-05, SH-01 |
| Status | Draft for review. Nothing implemented, tested or approved. All BDT figures are HYPOTHETICAL. Provenance: USER-REQ (SC-11) plus PROPOSED engineering detail. |

## 1. Domain situation

**Restated.** A verified supplier opens the earnings screens and sees distinct figures: expected sales (committed but not yet fulfilled), earned amount (recognised at the approved event), portions held because of disputes, payouts already completed, and the amount currently available. The supplier requests a transfer. The transfer must not exceed the available amount. Accounts reviews the beneficiary account (ownership) and the orders behind the balance. The documentation separates five things that a prototype toast collapses into one: *approval*, *transfer attempted*, *processor response*, *bank confirmation*, and *failure recovery*. A request is not a payment.

**Refinements adopted (PROPOSED, not approved).**

1. Available balance is never stored as a mutable field. It is derived: recognised supplier earnings − holds − reservations for open payout requests − settled payouts − reversals (INV-09), computed from posted journal lines and hold records at a named ledger sequence number.
2. Submitting a request reserves its amount so that the same money cannot be requested twice. The reservation is a hold-type record, not a payment.
3. Payout state vocabulary is the confirmed one: Requested, Under Review, Approved, Processing, Settled, Failed, Rejected. "Settled" is reachable only through `recordPayoutResult` carrying external confirmation.
4. Approval checks the balance again at approval time and stores the ledger sequence number it used (INV-14).
5. The payout destination must be an approved, ownership-verified `ent.PayoutDestination`. A change of destination triggers re-verification before it is usable. No PIN or password is ever requested.
6. The processor's synchronous "accepted" is not settlement. Settlement needs bank or processor confirmation that is matched to the batch.

**Assumptions.** The processor or bank channel, its confirmation artefact, and whether transfer fees are borne by the platform or the supplier are undefined. They are written as `policy.payout.fee_bearer` (BR-014, PENDING) and are not computed in this document.

| Policy | Open question for SC-11 | Parameter used |
|---|---|---|
| BR-010 | Which milestone makes an amount "earned" | `policy.earning.supplier_recognition_event` |
| BR-014 | Minimum amount, frequency, destination types, hold reasons, release rules | `policy.payout.min_amount_minor`, `policy.payout.frequency`, `policy.payout.destination_types` |
| BR-015 | Who decides disputes, effect on held portions | `policy.dispute.hold_effect` |
| BR-020 | Dual-approval threshold | `policy.finance.dual_approval_threshold_minor` |

## 2. Actors, role claims and permissions outline

Claim and permission names are PROPOSED; reconcile with [AUTHORIZATION](../api/AUTHORIZATION.md).

| Actor | Role claim | Permissions used | Denied in this scenario |
|---|---|---|---|
| Supplier | `role.supplier` (approved, active, own kitchen) | `perm.payout.request` for own account; `perm.earnings.read` own | Reading another supplier's balance, approving, changing a destination without re-verification |
| Accounts Operator | `role.accounts.operator` | `perm.payout.review` (verify beneficiary, inspect orders, prepare batch) | Approving a payout it reviewed above the threshold |
| Payout Approver | `role.accounts.payout_approver` | `perm.payout.approve`, `perm.payout.reject` | Approving where it is also the reviewer or the batch creator |
| Accounts Manager | `role.accounts.manager` | `perm.payout.release_batch`, `perm.hold.place`, `perm.hold.release` | Editing journals |
| Financial Auditor | `role.accounts.auditor` | `perm.ledger.read`, `perm.audit.read` | All writes |
| Admin (operations) | `role.admin` | Aggregate view only (NA-05) | Approving, releasing or editing any payout or balance (the denied actor in SCT-11-P) |
| Another supplier | `role.supplier` | Own data only | Any access to this supplier's balance |
| Trusted backend | service principal | `postJournal`, processor client | Not invocable from clients |

## 3. Sample data definitions (HYPOTHETICAL BDT, integer paisa)

| Item | Identifier | Paisa | Display |
|---|---|---|---|
| Expected sales (future committed obligations, informational) | projection only | 300,000 | BDT 3,000.00 |
| Lifetime recognised supplier earnings (net of platform commission) | `ent.SupplierEarning` lines | 210,000 | BDT 2,100.00 |
| Completed payouts to date | PO-HYP-0001 settled | 50,000 | BDT 500.00 |
| Held, disputed portion | `ent.Hold` HLD-HYP-0030 | 30,000 | BDT 300.00 |
| **Available balance** = 210,000 − 50,000 − 30,000 | derived | **130,000** | **BDT 1,300.00** |
| Payout request A | PO-HYP-0002 | 120,000 | BDT 1,200.00 |
| Available after A is reserved | derived | 10,000 | BDT 100.00 |
| Over-request (rejected in a test) | attempt | 140,000 | BDT 1,400.00 |
| Competing requests (concurrency test) | PO-HYP-0003 and PO-HYP-0004 | 80,000 each | BDT 800.00 each |
| Minimum payout (illustration only, not policy) | `policy.payout.min_amount_minor` | 10,000 | BDT 100.00 |
| Dual-approval threshold (illustration only) | `policy.finance.dual_approval_threshold_minor` | 100,000 | BDT 1,000.00 |
| Beneficiary | PD-HYP-01, bank account shown as `••••4401`, holder name equals kitchen owner | — | masked |
| Settlement batch | SB-HYP-0007 | 120,000 | BDT 1,200.00 |
| Processor reference | PRC-HYP-3345 | — | — |
| Bank confirmation | BC-HYP-3345 | 120,000 | BDT 1,200.00 |

Principals: supplier `PR-SUP-01`, other supplier `PR-SUP-02`, operator `PR-ACC-OP-01`, approver `PR-ACC-PA-01`, manager `PR-ACC-MGR-01`, admin `PR-ADM-03`. All synthetic.

## 4. Decision table

### 4.1 Observations and their effects

| # | Observation | Actors and role claims | Service trigger | Source record | Precondition | Expected change | External dependency | Reversible? |
|---|---|---|---|---|---|---|---|---|
| O1 | Request received | Supplier, `role.supplier` | `requestPayout` from NS-02 reaches the trusted boundary | Client envelope | Authenticated, active grant, own account | None. Envelope authenticated and fingerprinted. | None | Yes |
| O2 | Command accepted | Trusted backend for the supplier | Request recorded, amount reserved | New `ent.PayoutRequest` PO-HYP-0002, balance snapshot at ledger sequence S1, reservation hold | Destination verified and active, amount ≤ available at S1, amount ≥ `policy.payout.min_amount_minor`, no conflicting reservation | PayoutRequest Requested. Available balance for display falls from 130,000 to 10,000 (reserved, not paid). **No settlement journal.** | None | Yes: supplier cancel, Accounts reject, or expiry releases the reservation |
| O2b | Review, approval, batch, release (internal checkpoints between O2 and O3) | Operator reviews, Approver approves, Manager releases. `role.accounts.operator`, `role.accounts.payout_approver`, `role.accounts.manager` | `reviewPayout`, `approvePayout`, `createPayoutBatch`, `releasePayoutBatch` | `ent.PayoutApproval`, `ent.SettlementBatch` SB-HYP-0007 | Beneficiary ownership verified; orders inspected; balance re-checked at approval (INV-14); maker ≠ checker (INV-15) | Under Review → Approved → Processing. At release, journal JE-HYP-2001 moves the amount from supplier payable to settlement clearing. | Processor instruction submitted with a stable idempotency reference | Before release: reject or cancel. After release: only via failure result and compensating reversal |
| O3 | Funds externally confirmed | Trusted backend, Accounts Operator | `recordPayoutResult` with processor and bank confirmation matched to SB-HYP-0007 | `ent.PayoutResult`, bank confirmation BC-HYP-3345 | Batch Processing; confirmation amount and beneficiary match | Payout Settled; journal JE-HYP-2002 clears settlement clearing against cash | Processor callback or bank statement | Compensating only if confirmation is later withdrawn by the bank |
| O4 | Service delivered | No actor. Meals were delivered and earnings recognised before the request | Recognition events from earlier fulfilment | `ent.SupplierEarning` lines referencing source obligations | Recognised | **No change.** Review inspects these lines; the payout does not alter them. | None | Not applicable |
| O5 | Liability extinguished | Trusted backend | Posting of JE-HYP-2002 | `ent.JournalEntry`, `ent.JournalLine` | O3 | Supplier payable stays reduced by 120,000 permanently; settlement clearing returns to zero; payout history entry becomes immutable | None | Compensating only |

### 4.2 Interface update moments

| # | Customer app | Supplier workspace (S-08, NS-01, NS-02, NS-03) | Rider workspace | Admin web (NA-05) | Accounts web (NF-05, NF-07, NF-08, NF-11, NF-13) |
|---|---|---|---|---|---|
| O1 | No change. Customers never see supplier finance. | Submit shows a local "Sending" state only. Balance unchanged. | No change. A rider has no access to supplier balances. | No change. | No change. |
| O2 | No change. | On receipt: NS-02 shows Requested with the stable receipt reference. Available shows BDT 100.00 and a separate "Reserved for payout BDT 1,200.00" line. NS-03 gains the request. | No change. | Aggregate "payout requests pending" count may rise. No supplier detail. | NF-07 queue gains the request with balance snapshot, destination, and linked earnings. NF-05 shows the reservation. |
| O2b | No change. | Status moves Under Review, Approved, Processing as each authoritative commit projects. Processing text: "Transfer sent to the processor. Not yet confirmed." | No change. | Aggregates only. | Each step shows actor identity. NF-08 batch shows Processing. NF-11 shows JE-HYP-2001. |
| O3 | No change. | NS-03 shows Settled and the receipt only after the confirmation commit. Notification `ntf.payout.settled`. | No change. | Aggregates fall. | NF-08 shows Settled with processor and bank references. NF-11 shows JE-HYP-2002. |
| O4 | Unchanged. | Earned amount lines unchanged (NS-01). | Unchanged. | Unchanged. | NF-05 recognised earnings unchanged. |
| O5 | Unchanged. | Lifetime paid increases to 170,000; available stays BDT 100.00. | No change. | Aggregate payables fall. | NF-01 supplier payables metric falls by 120,000; NF-13 shows no open exception. |

## 5. Sequence diagram

```mermaid
sequenceDiagram
    autonumber
    participant CA as Customer app
    participant PA as Partner app Supplier
    participant AW as Admin web
    participant ACW as Accounts web
    participant BE as Trusted backend
    participant FS as Firestore
    participant LS as Ledger store
    participant GW as Payout processor and bank
    participant NT as Notification service

    PA->>BE: requestPayout requestId P1 amount 120000 destination PD-HYP-01
    BE->>LS: derive available at ledger sequence S1 from journal lines and holds
    BE->>LS: one transaction - receipt, PayoutRequest Requested, reservation, audit, outbox
    LS-->>BE: committed
    BE-->>PA: receipt RC-HYP-9101 status Requested
    BE->>FS: outbox projects request and reduced available
    BE->>NT: ntf.payout.requested to Accounts queue
    ACW->>BE: reviewPayout by Operator - beneficiary and orders checked
    Note over ACW,BE: Human checkpoint - Approver differs from Operator and Batch creator
    ACW->>BE: approvePayout by Approver
    BE->>LS: recheck available at S2, record sequence, state Approved, audit
    ACW->>BE: createPayoutBatch then releasePayoutBatch by Manager
    BE->>LS: one transaction - batch Processing, JE-HYP-2001, audit, outbox
    BE->>GW: transfer instruction with idempotency reference SB-HYP-0007
    GW-->>BE: accepted PRC-HYP-3345 not final
    GW-->>BE: bank confirmation BC-HYP-3345 amount 120000
    BE->>LS: recordPayoutResult - Settled, JE-HYP-2002, audit, outbox
    BE->>FS: outbox projects Settled
    BE->>NT: ntf.payout.settled to supplier
    NT-->>PA: notification
    Note over CA,AW: Customer app untouched, Admin web sees aggregates only
```

**Short text sequence.** (1) Supplier submits; the backend reserves the amount and returns a receipt (O1, O2). (2) An operator verifies the beneficiary and inspects the orders; a different approver approves after a fresh balance check. (3) A manager creates and releases the batch; the ledger moves the amount from supplier payable to settlement clearing and the processor receives one idempotent instruction (O2b). (4) Only the matched bank or processor confirmation produces Settled and the cash journal (O3, O5).

**Human approval checkpoints.** (a) Beneficiary ownership check by the Operator. (b) Approval by a Payout Approver who is neither reviewer nor batch creator (INV-15). (c) Release by the Manager. (d) Manual investigation of any unconfirmed Processing batch.

## 6. Commands, idempotency and transaction boundaries

| Command | Logical operation id | Atomic boundary | Duplicate defence | Failure class |
|---|---|---|---|---|
| `requestPayout` | `op:payout-req:{supplierId}:{clientRequestId}` plus unique reservation keyed on `{supplierId, ledgerSequence}` | Receipt, PayoutRequest, reservation, audit, outbox in one ledger-store transaction | Per-principal requestId returns the stored receipt; optimistic check on the account's ledger sequence rejects a competing request that would overdraw | Retry safe; over-draw is a business rejection, not a retry |
| `reviewPayout` | `op:payout-review:{payoutId}` | Review record, state, audit | One review per state transition | Retry safe |
| `approvePayout` / `rejectPayout` | `op:payout-approve:{payoutId}` | Approval row with sequence number used, state, audit | Unique approval per payout; reject if approver equals reviewer or maker | Retry safe |
| `createPayoutBatch` | `op:batch-create:{sortedPayoutIds hash}` | Batch row, membership rows | Unique membership: a payout belongs to one open batch | Retry safe |
| `releasePayoutBatch` | `op:batch-release:{batchId}` | State Processing, JE-HYP-2001, outbox that sends the instruction | Unique release per batch; processor idempotency reference = batch id | Pending → retry (resend only after querying the processor) |
| `recordPayoutResult` | `op:payout-result:{batchId}:{processorEventId}` | Result row, state Settled or Failed, journal, audit | Unique processor event id; one terminal result per batch line | Retry safe; compensating entry on failure |
| `placeHold` / `releaseHold` | `op:hold:{payoutOrAccountId}:{reasonCode}:{seq}` | Hold row, audit | Unique per reason and sequence | Retry safe |

**Rules.**

- *Stable logical operation id*: every command derives it from business keys; client `requestId` only identifies a retry of one call.
- *Immutable before and after*: each transition writes an `ent.AuditEvent` with before and after state hashes, actor, grant version, reason and receipt.
- *Independent reconciliation*: processor callbacks and bank statement lines are ingested independently and matched to batches by reference and amount. A duplicate callback is stored and deduplicated by processor event id. A callback with no matching batch goes to NF-13.
- *Pending versus retry versus compensating*: Processing without confirmation is *pending*, resolved by querying the processor with the same reference (never by sending a second instruction). A lost response is a *retry* of the same command. A confirmed failure is closed by a *compensating* reversal of JE-HYP-2001 and release of the reservation.
- *No mutable summary*: supplier balance cards (S-08, NS-01) are queries over journal lines, holds and events at a stated sequence number; no editable `supplier.balance` exists.

## 7. Event and ledger trace

### 7.1 Events

| Seq | Event | Actor | Before → after | Journal |
|---|---|---|---|---|
| 1 | `evt.payout.requested` | `PR-SUP-01` | none → Requested; reservation 120,000 | none |
| 2 | `evt.payout.review_completed` | `PR-ACC-OP-01` | Requested → Under Review (beneficiary verified) | none |
| 3 | `evt.payout.approved` | `PR-ACC-PA-01` | Under Review → Approved; balance recheck at S2 | none |
| 4 | `evt.payout.batch_released` | `PR-ACC-MGR-01` | Approved → Processing | JE-HYP-2001 |
| 5 | `evt.payout.processor_accepted` | processor | no state change (acknowledgement stored) | none |
| 6 | `evt.payout.settled` | system on confirmation | Processing → Settled | JE-HYP-2002 |

### 7.2 Journals

**JE-HYP-2001** (release; INV-01, INV-09, INV-14)

| Line | Account | Debit | Credit |
|---|---|---|---|
| 1 | `acct.supplier_payable` | 120,000 | |
| 2 | `acct.settlement_clearing` | | 120,000 |
| | **Totals** | **120,000** | **120,000** |

**JE-HYP-2002** (confirmed settlement)

| Line | Account | Debit | Credit |
|---|---|---|---|
| 1 | `acct.settlement_clearing` | 120,000 | |
| 2 | `acct.bank_cash` | | 120,000 |
| | **Totals** | **120,000** | **120,000** |

**Failure compensation JE-HYP-2003** (if the bank returns the transfer): reverses JE-HYP-2001: Dr `acct.settlement_clearing` 120,000; Cr `acct.supplier_payable` 120,000. The reservation is released and the payout is Failed. If the transfer fee is charged on a failed attempt, its treatment follows `policy.payout.fee_bearer` (PENDING) and is not computed here.

Derived positions after JE-HYP-2002: supplier payable = 210,000 recognised − 50,000 earlier settled − 120,000 = 40,000, of which 30,000 is held, leaving 10,000 available (matches section 3).

## 8. Acceptance and integration tests

All planned, none executed. Abuse tests: SCT-11-P and SCT-11-X.

### SCT-11-N — Normal request to settlement

- **Given** available balance 130,000, destination PD-HYP-01 verified.
- **When** the supplier requests 120,000, the operator reviews, an independent approver approves, the manager releases, and the bank confirmation for 120,000 arrives.
- **Then** states pass Requested → Under Review → Approved → Processing → Settled; JE-HYP-2001 and JE-HYP-2002 each balance; the supplier sees Settled only after the confirmation commit; available shows BDT 100.00; payables metric falls by 120,000; notifications and audit events equal the number of transitions.

### SCT-11-P — Insufficient permission and over-request (abuse test)

- **Given** `PR-SUP-02`, `PR-ADM-03` and a request for 140,000 from `PR-SUP-01`.
- **When** `PR-SUP-02` calls `requestPayout` or reads PO-HYP-0002; `PR-ADM-03` calls `approvePayout`; `PR-SUP-01` requests 140,000.
- **Then** all fail closed before any write (`PERMISSION_DENIED`, `INSUFFICIENT_AVAILABLE_BALANCE`); no reservation; no journal; denied attempts audited with actor and reason; UI hiding is not relied upon.

### SCT-11-C — Concurrent requests

- **Given** available 130,000 and two requests of 80,000 sent at the same moment (for example from two devices).
- **When** both reach `requestPayout`.
- **Then** exactly one commits (reservation sequence check); the other returns `INSUFFICIENT_AVAILABLE_BALANCE`; total reserved never exceeds available (INV-14); a second concurrency case, a hold placed during approval, makes approval fail with `STALE_BALANCE` and require re-review.

### SCT-11-L — Lost response, successful server commit

- **Given** `releasePayoutBatch` committed and the instruction was sent, but the processor response and the client response were lost.
- **When** the job retries and the manager retries with the same requestId.
- **Then** the manager receives the stored receipt; the retry first queries the processor by reference SB-HYP-0007 and finds one transfer; no second instruction is sent; one JE-HYP-2001; the state stays Processing until confirmation.

### SCT-11-X — Inconsistent third-party response (abuse test)

- **Given** a batch in Processing.
- **When** the processor reports success but the confirmation names a beneficiary account or an amount (119,500) that differs from the batch, or a forged success callback arrives without a valid reference.
- **Then** the payout is not marked Settled; a reconciliation exception appears in NF-13 and the batch stays Processing under investigation; no cash journal; the supplier sees "Transfer sent, awaiting confirmation"; an authorised resolution is required.

### SCT-11-R — Recovery after partial failure

- **Given** a batch of three payouts where the bank rejects one and the Firestore projection fails for another.
- **When** results are recorded and projections retry.
- **Then** two payouts Settled, one Failed with JE compensation and reservation released; the supplier can submit a new request with a new logical operation; projections converge by event id; ledger totals and supplier statements still reconcile.

### 8.1 What must agree

| Layer | Must agree |
|---|---|
| Database constraints | One reservation per ledger sequence, unique approval per payout, unique processor event id, balanced journals, no payout above available at approval |
| Notifications | One notification per state transition; Settled notification only after confirmation commit |
| Audit | One event per accepted command and each denied attempt |
| Journals | Release and settlement journals both present for every Settled payout; reversal present for every Failed one |
| Read models | NS-01 and S-08 totals equal ledger-derived values at the displayed sequence |

## 9. Screen states

| Screen | App | State | Accessible text (key) | Next action | Offline fallback |
|---|---|---|---|---|---|
| NS-02 Payout request | PAR-S | Amount above available | "You can request up to BDT 1,300.00. Held funds cannot be requested." (`err.payout.over_available`) | Change amount | Draft saved locally; submit disabled offline with reason |
| NS-02 | PAR-S | Destination needs verification | "This account must be verified before payout." (`err.payout.destination_unverified`) | Open destination verification | Read-only |
| NS-03 Payout history | PAR-S | Processing | "Sent to the processor. Not confirmed yet." (`status.payout.processing`) | Wait or open details | Last known state with an as-of time |
| NS-03 | PAR-S | Failed | "The transfer did not complete. The amount is back in your balance." (`status.payout.failed`) | Submit a new request | Read-only |
| S-08 / S-09 (legacy) | PAR-S | Recorded versus transferred | Must not say "paid" until Settled (legacy S-09 notes "Recorded" is not a bank transfer) | None | Cached |
| NF-07 Payout request review | ACC | Self-review | "You prepared this payout. A different approver is required." (`err.sod.same_identity`) | Reassign | Not applicable |
| NF-08 Payout batch execution | ACC | Unconfirmed after processor accepted | "Waiting for bank confirmation. Do not resend." (`status.batch.awaiting_confirmation`) | Query processor, escalate | Read-only; release disabled |
| NA-05 | ADM | Limited | "Summary only." (`status.admin.limited`) | Request access | Cached aggregates |

Layouts follow [ACCOUNTS_SCREENS](../design/screens/ACCOUNTS_SCREENS.md) and [SUPPLIER_SCREENS](../design/screens/SUPPLIER_SCREENS.md). Errors are announced to assistive technology, not colour-only, and tolerate Bangla text expansion.

## 10. Links

| Kind | Link |
|---|---|
| Business rules | [POLICY_DECISION_REGISTER](../requirements/POLICY_DECISION_REGISTER.md) (BR-009, BR-010, BR-014, BR-015, BR-020) |
| API commands | [COMMANDS_EARNINGS_AND_PAYOUTS](../api/COMMANDS_EARNINGS_AND_PAYOUTS.md), [COMMANDS_LEDGER_AND_GOVERNANCE](../api/COMMANDS_LEDGER_AND_GOVERNANCE.md) |
| Entities | `ent.SupplierEarning`, `ent.Hold`, `ent.PayoutRequest`, `ent.PayoutApproval`, `ent.SettlementBatch`, `ent.PayoutResult`, `ent.PayoutDestination`, `ent.JournalEntry`, `ent.RequestReceipt`, `ent.AuditEvent` ([FINANCIAL_DATA_MODEL](../database/FINANCIAL_DATA_MODEL.md)) |
| Permissions | [AUTHORIZATION](../api/AUTHORIZATION.md), [USER_ROLES](../requirements/USER_ROLES.md) |
| Specifications | [SUPPLIER_EARNINGS](../partner-app/SUPPLIER_EARNINGS.md), [SUPPLIER_SETTLEMENT](../accounts-web/SUPPLIER_SETTLEMENT.md), [PAYOUT_MANAGEMENT](../accounts-web/PAYOUT_MANAGEMENT.md), [ADR-010](../adr/010-payout-maker-checker.md) |
| Tests | [FINANCIAL_TEST_CASES](../testing/FINANCIAL_TEST_CASES.md), [INTEGRATION_TEST_CASES](../testing/INTEGRATION_TEST_CASES.md) (SCT-11-N/P/C/L/X/R) |
| Runbooks | [SETTLEMENT_AND_RECONCILIATION_RUNBOOK](../operations/SETTLEMENT_AND_RECONCILIATION_RUNBOOK.md), [INCIDENT_RESPONSE](../operations/INCIDENT_RESPONSE.md) |
| Traceability | [REQUIREMENTS_TRACEABILITY_MATRIX](../requirements/REQUIREMENTS_TRACEABILITY_MATRIX.md) (FR-036, FR-038, INV-09, INV-14, INV-15) |
| Related scenarios | SC-12 (rider payout), SC-16 (override attempt), SC-24 (adjustment after payout) |

## 11. Unapproved assumptions flagged

1. The recognition event that makes an amount "earned" (BR-010) is not decided; the sample treats 210,000 as already recognised.
2. Minimum payout, frequency, destination types and hold rules (BR-014) are not decided; 10,000 is an illustration.
3. How a disputed hold is sized and released (BR-015) is not decided.
4. The approval threshold and the number of approvers (BR-020) are not decided.
5. Fee bearer and the processor or bank confirmation format are undefined; no real processor or account identifiers are used.
6. Chart-of-accounts names are PROPOSED.
7. Whether a supplier may cancel a Requested payout, and any expiry of reservations, is not decided.
8. Nothing here is implemented or tested. A "payout recorded" toast, as in the legacy S-09 and A-13 prototypes, is never evidence that money moved.
