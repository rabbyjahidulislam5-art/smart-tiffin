# SC-01 — Monthly prepaid service before kitchen fulfilment

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | CUS, PAR-Supplier, ACC, BE |
| Depends on | [Custom subscription engine](../customer-app/CUSTOM_SUBSCRIPTION_ENGINE.md), [Supplier earnings](../partner-app/SUPPLIER_EARNINGS.md), [Financial data model](../database/FINANCIAL_DATA_MODEL.md) |
| Authoritative policies | BR-002, BR-006, BR-009, BR-010 — all PENDING |
| Invariants exercised | INV-01, INV-06, INV-09, INV-13, INV-18 |
| Status | Draft. All BDT figures HYPOTHETICAL. Nothing implemented. |

## 1. Domain situation
A customer pays 7,200.00 BDT upfront for a month of lunch+dinner (52 meals). The platform must recognise verified cash and an unfulfilled-service liability (`customer_prepaid_obligation`), not revenue. Supplier/rider pay accrues only at their own recognition events (BR-010/BR-011), never from the customer's payment alone. Mid-month: two lunches are skipped (credit), the kitchen changes mid-month (BR-024), and one dinner is cancelled outright with no replacement.

## 2. Actors and permissions
Customer (own agreement, `perm.sub.manage_own`); Supplier (own obligations, `perm.catalogue.manage_own`); Accounts Operator/Manager (ledger, read/approve); Admin (no balance access). Denied: Admin attempting to view the ledger directly (routed to NA-05 aggregate only).

## 3. Sample data (HYPOTHETICAL)
Quote total 720,000 paisa. Per-meal price ≈ 13,846 paisa (illustrative). Two skipped lunches credit ≈ 27,692 paisa. One cancelled dinner (no replacement, BR-005 pending) refund/credit ≈ 13,846 paisa.

## 4. Decision table
| Observation | Trigger | Expected change | Interfaces updated |
|---|---|---|---|
| Request received | `confirmQuote` | none | CUS shows "processing" |
| Command accepted | `placeOneTimeOrder`-equivalent for subscription draft | Draft created | CUS |
| Funds externally confirmed | Gateway IPN validated | `cash_and_clearing` Dr / `customer_prepaid_obligation` Cr 720,000 | CUS (Active), ACC (NF-01 receivable) |
| Service delivered | Each meal obligation fulfilled | Partial recognition per meal | PAR-Supplier (earned balance), ACC |
| Liability extinguished | Full month fulfilled or cancelled/credited | `customer_prepaid_obligation` reduced to 0 | CUS, ACC |

## 5. Sequence (textual + Mermaid)
```mermaid
sequenceDiagram
  participant C as Customer App
  participant BE as Trusted backend
  participant PG as Ledger
  participant S as Supplier workspace
  C->>BE: confirmQuote + placeOneTimeOrder(subscription)
  BE->>PG: post prepaid-obligation journal (on verified payment)
  loop each fulfilled obligation
    BE->>PG: recognizeSupplierEarning (partial)
  end
  C->>BE: skipMeals (2 lunches)
  BE->>PG: issueCredit
  Note over BE,PG: Kitchen change mid-month routed via SC-07 continuity decision
```
Human checkpoint: none beyond the customer's own payment confirmation and Accounts' period-close review.

## 6. Commands, idempotency, transactions
`confirmQuote`/`placeOneTimeOrder`/`skipMeals` each use `(uid, requestId)` receipts plus natural keys (one credit per skip origin, INV-08). The recognition job is idempotent per obligation (INV-19-equivalent for suppliers).

## 7. Event and ledger trace
Journal 1 (payment verified): Dr cash_and_clearing 720,000 / Cr customer_prepaid_obligation 720,000. Journal 2 (per-meal recognition, illustrative one week ≈ 180,000 fulfilled): Dr customer_prepaid_obligation 180,000 / Cr supplier_payable 162,000 / Cr platform_revenue 18,000. Journal 3 (two skips): Dr customer_prepaid_obligation 27,692 / Cr customer_credit_liability 27,692.

## 8. Acceptance tests (planned, SCT-01-*)
SCT-01-N: full month fulfilled, prepaid obligation reaches zero exactly. SCT-01-P: a supplier attempts to recognise its own earning without the recognition event — rejected. SCT-01-C: two skip requests for the same meal race — one credit only. SCT-01-L: lost response on skip, retried — one credit (SC-04 pattern). SCT-01-X: gateway reports an inconsistent status post-payment — order stays pending, not guessed. SCT-01-R: recovery after a partial outbox failure — recognition eventually consistent, no duplicate.

## 9. Screen states
CUS billing (C-20, NC-13): shows prepaid liability declining as meals are fulfilled, not a flat "paid" badge. PAR-Supplier (S-08, NS-01): earned vs expected shown separately.

## 10. Links
[BR-002, BR-006, BR-009, BR-010](../requirements/POLICY_DECISION_REGISTER.md); [COMMANDS_ORDERS_AND_SUBSCRIPTIONS](../api/COMMANDS_ORDERS_AND_SUBSCRIPTIONS.md); [COMMANDS_EARNINGS_AND_PAYOUTS](../api/COMMANDS_EARNINGS_AND_PAYOUTS.md); related SC-04, SC-07.

## 11. Unapproved assumptions
Commission split (18,000/162,000), credit factor, and the mid-month kitchen-change resolution are all illustrative/PENDING.
