# SC-23 — Promotional credit versus paid service credit

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | CUS, BE |
| Depends on | [Customer credit rules](../payments/CUSTOMER_CREDIT_RULES.md) |
| Authoritative policies | BR-006, BR-008, BR-019, BR-025 — PENDING |
| Invariants exercised | INV-07, INV-08 |
| Status | Draft. HYPOTHETICAL. Nothing implemented. |

## 1. Domain situation
A promotional credit (its own eligibility, marketing incentive) and a service adjustment (from a skipped prepaid meal) must be stored separately, with correct application order and expiry decisions. The customer sees each credit's origin. A promotional incentive never becomes a cash refund unless separately approved. Negative balances are prevented; dispute reversals are supported.

## 2. Actors and permissions
Customer (uses credit at checkout); Accounts Manager (voids a credit if abused).

## 3. Sample data (HYPOTHETICAL)
Promotional credit 5,000 paisa (campaign `PROMO-HYP-01`, expires in 30 days — illustrative). Service credit 13,000 paisa (from a skip). Both on one `ent.CreditAccount`, distinguished by `type`.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | `consumeCredit` at checkout for an 18,000-paisa obligation |
| Command accepted | Application order (PROPOSED): service credit applied first, then promotional, or per an approved order |
| Funds externally confirmed | N/A |
| Service delivered | N/A yet |
| Liability extinguished | Both credit types reduced correctly; balance never negative (INV-07) |

## 5. Sequence
```mermaid
sequenceDiagram
  participant C as Customer App
  participant BE as Trusted backend
  C->>BE: confirmQuote (18000 due, credits available)
  BE->>BE: apply service credit 13000, then promo credit 5000
  BE->>BE: consumeCredit x2, remaining due 0
```

## 6. Commands, idempotency, transactions
Each `consumeCredit` call is scoped to one credit transaction id; applying two credit types in one checkout is two atomic consumptions within the same overall transaction, never a partial application visible mid-way.

## 7. Event and ledger trace
Journal: Dr customer_credit_liability 18,000 (13,000 service + 5,000 promo, tracked as two lines or two linked transactions) / Cr customer_prepaid_obligation 18,000.

## 8. Acceptance tests (SCT-23-*)
SCT-23-N: both credit types applied correctly and distinguishably in the receipt. SCT-23-P: a customer cannot apply another customer's credit. SCT-23-C: two checkouts attempt to consume the same promotional credit concurrently — one succeeds, balance never goes negative. SCT-23-L: consumption response lost, retried — one consumption. SCT-23-X: the promotional campaign is retroactively found to be abused (e.g. duplicate accounts) — `voidCredit` reverses only the promotional portion, service credit unaffected. SCT-23-R: recovery after a partial multi-credit consumption failure — both consumptions roll back together (single transaction) rather than leaving one applied and one not.

## 9. Screen states
NC-11 (credit ledger): shows each credit's class, origin and expiry (if any) distinctly.

## 10. Links
[BR-006, BR-008, BR-019, BR-025](../requirements/POLICY_DECISION_REGISTER.md); related SC-04.

## 11. Unapproved assumptions
The application order between credit types and the 30-day expiry are illustrative; BR-008/BR-019 have no approved value.
