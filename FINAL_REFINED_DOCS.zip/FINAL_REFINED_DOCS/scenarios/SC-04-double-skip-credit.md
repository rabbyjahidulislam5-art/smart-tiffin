# SC-04 — Attempted double skip credit

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | CUS, BE |
| Depends on | [ADR-008](../adr/008-idempotent-command-envelope.md), [Customer credits](../customer-app/CUSTOMER_CREDITS.md) |
| Authoritative policies | BR-006 — PENDING |
| Invariants exercised | INV-04, INV-08 |
| Status | Draft. HYPOTHETICAL figures. Nothing implemented. |

## 1. Domain situation
A user taps Skip twice on a slow connection, then retries after reopening the app. Only one eligible meal status change and one bounded credit issuance may occur. Idempotency keys and a unique adjustment-origin constraint must guarantee this even across a lost response and an app restart.

## 2. Actors and permissions
Customer (own obligation only, `perm.sub.skip_own`).

## 3. Sample data (HYPOTHETICAL)
One lunch obligation, 13,000 paisa, eligible credit factor 1.0 → credit 13,000.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received (tap 1) | `skipMeals` reaches backend |
| Request received (tap 2, same requestId, same session) | Same envelope |
| Command accepted | Receipt written, obligation → Skipped, credit 13,000 issued once |
| Funds externally confirmed | N/A (no cash movement) |
| Service delivered | N/A (meal never prepared) |
| Liability extinguished | `customer_prepaid_obligation` reduced by 13,000, `customer_credit_liability` increased by 13,000 |

## 5. Sequence
```mermaid
sequenceDiagram
  participant C as Customer App
  participant BE as Trusted backend
  participant PG as Ledger
  C->>BE: skipMeals requestId R1 (tap 1, lost response)
  BE->>PG: commit (obligation Skipped, credit issued)
  C->>BE: skipMeals requestId R1 (tap 2, same request)
  BE-->>C: replayed result (receipt RC-1)
  C->>BE: skipMeals requestId R2 (app restart, user retries same obligation)
  BE-->>C: ALREADY_SKIPPED referencing RC-1, no new credit
```

## 6. Commands, idempotency, transactions
`skipMeals` keyed by `(uid, requestId)` for the immediate retry, and by `(obligationId)` unique-skip constraint for the cross-session retry (INV-08). Both paths return the original receipt, never a second credit.

## 7. Event and ledger trace
One journal only: Dr customer_prepaid_obligation 13,000 / Cr customer_credit_liability 13,000, regardless of how many requests arrived.

## 8. Acceptance tests (SCT-04-*)
SCT-04-N: a single skip produces exactly one credit. SCT-04-P: a different customer's obligation cannot be skipped by this principal. SCT-04-C: two tabs/devices send the skip concurrently — one commits, one replays. SCT-04-L: the exact lost-response case above — one credit, stable receipt shown on reopen. SCT-04-X: the server's response is corrupted in transit — client retries safely with the same requestId. SCT-04-R: app crash between send and receive — on relaunch, a read-by-requestId (or by obligation state) shows the already-skipped state, no re-skip offered.

## 9. Screen states
NC-09 (skip request): after the first tap, the button becomes disabled and shows "Confirming…"; on reopen, if already skipped, shows the stable receipt reference and credit amount, never a chance to skip again.

## 10. Links
[BR-006](../requirements/POLICY_DECISION_REGISTER.md); [api/API_SPECIFICATION §5.3](../api/API_SPECIFICATION.md); related SC-01, SC-06.

## 11. Unapproved assumptions
The credit factor and exact formula are PENDING (BR-006); this scenario only proves single-issuance, not the amount's correctness.
