# SC-25 — Role switching in one partner device

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | PAR-Supplier, PAR-Rider, BE |
| Depends on | [ADR-011](../adr/011-roles-claims-and-sessions.md), [Partner App architecture](../partner-app/PARTNER_APP_ARCHITECTURE.md) |
| Authoritative policies | BR-023 — PENDING |
| Invariants exercised | NFR-007, NFR-029 (no direct INV, but SC-25 is a security scenario) |
| Status | Draft. HYPOTHETICAL. Nothing implemented. |

## 1. Domain situation
One person may apply separately as supplier and rider; access must follow actual verified role assignments, not merely a tab switch. Whether one account may legitimately hold both roles is BR-023, PENDING. Shared notifications, profile fields and financial accounts must remain role-scoped, with correct logout and session expiry behaviour.

## 2. Actors and permissions
One principal holding both a Supplier grant and a Rider grant (once BR-023 approves this); each grant has its own workspace, balance and notification scope.

## 3. Sample data (HYPOTHETICAL)
Supplier balance (Kitchen X) 40,000 paisa eligible; Rider balance 15,000 paisa eligible — these must never be summed or confused.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | Principal switches workspace in the Partner App |
| Command accepted | `workspace` field in the envelope declares the active grant; server verifies the principal actually holds it |
| Funds externally confirmed | N/A |
| Service delivered | N/A |
| Liability extinguished | N/A — this scenario proves isolation, not a financial flow |

## 5. Sequence
```mermaid
sequenceDiagram
  participant P as Principal (one device)
  participant BE as Trusted backend
  P->>BE: requestPayout(workspace: supplier, amount: 40000)
  BE->>BE: verify active grant = supplier; balance check against supplier_payable only
  P->>BE: switch workspace to rider
  P->>BE: requestPayout(workspace: rider, amount: 15000)
  BE->>BE: verify active grant = rider; balance check against rider_payable only
```

## 6. Commands, idempotency, transactions
Every command carries the declared `workspace`; the server independently verifies the principal holds that grant and scopes every read/write to it. No command ever reads or writes across both workspaces in one call.

## 7. Event and ledger trace
Two entirely independent payout requests, each against its own payable account; no netting between them (absent a separate, explicit policy, which does not exist for supplier/rider cross-netting).

## 8. Acceptance tests (SCT-25-*)
SCT-25-N: both workspaces function independently with correctly scoped balances and notifications. SCT-25-P: a command declaring `workspace: supplier` from a principal who only holds a Rider grant is rejected. SCT-25-C: rapid workspace switching with in-flight requests from both — each request resolves against the workspace it declared, not whichever is currently displayed on screen. SCT-25-L: a workspace-switch UI action's confirmation is lost, retried — no duplicate switch, state converges correctly. SCT-25-X: a notification intended for the rider workspace is mistakenly delivered while the supplier workspace is active — rejected as a defect if it occurs; the design requires per-workspace notification scoping (SH-01@PAR-Supplier vs SH-01@PAR-Rider). SCT-25-R: recovery after sign-out — no workspace state or balance view from the prior session persists (fixes the legacy prototype's "sign-out doesn't clear Store" gap).

## 9. Screen states
Partner App workspace switcher: an explicit, deliberate action (not a passive tab), with a visible confirmation of which workspace is now active before any balance or assignment data loads.

## 10. Links
[BR-023](../requirements/POLICY_DECISION_REGISTER.md); [ADR-011](../adr/011-roles-claims-and-sessions.md); related SC-12.

## 11. Unapproved assumptions
BR-023 itself — whether dual-role accounts are permitted at all — is entirely PENDING; this scenario documents the isolation requirements that apply if it is approved.
