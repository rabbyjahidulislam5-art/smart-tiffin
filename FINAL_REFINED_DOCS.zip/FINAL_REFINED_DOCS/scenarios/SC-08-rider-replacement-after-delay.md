# SC-08 — Rider replacement after pickup delay

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | PAR-Rider, PAR-Supplier, CUS, ADM, BE |
| Depends on | [Rider modules](../partner-app/RIDER_MODULES.md), [api/COMMANDS_DELIVERY.md](../api/COMMANDS_DELIVERY.md) |
| Authoritative policies | BR-011 — PENDING |
| Invariants exercised | INV-19 |
| Status | Draft. HYPOTHETICAL figures. Nothing implemented. |

## 1. Domain situation
A rider experiences a breakdown before collecting a prepared order. Dispatch identifies a backup, changes assignment ownership once, and notifies the supplier and customer. The original rider's expected earnings are cancelled or adjusted by policy; only verified completion earns payout. Race conditions: both riders attempt pickup, or the old rider reconnects after being reassigned.

## 2. Actors and permissions
Original rider (loses access on reassignment); replacement rider (`perm.delivery.accept_offer`); Admin dispatcher (`perm.delivery.reassign`).

## 3. Sample data (HYPOTHETICAL)
Delivery fee 3,000 paisa, payable to whichever rider completes it.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | `reassignDelivery` by Admin dispatcher |
| Command accepted | Assignment moved to replacement rider; original rider's access revoked immediately |
| Funds externally confirmed | N/A |
| Service delivered | Replacement rider completes via `submitDeliveryProof` |
| Liability extinguished | `recognizeRiderEarning` for the replacement only; if the original rider's earning had been prematurely recognised, `earningReversed` is posted |

## 5. Sequence
```mermaid
sequenceDiagram
  participant R1 as Original rider
  participant A as Admin Web
  participant BE as Trusted backend
  participant R2 as Replacement rider
  R1--xBE: breakdown, no further action
  A->>BE: reassignDelivery(orderId, newRiderId)
  BE->>R1: access revoked (outbox)
  BE->>R2: assignment granted
  R2->>BE: confirmPickup, submitDeliveryProof
  BE->>BE: recognizeRiderEarning(R2) only
```

## 6. Commands, idempotency, transactions
`reassignDelivery` is a SAGA: operational reassignment in Firestore, paired with a reversing journal in PostgreSQL if R1's earning was already recognised, linked by one operation key — both steps complete or neither does.

## 7. Event and ledger trace
If R1 had been prematurely recognised: Dr rider_payable 3,000 (R1) / Cr customer_prepaid_obligation 3,000 (reversal), then Dr customer_prepaid_obligation 3,000 / Cr rider_payable 3,000 (R2, on actual completion).

## 8. Acceptance tests (SCT-08-*)
SCT-08-N: reassignment completes, only R2 is paid. SCT-08-P: R1 attempts to submit delivery proof after reassignment — denied, access already revoked. SCT-08-C: R1 and R2 both attempt pickup confirmation at the same moment — only one (R2, the assigned rider) succeeds. SCT-08-L: reassignment command's response is lost, retried — one reassignment, not two. SCT-08-X: R1's device reconnects after being offline and sends a stale pickup confirmation — rejected as the assignment no longer belongs to R1. SCT-08-R: recovery after the reversal journal posts but the notification to R1 fails — notification retried, ledger already correct.

## 9. Screen states
R-01/legacy and the new rider dashboard show "Reassigned — this delivery is no longer yours" immediately on access revocation.

## 10. Links
[BR-011](../requirements/POLICY_DECISION_REGISTER.md); [Workflow WF-J](WORKFLOWS_A_TO_J.md); related SC-21.

## 11. Unapproved assumptions
Whether R1 receives any partial compensation for work done before the breakdown is PENDING (BR-011).
