# SC-06 — Change to a cheaper lunch

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | CUS, PAR-Supplier, BE |
| Depends on | [Customer credit rules](../payments/CUSTOMER_CREDIT_RULES.md), [ADR-014](../adr/014-subscription-agreement-and-meal-obligations.md) |
| Authoritative policies | BR-006, BR-007, BR-008, BR-017, BR-018 — PENDING |
| Invariants exercised | INV-08, INV-17 |
| Status | Draft. HYPOTHETICAL figures. Nothing implemented. |

## 1. Domain situation
The selected substitute costs less than the already-paid scheduled lunch. The eligible credit/adjustment respects discounts, delivery grouping, refund policy and tax. Both the old and new meal versions are tracked. Supplier capacity decreases for the old item and increases for the new one without a duplicated production order. The credit is non-cash, never conflated with a bank reimbursement.

## 2. Actors and permissions
Customer (own obligation); Supplier (capacity read/write for its own kitchen, no direct balance access).

## 3. Sample data (HYPOTHETICAL)
Old price 20,000; new price 14,000; credit 6,000 paisa.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | `quoteScheduleChange` (downgrade) |
| Command accepted | Adjustment quote: direction "credit", amount 6,000 |
| Funds externally confirmed | N/A (credit only, no cash movement) |
| Service delivered | N/A yet |
| Liability extinguished | `confirmScheduleChange` applies: obligation → new meal; `issueCredit` 6,000; supplier capacity forecast decremented for old meal, incremented for new |

## 5. Sequence
```mermaid
sequenceDiagram
  participant C as Customer App
  participant BE as Trusted backend
  participant S as Supplier workspace
  C->>BE: quoteScheduleChange(replace, cheaper meal)
  BE-->>C: adjustmentQuote { direction: credit, amount: 6000 }
  C->>BE: confirmScheduleChange
  BE->>BE: issueCredit 6000; obligation -> new meal
  BE->>S: capacity forecast updated (old -1, new +1)
```

## 6. Commands, idempotency, transactions
One `issueCredit` per `adjustmentQuoteId` (INV-08); capacity decrement/increment is a single atomic step inside the same transaction as the obligation change, never two separate writes that could partially fail.

## 7. Event and ledger trace
Journal: Dr customer_prepaid_obligation 6,000 / Cr customer_credit_liability 6,000.

## 8. Acceptance tests (SCT-06-*)
SCT-06-N: downgrade confirmed, exactly one 6,000 credit, capacity correctly shifted. SCT-06-P: a foreign customer cannot confirm this change. SCT-06-C: concurrent downgrade and skip requests on the same obligation race — only one change applies, the other is rejected as stale (`expectedVersion`). SCT-06-L: lost confirmation response, retried — one credit. SCT-06-X: capacity service reports an inconsistent count after the shift — a reconciliation flag is raised, not silently trusted. SCT-06-R: recovery after a crash between credit issuance and capacity update — both complete atomically or neither does (single transaction).

## 9. Screen states
NC-10 (replacement quotation): shows the credit amount clearly labelled "service credit", never "refund".

## 10. Links
[BR-006, BR-017](../requirements/POLICY_DECISION_REGISTER.md); related SC-05.

## 11. Unapproved assumptions
Credit formula, discount and tax treatment on a downgrade are all PENDING.
