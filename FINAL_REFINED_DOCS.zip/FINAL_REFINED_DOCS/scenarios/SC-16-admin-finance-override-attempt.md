# SC-16 — Admin asks for finance override

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | ADM, ACC, BE |
| Depends on | [ADR-010](../adr/010-payout-maker-checker.md), [api/AUTHORIZATION.md](../api/AUTHORIZATION.md) |
| Authoritative policies | BR-020 — PENDING |
| Invariants exercised | INV-15 |
| Status | Draft. HYPOTHETICAL. Nothing implemented. |

## 1. Domain situation
An administrator needs operational context but attempts to approve a payout prepared by the same identity (or, for this scenario, attempts to approve any payout at all, since Admin holds no payout authority by design). Segregation of duties, scoped privileges and explicit approval thresholds must be enforced. The rejected action is visible without changing settled funds. The attempt is logged with an escalation path. A Super Admin title does not bypass this.

## 2. Actors and permissions
Admin / Super Admin (bounded, no implicit payout authority); the Accounts Operator who prepared the payout (denied self-approval, same-identity case).

## 3. Sample data (HYPOTHETICAL)
Payout request PR-HYP-77, 48,000 paisa, prepared by `PR-ACC-OP-01`.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | `approvePayout` called by `PR-ADM-03` (Admin) and separately by `PR-ACC-OP-01` (same preparer) |
| Command accepted | Neither call is accepted — both rejected before any write |
| Funds externally confirmed | N/A — rejected before this stage |
| Service delivered | N/A |
| Liability extinguished | No change; PR-HYP-77 remains Under Review |

## 5. Sequence
```mermaid
sequenceDiagram
  participant A as Admin Web
  participant Ac as Accounts Web (same identity as preparer)
  participant BE as Trusted backend
  A->>BE: approvePayout(PR-HYP-77)
  BE-->>A: PERMISSION_DENIED (no payout authority)
  Ac->>BE: approvePayout(PR-HYP-77) -- same principal as preparer
  BE-->>Ac: SEGREGATION_OF_DUTIES (maker == checker)
  Note over BE: Both denials logged as audit events; PR-HYP-77 unchanged
```

## 6. Commands, idempotency, transactions
`approvePayout` performs its preparer/approver identity check and role check **before** any write; a denied attempt writes only an audit event, never a partial approval.

## 7. Event and ledger trace
No journal is posted. The audit log gains two denied-attempt entries.

## 8. Acceptance tests (SCT-16-*)
SCT-16-N: an eligible, different-principal approver (PayAp) approves successfully — contrast case proving the system works normally. SCT-16-P: the Admin attempt above — rejected, logged. SCT-16-C: the self-approval attempt races with a legitimate approval from a different principal — the legitimate one wins if it arrives validly; the self-approval is rejected regardless of timing. SCT-16-L: the Admin's rejected call is retried — still rejected, no state drift. SCT-16-X: a forged claim attempts to present the Admin as a Payout Approver — rejected at the server-side role re-derivation step, never trusting a client-presented claim alone. SCT-16-R: no recovery needed — nothing committed.

## 9. Screen states
NA-05/NF-07: the Admin's view shows no approve action at all (not merely disabled — absent from the UI because the command is unavailable to that role); the Accounts self-approval attempt shows an explicit "A different approver is required" message.

## 10. Links
[BR-020](../requirements/POLICY_DECISION_REGISTER.md); [AUTHORIZATION](../api/AUTHORIZATION.md) §3; related SC-11.

## 11. Unapproved assumptions
The escalation path (who is notified of a repeated override attempt) is PROPOSED, not approved.
