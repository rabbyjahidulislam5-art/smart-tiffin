# SC-14 — Payment refund during partial subscription fulfilment

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation author (scenarios) |
| Applies to | CUS, ACC, BE |
| Depends on | [Refunds and adjustments](../accounts-web/REFUNDS_AND_ADJUSTMENTS.md), [Customer credit rules](../payments/CUSTOMER_CREDIT_RULES.md) |
| Authoritative policies | BR-005, BR-006, BR-015 — PENDING |
| Invariants exercised | INV-06, INV-17 |
| Status | Draft. HYPOTHETICAL. Nothing implemented. |

## 1. Domain situation
An order bundle contains both fulfilled and future meals. A dispute or cancellation results in a permitted partial refund and service-credit adjustment. The refundable base is computed from unfulfilled obligations only, minus approved fees and already-used credits. Never both a full cash refund and a duplicated equivalent credit. Journal reversals and a transparent receipt are required.

## 2. Actors and permissions
Customer (requests); Accounts Operator (prepares refund); Accounts Manager/Payout Approver (approves).

## 3. Sample data (HYPOTHETICAL)
Monthly bundle 720,000 paisa; 468,000 already fulfilled (13/26 meals); unfulfilled base 252,000; approved cancellation fee (illustrative) 10%: refundable 226,800.

## 4. Decision table
| Observation | Expected change |
|---|---|
| Request received | `requestCancellation` with reason |
| Command accepted | `cancelSubscription` records the decision |
| Funds externally confirmed | N/A — refund is outbound |
| Service delivered | Already-fulfilled 468,000 unaffected |
| Liability extinguished | `initiateRefund` for 226,800 approved, `recordRefundResult` confirms external execution |

## 5. Sequence
```mermaid
sequenceDiagram
  participant C as Customer App
  participant Ac as Accounts Web
  participant BE as Trusted backend
  C->>BE: requestCancellation
  Ac->>BE: initiateRefund(226800) -- prepared
  Ac->>BE: approve (different principal)
  BE->>BE: post refundApproved journal
  BE->>GW: execute refund (gateway/bank)
  BE->>BE: recordRefundResult (confirmed)
```

## 6. Commands, idempotency, transactions
`initiateRefund` checks for an existing credit against the same obligations before approving (INV-17); `recordRefundResult` is the only command that marks the refund Executed.

## 7. Event and ledger trace
Journal 1 (approval): Dr refunds_and_adjustments 226,800 / Cr customer_prepaid_obligation 226,800. Journal 2 (execution confirmed): Dr customer_prepaid_obligation 226,800 / Cr cash_and_clearing 226,800 (outbound).

## 8. Acceptance tests (SCT-14-*)
SCT-14-N: refund computed correctly from unfulfilled obligations only, one journal pair, receipt shown. SCT-14-P: the customer cannot self-approve their own refund. SCT-14-C: two refund requests for the same cancellation race — one processed. SCT-14-L: approval response lost, retried — one refund. SCT-14-X: the gateway refund API is temporarily unavailable — refund stays Approved-not-executed, never shown as completed. SCT-14-R: recovery after `recordRefundResult` partially fails to update the read model — projection retried, ledger unaffected.

## 9. Screen states
NF-10 (refund/chargeback management): shows the refundable-base calculation with its components; NC-17 (refund tracker): distinguishes credit from refund explicitly.

## 10. Links
[BR-005, BR-006, BR-015](../requirements/POLICY_DECISION_REGISTER.md); related SC-01, SC-23.

## 11. Unapproved assumptions
The 10% cancellation fee is illustrative only; BR-005 has no approved fee.
