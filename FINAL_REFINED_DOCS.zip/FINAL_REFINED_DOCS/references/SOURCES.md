# Source provenance and gaps

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (adds the two primary requirement sources and official-documentation references; original rows unchanged) |
| Owner | Documentation lead |
| Status | Original rows are the 2026-10-28/initial-2026-10-30 source record; new rows below record the four-application rewrite's sources. |

Updated 2026-10-30.

## 2026-10-30 extension — primary sources and official references

| Source | Observed / used | Limitation |
|---|---|---|
| Expanded master prompt (supplied in conversation, 2026-10-30) | Four-application architecture, finance domain, 25 scenarios, 55 proposed screens; preserved as [analysis/SOURCE_MASTER_PROMPT_DIGEST.md](../analysis/SOURCE_MASTER_PROMPT_DIGEST.md) | Not a file on disk; digest is a careful restatement, not a verbatim copy |
| Legacy prototype documentation (supplied in conversation, 2026-10-30) | 94-screen React prototype inventory; preserved as [analysis/SOURCE_LEGACY_PROTOTYPE_DIGEST.md](../analysis/SOURCE_LEGACY_PROTOTYPE_DIGEST.md) | Describes code not present in this repository; OBSERVED only as reported by its own author |
| Official SSLCOMMERZ developer documentation | **Not retrieved in this session** (no live web access confirmed during the payments authoring pass) | Every SSLCOMMERZ-specific field/endpoint in [payments/SSLCOMMERZ_INTEGRATION_PLAN.md](../payments/SSLCOMMERZ_INTEGRATION_PLAN.md) is marked "to verify before implementation" |
| Firebase official documentation (security rules, transactions, Functions, custom claims) | Cited by URL in [adr/002-trusted-command-boundary.md](../adr/002-trusted-command-boundary.md) and [api/AUTHORIZATION.md](../api/AUTHORIZATION.md); not independently re-fetched in this session | Treat as "to verify" alongside any version-specific claim |
| Managed PostgreSQL provider documentation | Not retrieved; no provider selected (ADR-005, DEC-010) | Open |
| WCAG / accessibility guidance | Referenced conceptually in [design/ACCESSIBILITY.md](../design/ACCESSIBILITY.md); not independently re-fetched | Open |
| Bangladesh payment/financial regulatory guidance | **Not researched.** Legal/regulatory questions are listed, not answered, in [security/AUDIT_AND_COMPLIANCE.md](../security/AUDIT_AND_COMPLIANCE.md) | Requires a qualified legal reviewer, not this documentation effort |

Every claim above that says "not retrieved" or "to verify" must be checked against the provider's current official documentation before implementation; nothing in the payments, architecture or security documents should be read as independently verified against an external source by this pass.

| Source | Observed / used | Limitation |
|---|---|---|
| Direct user request 2026-10-30 | Complete Flutter/Firebase design/build/test/delivery, glass UI, all roles/controls, final actual-visual PDF | Plan approval requested before design; exact BR policies not supplied |
| Six PNG attachments in current conversation | Visually inspected; five distinct designs; control audit records all observed elements | Partial clipped category wording and illustrative claims are not final product facts |
| Local SRS/requirements/architecture/database/planning documents | Existing baseline read and preserved; canonical BR policies remain pending | Prior claims of delivered files checked against actual filesystem; some files were absent |
| Dart_Flutter_Codex_Master_Prompt.md | Named by the earlier BR evidence register | Not available in inspected workspace; not read during this turn; source completeness remains open |
| Earlier user clarifications | Recorded in existing canonical documents | This review does not independently reconstruct absent conversation history |
| Tool audit | Actual filesystem/command/tool-discovery results | Tool availability and cached metadata do not prove runtime/cloud readiness |

See the [capability audit](../setup/CAPABILITY_AUDIT_2026-10-30.md) for official Flutter/Firebase references checked in this review. See [screenshot audit](../design/SCREENSHOT_ACTION_AUDIT.md) for attachment identities. No attached document instruction overrides the direct task or authorizes installations/cloud actions.
