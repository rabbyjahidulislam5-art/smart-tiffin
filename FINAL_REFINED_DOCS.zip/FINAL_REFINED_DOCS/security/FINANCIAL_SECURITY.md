# Financial security

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Security review owner — to be identified |
| Purpose | Controls against the specific financial-misconduct scenarios named in the master prompt: price tampering, forged callbacks, double credit, payout fraud, journal tampering, duplicate COD deposits, replay. |
| Depends on | [Threat model](THREAT_MODEL.md), [security requirements SEC-013…024](SECURITY_REQUIREMENTS.md), [database/FINANCIAL_DATA_MODEL.md](../database/FINANCIAL_DATA_MODEL.md) |
| Status | PROPOSED — NOT APPROVED. No control below is implemented or tested. |

## 1. Misconduct scenarios and controls

| Scenario | Trusted control | Race/replay constraint | Evidence that counts | Anomaly that triggers Accounts review |
|---|---|---|---|---|
| Malicious client changes a price | Server-computed `ent.Quote` is the only payable-amount source (NFR-017) | `expectedTotalMinor` mismatch rejected at `confirmQuote` | Server quote snapshot, never a client value | Repeated `quote_mismatch` from one principal |
| Reusing an old quote | Quote `expiresAt`, checked server-side | Expired-quote rejection | Quote expiry timestamp | Repeated attempts to use an expired quote |
| Forging a payment success callback | `handleGatewayNotification` signature/validation before any state change | Deduplicated by `gwevt` key; browser redirect never trusted | `ent.GatewayVerification` record only | Unvalidated or malformed inbound events |
| Applying a credit twice | Unique origin constraint on `ent.CreditTransaction` (INV-08) | Idempotent `skipMeals`/`issueCredit` | The unique origin id | A `requestId` replay that would otherwise double-post |
| Paying an unverified beneficiary | `ent.PayoutDestination` verified and re-verified on change (SH-08 pattern) | Payout released only against a verified destination | Destination verification timestamp and approver | A payout request against a just-changed destination |
| Editing a posted journal | Schema/command layer permits only `reverseJournal`/`approveAdjustment` (INV-02) | N/A (no direct edit path exists) | The reversing/adjusting journal itself | Any attempt that reaches the rejected edit path |
| Reporting the same COD deposit repeatedly | Unique `depositReference` constraint (INV-12) | First submission wins; second is `conflict` | The unique deposit reference | Repeated submission of the same reference by different accounts |

## 2. Segregation of duties

Every payout and every adjustment above a configured limit requires a preparer and a different approver (BR-020, ADR-010, NFR-016). No Super Admin role bypasses this; "explicitly bounded privileges" means Super Admin can administer staff and policy, never execute or approve its own financial transaction.

## 3. Sensitive-change discipline

A sensitive command (payout destination change, role grant, policy publication, journal reversal) requires an accountable actor identity, an explicit permission check, a reason code from a published list, and a traceable event id (API spec §3.3). None of these is satisfied by a UI confirmation dialog alone — the check is re-run at the trusted boundary.

## 4. Monitoring and human investigation

Automated anomaly signals (repeated policy-gate hits, repeated `maker_equals_checker`, repeated `quote_mismatch`, validation-failure bursts) are flagged to Accounts or operations staff for human review; automation never substitutes for that review (USER-REQ). An uncertain transaction status is never resolved by guessing: the system preserves the pending state, investigates, reconciles, and informs the user — never invents a success or failure (API spec §5.3).

## 5. Rate limiting and replay prevention

See [security/SECURITY_REQUIREMENTS.md](SECURITY_REQUIREMENTS.md) SEC-022 and [api/API_SPECIFICATION.md](../api/API_SPECIFICATION.md) §10 for the proposed per-principal and webhook throttling parameters (no values approved).

## Acceptance and verification

Design-only. Verification requires an executed test per row in §1 demonstrating the control actually rejects the described misconduct attempt.
