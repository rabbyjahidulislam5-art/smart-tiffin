# Security control requirements

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (SEC-001…012 kept unchanged; SEC-013…024 added) |
| Owner | Security review owner — to be identified |
| Status | Proposed acceptance controls; implementation and tests unrun. |

Status: proposed acceptance controls; implementation and tests unrun. Product requirement IDs remain canonical in [SRS](../SRS.md). `SEC` IDs identify design controls without replacing FR/NFR IDs.

| Control | Requirement and verification condition | Trace |
|---|---|---|
| SEC-001 | Every protected operation rejects absent identity and inactive principal; test expired/revoked and stale-token cases | FR-001, FR-003; TEST-001, TEST-003 |
| SEC-002 | No client can alter canonical role, approval, calculated amount, verified payment, assignment authority or audit record directly | FR-003, FR-013, FR-021; TEST-003, TEST-013, TEST-021 |
| SEC-003 | Foreign-owner, cross-supplier and unassigned-courier reads/writes fail at the trusted boundary, including lists | FR-009, FR-017, FR-019; TEST-009, TEST-017, TEST-019 |
| SEC-004 | Duplicate/concurrent order, pause, reference and allocation requests produce at most one accepted effect | FR-007–008, FR-012–013; TEST-007, TEST-008, TEST-012, TEST-013 |
| SEC-005 | Delivery changes follow the four source-confirmed states and current assignment; no client override of skipped/reversed states | FR-020; TEST-020 |
| SEC-006 | Privileged action emits redacted actor/action/target/time/result audit; users cannot rewrite it | FR-021–024; TEST-021–024 |
| SEC-007 | Application and logs contain no server secret, provider PIN/OTP or plaintext password; tokens and private references are not public | FR-001, FR-013, FR-025; artifact and log inspection |
| SEC-008 | Logout/account change stops prior-user listeners and removes protected displayed state; private push targeting is detached | FR-001, FR-025; TEST-001, TEST-025 |
| SEC-009 | Provider-approved encrypted transport remains enabled; no certificate validation bypass or homemade cryptography | All networked features; code/config review and device checks |
| SEC-010 | Collect only necessary delivery/contact information; no GPS, contacts, camera or microphone permission without an approved feature | FR-019; Android manifest and permission-denial review |
| SEC-011 | Server operations verify authorization independently of Firestore Rules and use least-privilege runtime identity | FR-003; emulator plus trusted-service tests |
| SEC-012 | Backup, restore and migration exercises preserve authorization, financial reconciliation and deletion obligations | FR-012–013, FR-024; isolated recovery evidence |

The [authorization matrix](../api/AUTHORIZATION.md) supplies resource-level rules. BR-001–005 control policy outcomes; SEC controls do not choose a meal cutoff, bill formula, verifier role, assignment owner or refund eligibility. Missing policy must cause a visible blocked operation, not a guessed success.

Security acceptance requires executed evidence for both client SDK and trusted service paths. Document review alone cannot satisfy these controls.

## 2026-10-30 extension (SEC-013…024)

| Control | Requirement and verification condition | Trace |
|---|---|---|
| SEC-013 | Every inbound gateway notification is validated (signature/validation per official SSLCOMMERZ contract) before any state change; unvalidated events are persisted but never applied | FR-033, FR-041; BR-003 |
| SEC-014 | No client-supplied total, discount, fee or credit amount is ever trusted; the server quote snapshot is authoritative in every test | FR-030; NFR-017 |
| SEC-015 | Every money-moving command enforces a natural-key uniqueness constraint in addition to the `requestId` receipt | INV-04, INV-08, INV-12 |
| SEC-016 | No staff account can approve, release or settle a payout or adjustment it itself prepared | BR-020; NFR-016, INV-15 |
| SEC-017 | A posted ledger journal line is never directly editable; only `reverseJournal`/`approveAdjustment` can change a balance | FR-040; INV-02 |
| SEC-018 | Admin Web and Accounts Web sessions use CSRF-appropriate protections and MFA for sensitive actions; verified against the chosen hosting approach before implementation | ADR-011 |
| SEC-019 | A payout destination change is treated as a sensitive change requiring re-verification before the next payout can use it | BR-014 |
| SEC-020 | A reconciliation mismatch between Firestore and PostgreSQL is surfaced as an exception, never auto-corrected | NFR-026 |
| SEC-021 | Uploaded application/evidence documents are size- and type-bounded by Storage rules; never embedded inline in a command payload | FR-045 |
| SEC-022 | Rate limiting applies to quote creation, OTP requests and payment initiation per [architecture/SECURITY_ARCHITECTURE.md](../architecture/SECURITY_ARCHITECTURE.md) | NFR-022 |
| SEC-023 | No SSLCOMMERZ credential, connection string or signing key appears in any client bundle, log, test fixture or this documentation set | NFR-008, NFR-025 |
| SEC-024 | A dual-role (BR-023) principal's two workspaces never share a mutable balance or leak a cross-role notification | SC-25 |
