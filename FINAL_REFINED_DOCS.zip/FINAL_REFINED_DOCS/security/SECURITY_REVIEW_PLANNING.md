# Security review record (planning phase)

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (adds the four-app/finance review row; original rows unchanged) |
| Owner | Security review owner — to be identified |
| Status | Design reviewed; implementation security unverified. |

Cross-reference: this is the requirements-phase review. For the actual executed Firestore/Storage Rules test evidence against the real backend code, see [verification/FIREBASE_SECURITY_REVIEW_COPY.md](../verification/FIREBASE_SECURITY_REVIEW_COPY.md).

Review date: 2026-10-28. Scope: requirements and proposed technical boundaries. Result: **design reviewed; implementation security unverified**. There is no application, Firestore Rules deployment, trusted service, signed artifact or live account to assess.

| Review item | Current finding | Release gate |
|---|---|---|
| Privilege boundary | Explicit server-owned authority and private-data separation documented | Implement/test Rules and server authorization |
| Manual payment truth | Submitted reference separated from verification and settlement | Approve BR-002/003; execute duplicate/allocation tests |
| Assignment access | Courier limited to current assignment projection | Approve BR-004; test reassignment and suspension |
| Pause/cancel races | Atomic state/consequence requirement documented | Approve BR-001/005; test deadline/concurrency cases |
| Secret handling | Server/client separation specified | Inspect actual repository, config, APK and logs when created |
| Data lifecycle | Categories identified; retention undecided | Approve retention and test export/delete/restore |
| Dependencies | No application dependency manifest exists | Perform version/license/advisory review at selection |

No finding is marked fixed by a proposed document alone. The review identifies required evidence in [SECURITY_REQUIREMENTS](SECURITY_REQUIREMENTS.md) and [TEST_STRATEGY](../testing/TEST_STRATEGY.md). Track concrete implementation defects in [BUG_REPORTS](../testing/BUG_REPORTS.md) when reproducible evidence exists.

## 2026-10-30 extension — four-application and finance review

| Review item | Current finding | Release gate |
|---|---|---|
| Four-application boundary | Admin Web has no implicit Accounts authority by design (conflict register C-06) | Implement and test the role/claim separation across all four apps |
| Gateway webhook trust | `handleGatewayNotification` design requires signature/validation before any state change | Verify against official SSLCOMMERZ documentation before implementation; execute replay/forgery tests |
| Ledger immutability | Posted-journal immutability and reversal-only correction documented (INV-02) | Implement and test; no direct update path to a posted `JournalLine` |
| Maker-checker | Preparer ≠ approver documented for payouts and adjustments (ADR-010) | Implement and test self-approval rejection |
| Cross-store consistency | Outbox pattern documented; no instance exists | Implement and test the reconciliation sweep against injected mismatches |
| Web session security | CSRF/session requirements flagged as open (SEC-018) | Select hosting approach and verify its session model before implementation |

See [verification/FIREBASE_SECURITY_REVIEW_COPY.md](../verification/FIREBASE_SECURITY_REVIEW_COPY.md) for the executed Rules evidence, which covers only the current single-app baseline, not the extended entity set above.

Future review record must include tested revision/artifact, reviewer, environment, command/manual steps, results, severity, owner and disposition. A release blocker cannot be accepted implicitly by leaving this document unchanged. Public vulnerability communication and response ownership follow [SECURITY.md](../SECURITY.md).
