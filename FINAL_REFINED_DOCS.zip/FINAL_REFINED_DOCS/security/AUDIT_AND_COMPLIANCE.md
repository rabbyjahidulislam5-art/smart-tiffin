# Audit and compliance

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Security review owner / legal review owner — to be identified |
| Purpose | Define the audit-event model and list, without answering, the legal/regulatory questions the master prompt requires to be raised for Bangladesh. |
| Depends on | [Policy decision register](../requirements/POLICY_DECISION_REGISTER.md) BR-018, BR-025, [financial security](FINANCIAL_SECURITY.md) |
| Status | **No compliance is declared anywhere in this document.** Every question below is open. |

## 1. Audit event model

`ent.AuditEvent`: `actorId`, `action`, `targetType`, `targetId`, `timestamp`, `reasonCode?`, `priorState?`, `newState?`, `correlationId`. Written by the trusted backend only, in the same transaction as the action it records (extends the OBSERVED `auditEvents/{receiptId}` pattern to every new command). Append-only; no update or delete command exists for an audit event. Retention is governed by [database/DATA_RETENTION.md](../database/DATA_RETENTION.md) (open, DEC-010), except that financial audit events are retained at least as long as the journals they relate to.

## 2. Legal/regulatory questions (USER-REQ: raise, do not answer)

| Question | Why it matters | Status |
|---|---|---|
| Does the customer service-credit model constitute regulated "stored value" or e-money under Bangladesh law? | Determines whether credits need a licensed-issuer structure | Open — legal review required (BR-025) |
| May a service credit ever be converted to cash, and under what conditions? | Determines whether the "never withdrawable" default needs a formal exception process | Open (BR-025) |
| Does holding customer prepayments pending service delivery trigger a "customer funds" safeguarding obligation? | Determines account segregation and reporting requirements | Open |
| Does routing rider-collected COD cash through the platform's reconciliation create a payment-aggregator obligation? | Determines licensing/registration need for COD handling | Open |
| What tax (VAT/supplementary duty) applies to food, delivery and platform service fees, and how is it declared? | Determines BR-018's tax-line design and reporting cadence | Open (BR-018) |
| What financial reporting obligations apply to a platform recognising commission revenue from suppliers? | Determines MOD-RPT's mandatory report set | Open |
| What data-protection obligations apply to customer address, phone and payment-reference data? | Determines retention and access rules beyond NFR-008 | Open |
| What record-retention period applies to financial/ledger records under Bangladesh accounting or tax law? | Determines the retention value DATA_RETENTION.md currently leaves blank | Open |

## 3. What this document does not do

It does not declare the platform compliant with any Bangladesh financial, tax or data-protection law. It does not recommend a specific licence or registration. It exists so that an authorised legal reviewer has one place to start, per the master prompt's explicit instruction to identify legal/regulatory questions without claiming compliance.
