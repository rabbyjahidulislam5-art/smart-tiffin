# Secrets and sensitive configuration

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (adds SSLCOMMERZ and PostgreSQL rows; original rows unchanged) |
| Owner | Security review owner — to be identified |
| Status | Design policy. No credentials are requested, created, stored or deployed by this package. |

Status: design policy. No credentials are requested, created, stored or deployed by this package.

| Category | Handling |
|---|---|
| Firebase public client configuration | May be packaged only as provider-approved client values; not an authorization mechanism |
| Service account keys / server authorization | Trusted runtime only; prefer managed runtime credentials; never embed in Flutter assets or repository |
| Android signing material | Restricted owner-controlled storage; release process must document recovery and access |
| Auth/session tokens | Use provider-supported session handling; no debug printing or manual plaintext persistence |
| FCM registration tokens | Private device records; redact logs; rotate/detach on account switch/sign-out |
| Payment references, address and phone | Sensitive business data; minimal authorized views, redacted diagnostics, no public fixtures |
| SSLCOMMERZ merchant credentials (sandbox and, later, live) | Trusted backend secret manager only; never requested or used by this documentation effort; sandbox and live kept in separate secret scopes (ADR-007) |
| PostgreSQL ledger connection string | Trusted backend secret manager only; no client driver anywhere (ADR-005) |
| Payout destination details (bank/MFS account) | Treated as sensitive as a payment reference; never a PIN/OTP; access restricted to the owning principal and authorised Accounts staff |
| Admin Web / Accounts Web session secrets | Trusted backend / hosting platform secret store only; never logged |

An `.env` file inside a compiled application is not secret storage. No `.env.example` is generated until an actual runtime/configuration mechanism is chosen. Obfuscation is not protection for privileged credentials. [Configuration](../setup/CONFIGURATION.md) owns environment naming and validation.

Before adding an integration, identify the exact account/project, minimum permissions, storage location, rotation method and revocation owner. Keep development/staging/production resources separate. Do not paste secret values into chat, reports, screenshots, test fixtures or commit messages.

If a secret is exposed, restrict use and revoke/rotate it through the authorized provider workflow, investigate access, replace dependent configuration, and inspect the delivered artifact and history. Deleting the visible file alone does not invalidate a credential. Record a redacted incident and recovery verification; see [incident response](../operations/INCIDENT_RESPONSE.md).
