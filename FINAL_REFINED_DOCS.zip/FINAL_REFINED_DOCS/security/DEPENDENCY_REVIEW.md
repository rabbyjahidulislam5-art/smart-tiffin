# Dependency review policy and inventory

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (adds PostgreSQL and web-hosting candidates; original rows unchanged) |
| Owner | Security review owner — to be identified |
| Status | No Flutter/Dart/backend/web dependency manifest or lockfile is part of this requirements phase. |

Status: no Flutter/Dart/backend dependency manifest or lockfile is part of this requirements phase. No package installation, vulnerability scan or license clearance is claimed.

| Candidate | Purpose | Admission status |
|---|---|---|
| Flutter/Dart SDK | Android application and language | Version not selected; validate Android toolchain and pin compatible SDK during implementation |
| Official Firebase Flutter packages | Authentication, Firestore and messaging | Candidate package family; exact package versions, licenses and transitive graph require review |
| Firebase Admin SDK / chosen server runtime | Trusted logic and sending | Conditional on DEC-011; runtime/version and deployment cost unresolved |
| State, routing, serialization packages | Only if they solve actual complexity | No package selected; avoid duplicate overlapping libraries |
| Diagram renderer | Optional diagram validation | Documentation tooling only; parent records actual availability/results |

For each added dependency record authoritative package URL, publisher/repository, selected version, SDK/platform constraints, license, maintenance evidence, known advisories, transitive additions, justification and a removal/replacement plan if experimental. Check current metadata at selection rather than copying versions from this document.

Resolve and lock application dependencies with the real package manager. Review lockfile changes for unexpected sources and scripts. Scope upgrades to a concrete need, run impacted checks, and record compatibility. Temporary overrides need an owner, rationale and removal condition. Never fabricate generated dependency metadata or claim an advisory database was checked without a result.

No project license has been selected. Dependency review does not authorize choosing a license for the user's own code. Source/tool references are collected in [SOURCES](../references/SOURCES.md).

## 2026-10-30 extension

| Candidate | Purpose | Admission status |
|---|---|---|
| Managed PostgreSQL client library (e.g. a Node.js driver for Cloud Functions) | Ledger/finance store access | Candidate only; provider not selected (ADR-005, DEC-010) |
| Dart/Flutter workspace or Melos tooling | Monorepo package management | Candidate only; not configured (ADR-004) |
| SSLCOMMERZ SDK or direct HTTP integration | Gateway abstraction implementation | Candidate only; no credential or live integration in this phase (ADR-007) |
| Web hosting SDK/CLI for Admin Web / Accounts Web | Desktop web deployment | Candidate only; provider not selected ([deployment/WEB_HOSTING_ADMIN_AND_ACCOUNTS.md](../deployment/WEB_HOSTING_ADMIN_AND_ACCOUNTS.md)) |
| Mermaid CLI (documentation tooling only) | Diagram syntax verification | Not run by this effort; see [verification/FINAL_VERIFICATION_REPORT.md](../verification/FINAL_VERIFICATION_REPORT.md) for what was actually checked |
