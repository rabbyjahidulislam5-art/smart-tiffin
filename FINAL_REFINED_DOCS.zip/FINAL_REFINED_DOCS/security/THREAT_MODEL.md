# Threat model

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (extends 1.0 for four apps, the gateway and the financial domain; original rows unchanged) |
| Owner | Security review owner — to be identified |
| Status | Requirements threat assessment; no penetration test or security certification. |

Status: requirements threat assessment; no penetration test or security certification. Assets are identities, customer contact/destination data, order obligations, payment references, bill integrity, supplier earnings, role authority and notification credentials. Actors include ordinary users, malicious registered users, compromised devices/accounts and mistaken privileged operators.

| Threat | Entry point / impact | Required mitigation and evidence |
|---|---|---|
| Role escalation | Editable profile role or fabricated claim; administrative takeover | Separate server-owned principal; deny client privilege edits; direct SDK and command negative tests |
| Broken object authorization | Foreign order UID, supplier ID or assignment ID; disclosure/tampering | Per-object ownership and active-role check; collection query constraints; cross-user fixtures |
| Financial manipulation | Forged totals, paid flags, duplicate bKash/Nagad references | Trusted calculation, manual verification, unique scoped reference, idempotent allocation; concurrency tests |
| Courier data overexposure | Enumerating addresses or retaining reassigned destinations | Minimum assignment projection; revoke old access and client state; reassignment/suspension tests |
| State/race abuse | Delivered-state skip, late pause or concurrent preparation/cancel | Canonical state/version checks and atomic consequences; policy-boundary tests after decisions |
| Token/credential exposure | APK assets, logs, leaked server keys or notification tokens | Public client config separated from secrets; scan built artifacts/logs; runtime least privilege |
| Account takeover/abuse | Weak recovery flow, reused credentials, automated signups | Provider auth/recovery, sensitive-change reauthentication, measured abuse controls; no homemade crypto |
| Replay and stale access | Retried commands, old role token, account switch | Actor-scoped receipts, payload conflict check, current authorization, listener/cache isolation |
| Sensitive notification leakage | Lock-screen body, public topic, forged deep link | Generic body; private recipient targeting; authenticated target read |
| Operator error | Wrong project, destructive migration or misapplied verification | Environment allowlist, reviewed operations, audit, backup/restore and reconciliation |

Relevant mobile security areas are authentication, storage, network, platform interaction, code quality and privacy. [OWASP MASVS](https://mas.owasp.org/MASVS/) provides a review framework; this project claims no MASVS certification. Accessed 2026-10-28.

Current scope has no file upload, URL-fetch service, custom SQL query, browser cookie session or payment webhook. SSRF, path traversal, unsafe upload, CSRF and webhook-signature controls are therefore not invented components; reassess them if such features are introduced. Validate all structured fields and render user text as text, not executable markup.

Residual requirements risks: BR-001–005 unresolved; provider/auth onboarding DEC-009; region/retention and capacity DEC-010; trusted host DEC-011; review/complaint and notification policy DEC-013/015. These are release gates, not accepted production risks.

## 2026-10-30 extension — gateway, finance and web threats

**Statement reversed:** the original text above says "Current scope has no file upload, URL-fetch service, custom SQL query, browser cookie session or payment webhook." This is **no longer true**: ADR-007 introduces a payment webhook (`handleGatewayNotification`), Admin Web and Accounts Web introduce browser sessions, and application document upload already existed (`saveEvidence`). Each new surface below has its own control.

| Threat | Entry point / impact | Required mitigation and evidence |
|---|---|---|
| Forged or replayed gateway callback | `handleGatewayNotification` trusted as a real IPN without signature/validation | Verify against the official SSLCOMMERZ signature/validation contract before any state change; deduplicate by `gwevt` key (INV-05); never trust a browser redirect (SC-13) |
| Price tampering | Client sends a modified total at `confirmQuote`/`placeOneTimeOrder` | Server-computed `ent.Quote` is the only source of truth; `expectedTotalMinor` mismatch rejected (NFR-017) |
| Double credit / double refund | Retried skip, or a refund requested against an already-credited obligation | Unique origin constraint (INV-08), explicit double-compensation check (INV-17) |
| Payout fraud via self-approval | A single staff account prepares and approves its own payout | Maker-checker enforced at the command layer (ADR-010, INV-15) |
| Ledger tampering | An attempt to edit a posted journal line directly | Journals are append-only/reversal-only at the schema and command level (INV-02) |
| Duplicate COD deposit reporting | The same bank deposit reference submitted twice | Unique `depositReference` constraint (INV-12) |
| Web session hijack / CSRF on Admin Web or Accounts Web | A forged request riding an authenticated desktop browser session | Session tokens with appropriate SameSite/CSRF protections (to verify against the chosen web hosting approach), MFA for sensitive actions |
| Beneficiary substitution | A payout destination changed just before a payout is released | Destination changes treated as a sensitive, re-verified change (SH-08 pattern extended to `ent.PayoutDestination`) |
| Cross-store inconsistency exploited | An attacker times a request to land between the Firestore and PostgreSQL steps of a SAGA | Outbox pattern with idempotent consumers; reconciliation sweep raises, never silently fixes, a gap (NFR-026) |
| Document/application upload abuse | Oversized or malicious file via `saveEvidence`/application documents | Storage rules bound size/type; documents referenced by id, never inlined in command payloads (16 KB cap) |

Relevant web security areas (new, for Admin Web and Accounts Web) are session management, CSRF, content security policy and desktop-browser-specific XSS surfaces; these have no OWASP MASVS (mobile) equivalent review yet and are an open item for [security/SECURITY_REQUIREMENTS.md](SECURITY_REQUIREMENTS.md) extension.
