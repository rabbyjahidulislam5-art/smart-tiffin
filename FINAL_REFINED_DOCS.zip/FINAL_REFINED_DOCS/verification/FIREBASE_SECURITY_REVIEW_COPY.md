# Rules prototype review — executed evidence (copy)

Cross-reference: this is a copy of `firebase/SECURITY_REVIEW.md` (real executed Firestore/Storage Rules test evidence against the backend code). The original is untouched and remains the authoritative source. For the earlier requirements-phase review, see [security/SECURITY_REVIEW_PLANNING.md](../security/SECURITY_REVIEW_PLANNING.md).

---

The executed result is reported by the commands in [backend setup](../../backend/README.md); this document explains the tested boundary, not a production security certification.

## Observed contract and assumptions

Canonical `principals/{uid}` stores server-owned `active` and `role`. `users/{uid}` stores private profile text and locale; addresses, preferences and device tokens are nested private records. `foods`, `menus` and `plans` contain supplier-owned public-safe catalogue text, never customer PII. All client reads are authenticated except no anonymous access is granted. Read queries are filtered by publication or current ownership and capped at 50. Profile, catalogue and intake changes go through one callable; all direct writes are denied, including creation. The callable allowlists every field, bounds Unicode text/arrays and owns role, timestamps, ownership and versions.

The implemented app must use this contract. Draft catalogue changes cannot publish offers or set money, and only an approved supplier can save them. Raw financial and delivery details have no general admin read bypass. Current delivery projections alone expose necessary courier data; permission is checked using current principal role and assignment activation. Supplied claims cannot override canonical principal state.

## Attack checks

`functions/test/rules.test.js` executes private profile/address reads by another user, anonymous catalogue list, unfiltered and unbounded list, unpublished data read, finance writes, role escalation, ownership takeover, timestamp changes, unknown fields, invalid types, oversized input, required-field removal, foreign/orphan nested writes, raw delivery/audit reads, inactive courier history and direct deletion. Every attempted mutation must fail under Rules. No create/update schema bypass exists because neither is permitted from SDK clients.

`functions/test/commands.test.js` exercises the actual server allowlists, Unicode length, malformed envelopes, policy gates for all roles, revoked identities, pending-account bootstrap, receipt replay and changed payload conflicts, version races, foreign supplier data, immutable published offers, menu reference ownership and foreign complaint orders. `functions/test/firestore.test.js` executes real Firestore transactions for concurrent same-request retries and simultaneous stale updates; a simulated transaction test is not substituted for this check.

Notifications have no client read-state update yet; counters and financial allocations cannot be written. No public review projection, evidence upload, export handler or privileged role-grant command exists. Those absent operations remain denied rather than acquiring permissions from example policy suggestions.

Prototype Rules still require review against the finally selected cloud database, identity/onboarding policy, supported app queries and deployment IAM. Emulator checks do not establish cloud deployment, App Check attestation, Android delivery, production abuse resistance, operational retention or approved business behavior.

Actual 2026-10-30 result: all six Rules test groups and the real concurrent Firestore transaction test passed in emulator 1.22.0 (Standard edition). No tested attack succeeded. Twelve command-core tests passed on Node 24.17.0 and Node 22.23.4. See the backend verification section for commands and remaining limits.
