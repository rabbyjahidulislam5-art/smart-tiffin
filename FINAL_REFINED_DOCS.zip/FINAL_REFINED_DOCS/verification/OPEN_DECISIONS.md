# Open decisions — consolidated register

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Product/business decision owner — not yet named (DEC-010 scope) |
| Purpose | Single consolidated list of every PENDING business decision and PROPOSED-not-approved architecture choice carried across this rewrite, so nothing is approved by omission. |
| Depends on | [requirements/POLICY_DECISION_REGISTER](../requirements/POLICY_DECISION_REGISTER.md), [requirements/BUSINESS_RULES](../requirements/BUSINESS_RULES.md), [adr/](../adr/) |
| Status | No entry in this file is approved. Listing here does not change any status; it only aggregates. |

## 1. Business rules — all PENDING

| ID | Subject | Decision record | Status |
|---|---|---|---|
| BR-001 | Meal pause/skip policy (granularity, cutoff, reversal, preparation override, financial effect) | DEC-004 | PENDING |
| BR-002 | Billing and monetary policy (basis, coverage, proration, due dates, fees, tax, rounding, adjustments) | DEC-003 | PENDING |
| BR-003 | Manual payment verification (verifier authority, evidence, deduplication, allocation) | DEC-005 | PENDING |
| BR-004 | Delivery assignment (owner, method, eligibility, reassignment, completion evidence) | DEC-006 | PENDING |
| BR-005 | Cancellation and refund policy (actors, scope, charges, approval, execution) | DEC-007 | PENDING |
| BR-006…BR-026 | 21 new rules covering service credits, SSLCOMMERZ gateway validation, all 4 COD models, subscription-vs-obligation distinction, supplier/rider earnings independence, payout cadence, maker-checker thresholds, refund/adjustment authority, substitution policy, time-zone/cutoff evaluation, and more | DEC-016…DEC-036 | PENDING (all 21) |

No BR has a guessed cutoff time, formula, verifier identity, assignment owner, or refund entitlement. Every numeric example attached to a BR or DEC is explicitly labelled hypothetical BDT.

## 2. Architecture decisions — PROPOSED, not approved as business policy

ADR-001…003 describe the pre-existing, already-running baseline (Flutter/Firebase single app, trusted command boundary, status-and-reference manual payments) and are OBSERVED fact, not proposals. ADR-004 onward are new proposals from this rewrite and remain open for approval:

| ID | Subject | Status |
|---|---|---|
| ADR-004 | Four-application monorepo split (Customer, Partner, Admin Web, Accounts Web) | PROPOSED |
| ADR-005 | Hybrid datastore: Firebase Auth + Firestore (operational/read models) + managed PostgreSQL (ledger) | PROPOSED |
| ADR-006 | Double-entry ledger design and chart of accounts | PROPOSED |
| ADR-007 | Payment gateway abstraction (SSLCOMMERZ) plus the 4 COD models | PROPOSED |
| ADR-008 | Idempotent command envelope extension | PROPOSED |
| ADR-009 | Quote and price-snapshot model | PROPOSED |
| ADR-010 | Payout maker-checker segregation of duties | PROPOSED |
| ADR-011 | Roles, claims and session model across 4 apps | PROPOSED |
| ADR-012 | Notifications and scheduled-jobs design | PROPOSED |
| ADR-013 | Time-zone and cutoff evaluation policy | PROPOSED |
| ADR-014 | Subscription-agreement vs. meal-obligation model | PROPOSED |

User-made implementation-direction choices recorded via `AskUserQuestion` during planning (not business policy, but binding on *how* approved work should eventually be built): keep the `FINAL_REFINED_DOCS/` folder layout with added subfolders; use the hybrid Firestore + Postgres-ledger datastore direction in ADR-005 rather than an all-Firestore or all-Postgres alternative.

## 3. Conflicts between old single-app scope and the new four-app scope

22 numbered conflicts are tracked in full in `analysis/CONFLICT_REGISTER.md`; the ones with the largest business-decision impact are restated here for visibility:

| ID | Conflict | Resolution recorded | Still open? |
|---|---|---|---|
| C-01 | Old docs assume one Android app; new scope is 4 apps on 1 backend | Resolved structurally (four-app architecture documented); business approval of the four-app *product* decision itself still PENDING at the DEC level | Structural: resolved. Business approval: PENDING |
| C-06 | Old Admin app owned treasury/payout screens; new scope moves those to Accounts Web | Resolved by re-pointing F129 Admin treasury/payout rows to Accounts Web NF-07/NF-08 in `design/INVENTORY_RECONCILIATION.md` | Structural: resolved. Who is actually authorized to approve payouts in production: PENDING (ties to BR-014/BR-015/ADR-010) |
| Remaining 20 conflicts | Legacy ID collisions, screen-count mismatches, payment-model conflation, etc. | Each has an individually recorded resolution and authoritative file | See `analysis/CONFLICT_REGISTER.md` for the full table |

## 4. Named-but-unfilled ownership roles

The following roles are referenced throughout the documentation but have **no named person or team** assigned, per DEC-010 (owners) still being open:

- Incident lead, Finance lead, Security owner, Communications owner, Scribe, Legal and privacy adviser (`operations/INCIDENT_RESPONSE.md` §2)
- Security review owner (`security/SECURITY_REVIEW_PLANNING.md`)
- Payout maker and payout checker (distinct people, per ADR-010 and INV-15)
- Business/product decision owner for this entire register (header of this file)

## 5. What would need to happen before any of this becomes approved policy

1. A named business decision owner reviews each BR/DEC entry's question, evidence, and PROPOSED recommendation in `requirements/POLICY_DECISION_REGISTER.md`.
2. Each decision is recorded as approved with an explicit value (not a default), a date, and the approving person's role.
3. `requirements/BUSINESS_RULES.md` and `requirements/POLICY_DECISION_REGISTER.md` are updated to change status from PENDING to APPROVED with the recorded value, and downstream files (scenarios, screens, ledger postings) are checked for consistency with the approved value.
4. Architecture ADRs 004–014 are separately reviewed and accepted or rejected as *engineering* decisions (distinct from business policy, but some — e.g. ADR-007's gateway choice, ADR-010's maker-checker — have direct business-policy dependencies that must be approved together).

No step above has occurred as of this revision.
