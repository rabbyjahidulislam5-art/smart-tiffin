# Consistency audit — 2026-10-30 refinement

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation refinement lead (this session) |
| Purpose | Record what was actually checked for cross-document consistency, what was found wrong, and what was fixed, with evidence — not a generic "all good" statement. |
| Depends on | [DOCUMENTATION_COVERAGE](DOCUMENTATION_COVERAGE.md), [analysis/CONVENTIONS_AND_ID_REGISTER](../analysis/CONVENTIONS_AND_ID_REGISTER.md) |
| Status | Documentation-only audit. No code or deployment was inspected because none is in scope of this rewrite. |

## 1. Link-integrity check

**Method:** a read-only Node.js script (`checklinks.js`) was written to the session's personal scratchpad directory — **not** inside `FINAL_REFINED_DOCS/` and **not** delivered as a project file — to walk every `.md` file under `FINAL_REFINED_DOCS/`, extract Markdown link targets, and resolve each relative target against the actual file tree. This is a verification aid only, matching the user's instruction not to create external verification scripts as deliverables; it produced no output file and modified nothing.

**Result of first run (before the 2 depth fixes and the 4 new `verification/` files):** 1840 links checked, 61 flagged as unresolved.

**Result of re-run (after both fixes and after writing the 4 `verification/` files):** 1858 links checked, 44 flagged — all 44 confirmed to be the same directory-trailing-slash checker artefact described below; zero new genuine defects.

**Triage of the 61 flagged links:**

| Category | Count | Disposition |
|---|---|---|
| False positive: directory-only links (e.g. `](../design/screens/)`) mishandled by the checker's own path-normalisation (it preserved trailing slashes when comparing against a set of paths stored without them) | ~45 | Not a documentation defect. Checker bug, not fixed in any delivered file (the checker itself is scratch-only). |
| Expected: links to the 4 `verification/` files that did not yet exist at the time of the first run (`FINAL_VERIFICATION_REPORT.md`, `OPEN_DECISIONS.md`, `CONSISTENCY_AUDIT.md`, `DOCUMENTATION_COVERAGE.md`) | ~10 | Resolved by writing those 4 files in this session (this file is one of them). |
| False positive: links intentionally pointing outside `FINAL_REFINED_DOCS/` to the real repository (`../firebase/SECURITY_REVIEW.md` from root `SECURITY.md`; `../../backend/README.md` from `verification/FIREBASE_SECURITY_REVIEW_COPY.md`) | 2 | Verified to actually exist via `ls firebase/SECURITY_REVIEW.md backend/README.md` from the repository root. No fix needed; these links are correct and simply outside the checker's scan root. |
| **Genuine defect: wrong relative-path depth** | 2 | **Fixed** — see below. |

**Genuine defects found and fixed:**

1. `operations/INCIDENT_RESPONSE.md` — the "Depends on" header row linked `[security reporting](../../SECURITY.md)`. `INCIDENT_RESPONSE.md` lives one directory below `FINAL_REFINED_DOCS/` root, where `SECURITY.md` actually resides, so the correct target is one level up, not two. **Fixed to `../SECURITY.md`.**
2. `security/SECURITY_REVIEW_PLANNING.md` — the closing paragraph linked `[SECURITY.md](../../SECURITY.md)` for the same reason. **Fixed to `../SECURITY.md`.**

Both fixes were applied by direct edit; no other file required a path-depth correction.

## 2. Leftover placeholder/truncation-marker scan

**Method:** `grep -rn "APPEND-\|TODO\|PLACEHOLDER\|TBD-FILL\|<!-- "` (and the more specific `<!--CONTINUE-->` / `@@CONTINUE@@` variants) across the full tree, run after dead-subagent recovery.

**Found and fixed (all three resolved by direct authoring in this session, not by any agent):**

| File | Marker found | What was missing | Resolution |
|---|---|---|---|
| `design/screens/PARTNER_APPLICATION_SCREENS.md` | `<!-- APPEND-MARKER -->` | §5 (KITCHEN_STEPS field detail, AU-09), §6 (RIDER_STEPS field detail, AU-10), §7 (AU-11 status screen contract), §8 (F129 reconciliation) | All four sections written and appended |
| `design/screens/CUSTOMER_NEW_SCREENS.md` | `<!--CONTINUE-->` | NC-05 through NC-19 (15 screens) and a closing F129 reconciliation section | Written and appended in a compact contract format |
| `design/screens/CUSTOMER_PUBLIC_AND_AUTH_SCREENS.md` | `<!--@@CONTINUE@@-->` | All 9 AU-screens (AU-01, 02, 03, 04, 05, 06, 07, 08, 12) and a closing F129 reconciliation section | Written and appended, each noting the specific legacy defect it fixes (e.g. AU-03 replaces simulated demo-account auth; AU-05 replaces the "any six digits except 000000" OTP bypass with real rate-limited OTP) |

**Re-scan after fixes:** zero matches for all marker patterns, confirmed 2026-10-30.

## 3. Identifier range and collision check

- `requirements/FUNCTIONAL_REQUIREMENTS.md` was found to contain a literal `<!-- APPEND-FR-026 -->` comment in place of FR-026 through FR-050 (the author agent had written correct header blocks and revised FR-001…025 but died before the new range). Discovered by comparing FR count (25, wrong) against the already-correct UC/AC/US counts (50 each) for the same new range — the mismatch flagged FR as the outlier. **Fixed**: all 25 missing FR entries (FR-026…FR-050) were written with full bodies (Priority/module, Actors, Applications, Business rules/decisions, Preconditions, Main behaviour, Alternate/exceptions, Screens, Commands, Entities, Provenance, Acceptance links, Status), matching the convention already established by FR-001…025. Re-verified via `grep -coE '^## FR-[0-9]{3} —'` → 50.
- No other ID-range collision was found: BR-001…005 keep their original meanings and text (confirmed by diff-reading against the pre-existing `docs/requirements/BUSINESS_RULES.md`); BR-006…026/DEC-016…036 occupy the registered new range; ADR-001…003 are the pre-existing baseline decisions (Flutter/Firebase, trusted command boundary, status-and-reference payments) and ADR-004…014 are the new ones from this rewrite; no FR/UC/AC/US/NFR/TEST number below the registered new-range floor was reused or redefined.

## 4. Provenance-tag spot check

A sample of ~20 requirement and decision entries across `requirements/`, `scenarios/`, and `design/screens/` was read and confirmed to carry one of the four required tags (USER-REQ / OBSERVED / PROPOSED / PENDING) rather than an unqualified assertion. No untagged business-impacting statement was found in the sampled files. This is a sample check, not an exhaustive one; see §6 Residual risk.

## 5. Forbidden-claim scan

`grep -rniE "\btest(s|ing)? (passed|executed)\b|\bverified and (approved|deployed)\b|\bimplementation complete\b"` was run across the tree. No file was found asserting an executed test result, a completed implementation, or a business-policy approval outside of explicitly labelled "PENDING"/"PROPOSED, not approved" framing. `git status` was additionally checked and confirms only `FINAL_REFINED_DOCS/` paths are modified or added in this working tree — no file under `docs/`, `app/`, `backend/`, `firebase/`, or any root file outside `FINAL_REFINED_DOCS/` was touched by this rewrite.

## 6. Residual risk / what was not checked

- The link checker only verified that a target path *resolves to an existing file*; it did not confirm that the linked *anchor* (`#section-id`) exists within the target file, since Markdown heading-anchor slugs were stripped before comparison. A reader following a deep link could land on the right file but not the exact heading.
- ID-uniqueness was independently recomputed for FR/UC/AC/US/NFR/BR/DEC/ADR/SC (see `DOCUMENTATION_COVERAGE.md` §2) but `TEST-*` and `SCT-*` identifiers across all 25 scenario files and the testing/ directory were not individually deduplicated by script; this audit relied on each scenario file being authored with a distinct `SCT-nn-*` prefix per scenario number, which is structurally unlikely to collide but was not independently re-grepped.
- Mermaid diagram blocks were authored and read back by eye for syntax; no Mermaid CLI or renderer was run, so a subtle syntax error could still exist undetected.
