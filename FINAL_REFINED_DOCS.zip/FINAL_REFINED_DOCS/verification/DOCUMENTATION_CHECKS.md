# Documentation checks

Updated 2026-10-30. No historical verification report was present when this review began; earlier links to this file did not establish a passing check. Do not invent a prior manifest or test outcome.

Current evidence is in [PLANNING_REVIEW_2026-10-30.md](PLANNING_REVIEW_2026-10-30.md). The documented command is `node scripts/verify_docs.mjs`; its initial missing-file failure and later outcomes are recorded there. The verifier checks local document links and required baseline identifiers/artifacts, plus planned screen/control reference consistency. It does not validate legal/business approval, Markdown anchor semantics, diagram rendering, actual UI coverage, deployed security, tests or application behavior.
