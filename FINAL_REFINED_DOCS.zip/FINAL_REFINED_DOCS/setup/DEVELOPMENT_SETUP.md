# Development setup

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (adds monorepo/four-app setup; original single-app steps unchanged) |
| Owner | Setup author |
| Depends on | [setup/MONOREPO_AND_BUILD_OWNERSHIP.md](MONOREPO_AND_BUILD_OWNERSHIP.md) |
| Status | Documentation phase only; no Flutter/Firebase/PostgreSQL setup performed. |

## 2026-10-30 extension — future monorepo setup

Once implementation is authorised: a Dart/Flutter workspace (or Melos) manages the four `apps/*` packages and shared `packages/*` (see [MONOREPO_AND_BUILD_OWNERSHIP.md](MONOREPO_AND_BUILD_OWNERSHIP.md)); a local PostgreSQL instance (or a managed sandbox) is needed for ledger development, separate from the Firestore emulator already used by `backend/functions`. This remains a future step; the current phase needs only the tools below.

## This phase

A Markdown editor, Git for inspection, and Node.js are sufficient to use the package. No Flutter/Firebase restore or deployment is needed. From the project root, run:

```powershell
node scripts/verify_docs.mjs
```

The verifier uses built-in Node modules and installs nothing. The authoring host has Node v24.17.0; no lower-version compatibility is claimed. View [the environment audit](ENVIRONMENT_AUDIT.md) and [recorded results](../verification/DOCUMENTATION_CHECKS.md).

## Future Android implementation

1. Obtain approval records for policy-dependent work and decide application identifier, Android version/device support, authentication method, and environment ownership.
2. Select and pin a supported Flutter/Dart combination; verify SDK and Android tooling using the installed command help and [official installation guidance](https://docs.flutter.dev/install).
3. Generate the Android Flutter project using official tooling only after implementation is requested. Preserve these documents; inspect generated changes before merging.
4. Add maintained Firebase packages and generate their lockfile through the package manager. Choose versions based on the selected SDK, not this document's host observations.
5. Establish isolated development/emulator resources, then configure the project following [Firebase Flutter setup](https://firebase.google.com/docs/flutter/setup). Confirm the project ID and environment before any write.
6. Add test fixtures and deny-by-default authorization tests before connecting sensitive features. Validate formatting, analysis, tests and an Android build on the actual package.

These are preparation steps, not executed installation commands. Android SDK folders exist locally, but device, license, emulator, Gradle and release-build readiness have not been established. iOS is outside the confirmed first release.
