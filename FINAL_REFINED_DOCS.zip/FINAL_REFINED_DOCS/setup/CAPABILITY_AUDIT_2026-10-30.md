# Capability audit before installation or configuration

2026-10-30, Asia/Dhaka. Read-only discovery except writing this planning package and its inventory. No installation, configuration change, cloud project creation or deployment performed.

## Skills, agents, plugins and MCP

Filesystem discovery found **118 SKILL.md files** across the configured local skill and plugin-cache roots; this includes cached versions and is not a count of enabled unique skills. Exact paths are in [the inventory](INSTALLED_SKILL_PATHS_2026-10-30.txt). The session's available-skills descriptions were reviewed for fit; unrelated skill bodies were not activated merely because installed.

| Capability | Observed availability | Planned use / actual activation |
|---|---|---|
| Graphify | Project skill/executable present; graph initially absent and query failed | Raw source inspection after absence confirmed; later `graphify update .` succeeded with 458 nodes/655 edges/49 communities; code/structural update, not full document-semantic extraction |
| Ponytail | Active full-mode instructions and installed skill read | Focused planning changes; preserve all requested functionality |
| Superpowers | Installed process skills | using-superpowers and brainstorming read; builder review requested; implementation approval gate retained |
| Plugin Management | Installed skill and tools; skill read | Firebase discovery confirmed installed/enabled; no plugin added |
| Flutter architecture/responsive/Dart test skills | Present in session catalog and filesystem inventory | Invoke at architecture implementation, layout and meaningful test stages |
| Firebase 1.1.0 | Manifest read; discovery returned installed=true, ENABLED | Auth, Firestore and Rules skills available for appropriate build stages; plugin installation is not proof of CLI/cloud connection |
| Design/image skills | imagegen-frontend-mobile, redesign/design-taste, imagegen and related skills present | Use mobile design guidance when rendering begins; avoid conflicting visual directions or unnecessary image generation for ordinary icons |
| PDF | Installed PDF skill and bundled document runtime available | Invoke when creating/rendering/visually auditing the final all-screen PDF |
| Security tools/skills | Codex Security tools and Firebase Rules auditor available | Apply scoped threat/Rules checks when contracts and real code exist; no scan claim now |
| Collaboration | Session subagent tools available | One read-only plan reviewer; no persistent agent installed |
| Custom agent files | `C:/Users/Victus/.codex/agents` and `C:/Users/Victus/.agents/agents` both absent | No custom agent definition claimed; project AGENTS.md is operating guidance, not an installed agent |
| MCP config | Top-level local config inspection showed `mcp_servers.node_repl`; only names/command-related metadata inspected | Do not infer global server readiness from config entries |
| Exposed tool namespaces | Codex app, document/artifact runtime, Node REPL, browser/computer use, web/image tools, GitHub/Atlassian/Linear/Sites/Security/Pets and management tools present in session | Tool exposure is not proof of account connection; irrelevant external data not accessed |
| Firebase MCP | Plugin manifest advertises MCP, but no Firebase-named callable tool surfaced in this session's tool inventory | Connection/runtime readiness not verified; inspect at Firebase setup stage before proposing configuration |

Local config listed plugin entries for Codex app tools, browser, unified computer use, visualize, computer use, documents, PDF, spreadsheets, presentations, template creator, Ponytail and Chrome. Cached plugin manifests additionally include Firebase, Superpowers, Sites, Codex Security and others exposed in the session catalog. Cached files, config entries and callable tools are distinct evidence; none alone establishes a fully connected external service. Secrets, auth files and environment values were not dumped.

## Development/runtime observations

| Tool | Observed result | Limit |
|---|---|---|
| Flutter | Executable on PATH; cache metadata says 3.47.5 stable | Flutter doctor/build/launch not run; metadata is not successful SDK execution |
| Dart | Direct SDK executable reports 3.13.4 stable, windows_x64 | No application analyzer/tests yet |
| Node | `node --version` → v24.17.0 | Package downloads/emulators not tested |
| Java | Executable resolves through Oracle javapath | Version/Gradle compatibility not verified in this review |
| Android SDK | Standard local SDK directory has platforms, build-tools, platform-tools, emulator and system-images | Device/AVD/license/build readiness not established |
| adb | Not found on PATH | SDK platform-tools directory exists; no device check |
| Firebase / FlutterFire CLI | Neither command found on PATH | No assertion that binaries exist nowhere on disk; no CLI account connection tested |
| Git | Initialized repository, master has no commits; remote listing empty | All existing files untracked; ordinary git diff cannot show their contents |
| Python | WindowsApps shim on PATH; bundled runtime resolved by Codex tool | Use bundled interpreter for reproducible local document checks |
| Bundled authoring tools | Codex runtime 26.1025.11240 supplies Python, Node and document-related libraries | PDF rendering libraries not executed during planning |

## Stage-specific installation policy

No missing capability requires installation to finish the plan. Before implementation: validate Flutter doctor, Android target and a clean package restore; choose app ID and supported SDK floor. At backend setup: inspect official Firebase/FlutterFire instructions, existing plugin tools and CLI location; install only a verified missing tool required for the approved action. Never overwrite global configuration wholesale or infer permission to provision a paid cloud project. At PDF delivery: use bundled runtimes first. Fonts and third-party imagery require explicit license/provenance review.

## Primary technical references checked

The proposed UI/data separation aligns with [Flutter architecture guidance](https://docs.flutter.dev/app-architecture/guide). The phone-login reconciliation follows [Firebase phone authentication](https://firebase.google.com/docs/auth/flutter/phone-auth); provider setup still requires real project configuration via [FlutterFire setup](https://firebase.google.com/docs/flutter/setup). Authorization planning uses [Firebase Auth and Security Rules](https://firebase.google.com/docs/rules/rules-and-auth). Accessibility work will follow [Flutter accessibility guidance](https://docs.flutter.dev/ui/accessibility). These references support plans; they do not verify this application's behavior.
