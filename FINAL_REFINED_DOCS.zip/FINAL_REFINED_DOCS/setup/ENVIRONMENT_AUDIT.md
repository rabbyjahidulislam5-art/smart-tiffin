# Environment audit

| Field | Value |
|---|---|
| Revision | 1.1 · 2026-10-30 (historical banner added; content below is the unchanged 2026-10-28 snapshot) |
| Owner | Setup author |
| Status | Historical snapshot of the authoring host, not of any production environment. |

**Historical note (2026-10-30):** this audit predates the four-application scope and reflects only the tooling available to the original authoring session on 2026-10-28. No re-audit for PostgreSQL, Flutter monorepo tooling, or web-hosting CLIs has been performed. See [setup/MONOREPO_AND_BUILD_OWNERSHIP.md](MONOREPO_AND_BUILD_OWNERSHIP.md) for what a future audit needs to cover.

Observed on 2026-10-28 in the local Codex desktop workspace. These observations concern the execution host available to this chat; they do not establish production readiness.

| Capability | Observed state | Consequence |
|---|---|---|
| OS / architecture | Windows 10.0.26300 / X64 from runtime inspection | Windows commands are appropriate |
| Shell | PowerShell 7.6.5; no-profile calls used after slow startup | Avoid depending on profile behavior |
| Workspace | C:\Users\Victus\Documents\ChatGPT\Smart Tiffin Service Management System | Writable documentation workspace |
| Git | 2.56.0.windows.3; master, no commits or remotes at initial audit | No tested commit, PR or remote CI exists |
| File access | Workspace writes allowed; SDK/config folders read-only without separate permission | No global configuration edited |
| Network | Restricted; web documentation retrieval succeeded | Package access is not guaranteed |
| Disk | C: approximately 106 GB free at audit | Snapshot only; not an ongoing quota guarantee |
| Dart | Direct SDK executable reports 3.13.4 stable windows_x64 | Runtime exists; no application analyzed |
| Flutter | Cache metadata reports stable 3.47.5, Dart 3.13.4 | Metadata observed; wrapper version invocation did not complete |
| Node | v24.17.0 from executable | Documentation verifier can run without packages |
| Python | Bundled runtime 3.12.14 verified | Available for authoring; not required by verifier |
| Android SDK | Standard local SDK folder contains platform-tools, platforms, build-tools, emulator and system-images | Folder existence is not a doctor/build/device check |
| Java | Command resolves; version probe did not complete | Java/Gradle compatibility unverified |
| adb | Not on PATH during discovery | No connected device validation performed |
| Firebase CLI | Not on PATH | No Firebase commands, emulators or deployment run |
| VS Code | Executable resolves on PATH | Extension configuration uninspected |
| Android Studio | Not established | Installation/readiness not claimed |
| Dart MCP | Local invocation attempted; pub.dev lookup failed with socket error | Not connected or validated; optional for future coding |
| Database / CI / deployment utilities | No project or integration selected | No database, migration, release or remote check executed |
| Apple / desktop / web targets | Outside Android-first scope | Toolchains not audited |

## Evidence and limits

Read-only probes included Get-Command, Get-PSDrive, runtime OS/architecture, git status/remote/version, SDK cache metadata, direct Dart --version, Node --version and the bundled Python --version. Long-running wrapper/Java probes were interrupted; they are not passes. The Dart MCP help attempt needed package lookup, which failed; no SDK installation or upgrade was performed.

The initial source statement that no repository exists is superseded by observed initialized .git metadata. The project still has no application source. No credentials, environment dumps or secret configuration values were read or recorded.

Documentation verification is separately recorded in [DOCUMENTATION_CHECKS.md](../verification/DOCUMENTATION_CHECKS.md). Reaudit Android-specific tooling when implementation starts.
