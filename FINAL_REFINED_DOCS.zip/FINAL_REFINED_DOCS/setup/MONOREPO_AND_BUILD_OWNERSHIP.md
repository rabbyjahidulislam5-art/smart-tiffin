# Monorepo and build ownership

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Setup author |
| Purpose | Concrete responsibilities for the four apps and shared packages: package names, environment injection, release channels, build verification, isolated route/permission tests, deterministic fixtures. |
| Depends on | [ADR-004](../adr/004-four-app-monorepo.md), [architecture/MULTI_APP_ARCHITECTURE.md](../architecture/MULTI_APP_ARCHITECTURE.md) |
| Status | PROPOSED — NOT APPROVED. Nothing below exists on disk; the OBSERVED baseline is a single Flutter package `smart_tiffin`. |

## Package responsibilities

| Package | Owns | Never imports from |
|---|---|---|
| `apps/customer_app` | CUS UI, routes, state | Any other app |
| `apps/partner_app` | PAR UI (both workspaces), routes, state | Any other app |
| `apps/admin_web` | ADM UI, routes, state | Any other app, `accounts_web` |
| `apps/accounts_web` | ACC UI, routes, state | Any other app, `admin_web` |
| `packages/auth_contracts` | Auth/claim type definitions | Any app, any other package except `domain_models` |
| `packages/domain_models` | Entity types mirroring [database/DATA_DICTIONARY.md](../database/DATA_DICTIONARY.md)/[FINANCIAL_DATA_MODEL.md](../database/FINANCIAL_DATA_MODEL.md) | Any app, `api_clients` |
| `packages/design_tokens_ui` | Theme, shared widgets | Any app |
| `packages/localization` | ARB resources, formatting | Any app |
| `packages/api_clients` | Typed command/read wrappers | Any app |
| `packages/validation` | Shared validators | Any app |
| `packages/error_handling` | Error taxonomy mapping | Any app |
| `packages/notification_interfaces` | Notification type contracts | Any app |
| `packages/money_format` | BDT minor-unit formatting | Any app |
| `packages/test_utils` | Deterministic fixtures | Production code paths |

This table is the acyclic dependency graph required by NFR-023; a CI check (not yet configured) would enforce it mechanically.

## Build verification (per app, once implementation starts)

Each app: `flutter analyze`, `flutter test`, a platform build (Android for CUS/PAR, Web for ADM/ACC), and its own isolated route-registration/permission test suite (confirming, for example, that ADM cannot reach an ACC-only command). Backend: `npm run check`, `npm test`, `npm run test:rules` (OBSERVED commands, extended for the new command files).

## Release channels

See [planning/RELEASE_PLAN.md](../planning/RELEASE_PLAN.md) §"Release channels" for the per-app channel table; not duplicated here.

## Deterministic fixtures

`packages/test_utils` provides one fixture set per domain (catalogue, subscription, payment, COD, ledger) shared across all apps' tests, version-controlled, producing identical results across repeated local runs (NFR-024).

## Migration from the current single app

TASK-010 (tracked in [TASKS.md](../TASKS.md)) covers restructuring `app/lib/{app,data,design,ui}` into this layout; not performed by this documentation effort.

## Acceptance and verification

Design-only. Verification requires a dependency-graph tool confirming no cycle exists once the packages are created.
