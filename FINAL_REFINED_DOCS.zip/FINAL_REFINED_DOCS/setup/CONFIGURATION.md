# Configuration boundaries

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (adds four-app and PostgreSQL configuration rows; original rows unchanged) |
| Owner | Setup author |
| Status | No runtime configuration of any kind exists in this package. |

There is no runtime configuration, Firebase project ID, application ID, environment file, signing credential, or service-account key in this package.

## 2026-10-30 extension

| Future configuration | Owner and boundary | Validation required |
|---|---|---|
| Per-app package/application identifiers (CUS, PAR, ADM, ACC) | Application maintainer | Four distinct identifiers, never shared |
| PostgreSQL connection string (ledger) | Backend/operations owner | Trusted backend secret manager only; never in a client or this repository |
| SSLCOMMERZ sandbox/live credentials | Payments owner | Separate secret scopes; sandbox only in this phase (ADR-007) |
| Admin Web / Accounts Web hosting configuration | Release owner | Session/CSRF model verified before any staff account is invited |
| Policy version store (`ent.PolicyVersion`) | Business/finance owner | Every BR-001…026 parameter published only after recorded approval |

No .env.example is created because no environment-file mechanism has been selected. Do not add arbitrary keys to make setup appear complete. Configuration must fail early for an invalid environment and must never silently fall back to production.

| Future configuration | Owner and boundary | Validation required |
|---|---|---|
| Android application ID and supported SDKs | Application maintainer | Confirm distribution target and generate native project settings |
| Firebase client options | Application maintainer | Match intended project and Android registration; client values are not authorization secrets |
| Firebase Auth provider | Authorized product stakeholder + maintainer | Record DEC-009 and exercise sign-in, recovery and revocation |
| Firestore policy/rules/indexes | Backend maintainer | Emulator tests; explicit project/environment selection |
| Trusted command service | Architecture owner | DEC-011, supported runtime, billing implications and least privilege |
| Privileged server credentials | Operations owner | Keep outside app/build assets; rotate and restrict access |
| Policy version and approved rules | Business owner | Record BR/DEC approval evidence before enabling dependent commands |
| Locale, service time zone and currency | Product owner | Bangla/English confirmed; time zone/currency and rounding still need decision |
| Notification permission/token lifecycle | App and backend maintainers | Token ownership, logout/revocation cleanup and redacted payloads |
| Android signing material | Release owner | Private storage, recovery and authorized distribution |

No .env.example is created because no environment-file mechanism has been selected. Do not add arbitrary keys to make setup appear complete. Configuration must fail early for an invalid environment and must never silently fall back to production.
