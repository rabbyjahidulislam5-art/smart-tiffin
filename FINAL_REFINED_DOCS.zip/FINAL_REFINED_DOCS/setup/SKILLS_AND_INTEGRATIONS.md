# Skills and integrations

| Field | Value |
|---|---|
| Revision | 1.1 · 2026-10-30 (historical banner; original content unchanged) |
| Owner | Setup author |
| Status | Historical record of the 2026-10-28 authoring session's tool availability. |

**Historical note (2026-10-30):** this session's own tool/skill availability may differ; no re-audit was performed as part of the four-application rewrite, which used the Agent, Read, Write, Edit, Glob, Grep and Bash tools available in this session.

Status as of 2026-10-28. A skill supplies instructions; an MCP server supplies tools; a plugin may bundle both; a package is an application dependency; Firebase is an external service. None of these categories proves that another is configured.

| Capability | Type / source | Actual availability | Purpose / activation | Configuration, validation and removal |
|---|---|---|---|---|
| Cavecrew | Installed local skill, C:/Users/Victus/.agents/skills/cavecrew/SKILL.md | Read during this task; revision not recorded | Delegation guidance; broad work used bounded agents | No project installation; remove only through a later requested skill-management action |
| OpenAI Docs | Installed system skill, C:/Users/Victus/.codex/skills/.system/openai-docs/SKILL.md | Read during this task | Verify Codex guidance | Official pages opened; no config mutation |
| Parallel agents | Session collaboration tools | Three agents actually assigned nonoverlapping files | Independent document authoring and review | Primary agent integrates; no persistent external service |
| Dart/Flutter MCP server | Official SDK tooling; [tooling overview](https://docs.flutter.dev/ai/tools) | Not exposed as a connected tool; local probe hit pub.dev socket failure | Optional diagnostics/test/runtime help during implementation | Requires compatible SDK/client and successful startup; validate tools on synthetic workspace; remove only its scoped registration if later added |
| Dart and Flutter official plugin | Official [Flutter agent setup](https://docs.flutter.dev/ai/get-started) | Documented upstream; not installed or verified here | Potential coding assistance later | Check this installed Codex client's plugin support and exact source before installing; no installation was needed for requirements |
| GitHub | Available but uninstalled connector in session catalog; local Git is present | No connection or remote | Later source control/CI if selected | Use narrowly scoped authorization; verify repository identity; remove its connection rather than unrelated configuration |
| Firebase Auth / Firestore / FCM | External managed services specified in proposal | No connected project | Planned application identity, storage, notifications | Project/region/budget/access unresolved; future isolated environment and end-to-end validation required |
| FlutterFire packages | Application packages | No pubspec or resolved versions | Future Flutter integration | Verify SDK constraints, licenses and maintenance when selected; package-manager-generated lockfile |
| Custom project skills | None | Not created | No demonstrated repetitive workflow requiring one | Existing tools suffice; no hypothetical skill is called installed |

## Codex instruction discovery

[Official Codex guidance](https://learn.chatgpt.com/docs/agent-configuration/agents-md) describes global guidance followed by the project-root-to-working-directory chain; each directory selects an override, AGENTS.md, or configured fallback. Closer guidance takes precedence. The documented default combined limit is 32 KiB. Inspect applicable files when moving scope; nested files are not a universal recursive load.

Local ancestor inspection found no applicable instruction file before authoring. No project fallback setting was established and no configuration was changed. This package uses one concise root AGENTS.md; no nested override is needed. A new session's automatic discovery was not independently tested.

The Flutter setup page also mentions CODEX.md and .agent/rules. That does not establish automatic discovery for this client. Use the Codex-owned guidance and an explicitly inspected AGENTS.md instead of assuming an unverified fallback.

## Least-privilege workflow

No additional installation is required for this deliverable. Future installations need a concrete task, an official source, compatible versions, minimal workspace/project access and an actual validation procedure. Prefer read-only integrations for inspection, synthetic development data for tests and secret-free logs. Never replace a user's whole configuration to add one integration.
