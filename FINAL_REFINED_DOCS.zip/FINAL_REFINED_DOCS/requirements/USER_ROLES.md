# User roles and access requirements

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (supersedes 0.1 · 2026-10-28) |
| Owner | Requirements and planning author (documentation set) |
| Purpose | Define the actors, the five protected roles and the Accounts sub-roles, the capability matrix per application, segregation of duties, and the rule that Admin and Super Admin have no implicit finance override. |
| Applies to | CUS, PAR-S, PAR-R, ADM, ACC and the backend authorization layer |
| Depends on | [Glossary](GLOSSARY_AND_TERMINOLOGY.md), [policy decision register](POLICY_DECISION_REGISTER.md), [authorization contract](../api/AUTHORIZATION.md), [roles, claims and sessions decision](../adr/011-roles-claims-and-sessions.md), [multi-app architecture](../architecture/MULTI_APP_ARCHITECTURE.md) |
| Authoritative policies | BR-004 (assignment authority), BR-003 (verifier), BR-020 (approval limits and maker-checker), BR-023 (dual-role accounts); all PENDING. This file states the structure; it does not approve any limit or authority. |
| Status | Draft for review. Capability allocations are PROPOSED; the roles themselves are USER-REQ. Nothing is implemented; the existing code enforces only the OBSERVED baseline described in section 9. |

## 1. Roles

The earlier four roles (customer, supplier or cook, delivery personnel, admin) are retained and a fifth role, Accounts, is added together with its sub-roles. A guest is an unauthenticated visitor, not a role.

| Role | Meaning | Primary application | Provenance |
|---|---|---|---|
| Guest | Anonymous visitor; public kitchens, meals and plans only; no private data. A protected action captures intent and returns after sign-in. | CUS | USER-REQ; OBSERVED (protect sheet in the prototype) |
| Customer | Registered buyer | CUS | USER-REQ |
| Supplier (kitchen partner, cook) | Approved food provider; one or more kitchens | PAR, supplier workspace (PAR-S) | USER-REQ |
| Rider (delivery partner) | Approved delivery person | PAR, rider workspace (PAR-R) | USER-REQ |
| Admin (operations and governance staff) | Invited staff for operations and oversight. No unrestricted balance or payout authority. | ADM | USER-REQ |
| Accounts (Accounts and Finance staff) | Invited staff for collections, reconciliation, settlement, payouts, ledger and reporting. Sub-roles below. | ACC | USER-REQ |

### 1.1 Accounts sub-roles (USER-REQ names; privileges PROPOSED)

| Sub-role | Intent | Never allowed |
|---|---|---|
| Finance Viewer | Read-only finance dashboards and reports | Any write; export of raw personal data unless granted |
| Accounts Operator | Prepare: record verification results, prepare reconciliations, draft payout requests and batches, raise adjustment requests | Approve own preparation; release a batch; close a period |
| Accounts Manager | Review operator work, manage exceptions, review payouts, request period close | Approve a payout they prepared; override segregation of duties |
| Payout Approver | Act as the checker for payouts and adjustments within a configured limit (`policy.payout.approval_limit`, BR-020) | Approve their own request; approve above their limit; prepare a batch they approve |
| Financial Auditor | Read-only inspection of ledger, audit trail and exports | Any write or approval |
| Super Admin (bounded) | Staff and policy administration: invite and suspend staff, manage the role-grant workflow, publish operational policy versions | Any implicit finance override: cannot approve payouts, post or edit journals, verify remittances or reopen a period unless separately and explicitly granted an Accounts sub-role, and then subject to the same segregation of duties |

A role is a server-validated grant (a claim plus a record), never a user-interface selection. A visually selected account type on a sign-in or sign-up screen is routing intent only; the server decides from verified grants and approval state. (USER-REQ; ADR-011.)

## 2. Capability matrix by capability and role

Legend: **Own** = only the actor's own records; **Rel** = only records related to the actor through ownership, the supplier relationship or an active assignment; **Read** / **Manage** = read / create-and-change within the stated scope; **Prep** = prepare but not approve; **Appr** = approve within limit; **Ltd** = limited, non-sensitive summary; **Gated** = depends on a pending decision; **—** = no access. Every cell is PROPOSED and is enforced at the trusted boundary, not by hiding controls.

| Capability | Guest | Customer | Supplier | Rider | Admin | Accounts |
|---|---|---|---|---|---|---|
| Public kitchens, meals, plans, public availability | Read | Read | Read own preview | — | Read all, incl. unpublished (oversight) | — |
| Own profile, sessions, notification preferences | — | Own | Own | Own | Own | Own |
| Addresses and zone validation | — | Own | Kitchen address own | Own | — | — |
| Kitchen profile, meals, variants, price versions, allergens | — | Read | Manage own | — | Oversight (suspend, flag); cannot rewrite paid prices | — |
| Slot availability, capacity, stock | — | Read | Manage own | — | Oversight | — |
| Quotes and checkout (server-computed) | — | Own | — | — | — | Read snapshot |
| One-time orders | — | Own | Rel (own kitchen) | Rel (assigned) | Monitor | Read financial summary |
| Subscriptions, schedule changes, skip, replace | — | Own | Rel (obligations, no unnecessary customer data) | — | Inspect for support | Read financial snapshot |
| Service credits: balance and history | — | Own | — | — | Read for support | Manage (issue only from approved adjustment) |
| Online payment initiation and status | — | Own | — | — | Read status only | Verify, reconcile |
| Manual payment evidence (fallback) | — | Submit own | — | — | Gated (BR-003) | Gated (BR-003) |
| COD collection | — | Acknowledge own | — | Record (assigned only) | Read exceptions | Verify remittance, resolve discrepancy |
| Delivery assignment | — | — | Handoff | Accept or decline offers | Dispatch (BR-004 Gated) | — |
| Delivery state updates (Pending, Picked Up, On The Way, Delivered) | — | Read own | Read context | Update assigned only | Monitor; exceptional override Gated | — |
| Delivery proof and failure reports | — | Confirm own | Read | Submit (assigned) | Review | Read for disputes |
| Supplier earnings and statements | — | — | Own | — | Ltd | Manage |
| Rider earnings and statements | — | — | — | Own | Ltd | Manage |
| Payout request | — | — | Create own | Create own | — | Review, Prep, Appr (maker-checker) |
| Refund, dispute, chargeback, adjustment | Request dispute (own order) | Request own | Evidence own | Evidence own | Recommend; decide disputes per BR-015 (Gated) | Prep, Appr, post journals |
| Ledger, journals, reconciliation, period close | — | — | — | — | — | Per sub-role (section 4) |
| Finance reports and export | — | Own invoices | Own statements | Own statements | Operational reports; Ltd finance | Per sub-role |
| Partner application and corrections | — | Apply (as applicant) | Own application | Own application | Decide | Payout destination verification only |
| Staff accounts and role grants | — | — | — | — | Super Admin: invite, suspend; requests | Grants for finance roles require a second approver (BR-020) |
| Policy configuration | — | — | — | — | Propose; publish operational versions | Co-approval for financial parameters (PROPOSED) |
| Complaints and tickets | — | Submit and read own | Submit own | Submit own | Handle | Financial tickets only |
| Reviews | — | Submit on eligible own order | Read own | — | Moderate (policy Gated, DEC-013) | — |
| Audit log | — | — | — | — | Operational audit | Financial audit (Auditor read) |

## 3. Capability matrix by application

Each application exposes only the screens of its audience. A user holding grants for several applications signs in to each separately; sessions are not shared across web origins.

| Application | Roles allowed to sign in | Workspaces and navigation | Notes |
|---|---|---|---|
| CUS | Guest (no sign-in), Customer | Guest shell P-01…P-04; customer tabs C-01 Home, C-10 Subscriptions, C-16 Orders, C-23 Profile (OBSERVED prototype tabs); shared SH-* instance | An approved supplier or rider who is also a customer uses CUS as a customer only. |
| PAR | Supplier, Rider (each only with an approved grant) | Supplier workspace tabs S-01, S-04, S-06, S-08; rider workspace tabs R-01, R-07, R-09; separate dashboards, balances and notifications | One binary. The workspace is selected from verified grants. Dual-role handling is BR-023 (PENDING). A pending applicant sees AU-11 only; the prototype's lack of a role guard (known gap 20) must not be reproduced. |
| ADM | Admin staff, Super Admin | Desktop navigation: overview A-01, applications A-06, users A-08, orders A-10, incidents A-03, settings A-15, audit A-17, security A-18; new NA-01…NA-06 | Invite-only; multi-factor required (PROPOSED). No finance write paths. |
| ACC | Accounts sub-roles | Finance overview NF-01 and the NF-02…NF-17 workspaces | Invite-only; multi-factor required (PROPOSED); finance authority is per sub-role. |

## 4. Accounts sub-role capability matrix (PROPOSED)

Legend: **R** read; **P** prepare or request; **A** approve or post (checker); **—** none. Approval requires a different identity from the preparer and respects the configured limit (INV-15; BR-020).

| Capability | Finance Viewer | Accounts Operator | Accounts Manager | Payout Approver | Financial Auditor |
|---|---|---|---|---|---|
| Finance overview and dashboards (NF-01) | R | R | R | R | R |
| Online payment reconciliation (NF-02) | R | P | R, A (exceptions) | R | R |
| COD dashboard (NF-03) | R | R | R | R | R |
| COD deposit verification (NF-04) | R | P (verify) | A (second approval for discrepancies) | — | R |
| Supplier and rider payable ledgers (NF-05, NF-06) | R | R | R | R | R |
| Payout request review (NF-07) | R | P | P, review | A (within limit) | R |
| Payout batch execution (NF-08) | R | P (prepare) | P, release request | A (release as checker) | R |
| Customer credit liability (NF-09) | R | R | R | — | R |
| Refund and chargeback management (NF-10) | R | P | A within limit | A within limit | R |
| General ledger explorer (NF-11) | R | R | R | R | R |
| Period close workspace (NF-12) | R | P | A (close request) | — | R |
| Reconciliation exceptions (NF-13) | R | P | A | — | R |
| Financial report export (NF-14) | R (granted scope) | R | R, export | — | R, export |
| Finance role permissions (NF-15) | — | — | P (request) | — | R |
| Adjustment approval (NF-16) | R | P (request) | P | A (within limit) | R |
| Gateway settlement statement (NF-17) | R | P | A | — | R |

Whether period close needs a second approver, and all limits, are decided by BR-020 and BR-014; this table does not choose them.

## 5. Segregation of duties (PROPOSED controls, enforced by the backend)

| Duty | Control | Invariant / source |
|---|---|---|
| Payout approval | The preparer, reviewer and approver of one payout are different staff identities; approval amount ≤ approver limit; no emergency override path | INV-15; BR-020; SC-16 |
| Adjustment approval | Requester ≠ approver; approved adjustment is posted as a reversing or adjusting journal, never an edit | INV-02; FR-039, FR-040 |
| COD remittance verification | A rider can never verify their own remittance; one deposit reference is verified at most once; discrepancies need a different approver | INV-12; BR-013; SC-09, SC-10 |
| Period close and reopen | Preparer ≠ closer; reopening is governed and recorded; no silent backdating | INV-16; SC-15 |
| Role grants | No self-grant; requester ≠ approver; finance grants require Accounts-side approval; every grant is audited | FR-044; BR-020 |
| Admin versus Accounts | Admin cannot approve payouts, post journals, verify remittances or edit balances; the limited financial overview (NA-05) is read-only | SC-16; A-12, A-13 reclassification |
| Super Admin | Staff administration only; holds no implicit finance authority and cannot approve a payout they prepared | SC-16 |
| Partners | A supplier or rider cannot approve their own payout, verify their own earnings or change their balance | INV-09, INV-14 |
| Customers | A customer cannot set verification state, credit state or payment state | FR-003, FR-013 |
| Same person holding two staff grants | A person holding both an Admin grant and an Accounts grant is prohibited by default (PROPOSED); any exception needs explicit approval and increased audit | BR-020 |

## 6. Dual-role accounts (BR-023, PENDING)

The prototype lets a customer open "Apply as a Cook" or "Apply as a Rider" from the profile (OBSERVED, C-23). Whether one person may hold supplier and rider roles, or customer and partner roles, with one login is PENDING (BR-023, DEC-033).

PROPOSED, not approved: one identity may hold several grants; each grant has an independent workspace, independent financial balance, independent notifications and an independent authorization check on every command; navigation is derived from verified grants, never from a tab selection; there is no shared mutable balance; logout and session expiry apply to the whole identity. A rider-and-supplier person never nets one balance against the other except through an approved hold or offset (BR-026). Scenario SC-25 exercises this behavior.

Until BR-023 is approved, the proposed design assumes one effective partner role per identity at launch and does not allow registration to grant privilege.

## 7. Cross-cutting access requirements

1. Authentication alone does not authorize object access. Every request needs role, ownership or relationship (supplier-to-kitchen, rider-to-active-assignment, customer-to-own-record) and approval state, checked at the trusted boundary. Hidden controls and route guards are usability measures only.
2. A suspended, disabled, revoked or expired account is denied at the trusted boundary even when a client holds a valid session; revocation takes effect on the next request (ADR-011).
3. A supplier cannot read another supplier's orders, subscriptions or financial reports. A rider receives only the customer data needed for a current assignment; access ends on reassignment or completion.
4. Payment verification, refund approval and payout approval cannot be inferred from a dashboard label. Authority comes from a grant plus the BR-003, BR-005, BR-014 and BR-020 outcomes.
5. Privileged changes record actor, target, timestamp, reason code, request identity and prior and new state in restricted audit events.
6. Registration must not allow self-assignment of supplier approval, rider privilege, Admin or Accounts authority. Self-registered customers never gain finance or dispatch capability.
7. Staff accounts are created by invitation, approved, suspended and removed through audited flows; multi-factor authentication and session timeout apply (PROPOSED); no staff sign-in is linked from public screens.
8. No cross-role notification leakage, shared mutable balances or navigation that skips approval.
9. Role and account-status fields are never client-editable.
10. Collect only identity fields that are justified; masked display of phone, payout account and national identity values follows the prototype conventions (`+880 17••`, `••••4401`).

## 8. Screen implications

| Concern | Screens |
|---|---|
| Sign-in and role routing | AU-03, AU-12, AU-13, AU-11 (status), SH-05 |
| Applicant journeys | AU-09, AU-10, AU-11; admin side A-06, A-07, NA-03 |
| Staff and role administration | A-08, A-09, A-18, NF-15 |
| Segregation visibility (rejected attempts) | NA-05, NF-07, NF-16 and the audit screens A-17, NF-11 |

## 9. OBSERVED baseline of access control

The current `backend/functions` callable accepts one envelope `{command, requestId, expectedVersion?, payload}`. Working commands include `saveProfile`, `saveAddress`, `savePreferences`, `saveDevice`, `saveFood`, `savePlan`, `saveMenu`, `setAvailability` and `submitComplaint`. Policy-gated commands including `changeRole`, `approveSupplier`, `assignDelivery`, `verifyPayment` and `recordAdjustment` return `failed-precondition` until the corresponding policy exists. Firestore rules deny by default. These statements are OBSERVED from the files; this effort did not run or verify them. See [code reality snapshot](../architecture/CODE_REALITY_SNAPSHOT.md). The earlier decision DEC-009 (identity and role policy) remains open; its sign-in provider, bootstrap and multi-role questions are carried into [assumptions and constraints](ASSUMPTIONS_AND_CONSTRAINTS.md).

## 10. Acceptance and verification

| Condition | Reference |
|---|---|
| Each protected command has positive allowed-role and negative unauthenticated, wrong-role, foreign-object and revoked-actor tests | NFR-007; AC-003, AC-067 |
| Admin and Super Admin sessions cannot approve a payout, post a journal or verify a remittance | AC-067; SC-16 |
| A role switch in the Partner App follows verified grants, not a tab | AC-066; SC-25 |

## 11. Open decisions

| Decision | Status | Effect |
|---|---|---|
| BR-023 dual-role accounts | PENDING | Partner-App workspace routing and balances |
| BR-004 who may assign deliveries (Admin, Supplier, rule-based, courier claim) | PENDING | Dispatch capability for Admin and Supplier |
| BR-003 who verifies manual payment evidence | PENDING | Whether any actor verifies the fallback evidence |
| BR-020 approval limits and maker-checker thresholds | PENDING | Payout Approver limits; second approval for period close |
| DEC-009 sign-in providers, administrator bootstrap, recovery, multi-factor scope | PENDING | Authentication and all privilege transitions |
