# Policy decision register (extension of BR-001…BR-005)

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation lead; decision owner for every entry: **Business owner / authorised stakeholder — to be identified** |
| Purpose | Extend the existing decision register for the four-app, finance-enabled scope. Each entry follows the ten-field format required by the master prompt (question, evidence, alternatives, recommendation, business impact, technical impact, risk, owner, status, affected documents). |
| Applies to | All modules that depend on a commercial or legal rule |
| Depends on | [Business rules](BUSINESS_RULES.md) (BR-001…BR-005 detail), [assumptions and decisions](ASSUMPTIONS_AND_CONSTRAINTS.md), [glossary](GLOSSARY_AND_TERMINOLOGY.md) |
| Authoritative policies | This file for BR-006…BR-026; [BUSINESS_RULES.md](BUSINESS_RULES.md) for BR-001…BR-005 |
| Status | **Every entry is PENDING. Every recommendation is "PROPOSED — NOT APPROVED".** No cutoff, fee, percentage, threshold, deadline, tax rate or refund entitlement has been approved. Approval evidence: none supplied. |

## How to read this register

- Numbering: `BR-n` is the rule, `DEC-(n+10)` is its decision record (BR-006 ↔ DEC-016 … BR-026 ↔ DEC-036). The five original rules keep `BR-001…BR-005` with `DEC-004, 003, 005, 006, 007`.
- **Blocks** names only the behaviour that cannot be finalised; independent modules proceed with configurable parameters (`policy.*` names) and no default values.
- "Existing evidence" is the strongest source for the question. All figures anywhere in the documentation set that illustrate a rule are HYPOTHETICAL.
- Approval needs: selected option and every parameter, approver name and authority, effective date and policy version, approval evidence, accepted exceptions. Silence, a generated document, or "yes" without values is not approval.

## Original rules (kept; detail in BUSINESS_RULES.md)

| Rule | Subject | Decision | Status | Extended by |
|---|---|---|---|---|
| BR-001 | Meal pauses and skips (granularity, cutoff, reversal, preparation override, financial effect) | DEC-004 | PENDING | BR-006 (credit), BR-017 (substitution), BR-022 (time) |
| BR-002 | Billing (basis, coverage, proration, due dates, fees, tax, rounding, adjustments) | DEC-003 | PENDING | BR-007, BR-008, BR-009, BR-016, BR-018 |
| BR-003 | Payment verification (verifier authority, evidence, deduplication, allocation) | DEC-005 | PENDING | Applies to manual evidence; gateway validation rules in ADR-007; COD in BR-012/BR-013 |
| BR-004 | Delivery assignment (owner, method, eligibility, reassignment, completion evidence) | DEC-006 | PENDING | BR-011 (compensation), BR-023 |
| BR-005 | Cancellation and refunds (actors, scope, charges, approval, execution) | DEC-007 | PENDING | BR-006, BR-015, BR-025 |

## New rules

Each block gives: question · existing evidence · alternatives · PROPOSED recommendation · business impact · technical impact · security/financial risk · owner · status · affected documents/modules.

### BR-006 / DEC-016 — Service-credit eligibility, calculation and use
- **Question:** When does a skipped, paused or reduced prepaid meal create a service credit, in what amount, and how may it be used?
- **Evidence:** USER-REQ master prompt phase 5 (credits for eligible skips subject to approved cutoff and credit policy; formulas required; credits are liabilities, not a wallet). No values supplied.
- **Alternatives:** (a) credit = meal price share of the paid obligation, excluding delivery fee; (b) credit includes proportional delivery fee when the delivery trip is avoided; (c) tiered credit by notice period; (d) no credit after kitchen has started preparation.
- **PROPOSED (not approved):** (a) with delivery component treated per BR-007 outcome; credit reduces future payable only; computed server-side from the original quote snapshot.
- **Business impact:** Customer trust, cash-flow and liability size. **Technical impact:** formula engine, `ent.CreditTransaction`, unique origin constraint (INV-08). **Risk:** double credit, over-credit, credit used against fulfilled obligations.
- **Owner:** business owner + finance. **Status:** PENDING. **Affects:** CUSTOMER_CREDIT_RULES, PRICING_AND_BILLING, FR-031/032, NC-09/11/16, MOD-CRD, MOD-SUB, SC-01/04/05/06/14/23.

### BR-007 / DEC-017 — Delivery charges
- **Question:** How is the delivery fee set for one-time orders, daily/weekly/monthly deliveries, grouped meals, separate trips, zone or distance, and partner-specific arrangements?
- **Evidence:** USER-REQ (policies must differ by purchase type; configurable; none invented); prototype sample "BDT 40 delivery" is OBSERVED sample only.
- **Alternatives:** flat per delivery; per zone band; per distance band; free above subscription threshold; grouped delivery fee per trip regardless of slots count.
- **PROPOSED:** configurable zone-band fee with per-trip grouping rule, versioned in `ent.PolicyVersion`.
- **Impacts:** quote engine, delivery-fee credit on skip, NC-07. **Risk:** under/over billing, rider cost mismatch. **Owner:** business owner. **Status:** PENDING. **Affects:** PRICING_AND_BILLING, FR-030, MOD-PRC, SC-02/22.

### BR-008 / DEC-018 — Subscription and promotional discounts
- **Question:** Which discounts exist, how they stack, expiry, whether quote expiry voids a promotion, and whether a discount is clawed back on skip.
- **Evidence:** USER-REQ (discount lines in quote; document whether quote expiry invalidates a promotion). **Alternatives:** plan-level percentage; per-meal fixed; promo code; none. **PROPOSED:** discounts attach to quote lines and are prorated on credit. **Risk:** abuse, stacking errors. **Status:** PENDING. **Affects:** PRICING_AND_BILLING, SC-23, MOD-PRC.

### BR-009 / DEC-019 — Platform commission and service fee
- **Question:** How platform commission (from suppliers) and customer service fee are determined, and when revenue is recognised.
- **Evidence:** USER-REQ (revenue separate from gross collections; commission and service-fee accounting). **Alternatives:** percentage of food value; fixed per order; tiered by volume. **PROPOSED:** percentage parameter per kitchen contract, recognised at the supplier-earning recognition event. **Impacts:** ledger revenue, supplier statements. **Risk:** misstatement of revenue. **Status:** PENDING. **Affects:** accounts-web/FINANCIAL_LEDGER, SUPPLIER_EARNINGS, FR-036/040.

### BR-010 / DEC-020 — Supplier earning recognition event
- **Question:** At which milestone does a supplier become entitled to earnings: accepted, prepared, handed off, delivered, or delivery verified?
- **Evidence:** USER-REQ (define exact event; prepayment ≠ earned). **Alternatives:** handoff to rider; delivery completion; delivery verified + no dispute window. **PROPOSED:** delivery completion with a configurable dispute hold. **Risk:** paying for undelivered meals; supplier disputes. **Status:** PENDING. **Affects:** SUPPLIER_EARNINGS, NS-01, NF-05, INV-09, SC-01/03/21.

### BR-011 / DEC-021 — Rider delivery compensation
- **Question:** How the per-delivery fee is determined, when it is confirmed, and what happens on failure, reassignment, or customer absence.
- **Evidence:** USER-REQ (assignment alone earns nothing; reassignment must not double pay). **Alternatives:** flat per delivery; distance band; per-trip incentive; partial pay on failed delivery. **PROPOSED:** fixed per-trip parameter recognised on verified completion; reversed/prorated on reassignment per policy. **Risk:** double payment, fraud. **Status:** PENDING. **Affects:** RIDER_EARNINGS, NR-01, NF-06, INV-19, SC-08/21.

### BR-012 / DEC-022 — COD eligibility and limits
- **Question:** Which orders/customers may use COD; per-order and outstanding limits; whether COD is allowed for subscriptions and in which of the four COD models.
- **Evidence:** USER-REQ (COD for eligible one-time orders and any specifically approved subscription arrangement; four separate models). **Alternatives:** one-time only; new-customer cap; trust tiers; allow weekly collection. **PROPOSED:** one-time orders only until a subscription model is approved; limits as parameters. **Risk:** credit exposure, unpaid balances. **Status:** PENDING. **Affects:** COD_PAYMENT_WORKFLOW, NC-14, SC-03, MOD-COD.

### BR-013 / DEC-023 — COD remittance deadlines, overdue and recovery
- **Question:** Deadline for rider remittance, partial remittance, overdue handling, recovery, and whether outstanding COD blocks rider payouts or assignments.
- **Evidence:** USER-REQ (partial remittance, overdue cash, discrepancies, recovery). **Alternatives:** same-day; next business day; weekly batch. **PROPOSED:** configurable deadline with escalation states; no auto write-off. **Risk:** cash loss, disputes. **Status:** PENDING. **Affects:** COD_RECONCILIATION, NR-04/05, NF-03/04, SC-09/10/12.

### BR-014 / DEC-024 — Payout thresholds, frequency and holds
- **Question:** Minimum payout, frequency, destination types (bank/MFS), hold reasons and release rules.
- **Evidence:** USER-REQ (thresholds, settlement frequency, holds). **Alternatives:** on-demand with minimum; weekly batch; monthly. **PROPOSED:** request-based with configurable minimum and batch release. **Risk:** unverified beneficiary, premature payout. **Status:** PENDING. **Affects:** PAYOUT_MANAGEMENT, NS-02, NR-02, NF-07/08, SC-11/12.

### BR-015 / DEC-025 — Disputes and chargebacks
- **Question:** Who decides disputes, evidence required, time limits, effect on supplier and rider balances, chargeback loss allocation.
- **Evidence:** USER-REQ (disputes, chargebacks, evidence review, financial reversal). **Alternatives:** platform absorbs; supplier bears; split by fault. **PROPOSED:** decision workflow with holds; loss allocation left PENDING. **Status:** PENDING. **Affects:** REFUNDS_AND_ADJUSTMENTS, NF-10, A-05, SC-14.

### BR-016 / DEC-026 — Unpaid subscription handling and suspension
- **Question:** Grace period, service suspension, retries, collection for unpaid weekly/monthly or COD-settled subscriptions.
- **Evidence:** USER-REQ (unpaid balances, service suspension policies where applicable). **PROPOSED:** no service beyond paid coverage unless an approved postpaid arrangement exists. **Status:** PENDING. **Affects:** PRICING_AND_BILLING, NC-12/13, MOD-SUB.

### BR-017 / DEC-027 — Meal substitutions, upgrades and downgrades
- **Question:** Which substitutions are allowed (same kitchen, same slot), cutoff, price difference handling, whether a downgrade difference becomes credit or refund.
- **Evidence:** USER-REQ (replace, upgrade/downgrade, quotation, credit/debit difference). **PROPOSED:** same-kitchen future obligations before cutoff; difference as charge or credit; both items never fulfilled. **Status:** PENDING. **Affects:** NC-10, FR-031, SC-05/06.

### BR-018 / DEC-028 — Tax calculation
- **Question:** Whether and how tax applies to food, delivery and service fee; inclusive or exclusive display.
- **Evidence:** USER-REQ ("applicable tax where legally required"; legal compliance never declared). **PROPOSED:** tax is a configurable line with rate/version, off until confirmed by qualified advice. **Risk:** regulatory. **Status:** PENDING (legal). **Affects:** PRICING_AND_BILLING, AUDIT_AND_COMPLIANCE.

### BR-019 / DEC-029 — Credit expiry
- **Question:** Whether service and promotional credits expire and after what period.
- **Evidence:** USER-REQ ("expired credits if expiration is approved"). **Alternatives:** none; fixed months; per class. **PROPOSED:** no expiry until approved and legally reviewed. **Status:** PENDING. **Affects:** CUSTOMER_CREDIT_RULES, NC-11, NF-09.

### BR-020 / DEC-030 — Financial approval limits and maker-checker
- **Question:** Amount thresholds per role, dual approval, who may approve own preparation (never), emergency override.
- **Evidence:** USER-REQ (preparer ≠ approver; approval limits). **PROPOSED:** maker ≠ checker always; thresholds as parameters; no override path. **Status:** PENDING. **Affects:** PAYOUT_MANAGEMENT, NF-15/16, SC-16, INV-15.

### BR-021 / DEC-031 — Multi-kitchen subscriptions
- **Question:** May one subscription span kitchens; separate deliveries and fees; invoice allocation.
- **Evidence:** USER-REQ (different kitchens "when allowed by approved business rules"). Prototype enforces one kitchen per cart (OBSERVED). **PROPOSED:** one kitchen per subscription agreement at launch; multiple agreements per customer allowed; explain restriction before payment. **Status:** PENDING. **Affects:** NC-04, C-05, SC-22.

### BR-022 / DEC-032 — Cutoff rules and service time
- **Question:** Cutoff per slot/kitchen/category, time zone, holidays, cross-midnight handling.
- **Evidence:** USER-REQ (first-class domain; no arbitrary deadline). Relates DEC-008 (Asia/Dhaka, proposed). **PROPOSED:** policy-versioned cutoff evaluated server-side against canonical UTC timestamps and Asia/Dhaka service dates. **Status:** PENDING. **Affects:** TIME_AND_CUTOFF_POLICY, BR-001, FR-050.

### BR-023 / DEC-033 — Dual-role accounts
- **Question:** May one person be both supplier and rider, or customer and partner, with one login.
- **Evidence:** USER-REQ (explicit policy required). Prototype: Customer profile offers "Apply as a Cook / Rider" (OBSERVED). **PROPOSED:** one identity may hold several grants, each with an independent workspace, balance and authorisation check; no shared mutable balance. **Status:** PENDING. **Affects:** USER_ROLES, SC-25, ADR-011.

### BR-024 / DEC-034 — Kitchen discontinuity and compliance lapse
- **Question:** What happens to paid commitments when a kitchen goes offline or loses certification; who approves replacement kitchens; customer remedies.
- **Evidence:** USER-REQ (SC-07, SC-17). **PROPOSED:** block new orders; managed resolution queue; replacement only with customer consent. **Status:** PENDING. **Affects:** ADM approval workflows, SC-07/17.

### BR-025 / DEC-035 — Legal status of credits, stored value and customer funds
- **Question:** Whether credits, prepaid obligations or payout handling constitute regulated stored value or customer-funds activity in Bangladesh, and whether credit may ever be cashed out.
- **Evidence:** USER-REQ (identify legal questions; no compliance claim). **PROPOSED:** credits non-withdrawable until written advice says otherwise. **Status:** PENDING (legal). **Affects:** AUDIT_AND_COMPLIANCE, CUSTOMER_CREDIT_RULES.

### BR-026 / DEC-036 — Netting of rider COD obligation against rider earnings
- **Question:** May outstanding COD remittance be offset against rider payable; under what approval.
- **Evidence:** USER-REQ ("approved offsets, if policy allows"; SC-12). **PROPOSED:** no automatic netting; explicit approved hold/offset only. **Status:** PENDING. **Affects:** RIDER_SETTLEMENT, NF-06, SC-12, INV-10.

## Summary

| Count | Value |
|---|---|
| Original rules | 5 (BR-001…BR-005) |
| New rules | 21 (BR-006…BR-026) |
| Total decision records in register | 26 rules; all PENDING |
| Approved | 0 |
