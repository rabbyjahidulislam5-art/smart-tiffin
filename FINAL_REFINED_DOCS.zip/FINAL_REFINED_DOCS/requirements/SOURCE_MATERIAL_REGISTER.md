# Source material register

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (reverses 0.1 · 2026-10-28, which wrongly marked both sources "not adopted") |
| Owner | Documentation lead (primary agent) |
| Purpose | Record the provenance of the two documents the user supplied in conversation and state, without qualification, that both are now this project's primary requirements. |
| Applies to | All applications and all documentation |
| Depends on | [Source digest: master prompt](../analysis/SOURCE_MASTER_PROMPT_DIGEST.md), [Source digest: legacy prototype](../analysis/SOURCE_LEGACY_PROTOTYPE_DIGEST.md), [conflict register](../analysis/CONFLICT_REGISTER.md) item C-04 |
| Status | Current. This revision corrects the earlier register, which the user's 2026-10-30 instruction explicitly reversed. |

## Correction notice

The 0.1 revision of this file (2026-10-28, superseded) stated that the four-application split, the Accounts Web application, and the 94-screen prototype inventory were "aspirational source material — NOT approved scope" and instructed readers not to cross-reference their identifiers. **That instruction is withdrawn.** On 2026-10-30 the user explicitly designated both documents as this project's primary requirements and directed a full reconciliation rather than a rejection. See [conflict register item C-04](../analysis/CONFLICT_REGISTER.md).

## 1. "Smart Tiffin master prompt" (the expanded master prompt)

| Field | Value |
|---|---|
| Origin | Supplied inline in conversation by the user, 2026-10-30. Not a file on disk in this repository; preserved in full as the [master prompt digest](../analysis/SOURCE_MASTER_PROMPT_DIGEST.md). |
| Status | **Primary requirement (USER-REQ).** |
| Content | A twenty-phase specification: four applications (Customer mobile, Partner mobile with supplier and rider workspaces, Admin Web, Accounts Web) on one shared backend; a flexible kitchen and meal system; a custom daily/weekly/monthly subscription engine; non-cash customer service credits; a pricing and billing engine; SSLCOMMERZ (future) and four distinct COD models; supplier and rider earnings and payouts; a dedicated Accounts department with a double-entry ledger, reconciliation and maker-checker payouts; ten end-to-end workflows (A–J) and twenty-five cross-system scenarios (SC-01…SC-25); an extended policy decision register; 94 "observed prototype" screen identifiers plus 55 "proposed documentation" screen identifiers (NC/NS/NR/NA/NF); and governance sections on provenance, monorepo ownership, time/cutoff policy, pricing snapshots, authentication, cash-versus-earnings terminology, misconduct prevention, accessibility and the integration roadmap. |
| Adoption | Adopted as the primary requirement source for architecture, the four applications, the subscription and finance domain, the policy register extension (BR-006…BR-026), the scenario catalogue, and the proposed screen set. Every commercial figure, cutoff, fee, percentage or threshold it illustrates remains explicitly **hypothetical** and **not approved**; BR-001…BR-005 keep their original repository meanings and stay Pending Decision exactly as before this request. Where the prompt recommends an architecture (for example, re-evaluating Firestore against a relational store for financial data), that recommendation is carried as a **PROPOSED, not-approved** architecture decision record, never as settled policy. |

## 2. "FRONTEND_UI_UX_COMPLETE_SYSTEM_DOCUMENTATION.md" (the legacy prototype documentation)

| Field | Value |
|---|---|
| Origin | Supplied inline in conversation by the user, 2026-10-30. Not a file on disk; describes `apps/smart-tiffin-prototype-copy/`, a path confirmed absent from this repository. Preserved in full as the [legacy prototype digest](../analysis/SOURCE_LEGACY_PROTOTYPE_DIGEST.md). |
| Status | **Primary requirement for the legacy screen inventory (OBSERVED, as reported by its own author).** |
| Content | A code-read inventory of 94 screens in a React 18/TypeScript/Vite prototype (`P-`, `AU-`, `SH-`, `C-`, `S-`, `R-`, `A-`, `X-` identifiers), each tagged Interactive, UI-only or Simulated; the full navigation and state model (`ProtoProvider`/`Store`); a design-token system (glassmorphism, per-role colour, four responsive bands); twenty-two documented prototype gaps; and a backend-integration-points table. |
| Adoption | The 94 screen identifiers are now **authoritative and unchanged** — see [conventions and identifier register, §4](../analysis/CONVENTIONS_AND_ID_REGISTER.md). They are reconciled one-to-one against the project's own earlier 129-family planning inventory in [design/INVENTORY_RECONCILIATION.md](../design/INVENTORY_RECONCILIATION.md), with every legacy ID mapped to one of the four applications and given a migration action (Reuse / Extend / Replace / Split). The documented design tokens, navigation patterns and prototype gaps are adopted as the visual and behavioural reference for Flutter re-implementation (see [design/DESIGN_SYSTEM.md](../design/DESIGN_SYSTEM.md) and [architecture/REACT_TO_FLUTTER_MIGRATION.md](../architecture/REACT_TO_FLUTTER_MIGRATION.md)), never as evidence that any backend behaviour is implemented: every prototype status (I/U/S) is carried forward unchanged and a simulated interaction is never described as a working feature of the real `app/` Flutter project described in [architecture/CODE_REALITY_SNAPSHOT.md](../architecture/CODE_REALITY_SNAPSHOT.md). |

## 3. Resulting rule for every other document in this package

Both sources are cited as `[master prompt digest]` and `[legacy prototype digest]` wherever a requirement, screen, workflow or scenario originates from them. No document in `FINAL_REFINED_DOCS/` may describe either source as merely "reference only" or "not adopted"; any remaining such statement in an unrevised file is a defect tracked in the [existing document audit](../analysis/EXISTING_DOCUMENT_AUDIT.md) and the [obsolete document review](../analysis/OBSOLETE_DOCUMENT_REVIEW.md).
