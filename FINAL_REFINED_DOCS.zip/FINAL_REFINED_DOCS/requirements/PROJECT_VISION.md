# Project vision

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (supersedes 0.1 · 2026-10-28) |
| Owner | Requirements and planning author (documentation set) |
| Purpose | State why Smart Tiffin exists, what outcomes the four-application platform is meant to deliver, and which statements are confirmed, observed, proposed or still pending. |
| Applies to | CUS, PAR (supplier and rider workspaces), ADM, ACC and the shared backend (BE) |
| Depends on | [Project scope](PROJECT_SCOPE.md), [stakeholder analysis](STAKEHOLDER_ANALYSIS.md), [glossary](GLOSSARY_AND_TERMINOLOGY.md), [conventions](../analysis/CONVENTIONS_AND_ID_REGISTER.md), [master prompt digest](../analysis/SOURCE_MASTER_PROMPT_DIGEST.md), [legacy prototype digest](../analysis/SOURCE_LEGACY_PROTOTYPE_DIGEST.md) |
| Authoritative policies | None defined here. Commercial and legal rules are owned by [BUSINESS_RULES.md](BUSINESS_RULES.md) (BR-001…BR-005) and [POLICY_DECISION_REGISTER.md](POLICY_DECISION_REGISTER.md) (BR-006…BR-026); all are PENDING |
| Status | Draft for review. This is a requirements and design document. Nothing is implemented by this documentation effort, nothing is tested, and no business policy is approved. |

## 1. Vision statement

Smart Tiffin connects people who want regular home-style meals with the kitchens that cook them, the riders who deliver them, the operations staff who keep the service healthy, and the accounts team that keeps the money accurate and explainable. The platform is a set of four cooperating Flutter applications on one authoritative backend. It replaces manual coordination of subscriptions, meals, preparation, delivery, collections and payouts with traceable, role-separated workflows. (USER-REQ: master prompt, Phase 2.)

| Application | Code | Primary audience | Vision in one sentence |
|---|---|---|---|
| Customer App | CUS | Guests and customers (students, office employees, bachelors and other households) | Let a customer discover kitchens and build exactly the meal plan they need, then understand every charge and credit. |
| Partner App | PAR | Suppliers (kitchen partners) and riders (delivery partners), in two protected workspaces | Give each partner a clear daily work queue and an honest view of what they have earned and what they owe. |
| Admin Web | ADM | Operations and governance staff | Provide a real desktop console for approvals, dispatch, incidents, policy configuration and oversight, without authority over money. |
| Accounts Web | ACC | Accounts and Finance staff | Own collections, reconciliation, settlement, payouts, the ledger and financial reporting under segregation of duties. |
| Shared backend | BE | All applications | Hold one domain model, one command surface and the only authority for prices, roles and balances. |

## 2. Intended outcomes

The outcomes below are intended benefits. No baseline for time saved, customer satisfaction, revenue or operating cost has been supplied, so none is a measured improvement.

| Outcome | How later implementation will be evaluated | Related requirements |
|---|---|---|
| A customer can discover kitchens, order a single meal, or compose a daily, weekly, monthly or custom subscription with different meals per date and slot, and is never forced into a fixed monthly package. | Journeys complete against persisted records with server-computed quotes; the schedule preview equals the generated meal obligations. | FR-004–FR-010, FR-026–FR-031 |
| A customer always knows what they will pay, what was credited and why. | Every quote line, invoice line, credit entry and receipt traces to a stable source identifier; totals agree across quote, invoice, payment and journal (INV-18). | FR-012, FR-030, FR-032, FR-035 |
| A supplier knows what to prepare, how much capacity is committed, and what it has genuinely earned. | Cooking totals reconcile to obligations exactly once; earning recognition follows the approved event (BR-010), not the payment date. | FR-014–FR-017, FR-027, FR-036, FR-046 |
| A rider knows the assigned work, records delivery proof and cash honestly, and sees compensation separately from cash held for the company. | Assignment alone creates no withdrawable balance; collected COD cash is never counted as rider income (INV-10, INV-11). | FR-019, FR-020, FR-034, FR-037, FR-047 |
| Administrators can govern the service and resolve incidents without being able to move money. | Admin sessions cannot approve payouts, edit journals or verify remittances; attempts are rejected and logged. | FR-021–FR-023, FR-043, FR-044 |
| Accounts staff can prove that every figure is derivable from posted journals and immutable events. | Dashboard totals reconcile to the ledger (INV-20); gateway and COD reconciliation exceptions are visible and resolvable. | FR-040–FR-042 |
| Users receive meaningful, privacy-safe service information. | Notifications carry minimal data and open authorized current data. | FR-025 |

## 3. Confirmed direction, observed baseline and boundaries

| Statement | Tag | Notes |
|---|---|---|
| Flutter and Dart for all four client applications; Customer and Partner are separate mobile applications; Admin and Accounts are desktop-first web applications. | USER-REQ | Master prompt Phase 2 and final non-negotiables. |
| Android first; the architecture must allow iOS later. Bangla and English everywhere. | USER-REQ | Confirmed 2026-10-28; reaffirmed in the master prompt. |
| SSLCOMMERZ is the selected payment gateway. It is documented and prepared as a future integration; it is not connected, no credentials exist and no real transaction is performed by this effort. | USER-REQ | Sandbox credentials are to be supplied later during backend implementation. |
| Cash on delivery is supported for eligible orders and any specifically approved subscription arrangement. | USER-REQ | Eligibility and limits are PENDING (BR-012). |
| The platform is built on the existing project; it is not restarted. | USER-REQ | The single combined app described in earlier documents is replaced by four applications (ADR-004). |
| Today the workspace contains one combined Flutter app (`app/`, package `smart_tiffin`), one Cloud Functions callable (`backend/functions`, command `executeCommand`) and Firestore/Storage rules (`firebase/`). All are untracked in Git and none was verified by this effort. | OBSERVED | See [code reality snapshot](../architecture/CODE_REALITY_SNAPSHOT.md). |
| A hybrid datastore (Firebase for operational data, a transactional relational ledger store for finance) is the recommended architecture. | PROPOSED | Not an approved requirement; see ADR-005 and [system architecture](../architecture/SYSTEM_ARCHITECTURE.md). |
| Every commercial rule (pause cutoffs, billing, verification authority, assignment, cancellation, credits, commissions, recognition events, payout thresholds, tax, approval limits and the rest) is undecided. | PENDING | BR-001…BR-026; no value is invented anywhere in this set. |

Visual identity is preserved from the supplied screenshots and the 94-screen React prototype: Smart Tiffin branding, warm orange for customers, green for suppliers, blue for riders, an indigo administrative identity, card layouts, soft shadows, rounded corners and restrained glass surfaces. (USER-REQ; OBSERVED in the prototype.)

## 4. What this phase delivers

This effort produces a single, interconnected, implementation-ready documentation set in `FINAL_REFINED_DOCS/`. It does not produce application code, live service configuration, a deployment, a real gateway connection or a payout. Product completion additionally requires implemented acceptance criteria and measured checks, which do not exist yet. Scope boundaries are in [PROJECT_SCOPE.md](PROJECT_SCOPE.md) and the honest current state is in [PROJECT_STATUS.md](../PROJECT_STATUS.md).

## 5. Success for this phase

1. Every source feature (FR-001…FR-025) is retained and revised, and every new capability from the 2026-10-30 requests has a stable identifier (FR-026…FR-050).
2. Each functional requirement has actors, applications, modules, rules, screens, commands, entities, policy dependencies, provenance and acceptance links.
3. Unresolved decisions are explicit, owned and non-blocking for independent modules.
4. Architecture, data, API, security, finance and testing documents agree on identifiers, commands, entities and invariants.
5. Links and identifiers are checked, and every statement about testing or implementation is backed by recorded evidence or is labelled planned.

Stakeholder approval of the business baseline remains distinct from completion of the documentation.

## 6. Open items

| Item | Needed from | Effect |
|---|---|---|
| Named business owner or authorized stakeholder for all policy decisions | Project sponsor | No BR may be approved until the approver is identified. |
| Approval of the four-application architecture and hybrid datastore proposal | Business owner and technical lead | Gates implementation of the foundation work (ADR-004, ADR-005). |
| Legal and tax advice on stored value, customer funds, payout handling and tax | Qualified advisors | Gates BR-018 and BR-025; no compliance is claimed. |
