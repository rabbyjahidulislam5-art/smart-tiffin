# Stakeholder analysis

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (supersedes 0.1 · 2026-10-28) |
| Owner | Requirements and planning author (documentation set) |
| Purpose | Identify everyone with a stake in Smart Tiffin, what each needs, how each takes part in validation, and who holds decision authority, including the Accounts and Finance function, riders as delivery partners and the payment gateway provider. |
| Applies to | All applications and all policy decisions |
| Depends on | [User roles](USER_ROLES.md), [business rules](BUSINESS_RULES.md), [policy decision register](POLICY_DECISION_REGISTER.md), [project vision](PROJECT_VISION.md) |
| Authoritative policies | BR-001…BR-026 (all PENDING). The decision owner for every entry is "Business owner / authorized stakeholder — to be identified". |
| Status | Draft for review. No stakeholder contact details, interviews, sign-offs or approvals exist or have been fabricated. |

## 1. Stakeholder register

| Stakeholder | Need / concern | Participation and validation | Decision authority |
|---|---|---|---|
| Customers: students, office employees, bachelors, households | Affordable regular meals; flexible schedules; understandable charges, credits and delivery state; privacy; confidence that skipped meals are honoured | Walk through custom subscription, skip, replace, credit redemption, one-time order, COD and online payment scenarios in both languages | Feedback only. Cannot approve platform-wide business rules unless separately authorized. |
| Suppliers / kitchen partners (cooks, home chefs, cloud kitchens, restaurants) | Accurate daily and forward quantities; manageable menus, variants and capacity; clear earning recognition; timely, explainable payouts; fair handling of cancellations and disputes | Reconcile cooking totals against skips and replacements; review earnings terminology (expected, recognised, held, eligible, settled); review payout request and history flows | Operational feedback. Commission, settlement and cutoff authority remain unassigned (BR-009, BR-010, BR-014). |
| Riders / delivery partners | Correct assignments and addresses; clear separation between delivery compensation and company cash held (COD); safe, simple proof of delivery; transparent balances and payouts | Walk through offer acceptance, pickup, proof, missing customer, COD collection and remittance, reassignment and payout scenarios | Assignment authority is pending (BR-004); compensation rule pending (BR-011). Riders are partners, not Accounts or Admin staff, and hold no finance authority. |
| Administrators / operations staff | Controlled onboarding, dispatch, incident and complaint handling, policy configuration, trustworthy operational reporting | Validate account lifecycle, application review checklist, cross-role denial, reassignment, audit visibility | The administrative role is confirmed; approval and verification authority are not. Admin cannot move money. |
| Accounts and Finance staff (Finance Viewer, Accounts Operator, Accounts Manager, Payout Approver, Financial Auditor) | A ledger that balances; reconciliation of gateway and COD cash; payout controls with preparer and approver separated; defensible period close and reports | Validate reconciliation, deposit verification, payout maker-checker, adjustment, refund and period-close scenarios; review report definitions | Hold the finance workflows within delegated limits. Approval limits are pending (BR-020). New role in this revision (USER-REQ). |
| Business owner / authorized stakeholder — to be identified | Own commercial rules, service obligations, costs and risk; accept the four-application delivery architecture | Supply and approve BR-001…BR-026 with exact values, authority, effective date and evidence | Required approver for every business policy. A person has not been named. |
| Legal, tax and regulatory advisors (to be engaged) | Clarity on stored value, refundable credits, customer funds, payout handling, taxes and reporting in Bangladesh | Written advice referenced from BR-018 and BR-025 | Advise. No compliance is claimed anywhere in this set without evidence. |
| Payment gateway provider: SSLCOMMERZ | Correctly formed initiation requests, validated notifications, settlement and refund processing under the merchant agreement | Merchant onboarding, sandbox credentials supplied later, verification of current official documentation before implementation | Governs its own service contract and channels available to the merchant account. Does not decide tiffin policies. |
| Banks and mobile financial services (bank transfer, bKash, Nagad and similar) | Valid payout destinations and settlement evidence | Beneficiary verification and external confirmation of transfers (an outbound transfer is complete only after external confirmation) | Govern their own transfer rules. |
| Messaging and push providers (Firebase Cloud Messaging and any later SMS or email provider) | Valid, privacy-safe messages | Notification design reviewed after privacy, cost, authorization and failure requirements are documented | Govern their own service contracts. |
| Firebase and cloud service providers | Valid supported use of managed identity, data, messaging and hosting | Later verification of actual project settings, quotas, regional availability and security behavior | Govern service contracts. Do not decide tiffin policies. |
| Project student / development team | A feasible, verifiable programme delivered in traced vertical slices | Implement only after dependencies are resolved; keep ownership of shared packages bounded | Engineering recommendations; cannot silently decide business rules. |
| Course instructor / evaluator (CSE-489 context carried from the earlier phase) | Evidence of required mobile-programming outcomes | Review specification, demonstration and test evidence against the rubric | Rubric and submission deadline have not been supplied. |

## 2. Stakeholder-to-application map

| Stakeholder | CUS | PAR-S | PAR-R | ADM | ACC | Backend / external |
|---|---|---|---|---|---|---|
| Customer | Primary | — | — | — | — | Receives notifications; pays via gateway or rider |
| Supplier | — | Primary | — | Reviewed by | Settled by | — |
| Rider | — | — | Primary | Dispatched by | Remits cash to; settled by | — |
| Admin staff | — | — | — | Primary | Limited summary only | — |
| Accounts staff | — | — | — | — | Primary | Gateway statements, bank evidence |
| Gateway provider | Hosted payment page | — | — | — | Settlement statements | Notifications and validation API |

## 3. Decisions and communication

The user confirmed Android first and Bangla/English on 2026-10-28. The user stated that business rules had been decided but supplied no values, authority assignments or policies. That acknowledgement is not policy approval. A later explicit instruction requires BR-001…BR-005 to remain Pending Decision until approval evidence exists. The 2026-10-30 master prompt adds the BR-006…BR-026 areas and requires each to carry the label "PROPOSED — NOT APPROVED" until the business owner approves values.

- Decision questions, alternatives and consequences are in [BUSINESS_RULES.md](BUSINESS_RULES.md) (BR-001…BR-005) and [POLICY_DECISION_REGISTER.md](POLICY_DECISION_REGISTER.md) (BR-006…BR-026).
- Required reviewers by decision: supplier and rider representatives for assignment, cutoff, recognition, commission, COD and payout rules; Accounts for approval limits, thresholds, holds and period close; legal and tax advisors for BR-018 and BR-025.
- No stakeholder contact details, external messages, interviews, sign-offs or course approvals have been fabricated. Future feedback must be recorded with date, source, affected identifiers and the precise accepted decision.

## 4. Conflicts of interest the design must control

| Conflict | Control (PROPOSED) |
|---|---|
| A rider holds company cash and is also paid compensation | Compensation and cash custody are separate balances; netting only with explicit approval (BR-026, INV-10). |
| A supplier benefits from its own payout approval | A partner can never review or approve its own payout; maker and checker are different staff identities (INV-15). |
| Admin staff can see operational problems that affect money | Admin proposes adjustments or disputes decisions; Accounts approves and posts journals; Admin has no finance write path. |
| The same staff member could prepare and approve a financial action | Segregation of duties enforced in the trusted backend, not only the interface. |
| A person is both a supplier and a rider | Permitted only if BR-023 is approved; each grant has an independent workspace, balance and authorization. |

## 5. Verification and open items

| Item | Condition |
|---|---|
| Stakeholder map accepted | The business owner confirms the list and names a representative for each group. |
| Approvers named | BR-001…BR-026 each have an approver name and authority recorded in the policy files. |
| Gateway merchant relationship established | Merchant account, sandbox credentials supplied through an authorized secret channel; recorded without the secrets. |
