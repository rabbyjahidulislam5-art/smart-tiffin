# Assumptions, constraints and decisions

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (supersedes 0.1 · 2026-10-28) |
| Owner | Requirements and planning author |
| Purpose | Index every open decision (DEC-001…DEC-036) that is not itself a BR-numbered business rule, and record what each decision depends on. |
| Applies to | CUS, PAR, ADM, ACC, BE |
| Depends on | [Business rules](BUSINESS_RULES.md), [policy decision register](POLICY_DECISION_REGISTER.md), [glossary](GLOSSARY_AND_TERMINOLOGY.md) |
| Status | Draft for review. No DEC value is approved. |

## Evidence and interpretation

**2026-10-30 scope update:** both the expanded master prompt and the legacy prototype documentation supplied by the user that day are now this project's **primary requirement sources** (see the corrected [source material register](SOURCE_MATERIAL_REGISTER.md)), not merely reference material. They expand the product to four applications (Customer, Partner, Admin Web, Accounts Web) on one shared backend, with a flexible subscription engine, non-cash service credits, SSLCOMMERZ (future) plus four COD models, supplier/rider earnings and payouts, and a double-entry ledger. This supersedes the previous task's single-app, documentation-only framing described below, which remains historical. See [scope](PROJECT_SCOPE.md) and [screenshot reconciliation](SCREENSHOT_SCOPE_RECONCILIATION.md). **No BR or DEC value, original or extended, is approved by this expansion.** DEC-016…DEC-036, one per new business rule BR-006…BR-026, are registered in full in [POLICY_DECISION_REGISTER.md](POLICY_DECISION_REGISTER.md); this file does not duplicate them, only indexes them below alongside DEC-001…DEC-015.

The supplied master prompt contains a project proposal and a requirements-preparation scope. Its general lifecycle directions are guidance for applicable phases; they do not make application code or production deployment part of this phase. The current local workspace contains an initialized Git directory, which refines the proposal's statement that no repository exists; no application has been generated.

The user subsequently confirmed Android-first and Bangla/English. A “yes” response to whether business decisions exist did not include their contents. The user's later direction explicitly requires BR-001–BR-005 to remain **Pending Decision**, with proposed alternatives clearly labelled. No policy is approved by silence or by an agent recommendation.

## Decision index

[BUSINESS_RULES](BUSINESS_RULES.md) is the canonical detailed register for DEC-003–DEC-007 and BR-001–BR-005. This index does not redefine those policies.

| ID | Topic | Status and exact remaining information | Impact |
|---|---|---|---|
| DEC-001 | Platforms | Android-first confirmed; minimum supported Android version and reference test devices still to select | Platform generation, package support and device evidence |
| DEC-002 | Languages | Bangla and English confirmed; translation ownership, initial locale and glossary open | UI strings, date/number formatting and language QA |
| DEC-003 | Billing | Pending Decision; see BR-002 | Plan basis, coverage, partial months, fees/taxes if applicable, due dates, adjustments and reports |
| DEC-004 | Pauses | Pending Decision; see BR-001 | Deadline, timezone, granularity, preparation interaction, reversals and bill/cooking effects |
| DEC-005 | Payment verification | Pending Decision; see BR-003 | Authorized verifier, independent evidence, duplication, correction and allocation |
| DEC-006 | Delivery assignment | Pending Decision; see BR-004 | Manual/automatic ownership, eligibility, workload, reassignment and exceptions |
| DEC-007 | Cancellation and refunds | Pending Decision; see BR-005 | Actors, lifecycle eligibility, fees, credits, approval and externally completed refund evidence |
| DEC-008 | Currency and service time | Proposed Asia/Dhaka and BDT represented in integer minor units; not approved | Date-only service keys, deadlines, bill periods, price formatting and rounding |
| DEC-009 | Identity and roles | Sign-in provider(s), verification/recovery policy, administrator bootstrap, supplier/courier onboarding, multi-role accounts and disabling/revocation behavior unspecified | Authentication and all privilege transitions |
| DEC-010 | Operating constraints | Owner, scale, concurrency, budget, timeline, Firebase project/region, retention, backup goals, legal/privacy duties, monitoring and distribution destination unspecified | Production architecture, retention and release readiness |
| DEC-011 | Trusted backend | **Extended 2026-10-30, PROPOSED — NOT APPROVED:** Firebase Authentication + Cloud Firestore for operational/read models, Cloud Functions as the trusted command boundary, plus a managed PostgreSQL instance for the double-entry ledger, payouts and COD remittance (see [ADR-005](../adr/005-hybrid-datastore.md)); runtime ownership for financial operations/notifications across four apps still undecided in detail | Privileged operations, including ledger posting and payout approval, must never run with trusted credentials in any client, mobile or web |
| DEC-012 | Offline behavior | Dedicated offline writes and queue/conflict semantics unspecified. Proposed online-confirmed critical mutations; cached reads explicitly labelled | Avoid accidental financial/state writes queued without a defined contract |
| DEC-013 | Reviews and complaints | Review eligibility, rating scale, edits, visibility/moderation; complaint submitter roles, categories, transitions and response targets unresolved | Feedback validation, ownership, UI and retention |
| DEC-014 | Preparation and delivery exceptions | Proposed cooking states Pending/Preparing/Ready are unapproved. Define preparation handoff and handling for failed delivery, correction, refusal or exceptional reassignment without silently replacing the confirmed delivery chain | Cooking/dispatch state machine and incident paths |
| DEC-015 | Notification policies | Reminder timing, eligible recipients, menu-update audience, opt-in handling and in-app notification history decision unresolved | FCM event triggers, privacy, deduplication and scheduling |

For DEC-008–DEC-015, the owner is **Business owner/authorized stakeholder — to be identified**, with the relevant engineering specialist advising. No approval evidence has been supplied. Engineering recommendations are reversible proposals; final schema and contract work must record adopted decisions first.

## Extended decision index (DEC-016…DEC-036, 2026-10-30)

Each row below is detailed in full in [POLICY_DECISION_REGISTER.md](POLICY_DECISION_REGISTER.md) under the linked BR; this index exists only so that DEC-001…DEC-036 can be read as one continuous list.

| ID | Linked rule | Topic |
|---|---|---|
| DEC-016 | BR-006 | Service-credit eligibility, calculation and use |
| DEC-017 | BR-007 | Delivery charges |
| DEC-018 | BR-008 | Subscription and promotional discounts |
| DEC-019 | BR-009 | Platform commission and service fee |
| DEC-020 | BR-010 | Supplier earning recognition event |
| DEC-021 | BR-011 | Rider delivery compensation |
| DEC-022 | BR-012 | COD eligibility and limits |
| DEC-023 | BR-013 | COD remittance deadlines, overdue and recovery |
| DEC-024 | BR-014 | Payout thresholds, frequency and holds |
| DEC-025 | BR-015 | Disputes and chargebacks |
| DEC-026 | BR-016 | Unpaid subscription handling and suspension |
| DEC-027 | BR-017 | Meal substitutions, upgrades and downgrades |
| DEC-028 | BR-018 | Tax calculation |
| DEC-029 | BR-019 | Credit expiry |
| DEC-030 | BR-020 | Financial approval limits and maker-checker |
| DEC-031 | BR-021 | Multi-kitchen subscriptions |
| DEC-032 | BR-022 | Cutoff rules and service time |
| DEC-033 | BR-023 | Dual-role accounts |
| DEC-034 | BR-024 | Kitchen discontinuity and compliance lapse |
| DEC-035 | BR-025 | Legal status of credits, stored value and customer funds |
| DEC-036 | BR-026 | Netting of rider COD obligation against rider earnings |

## Explicit assumptions for draft design

- The platform is a multi-kitchen marketplace across four applications on one backend; "single service platform" is superseded. Whether one subscription may span multiple kitchens remains BR-021/DEC-031.
- Customer location can be a supplied address for the required status-based delivery workflow; continuous GPS is not assumed and, where offered, requires explicit consent (see [time and cutoff policy](../architecture/TIME_AND_CUTOFF_POLICY.md) and the accessibility/privacy governance in the [master prompt digest](../analysis/SOURCE_MASTER_PROMPT_DIGEST.md)).
- A submitted bKash/Nagad reference is a claim awaiting verification, unchanged by the new scope; it is now one of several evidentiary paths alongside server-validated SSLCOMMERZ transactions and Accounts-verified COD remittances. A valid-looking reference does not prove settlement.
- A plan, order, subscription (agreement) and meal obligation need stable historical terms, each preserved as an immutable quote snapshot (see [ADR-009](../adr/009-quote-and-price-snapshots.md)); exact fields and financial policies remain provisional.
- No source-code license, cloud project, credential, signing key, production user data, SSLCOMMERZ merchant account or release approval is provided for any of the four applications.
- Draft targets in [NFRs](NON_FUNCTIONAL_REQUIREMENTS.md) are reviewable proposals, not measurements.
- The hybrid datastore, the four-application monorepo and the SSLCOMMERZ gateway abstraction are PROPOSED architecture directions chosen by the user for documentation purposes; they are not approved business policy and carry no commercial value by themselves.

## Decision closure process

Capture the exact selected option, parameters, authority name/role, approval date and evidence reference. Update the canonical BR register first, then affected FR/UC/AC/test designs, architecture and provisional data model. A requirement may remain in first-release scope while its implementation is blocked. Do not infer approval from the existence of a screen, document, source file or test stub.

