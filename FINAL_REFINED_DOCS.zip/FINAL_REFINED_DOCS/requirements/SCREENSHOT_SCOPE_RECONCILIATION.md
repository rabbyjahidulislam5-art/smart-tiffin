# Screenshot and request scope reconciliation

| Field | Value |
|---|---|
| Revision | 1.1 · 2026-10-30 (adds the legacy/proposed screen-ID mapping; body otherwise unchanged) |
| Owner | Requirements and planning author |
| Purpose | Reconcile the six supplied screenshots against both the original 129-family planning inventory and the now-authoritative legacy 94-screen prototype IDs. |
| Depends on | [Complete screen inventory](../design/COMPLETE_SCREEN_INVENTORY.md), [inventory reconciliation](../design/INVENTORY_RECONCILIATION.md), [screenshot action audit](../design/SCREENSHOT_ACTION_AUDIT.md) |
| Status | Draft for review. FR-001–FR-025 retain their original identity and Must priority; FR-026…050 extend them. No new commercial policy is approved here. |

**Legacy-ID cross-reference (added 2026-10-30):** Each `UX-nn` row below was originally mapped only to F129 planning-inventory families. Those same screenshot subjects also correspond to legacy prototype screens: UX-01/UX-02 → AU-03/AU-05/AU-11; UX-03 → C-01/C-10/C-13/C-15; UX-04 → C-04/C-05/C-06/NC-02/NC-03; UX-05 → C-18/R-01/R-02; UX-06 → SH-02/SH-17 (F129); UX-07 → S-01/S-04/NS-05; UX-08 → S-02/S-03; UX-09 → R-01/R-07/R-08/R-09; UX-10 → R-05/NR-06; UX-11 → A-06/A-07/AU-09/AU-10; UX-12 → A-04/A-03; UX-13 → A-05/NF-10; UX-14 → A-12/A-13/NF-07/NF-08 (now Accounts-owned, conflict register C-06); UX-15 → A-14/NF-14; UX-16 → P-02/P-03/C-04 (subscription/discount copy is still BR-008, Pending); UX-17 → SH-04/SH-05/SH-09/SH-10 (F129) and the legacy SH equivalents; UX-18 → the design system and PDF production plan for all four applications.

The new direct request expands delivery to design and implementation after plan approval. The earlier preparation-only boundary remains historical. Five distinct screenshot designs provide visual and interaction evidence, not evidence of live services, paid transactions, verified identities or approved business rules.

| Reference | Source / gap | Proposed disposition and dependencies |
|---|---|---|
| UX-01 | Screenshot role tabs, phone label with password, customer-only Google | Design separate email/password and phone-OTP journeys; Google customer option conditional on DEC-009; selected role is routing intent only |
| UX-02 | Fingerprint login | Preserve a biometric setup/unlock design; conditional extension requiring device support and threat-model/DEC-009 review; never independent server authentication |
| UX-03 | Active plan, pause, calendar, Modify routine | Current FR-006/008; plan schedule and change request destinations; no guessed 30-day term or pause credit |
| UX-04 | Food detail, supplier page, categories, See All, Subscribe | Current FR-004/005/006/007; search/filter and ingredient/allergen presentation proposed; seller claims must be attributed and verified badges evidence-backed |
| UX-05 | Live delivery map, GPS HD, recenter, turn-by-turn, 11 min/2.4 km | Live GPS and in-app routing remain later-release designs; current release uses four-state tracking/address. Preserve a labelled future-map preview in design documentation; do not ship a fake live map |
| UX-06 | Rider/customer/kitchen phone and message icons | Contact-sheet designs retained; user-initiated dialer handoff proposed, messaging channel/provider and privacy unresolved. Do not silently implement real-time chat |
| UX-07 | Supplier accepting-orders switch, portions, stock quantities | Availability current FR-015; online kitchen status and per-item capacity extension require semantics/permissions and atomic reservation decisions. Quantity is not the existing boolean availability requirement |
| UX-08 | Accept/decline, preparation stage, dispatch timer | Current FR-017 with DEC-014. Decide whether Prepped/Preparing/Packed map to workflow; never conflate preparation with delivery or invent refund effects of decline |
| UX-09 | Rider duty, completed/in-progress counts, earnings, vehicle, rating | Assigned work/history/profile designs retained; duty scheduling, rider earnings/ratings and vehicle data are extensions with retention and accounting decisions |
| UX-10 | SOS, traffic/delay report, arrival/proof wording | Design safety contact and incident/report/result screens; emergency destination and responsible operator must be real and approved. No arbitrary emergency number, automatic delivery proof or guaranteed response |
| UX-11 | Admin NID/kitchen/hygiene checks, dossier, approve, fast-track | Supplier approval current FR-021; evidence workflow is conditional extension. Fast-track means priority review, never bypass checks. Storage, access and retention decision required before document uploads |
| UX-12 | Admin backup rider, incident history/detail | FR-019/020/022/023 with BR-004; assignment view is permission-gated and does not assume admin dispatch authority |
| UX-13 | Replacement credit and disputes | FR-023 plus BR-002/005. Show proposed adjustment/review paths; no hard-coded credit entitlement or one-tap money mutation |
| UX-14 | Escrow, liquidity, disbursement, payout settings | Treasury/escrow and real payout execution are later proposals beyond manual reference verification. Full designs retained in later-release appendix, with provider/legal/finance requirements unresolved |
| UX-15 | Revenue, audit ledger CSV, status/uptime/latency | Revenue current FR-024; export and operational metrics are proposed extensions. Restrict/redact exports and mitigate spreadsheet formula injection. Never invent uptime, response-time or settlement values |
| UX-16 | Monthly offer, 20% savings, halal, bestseller, kitchen verification | Offer detail retained; claims need approved catalog/operational evidence. Discounts/coupons are later scope; screenshot copy is not an approved pricing rule |
| UX-17 | Registration, notifications, security/settings, support, terms, hygiene | Required supporting journeys with owner-authored content and DEC-009/010/013/015 dependencies. Do not create public admin registration |
| UX-18 | Glassmorphism, responsive EN/BN, all states and comprehensive visual PDF | Explicit new deliverables; design specification and capture acceptance in docs/design; screenshot appearance alone cannot pass functional tests |

## Release labels

- **R1:** required first-release behavior; may still await a named policy or integration. Blocked R1 work cannot be declared complete or reclassified as later simply to finish.
- **Conditional:** supporting or screenshot-expanded capability needing a scope/operational decision. It remains inventoried and designed; enabling it requires an explicit contract.
- **Later:** live GPS, online gateway, escrow/payout execution and source-listed AI/coupons/loyalty/multi-kitchen proposals. User-visible release copy must reflect what is actually enabled.

Every screenshot control is mapped in [the action audit](../design/SCREENSHOT_ACTION_AUDIT.md). Every planned destination appears in [the inventory](../design/SCREEN_INVENTORY.md). A future feature may be included in design review; it must not masquerade as an active production control.

## Approval evidence

The 2026-10-30 request confirms the desired complete design/build/PDF outcome and glass visual direction. It does not supply the actual BR policies, service credentials, cloud destination or legal terms. Scope proposal approval is pending. Original Markdown upload is unavailable; the existing local requirement documents are the working baseline, not proof the missing source has been completely reconciled.
