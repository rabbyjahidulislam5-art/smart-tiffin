# Glossary and terminology

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Documentation lead (primary agent) |
| Purpose | One shared vocabulary for money, obligations, roles and states, so that no team confuses cash collected, customer credit, earnings, revenue or rider-held cash. |
| Applies to | All apps and all documents |
| Depends on | [Conventions](../analysis/CONVENTIONS_AND_ID_REGISTER.md), [policy register](POLICY_DECISION_REGISTER.md) |
| Authoritative policies | BR-002, BR-006, BR-010, BR-011, BR-012, BR-013, BR-014, BR-025, BR-026 (all PENDING) |
| Status | Draft for review. Definitions are USER-REQ where taken from the master prompt, PROPOSED where they add precision. No policy value is approved. |

## 1. Money terms (USER-REQ meaning, PROPOSED precision)

| Term | Definition | Is it cash? | Where it lives (PROPOSED) |
|---|---|---|---|
| **Customer cash payment** | Money actually received from a customer by gateway or by rider (COD) | Yes, once externally confirmed | Ledger: payment clearing / COD receivable → bank |
| **Verified collection** | A customer payment confirmed by trusted server validation (gateway) or by Accounts verification (COD remittance). A browser redirect is not verification | Yes | Ledger |
| **Prepaid customer obligation** | The amount of verified prepayment whose service has not yet been delivered. A liability of the platform to deliver service | Funded by cash, not itself spendable | Ledger liability account |
| **Service credit** | Non-cash entitlement created by an approved adjustment (for example an eligible skipped prepaid meal) that can reduce a future payable. An accountable liability | **No.** Not a wallet, not withdrawable, not transferable unless a separate legal/financial policy (BR-025) says so | `ent.CreditAccount` / `ent.CreditTransaction`, liability account |
| **Promotional credit** | Non-cash incentive with its own eligibility; stored separately from service credit; never refundable as cash unless approved | No | Separate credit class |
| **Gateway refund** | Actual return of money to the customer's payment instrument through the gateway, confirmed externally | Yes (outflow) | Ledger + `ent.Refund` |
| **Subscription price adjustment** | Change to the amount owed after an approved plan/meal change (up or down), recorded as an adjustment against the original obligation | No by itself | `ent.Adjustment` |
| **Unpaid bill** | A billed amount not yet covered by verified payment | No | Invoice / receivable |
| **COD receivable** | Amount invoiced to be paid in cash on delivery and not yet remitted to the company | No until remitted | Ledger asset |
| **Rider-held COD cash** | Customer cash physically held by a rider that belongs to the company; owed to Accounts. **Never rider income** | Cash in custody, company-owned | `ent.CodCollection` / remittance liability |
| **Supplier earning (expected)** | Value a supplier will earn if committed meals are fulfilled; informational | No | Projection |
| **Supplier earning (recognised)** | Amount the supplier has become entitled to at the approved recognition event (BR-010) | Payable, not cash | `ent.SupplierEarning`, supplier payable |
| **Rider compensation (expected / assigned)** | Estimated fee when a delivery is assigned; creates no withdrawable balance | No | Projection |
| **Rider compensation (confirmed)** | Fee earned after delivery meets the approved completion/verification policy (BR-011) | Payable, not cash | `ent.RiderEarning`, rider payable |
| **Platform revenue** | Commission and fees the company is entitled to once recognised. **Not** gross customer collections | No | Ledger revenue |
| **Payable balance (supplier/rider)** | Recognised earnings minus holds, reversals and settled payouts | No | Ledger liability |
| **Payout** | A transfer of eligible payable balance to an approved destination. Completed only after external confirmation | Yes (outflow) | `ent.PayoutRequest` → `ent.SettlementBatch` |
| **Hold** | A restriction placing part of a payable on hold (dispute, discrepancy, compliance) | — | `ent.Hold` |
| **Adjustment** | A controlled correcting entry (reversing or adjusting journal) with reason code and approval; never an edit of history | — | `ent.Adjustment`, journals |
| **Chargeback** | A dispute filed externally against a card/MFS payment | — | `ent.Dispute` |
| **Quote** | Server-computed price record for a specific selection, with expiry; the only source of payable amounts | — | `ent.Quote` (immutable snapshot) |
| **Minor unit** | The smallest BDT unit (paisa); all stored money is an integer count of minor units. Customer display shows two decimals | — | everywhere |

## 2. Subscription and commerce terms

| Term | Definition |
|---|---|
| **Kitchen** | A verified supplier's operating food business, with service areas, hours, slots, menu |
| **Meal / variant** | A dish offered by a kitchen; a variant is a size/portion/option with its own price version |
| **Slot** | One of breakfast, lunch, afternoon snack, dinner (identifier `slot.breakfast`, `slot.lunch`, `slot.snack`, `slot.dinner`) — an identifier, never a translated label |
| **One-time order** | A single purchase of one or more meals for a date/slot without a subscription |
| **Subscription (agreement)** | The customer's commitment: kitchen(s), schedule rules, term, price terms, billing cycle. It is versioned, never overwritten |
| **Meal obligation** | One scheduled meal (date + slot + meal + quantity) generated under a subscription or an order. The unit that is cooked, delivered, skipped, replaced, earned and credited |
| **Subscription duration vs billing frequency** | Duration is how long service runs; billing frequency is how often payment is due. They are independent settings |
| **Plan** | A kitchen-published template/option (daily, weekly, monthly, custom-eligible) that a customer may adopt or customise. Not a fixed package imposed on the customer |
| **Skip / pause / replace** | Skip: remove an eligible obligation (may create a credit). Pause: exclude dates or a slot for a period. Replace: swap the meal of an eligible obligation (may produce a debit or credit difference) |
| **Cutoff** | The latest time a change to an obligation is accepted. A configured policy parameter (BR-001, BR-022), never hard-coded |
| **Dispatched** | The obligation's meal has been handed to a rider; no customer change unless an explicit exception policy exists |
| **Delivery states (confirmed)** | Pending → Picked Up → On The Way → Delivered. Failed/undeliverable is an exception outcome (DEC-014), not a replacement for these four |

## 3. Roles

| Role | Meaning | App |
|---|---|---|
| Guest | Anonymous visitor; no private data | CUS |
| Customer | Registered buyer | CUS |
| Supplier / Kitchen partner (Cook) | Approved food provider | PAR (supplier workspace) |
| Rider / Delivery partner | Approved delivery person | PAR (rider workspace) |
| Admin / operations staff | Governance and operations; invited only | ADM |
| Accounts staff | Finance department; invited only; sub-roles below | ACC |
| Finance Viewer | Read-only finance data | ACC |
| Accounts Operator | Prepares collections, reconciliations, payout drafts | ACC |
| Accounts Manager | Reviews and manages operator work and exceptions | ACC |
| Payout Approver | Approves payouts within limit (checker) | ACC |
| Financial Auditor | Read-only audit and ledger inspection | ACC |
| Super Admin (bounded) | Staff and policy administration with explicitly bounded privileges; **no implicit finance override** | ADM/ACC |

A role is a server-validated grant (claim + record), never a UI selection. Whether one person may hold two partner roles is PENDING (BR-023).

## 4. State vocabularies (separate models; do not merge)

| Model | States |
|---|---|
| **Payment** | Pending · Initiated · Awaiting Confirmation · Verified · Failed · Cancelled · Expired · Refunded · Partially Refunded · Disputed · Unknown |
| **Subscription agreement** | Draft · Pending Payment · Scheduled · Active · Paused · Partially Modified · Completed · Cancelled · Expired |
| **Meal obligation** | Scheduled · Skipped · Replaced · Preparing · Ready · Handed Off · Delivered · Failed · Cancelled (preparation and delivery sub-states are separate, see [data flow](../architecture/DATA_FLOW.md)) |
| **Delivery** | Pending · Picked Up · On The Way · Delivered (+ exception outcome) |
| **COD collection** | Recorded · Confirmed · Due for Remittance · Partially Remitted · Remitted (pending verification) · Verified · Overdue · Disputed · Written Off |
| **Payout** | Requested · Under Review · Approved · Processing · Settled · Failed · Rejected |
| **Credit entry** | Issued · Reserved · Consumed · Released · Voided · Expired (expiry only if BR-019 approved) |
| **Application (partner)** | Draft · Submitted · In Review · Information Requested · Approved · Rejected |
| **Ledger journal** | Draft · Posted · Reversed (never edited) |
| **Accounting period** | Open · Closing · Closed · Reopened (governed) |
| **Balance qualifiers** | *paid* (externally confirmed money) · *pending* (awaiting confirmation or event) · *posted* (written to the ledger) · *held* (restricted by a hold) · *reserved* (earmarked for a pending operation) · *disputed* (subject to a dispute) · *available* (eligible for payout or use now). Each dashboard figure names its qualifier |

## 5. Event moments (used in scenario decision tables)

*Request received* (client call reached the trusted boundary) → *command accepted* (validated, idempotency receipt written, state change committed) → *funds externally confirmed* (gateway server validation or Accounts-verified deposit / bank evidence) → *service delivered* (delivery completion or approved recognition event) → *liability extinguished* (prepaid obligation recognised, credit consumed/voided, payable settled and externally confirmed). Interfaces update at the moment their data changes, even for non-participating roles (read models).

## 6. Prototype statuses

I interactive · U UI-only/static · S simulated external action. These describe the legacy React prototype only.
