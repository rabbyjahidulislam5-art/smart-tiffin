# Project scope

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (supersedes 0.1 · 2026-10-28) |
| Owner | Requirements and planning author (documentation set) |
| Purpose | Define the four applications and shared backend, what is in and out of scope for the product, what this documentation effort does and does not do, and how scope changes are controlled. |
| Applies to | CUS, PAR, ADM, ACC, BE |
| Depends on | [Project vision](PROJECT_VISION.md), [functional requirements](FUNCTIONAL_REQUIREMENTS.md), [screenshot reconciliation](SCREENSHOT_SCOPE_RECONCILIATION.md), [source material register](SOURCE_MATERIAL_REGISTER.md), [product delivery plan](../planning/PRODUCT_DELIVERY_PLAN.md) |
| Authoritative policies | [BUSINESS_RULES.md](BUSINESS_RULES.md) and [POLICY_DECISION_REGISTER.md](POLICY_DECISION_REGISTER.md) (all PENDING). Scope inclusion never approves a policy. |
| Status | Draft for review. Scope statements are USER-REQ unless tagged otherwise; nothing is implemented by this effort. |

## 1. Scope history and current authority

| Date | Scope statement | Status |
|---|---|---|
| 2026-10-28 | Requirements preparation only; one combined Flutter application; manual bKash/Nagad references; gateway and live GPS "later". | Historical. Superseded for architecture and payment scope. |
| 2026-10-30 (first request) | Full design and implementation after plan approval, all roles, every screenshot interaction, supporting screens, verification and a visual PDF of actual rendered screens. | Active. Plan approval does not approve any BR. |
| 2026-10-30 (master prompt and 94-screen prototype document) | Four applications on one backend, Accounts Web, flexible kitchen and meal system, custom subscriptions, credits, SSLCOMMERZ and COD, supplier and rider earnings and payouts, double-entry ledger, 25 scenarios, 10 workflows, policy decision register. | Active. Both sources are PRIMARY requirements ([register](SOURCE_MATERIAL_REGISTER.md)). |
| 2026-10-30 (documentation refinement instruction) | Documentation and architecture redesign only, inside `FINAL_REFINED_DOCS/`, Markdown only, no code, no deployment, no real gateway connection. | Governs this effort. |

The master prompt instructs that the latest explicit requirements win over earlier documents and that obsolete architecture is revised, not silently kept. Where an earlier document says "one Flutter application", "gateway is a later release" or "no application exists", this set replaces the statement and records the change in the [requirements change log](../analysis/REQUIREMENTS_CHANGE_LOG.md).

## 2. Applications in scope

| Code | Application | Platform | Audience | In scope (summary) |
|---|---|---|---|---|
| CUS | Customer App | Flutter, Android first, iOS-ready architecture | Guests, customers | Public shell P-01…P-04; authentication; kitchen discovery and profiles; one-time orders; daily, weekly, monthly and custom subscriptions; quotes; skip, pause, replace, cancel; service credits; online payment and COD; billing, invoices, receipts; tracking; reviews, complaints, support. |
| PAR | Partner App | Flutter, Android | Suppliers and riders | One binary, two protected workspaces chosen by server-validated role. Supplier: kitchen, menu, variants, prices, stock and capacity, commitments, order acceptance, preparation, handoff, earnings, payouts. Rider: duty, offers, pickup, navigation, proof, COD collection and remittance, earnings, payouts. Shared application forms, document verification, status. |
| ADM | Admin Web | Flutter Web, desktop-first | Operations and governance staff | Executive overview, customers and partners, application approvals, kitchen and menu oversight, subscription and order monitoring, dispatch and incidents, zones, complaints and disputes, policy configuration, operations analytics, security and staff permissions, audit monitoring, limited financial overview. |
| ACC | Accounts Web | Flutter Web, desktop-first | Accounts and Finance staff | Financial overview, customer payments, COD receivables and deposit verification, supplier and rider payable ledgers, payout review and execution, credits and refunds, disputes and chargebacks, adjustments, reconciliation, general ledger, period close, finance reports, financial audit, finance role permissions. |
| BE | Shared backend | Trusted services | All applications | One domain model and one command surface: authentication claims, quotes, orders, subscriptions and obligations, payments and gateway handling, COD, credits, earnings, payouts, ledger, notifications, audit. |

Admin and Accounts are separate role-protected workspaces even though they share packages and the backend. Admin staff do not automatically hold authority to change balances or execute payouts. (USER-REQ.)

## 3. Product scope by capability

Every requirement below is part of the requested product. Presence in this list does not mean it is implemented. A blocking policy decision stops only the dependent behavior; the feature remains in scope.

| Area | Capabilities | Requirements |
|---|---|---|
| Identity and access | Registration, sign-in, recovery, sessions, roles and claims, invited staff, multi-factor for staff, partner onboarding and corrections | FR-001–FR-003, FR-021, FR-044, FR-045 |
| Catalogue and kitchens | Kitchen discovery and profile, meals, variants, price versions, allergens, slot availability, capacity and stock reservation | FR-004, FR-005, FR-014, FR-015, FR-026, FR-027, FR-046 |
| Purchasing | One-time orders, custom subscriptions, server quotes with immutable snapshots, order history | FR-006, FR-007, FR-009, FR-028–FR-030 |
| Subscription lifecycle | Pause, skip, resume, replace, upgrade, downgrade, cancel, renew, version history | FR-008, FR-031 |
| Credits | Non-cash service credits and promotional credits, reservation, consumption, voiding, history | FR-032 |
| Payments | SSLCOMMERZ through a gateway abstraction (prepared, not connected), manual evidence fallback, COD, billing schedules, invoices, receipts | FR-012, FR-013, FR-033–FR-035 |
| Delivery | Assignment, offers, pickup, four confirmed delivery states, proof, missing customer, reassignment, location consent | FR-010, FR-019, FR-020, FR-037, FR-047, FR-048 |
| Earnings and payouts | Supplier and rider earnings with recognition events, holds, payout requests, maker-checker approval, external confirmation | FR-018, FR-036, FR-038 |
| Finance | Refunds, disputes, chargebacks, adjustments, double-entry ledger, reconciliation, period close, reports and secured export | FR-024, FR-039–FR-042 |
| Operations | Admin operations, zones, policy configuration, incidents, complaints, notifications | FR-022, FR-023, FR-025, FR-043 |
| Cross-cutting | English and Bangla, themes, responsive layouts, accessibility, time zone and cutoff evaluation | FR-049, FR-050, NFR-013–NFR-032 |

## 4. Screens in scope

| Set | Count | Identifiers | Tag |
|---|---|---|---|
| Legacy prototype screens (authoritative, unchanged) | 94 | P-01…P-04, AU-01…AU-13, SH-01, SH-02, SH-04…SH-10, C-01…C-25, S-01…S-12, R-01…R-10, A-01…A-19, X-01, X-02 | OBSERVED (React prototype; statuses I/U/S carried in the digest) |
| Proposed new screens | 55 | NC-01…NC-19 (19), NS-01…NS-07 (7), NR-01…NR-06 (6), NA-01…NA-06 (6), NF-01…NF-17 (17) | PROPOSED (not confirmed routes) |
| Combined named screen contracts | 149 | — | — |

`SH-03` and `C-26` onward do not exist. X-01 and X-02 are design and QA tooling, not product screens. The earlier 129-family planning inventory is cited as `F129/<id>` and reconciled in the [inventory reconciliation](../design/INVENTORY_RECONCILIATION.md); the complete list is the [complete screen inventory](../design/COMPLETE_SCREEN_INVENTORY.md). Every actionable control must have a documented destination; known dead ends (for example the non-clickable kitchen cards in P-02) are recorded as gaps to fix, not preserved.

## 5. Payment gateway position

SSLCOMMERZ is the selected gateway. This effort prepares the integration architecture, gateway abstraction interface, payment lifecycle and validation contracts, environment configuration documentation, sandbox/live separation, payment screens, payment initiation and callback design, server-side validation, status reconciliation, refund boundaries and mock-gateway test cases. It does not obtain credentials, configure a merchant account, process any payment or declare the integration operational. A browser redirect or frontend callback is never treated as payment success. The integration is verified against current official SSLCOMMERZ documentation before implementation. See [SSLCOMMERZ integration plan](../payments/SSLCOMMERZ_INTEGRATION_PLAN.md) and [payment architecture](../payments/PAYMENT_ARCHITECTURE.md).

## 6. Out of scope

| Item | Disposition |
|---|---|
| Application code, live Firebase or database configuration, deployment, store distribution, CI execution by this effort | Not performed. Implementation is planned in [IMPLEMENTATION_PLAN.md](../planning/IMPLEMENTATION_PLAN.md). |
| Real gateway credentials, real transactions, real payouts, real customer data | Excluded from this effort and from all fixtures. |
| Declaring legal or regulatory compliance (stored value, customer funds, payout handling, taxes, reporting in Bangladesh) | Excluded. Legal questions are listed in [audit and compliance](../security/AUDIT_AND_COMPLIANCE.md); BR-018 and BR-025 stay PENDING. |
| Cash-out or transfer of customer service credits | Excluded unless a separate legal and financial policy approves it (BR-025). |
| Regulated wallet functionality for suppliers or riders | Not assumed. Supplier and rider accounts are internal earnings and settlement records. |
| AI recommendations, demand prediction, coupons and loyalty programs | Later-release items from the original source; not requested in the 2026-10-30 sources. Promotional credit exists only as a separately stored credit class (SC-23), not as a coupon engine. |
| iOS release | Architecture must allow it; an iOS build, scheduling and QA need a separate decision. |
| Multiple kitchens within one subscription agreement | Allowed only if approved rules permit it (BR-021). Until then, one kitchen per agreement is the PROPOSED launch rule and multiple agreements per customer remain allowed. |
| Third-party chat and calling infrastructure | Out of scope; user-initiated dialer hand-off is the proposed contact pattern. |
| Automatic settlement, automatic refunds, automatic write-offs | Not implied. Every outbound money movement requires the approvals and external confirmation defined in the finance requirements. |
| Continuous background location collection | Not assumed. Any location feature follows FR-048 consent and DEC-010 privacy decisions. |

## 7. What this effort has and has not done

| Done (documentation) | Not done |
|---|---|
| Audited existing documents against both primary sources, preserved the sources in digests, defined identifier conventions, glossary and policy register. | No application code written, changed or run. The existing `app/`, `backend/` and `firebase/` trees are described, not verified. |
| Refined requirements, planning, architecture, data, API, security, finance, screen and test documentation. | No test executed. Every test is a design unless a result is recorded in the [test results](../testing/TEST_RESULTS.md). |
| Recorded all unresolved decisions as PENDING with alternatives and PROPOSED recommendations. | No policy approved; no approval evidence supplied. |

## 8. Change control

A proposed scope change records the affected FR, UC, AC, BR, NFR and screen identifiers, rationale, cost and schedule impact, and approval evidence. The authorized stakeholder must accept a business policy before dependent schema and behavior are finalized. Scope may not be reduced by relabeling an incomplete requirement as "later". Canonical policy blockers are in [BUSINESS_RULES.md](BUSINESS_RULES.md) and [POLICY_DECISION_REGISTER.md](POLICY_DECISION_REGISTER.md); proposed engineering decisions stay labelled until approved. The earlier "documentation-only" restriction is historical and is not a permanent prohibition on later implementation.

## 9. Acceptance and verification of scope

| Check | Evidence expected |
|---|---|
| Each in-scope capability maps to at least one FR and one screen contract | Traceability matrix ([REQUIREMENTS_TRACEABILITY_MATRIX.md](REQUIREMENTS_TRACEABILITY_MATRIX.md)) |
| Counts reproduce: 4 applications, 94 legacy screens, 55 proposed screens, 25 scenarios, 10 workflows, 26 policy rules | [Documentation coverage](../verification/DOCUMENTATION_COVERAGE.md) |
| No out-of-scope item is described as implemented | [Consistency audit](../verification/CONSISTENCY_AUDIT.md) |

## 10. Open items

| Item | Decision owner | Reference |
|---|---|---|
| Whether the four-application split and hybrid datastore are approved as the delivery architecture | Business owner and technical lead (to be identified) | ADR-004, ADR-005 |
| Whether any subscription COD model is approved | Business owner | BR-012 |
| Whether multi-kitchen agreements are permitted | Business owner | BR-021 |
| Whether live rider location is shipped and under what consent and retention rules | Business owner and privacy owner | FR-048, DEC-010 |
