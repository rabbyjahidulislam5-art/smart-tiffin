# Requirements traceability matrix

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (original FR-001…025 rows kept unchanged; full-chain FR-026…050 table added) |
| Owner | Documentation lead |
| Depends on | [Complete screen inventory](../design/COMPLETE_SCREEN_INVENTORY.md), [api/API_SPECIFICATION.md](../api/API_SPECIFICATION.md), [database/DATA_DICTIONARY.md](../database/DATA_DICTIONARY.md) |
| Status | Documentation trace only; no implementation or execution evidence. |

Version 0.1 · 2026-10-28 · Requirements draft for review; application not implemented.

**Evidence boundary:** The table traces documentation and planned verification. No Flutter source, security rule, trusted handler, database deployment or executable product test exists in this phase. “Not created” is intentional and must never be interpreted as passed. Exact implementation paths and test paths must be added when real files exist, then associated with a tested revision. Business rules are [canonical and pending](BUSINESS_RULES.md).

| Requirement | Use case / acceptance / planned test | Design contract | Policy dependencies | Implementation / execution |
|---|---|---|---|---|
| FR-001 | UC-001 / AC-001 / TEST-001 | [identity](../api/API_SPECIFICATION.md) | See feature dependencies | Not created / not run |
| FR-002 | UC-002 / AC-002 / TEST-002 | [profiles](../database/DATA_DICTIONARY.md) | See feature dependencies | Not created / not run |
| FR-003 | UC-003 / AC-003 / TEST-003 | [authorization](../api/AUTHORIZATION.md) | See feature dependencies | Not created / not run |
| FR-004 | UC-004 / AC-004 / TEST-004 | [catalog](../architecture/MODULE_DESIGN.md) | See feature dependencies | Not created / not run |
| FR-005 | UC-005 / AC-005 / TEST-005 | [catalog](../architecture/MODULE_DESIGN.md) | See feature dependencies | Not created / not run |
| FR-006 | UC-006 / AC-006 / TEST-006 | [subscriptions](../database/DATABASE_DESIGN.md) | BR-001, BR-002, BR-005 | Not created / not run |
| FR-007 | UC-007 / AC-007 / TEST-007 | [orders](../api/API_SPECIFICATION.md) | BR-002, BR-005 | Not created / not run |
| FR-008 | UC-008 / AC-008 / TEST-008 | [subscriptions](../database/DATABASE_DESIGN.md) | BR-001, BR-002, BR-005 | Not created / not run |
| FR-009 | UC-009 / AC-009 / TEST-009 | [orders](../api/API_SPECIFICATION.md) | See feature dependencies | Not created / not run |
| FR-010 | UC-010 / AC-010 / TEST-010 | [delivery](../architecture/DATA_FLOW.md) | See feature dependencies | Not created / not run |
| FR-011 | UC-011 / AC-011 / TEST-011 | [reviews](../database/DATA_DICTIONARY.md) | See feature dependencies | Not created / not run |
| FR-012 | UC-012 / AC-012 / TEST-012 | [billing](../api/API_SPECIFICATION.md) | BR-002, BR-003, BR-005 | Not created / not run |
| FR-013 | UC-013 / AC-013 / TEST-013 | [payments](../api/API_SPECIFICATION.md) | BR-002, BR-003, BR-005 | Not created / not run |
| FR-014 | UC-014 / AC-014 / TEST-014 | [catalog](../architecture/MODULE_DESIGN.md) | BR-002 | Not created / not run |
| FR-015 | UC-015 / AC-015 / TEST-015 | [catalog](../architecture/MODULE_DESIGN.md) | See feature dependencies | Not created / not run |
| FR-016 | UC-016 / AC-016 / TEST-016 | [fulfillment](../architecture/MODULE_DESIGN.md) | BR-001, BR-002, BR-005 | Not created / not run |
| FR-017 | UC-017 / AC-017 / TEST-017 | [fulfillment](../architecture/MODULE_DESIGN.md) | BR-001, BR-004, BR-005 | Not created / not run |
| FR-018 | UC-018 / AC-018 / TEST-018 | [reporting](../architecture/MODULE_DESIGN.md) | BR-002, BR-003, BR-005 | Not created / not run |
| FR-019 | UC-019 / AC-019 / TEST-019 | [delivery](../architecture/DATA_FLOW.md) | BR-004 | Not created / not run |
| FR-020 | UC-020 / AC-020 / TEST-020 | [delivery](../architecture/DATA_FLOW.md) | BR-004, BR-005 | Not created / not run |
| FR-021 | UC-021 / AC-021 / TEST-021 | [administration](../api/AUTHORIZATION.md) | See feature dependencies | Not created / not run |
| FR-022 | UC-022 / AC-022 / TEST-022 | [administration](../api/AUTHORIZATION.md) | See feature dependencies | Not created / not run |
| FR-023 | UC-023 / AC-023 / TEST-023 | [complaints](../database/DATA_DICTIONARY.md) | See feature dependencies | Not created / not run |
| FR-024 | UC-024 / AC-024 / TEST-024 | [reporting](../architecture/MODULE_DESIGN.md) | BR-002, BR-003, BR-005 | Not created / not run |
| FR-025 | UC-025 / AC-025 / TEST-025 | [notifications](../architecture/INTEGRATION_DESIGN.md) | BR-002, BR-004 | Not created / not run |

## Screen planning trace — 2026-10-30

The following links map existing FRs to stable IDs in [the planned inventory](../design/SCREEN_INVENTORY.md). They are not rendered designs or executable coverage. Every row's product implementation/execution remains **Not created / not run**. Screenshot additions UX-01–UX-18 are separately reconciled in [the scope register](SCREENSHOT_SCOPE_RECONCILIATION.md); each source control has a mapping in [the audit](../design/SCREENSHOT_ACTION_AUDIT.md).

| Requirement | Planned screen families | Execution |
|---|---|---|
| FR-001 | AU-01–AU-12; SH-06/07/08 | Not run |
| FR-002 | C-02/03/23/29; S-19; R-10; A-27 | Not run |
| FR-003 | AU-01/10/12; SH-15; all protected role routes; A-21 | Not run |
| FR-004 | C-01/04/06/07/08 | Not run |
| FR-005 | C-05/08/14 | Not run |
| FR-006 | C-08–C-14; S-20/21 | Not run |
| FR-007 | C-06/09/10/11/17 | Not run |
| FR-008 | C-13/14/15; SH-20 | Not run |
| FR-009 | C-17 | Not run |
| FR-010 | C-18 | Not run |
| FR-011 | C-19/20; S-22; A-26 | Not run |
| FR-012 | C-26/27; A-17 | Not run |
| FR-013 | C-25/27; A-22 only for approved verifier | Not run |
| FR-014 | S-02–S-08; A-25 conditional oversight | Not run |
| FR-015 | S-04/09; C-06/10 | Not run |
| FR-016 | S-13/20/21 | Not run |
| FR-017 | S-10–S-15 | Not run |
| FR-018 | S-17/18 | Not run |
| FR-019 | R-01/02/09; A-11 if authorized | Not run |
| FR-020 | R-03–R-07; C-18; A-10/13 | Not run |
| FR-021 | A-02–A-08/21; AU-08–AU-10 | Not run |
| FR-022 | A-09/10/12/13 | Not run |
| FR-023 | C-21/22; SH-14; A-14/15/19 | Not run |
| FR-024 | A-16/17/18 | Not run |
| FR-025 | SH-01/02/04; all authorized notification destinations | Not run |

## Non-functional and business traceability

| Requirement group | Canonical design / validation plan | Evidence status |
|---|---|---|
| NFR-001–NFR-003 platform, language and accessibility | [Design guidance](../design/UI_UX_GUIDELINES.md), [accessibility](../design/ACCESSIBILITY.md), Android device and Bangla/English acceptance suite | Targets specified; not executed |
| NFR-004–NFR-006 performance, reliability and financial integrity | [Test strategy](../testing/TEST_STRATEGY.md), controlled load/clock/financial fixtures | Proposed numeric targets; not measured |
| NFR-007–NFR-009 authorization, privacy and failure/offline handling | [Security architecture](../architecture/SECURITY_ARCHITECTURE.md), cross-role and recovery tests | Specified; no security rule tests run |
| NFR-010–NFR-012 recoverability, maintainability and observability | [Test strategy](../testing/TEST_STRATEGY.md), [migration strategy](../database/MIGRATION_STRATEGY.md) | Proposed targets; operational decisions pending |
| BR-001 | FR-006/008/016; AC-BR001-01 through AC-BR001-04 | Pending Decision; no rule implementation |
| BR-002 | FR-006/007/012/018/024; AC-BR002-01 through AC-BR002-04 | Pending Decision; no calculation implementation |
| BR-003 | FR-012/013/018/024; AC-BR003-01 through AC-BR003-04 | Pending Decision; no verification integration |
| BR-004 | FR-019/020/021/022; AC-BR004-01 through AC-BR004-04 | Pending Decision; no assignment implementation |
| BR-005 | FR-006/007/008/012/013/016/018/024; AC-BR005-01 through AC-BR005-04 | Pending Decision; no cancellation/refund implementation |

## Full-chain traceability — FR-026…050 (2026-10-30)

Requirement → Application → Module → Screen → Backend Service (command) → Database Entity → Business Rule → Test → Documentation File.

| FR | App | MOD | Screen(s) | Command | Entity | BR | TEST | Doc |
|---|---|---|---|---|---|---|---|---|
| FR-026 | CUS | MOD-CAT | P-02, NC-01 | `searchKitchens` | `ent.Kitchen` | — | TEST-026 | [KITCHEN_AND_MEAL_SYSTEM](../customer-app/KITCHEN_AND_MEAL_SYSTEM.md) |
| FR-027 | PAR-S | MOD-CAT | S-04/05, NS-06 | `saveMealVariant`, `schedulePriceChange` | `ent.MealVariant`, `ent.PriceVersion` | — | TEST-027 | [SUPPLIER_SCREENS](../design/screens/SUPPLIER_SCREENS.md) |
| FR-028 | CUS | MOD-ORD | C-07/08, NC-14 | `placeOneTimeOrder` | `ent.Order` | BR-012 | TEST-028 | [ORDER_MANAGEMENT](../customer-app/ORDER_MANAGEMENT.md) |
| FR-029 | CUS | MOD-SUB | NC-04/05 | `saveSubscriptionSchedule` | `ent.Subscription`, `ent.MealObligation` | BR-001, BR-021 | TEST-029 | [CUSTOM_SUBSCRIPTION_ENGINE](../customer-app/CUSTOM_SUBSCRIPTION_ENGINE.md) |
| FR-030 | CUS, BE | MOD-PRC | C-12, NC-08 | `createQuote` | `ent.Quote` | BR-002, BR-007 | TEST-030 | [PRICING_AND_BILLING](../payments/PRICING_AND_BILLING.md) |
| FR-031 | CUS | MOD-SUB | C-14/15, NC-09/10 | `skipMeals`, `replaceMeal` | `ent.MealObligation` | BR-001, BR-006, BR-017 | TEST-031 | [CUSTOMER_CREDITS](../customer-app/CUSTOMER_CREDITS.md) |
| FR-032 | CUS, ACC | MOD-CRD | NC-11/16, NF-09 | `consumeCredit` | `ent.CreditAccount` | BR-006, BR-019 | TEST-032 | [CUSTOMER_CREDIT_RULES](../payments/CUSTOMER_CREDIT_RULES.md) |
| FR-033 | CUS, BE | MOD-PAY | C-08/09, NC-14 | `initiatePayment`, `handleGatewayNotification` | `ent.PaymentIntent` | BR-003 | TEST-033 | [SSLCOMMERZ_INTEGRATION_PLAN](../payments/SSLCOMMERZ_INTEGRATION_PLAN.md) |
| FR-034 | PAR-R, ACC | MOD-COD | NR-03/04, NF-03/04 | `recordCodCollection`, `verifyCodRemittance` | `ent.CodCollection` | BR-012, BR-013 | TEST-034 | [COD_PAYMENT_WORKFLOW](../payments/COD_PAYMENT_WORKFLOW.md) |
| FR-035 | CUS, ACC | MOD-PAY | C-20/21 | — (read) | `ent.Invoice` | BR-002 | TEST-035 | [CUSTOMER_SCREENS](../design/screens/CUSTOMER_SCREENS.md) |
| FR-036 | PAR-S, ACC | MOD-SET | S-08, NS-01, NF-05 | `recognizeSupplierEarning` | `ent.SupplierEarning` | BR-009, BR-010 | TEST-036 | [SUPPLIER_EARNINGS](../partner-app/SUPPLIER_EARNINGS.md) |
| FR-037 | PAR-R, ADM | MOD-DLV | R-10, NR-01 | `acceptAssignment`, `reassignDelivery` | `ent.DeliveryAssignment` | BR-011 | TEST-037 | [RIDER_MODULES](../partner-app/RIDER_MODULES.md) |
| FR-038 | PAR, ACC | MOD-SET | NS-02/03, NR-02, NF-07/08 | `requestPayout`, `approvePayout` | `ent.PayoutRequest` | BR-014, BR-020 | TEST-038 | [PAYOUT_MANAGEMENT](../accounts-web/PAYOUT_MANAGEMENT.md) |
| FR-039 | CUS, ADM, ACC | MOD-LED | NF-10 | `initiateRefund` | `ent.Refund` | BR-005, BR-015 | TEST-039 | [REFUNDS_AND_ADJUSTMENTS](../accounts-web/REFUNDS_AND_ADJUSTMENTS.md) |
| FR-040 | ACC | MOD-LED | NF-11/12 | `postJournal`, `closePeriod` | `ent.JournalEntry` | BR-020 | TEST-040 | [FINANCIAL_LEDGER](../accounts-web/FINANCIAL_LEDGER.md) |
| FR-041 | ACC | MOD-LED | NF-02/13/17 | `reconcileGatewayStatement` | `ent.ReconciliationItem` | — | TEST-041 | [PAYMENT_RECONCILIATION](../accounts-web/PAYMENT_RECONCILIATION.md) |
| FR-042 | ACC, ADM | MOD-RPT | NF-14, NA-06 | `exportReport` | — | — | TEST-042 | [ACCOUNTS_UI_UX](../accounts-web/ACCOUNTS_UI_UX.md) |
| FR-043 | ADM | MOD-ADM, MOD-POL | NA-01/02/04 | `publishPolicyVersion`, `reassignDelivery` | `ent.PolicyVersion` | BR-006…026 | TEST-043 | [OPERATIONS_MANAGEMENT](../admin-web/OPERATIONS_MANAGEMENT.md) |
| FR-044 | ADM, ACC | MOD-AUTH | NF-15 | `grantStaffRole` | `ent.StaffAccount` | BR-020 | TEST-044 | [ACCOUNTS_ARCHITECTURE](../accounts-web/ACCOUNTS_ARCHITECTURE.md) |
| FR-045 | PAR, ADM | MOD-AUTH | AU-09/10/11, NA-03 | `decideApplication` | `ent.Application` | — | TEST-045 | [APPROVAL_WORKFLOWS](../admin-web/APPROVAL_WORKFLOWS.md) |
| FR-046 | PAR-S, BE | MOD-CAT | NS-05 | `reserveStock`, `saveCapacity` | `ent.StockReservation` | — | TEST-046 | [KITCHEN_AND_MEAL_SYSTEM](../customer-app/KITCHEN_AND_MEAL_SYSTEM.md) |
| FR-047 | PAR-R, CUS | MOD-DLV | R-03, NR-06 | `submitDeliveryProof`, `reportDeliveryFailure` | `ent.DeliveryProof` | BR-011 | TEST-047 | [RIDER_MODULES](../partner-app/RIDER_MODULES.md) |
| FR-048 | CUS, PAR-R | MOD-DLV | C-18 | `updateRiderLocation` | `ent.RiderLocation` | — | TEST-048 | [architecture/TIME_AND_CUTOFF_POLICY](../architecture/TIME_AND_CUTOFF_POLICY.md) |
| FR-049 | All | cross-cutting | all | — | — | — | TEST-049 | [CUSTOMER_UI_UX](../customer-app/CUSTOMER_UI_UX.md) |
| FR-050 | BE | MOD-POL | all (cutoff-dependent) | — | `ent.PolicyVersion` | BR-022 | TEST-050 | [architecture/TIME_AND_CUTOFF_POLICY](../architecture/TIME_AND_CUTOFF_POLICY.md) |

## BR-006…026 traceability

See [requirements/POLICY_DECISION_REGISTER.md](POLICY_DECISION_REGISTER.md) "Affected documents" column per rule for the equivalent chain; not duplicated here to avoid a second source of truth.

Document integrity evidence is recorded by the primary agent in the [test results](../testing/TEST_RESULTS.md). Product features may be marked verified only after their acceptance checks pass against an identified implementation revision and environment.

