# Business rules and decision register

## Document control

| Field | Value |
|---|---|
| Project | Smart Tiffin Service Management System — four applications (Customer, Partner, Admin Web, Accounts Web) on one shared backend |
| Version | 0.3 — extended for the four-application, finance-enabled scope (supersedes 0.2 · 2026-10-28) |
| Prepared / reviewed date | 2026-10-28; extended 2026-10-30 |
| Current phase | Documentation refinement; no application implementation performed by this effort |
| Document status | Prepared for stakeholder review; business policies not approved |
| Rules in this register | BR-001 meal pauses (this file); BR-002 billing (this file); BR-003 manual payment verification (this file); BR-004 delivery assignment (this file); BR-005 cancellations/refunds (this file); **BR-006…BR-026 — credits, delivery fees, discounts, commission, earning recognition, COD, payouts, disputes, tax, credit expiry, approval limits, multi-kitchen, cutoff, dual-role, kitchen discontinuity, legal status of credits, COD netting — fully detailed in [POLICY_DECISION_REGISTER.md](POLICY_DECISION_REGISTER.md)** |
| Status of all five original rules | **Pending Decision** |
| Status of BR-006…BR-026 | **Pending Decision**, every recommendation **PROPOSED — NOT APPROVED** |
| Decision owner for all rules | **Business owner/authorized stakeholder — to be identified** |
| Approval evidence | None supplied for any rule, original or extended |
| Canonical role | This file is the single source of truth for BR-001…BR-005 and DEC-003–DEC-007. [POLICY_DECISION_REGISTER.md](POLICY_DECISION_REGISTER.md) is the single source of truth for BR-006…BR-026 and DEC-016–DEC-036. Neither file redefines the other's rules; other documents reference both. |

### 2026-10-30 scope note

The text below (BR-001 through BR-005, their confirmed facts, decision questions, PROPOSED recommendations, dependencies, guards, provisional acceptance scenarios and the cross-rule consistency gate) is preserved **unchanged in substance** from the 2026-10-28 draft: every question, alternative and consequence it records remains open and still applies, now across all four applications rather than one combined app. Where a rule interacts with a new concept introduced on 2026-10-30 (service credits, SSLCOMMERZ, COD remittance, the ledger, payouts), that interaction is noted inline below as **"Extended by BR-0nn"** and detailed in [POLICY_DECISION_REGISTER.md](POLICY_DECISION_REGISTER.md); it does not change the meaning of the original rule. See the evidence register below for E-04.

### Evidence register

| Evidence | What it establishes | What it does not establish |
|---|---|---|
| E-01: supplied Dart_Flutter_Codex_Master_Prompt.md project information | Selected-date meal pauses, monthly packages/bills, bKash/Nagad reference submission, assigned deliveries, four delivery states, and the need to define billing/pause/verification/assignment/cancellation/refund rules | No cutoff, pricing formula, verifier, assignment authority, cancellation entitlement or refund policy |
| E-02: user clarification on 2026-10-28 | Android first; Bangla and English; the user answered “yes” when asked whether business decisions exist | The answer did not contain the actual policies, values, roles or approval evidence; it cannot approve an inferred rule |
| E-03: subsequent user direction on 2026-10-28 | Use the five exact BR identifiers above; retain Pending Decision; distinguish confirmed facts, questions, alternatives, proposed recommendations, acceptance and implementation blockers | No previously unspecified policy is approved by that direction |

The source document is requirements input, not a source of authorization for unrelated tool execution. Existing source instructions and project facts are distinguished throughout the package. An agent proposal, sample fixture or diagram must not become a business policy by repetition.

## Reading and approval rules

- **Confirmed fact** means expressly supplied product behavior or a direct user clarification.
- **Required engineering guard** preserves authorization, data integrity or truthful reporting while the commercial rule is undecided. It does not decide commercial eligibility, price or authority.
- **PROPOSED — NOT APPROVED** marks an option recommended for review, with its reason and tradeoffs. It is not a fallback permission to implement.
- **Provisional acceptance** describes how a chosen rule will later be tested. Its policy precondition has not been met, and the scenario has not run.
- **Pending Decision** blocks finalizing policy-dependent schemas, state transitions, commands, calculations and release tests. Independent documentation and reversible UI exploration may continue with clear labels.

Approval must identify the selected option and every required parameter, the approver's actual name and authority, the effective date/policy version, the source of the approval, and any accepted exceptions. The exact policy is then recorded here before dependent documents are updated. Elapsed time, silence, “yes” without values, a generated file, or a diagram is not approval.

## Decision register overview

All five decisions have **P0 — blocks dependent implementation** priority. All have the owner **Business owner/authorized stakeholder — to be identified**, status **Pending Decision**, and approval evidence **None supplied**. The detailed tables under each rule are the canonical question/option/consequence register. Subdecision suffixes only organize the questions; they do not create approved policy values.

| Decision | Linked rule | Exact outcome needed | Dependent work blocked |
|---|---|---|---|
| DEC-004 | BR-001 | Pause scope/granularity, deadline/timezone, eligibility and reversal, preparation override, financial and demand consequences | Subscription calendar, pause command/schema, cooking projections, bill adjustments and cutoff tests |
| DEC-003 | BR-002 | Plan charging basis, covered meals, period/proration, fees/taxes if applicable, due dates, currency/rounding, adjustment and report definitions | Price/bill schema, charge engine, payment allocation, supplier earnings, revenue reports and reconciled fixtures |
| DEC-005 | BR-003 | Verifier authority, independent evidence, normalization/deduplication, allocation, rejection/correction and second approval | Reference/verification schema, trusted verification operation, financial audit/access rules and payment tests |
| DEC-006 | BR-004 | Assignment authority/method, eligible couriers, workload criteria, acceptance, reassignment and failed-delivery handling | Assignment schema, dispatch commands, access lifecycle, courier UI and exception tests |
| DEC-007 | BR-005 | Cancellation actors/lifecycle/scope, charges, refund eligibility, approval, execution/evidence and corrections | Cancellation/refund schema, accounting adjustments, operational exclusions, notification copy and financial tests |

Cross-cutting DEC-008 (timezone/currency), DEC-009 (identity/role policy), DEC-010 (operations/privacy/retention), DEC-011 (trusted execution) and DEC-014 (cooking/delivery exceptions) are indexed in [assumptions and constraints](ASSUMPTIONS_AND_CONSTRAINTS.md). They must be resolved where a selected business option depends on them.

| E-04: 2026-10-30 user-supplied master prompt and legacy prototype documentation (not repository files; see [source digests](../analysis/SOURCE_MASTER_PROMPT_DIGEST.md) and [source material register](SOURCE_MATERIAL_REGISTER.md)) | Four-application architecture; flexible subscription and credit requirements; SSLCOMMERZ (future) and four COD models; supplier/rider earnings and payouts; a dedicated Accounts department and double-entry ledger; the 94-screen legacy inventory; 25 cross-system scenarios; an explicit instruction to extend, not replace, this register | No value for BR-001…BR-005 or for any of the 21 new rules it motivates (BR-006…BR-026, registered separately); the master prompt itself labels every illustrative figure hypothetical and every recommendation "PROPOSED — NOT APPROVED" |

**Extended by:** BR-001 pause/skip financial effect interacts with BR-006 (service-credit eligibility and formula) and BR-017 (substitutions); BR-002 billing interacts with BR-007 (delivery fees), BR-008 (discounts), BR-009 (commission) and BR-016 (unpaid subscriptions); BR-003 payment verification is now one evidentiary path alongside gateway server validation (ADR-007) and is unaffected in its own meaning; BR-004 delivery assignment interacts with BR-011 (rider compensation) and BR-023 (dual-role accounts); BR-005 cancellation/refunds interacts with BR-006, BR-015 (disputes/chargebacks) and BR-025 (legal status of credits). None of these links changes a BR-001…BR-005 decision; they only identify where a future approval must be read together.

## BR-001 — Meal-pause policy

**Status:** Pending Decision. **Decision:** DEC-004. **Owner:** Business owner/authorized stakeholder — to be identified. **Approval evidence:** None supplied. **Source:** E-01, E-02, E-03.

### Confirmed facts

Customers must be able to pause meals for selected dates of a monthly subscription. Suppliers must see daily cooking requirements. Monthly bills and payment status are required. The proposal supplies neither a deadline nor the effect of a pause on charges, plan duration, already-started preparation or delivery. It does not specify a limit on pause days.

### Detailed decision questions and alternatives

| Subdecision | Exact question / required answer | Alternatives to evaluate | Consequences and dependent work |
|---|---|---|---|
| DEC-004.1 | Is a pause for a whole service date, one meal slot, selected food items or a quantity? Which slots does a package cover? | Whole date; per meal slot; item/quantity-specific | Whole date is simpler but cannot preserve one meal while pausing another. Finer scope requires stable slot/obligation identities and more validation. Blocks pause and obligation keys. |
| DEC-004.2 | What exact deadline applies, relative to which service date/slot, in which service timezone? Is equality at the deadline allowed? | Prior-day cutoff; same-day cutoff; a fixed lead interval per meal slot | Different choices change server-clock comparisons, local calendar presentation and boundary tests. The user must supply the actual time/interval; none is assumed. |
| DEC-004.3 | Can customers pause past dates, the current date, an already paused date, dates outside the subscription, or overlapping requests? What maximum date range/count applies? | Future eligible dates only; narrowly approved correction flow; bulk range with per-date results | Retroactive changes can invalidate cooking/billing history. Overlap must be normalized or rejected consistently. Blocks validation, request batching and response semantics. |
| DEC-004.4 | What happens after preparation begins, an order is ready, a courier is assigned, pickup occurs or delivery completes? Who can authorize an exception and what reason is required? | No override; designated staff override before a specified lifecycle point; documented correction only | Overrides may cause waste or operational conflicts. They require explicit authority, state checks and audit. No preparation or admin override is inferred. |
| DEC-004.5 | May a pause be reversed? Until when, by whom, and subject to availability or capacity? | No reversal; reversal before original cutoff; designated-staff reinstatement | Reinstatement can create extra cooking demand and must not silently bypass availability. Blocks pause lifecycle and demand recalculation. |
| DEC-004.6 | Does an accepted pause reduce the current bill, create a future credit, extend the subscription, or have no financial effect? How is the value determined? | Fixed no-credit package; per-meal credit; extension; approved hybrid | This is a commercial decision, not a database default. Each option changes BR-002, ledger entries and customer wording. Multiple simultaneous benefits must not be accidentally granted. |
| DEC-004.7 | How do already-generated orders and cooking totals reflect an accepted pause? What does a partly accepted multi-date request show? | Exclude linked obligations with preserved history; reject the whole batch on any ineligible date; accept eligible dates with explicit results | Requires one source of truth per meal obligation and clear atomicity. Blocks generated-order/demand contracts and avoids double counting or misleading success. |

### PROPOSED — NOT APPROVED recommendation

Use explicit date-and-meal-slot obligations where the plan actually contains multiple meals; enforce the approved cutoff using authoritative service time; preserve accepted pause history; and calculate cooking/billing consequences from the same accepted obligation exclusions. Reject ineligible dates with a clear reason. Prefer a simple, separately authorized exception process over silent retroactive editing. The actual cutoff, allowed dates, reversal rights and credit/extension effect must be supplied by the owner. This recommendation is for review only and does not choose those values.

### Dependencies, modules, security and audit

FR-006, FR-008, FR-012 and FR-016 depend on this rule; FR-007/017 may be affected by generated orders and preparation. BR-002 decides financial effect; BR-005 decides whether an action is a pause or cancellation. DEC-008 supplies timezone and DEC-014 supplies preparation semantics. Subscription, fulfillment, billing and notification modules must use the same approved policy version.

Required guards: a customer cannot pause another customer's subscription; retries cannot create duplicate benefits; historical dates cannot change because of the device clock; a failed write cannot show an accepted pause. Any approved override must identify its authorized actor and reason. Audit the request identity, subscription/obligation identifiers, affected service dates, prior/new state, policy version, authoritative decision time and override reason. Do not log full customer addresses or payment details.

### Provisional acceptance scenarios

| ID | Given / When / Then | Approval dependency |
|---|---|---|
| AC-BR001-01 | Given an approved cutoff and eligible date/slot, when the own-subscription request occurs just before, exactly at and just after that cutoff, then each result matches the approved equality/timezone rule. | DEC-004.1/.2/.3 |
| AC-BR001-02 | Given an accepted pause, when the same request is retried and a second request overlaps it, then each affected obligation is excluded at most once and any financial benefit occurs at most once. | DEC-004.3/.6/.7; BR-002 |
| AC-BR001-03 | Given preparation has reached each relevant state, when a normal customer and an expressly authorized override actor request a pause, then only the approved lifecycle/override outcome occurs and the reason is audited. | DEC-004.4; DEC-014 |
| AC-BR001-04 | Given a paused subscription and approved financial/reversal rules, when bills and daily cooking needs are recalculated or a permitted reversal is requested, then they reconcile to the same dated obligations and retain history. | DEC-004.5/.6/.7; BR-002 |

**Independent guard checks:** Attempt a foreign-subscription pause and a device-clock manipulation; neither can bypass ownership or authoritative policy evaluation. These are guard requirements, not evidence of a completed test.

**Implementation blocked:** No final pause schema, deadline constant, adjustment formula, kitchen-demand inclusion rule or reversal handler may be approved while the above decisions remain open.

## BR-002 — Billing and monetary policy

**Status:** Pending Decision. **Decision:** DEC-003. **Owner:** Business owner/authorized stakeholder — to be identified. **Approval evidence:** None supplied. **Source:** E-01, E-02, E-03.

### Confirmed facts

The app offers daily plans, weekly plans and monthly packages; customers view monthly bills/payment status; suppliers view earnings/payment history; administrators view revenue. The source does not define charging basis, taxes, fees, commission, proration, due dates, settlement or the meaning of revenue. A monthly package does not by itself establish a calendar-month bill or a fixed number of service days.

### Detailed decision questions and alternatives

| Subdecision | Exact question / required answer | Alternatives to evaluate | Consequences and dependent work |
|---|---|---|---|
| DEC-003.1 | Is each plan charged by fixed package, scheduled meals, delivered meals, actual consumption or a hybrid? What meals/quantities/days are included? | Fixed prepaid package; eligible scheduled meal basis; delivered meal basis; explicit hybrid | Determines the charge source and whether missing delivery or pauses change charges. Blocks plan contract, bill lines and reconciliation fixtures. |
| DEC-003.2 | Does monthly mean calendar month or a duration starting on subscription date? Are both endpoints inclusive? How are weekends, holidays and different month lengths handled? | Calendar month; fixed-day term; service-day package | Changes interval keys, duration, renewal and monthly presentation. A precise service calendar is required. |
| DEC-003.3 | How are partial months, mid-period start/end, package changes and overlapping subscriptions charged? | No proration; per service-day/meal proration; fixed prorated formula; changes only next period | Avoids arbitrary division by a guessed month length. Requires exact rounding and historical policy versions. |
| DEC-003.4 | Are delivery fees, service fees, commissions, taxes or discounts applicable? If yes, which actor pays, on what base, at what rate/amount and with what rounding? | None; explicit fixed amounts; explicit percentage/base with applicable obligations | No tax or fee is invented. Changes customer charges, supplier earnings and admin revenue; compliance advice is outside this requirements draft. |
| DEC-003.5 | What currency, precision, rounding mode and stage apply? How are dates/timestamps and service timezone represented? | Currency and integer minor units with defined rounding; explicitly supported alternatives if needed | Proposed BDT/Asia-Dhaka is not yet approved. Blocks price validation, arithmetic, formatting and period boundaries. |
| DEC-003.6 | When is a bill issued/due, can partial payments apply, and how are overpayments, underpayments and multiple bills allocated? | Prepaid; postpaid; mixed; explicit allocation priority/manual allocation | Depends on BR-003; affects bill status, reminders, balances and whether service eligibility is linked to payment. No automatic service suspension is assumed. |
| DEC-003.7 | How do pauses, cancellation, refunds, failed deliveries, supplier unavailability and corrections affect charges? | Separate adjustments preserving original charges; revised bill with version history; next-period credits | Must align BR-001/BR-005. Silent historical overwrites prevent reconciliation and dispute handling. |
| DEC-003.8 | What do supplier earnings, platform revenue, verified receipts, outstanding balances and payouts mean? Which event and date recognize each amount? | Gross versus net; earned versus paid; cash versus service-based recognition | Customer money received is not automatically supplier payout or platform revenue. Blocks reports and settlement-related terminology. |

### PROPOSED — NOT APPROVED recommendation

Store and calculate exact amounts using an approved currency and minor-unit representation; preserve the accepted price/plan/policy basis on each financial obligation; represent later corrections as traceable adjustments rather than silently rewriting prior charges. Make charge basis, verified payments, outstanding amounts and supplier payout status visibly distinct. Review BDT and Asia/Dhaka as a likely fit for the stated providers, but obtain approval. Do not choose a package formula, fee, tax, commission, proration rule or due date without the owner.

### Dependencies, modules, security and audit

FR-006/007/008/012/013/018/024 and reminders in FR-025 depend on this policy. Subscription, order, billing, payment and reporting modules need the same approved definitions. BR-001 pause effects, BR-003 verification/allocation and BR-005 cancellation/refund effects are interdependent; DEC-008 controls currency/service dates.

Required guards: trusted operations determine totals; customer-submitted amounts cannot overwrite authoritative charges; amount arithmetic must be exact; a pending reference is not verified money; reports preserve their source and basis. Audit bill/charge creation, policy version, approved adjustments, payment allocation and actor/reason. Access to detailed financial records must follow customer/supplier/admin scope. Preserve historical charges when catalogue prices change.

### Provisional acceptance scenarios

| ID | Given / When / Then | Approval dependency |
|---|---|---|
| AC-BR002-01 | Given approved daily/weekly/monthly pricing fixtures, when charges are calculated for full and partial service periods, then every line, fee/tax if applicable, rounded amount and total matches the approved exact result. | DEC-003.1/.2/.3/.4/.5 |
| AC-BR002-02 | Given an accepted pause, cancellation or failed service event, when a bill is generated or adjusted, then its effect follows the approved policy exactly once with preserved prior terms. | DEC-003.7; BR-001/BR-005 |
| AC-BR002-03 | Given partial, excessive and rejected payment claims, when verified allocations change, then balance/status follow the approved allocation rules; pending claims do not reduce verified balance. | DEC-003.6; BR-003 |
| AC-BR002-04 | Given a historical purchase followed by a price/policy change, when old bills and reports are read, then historical charges retain their accepted basis and reports reconcile to the approved recognition definition. | DEC-003.7/.8 |

**Independent guard checks:** Tamper with a client total or attempt another customer's bill write; reject the unauthorized operation. Verify that a submitted reference alone cannot set paid status.

**Implementation blocked:** No final monetary schema, bill formula, tax/fee field requirements, rounding constant, allocation rule, revenue formula, earning formula or service-suspension rule may be finalized before decision closure.

## BR-003 — Manual payment verification

**Status:** Pending Decision. **Decision:** DEC-005. **Owner:** Business owner/authorized stakeholder — to be identified. **Approval evidence:** None supplied. **Source:** E-01, E-02, E-03.

### Confirmed facts

Customers submit bKash/Nagad payment references and view payment status. Online gateway integration is a later release. Submitted references are customer claims; their appearance, format or successful storage cannot establish money received. Verification responsibility and evidence requirements are unspecified. No application user is authorized to verify solely because their role is called admin or supplier in a draft.

### Detailed decision questions and alternatives

| Subdecision | Exact question / required answer | Alternatives to evaluate | Consequences and dependent work |
|---|---|---|---|
| DEC-005.1 | Who verifies, for which suppliers/bills, and who can correct a decision? Can the claimant or beneficiary also verify? | Named admin permission; named supplier permission; independent finance operator; restricted combinations | Determines least-privilege checks and conflict-of-interest controls. A role label alone is insufficient. Blocks verifier assignment and grants. |
| DEC-005.2 | Which independent provider/account evidence must be checked: receiving account, provider, reference, amount, transaction date/time or payer context? Is additional customer evidence required? | Authorized recipient transaction record; independent account statement/portal check; explicitly specified supporting evidence | Screenshots or reference format alone may be forgeable. Optional attachments add storage/privacy obligations and are not automatically in scope. Never collect PIN/OTP/wallet login credentials. |
| DEC-005.3 | What normalization and uniqueness scope apply to references? How are case, whitespace, provider, receiving account, collisions and repeated submissions treated? | Provider/account-scoped normalized reference; exact provider-defined normalization; manual collision review | Avoids both double credit and false duplicate rejection. Do not assume provider identifiers are globally unique. Blocks deduplication keys and concurrency tests. |
| DEC-005.4 | Must claimed amount equal the bill? Can one payment cover multiple bills, partial amounts or overpayment? Who allocates it? | One payment/one bill; explicit split allocations; controlled balance/credit handling | Must match BR-002. Allocation totals cannot exceed independently verified money; precise policy remains open. |
| DEC-005.5 | What states/reasons are visible while pending, verified, rejected or disputed? May a customer amend a rejected claim or resubmit? | New version preserving original; separate replacement claim; controlled editable pending fields | Changes lifecycle and history. A correction must not erase the verification trail or silently create new credit. |
| DEC-005.6 | Which corrections, amount thresholds or conflicts require a second independent approval? Can a verified record ever be changed directly? | Single verifier with audit; dual approval for all; dual approval for defined sensitive cases | More control can increase turnaround and staffing cost. No threshold or approval requirement is approved yet. Blocks correction workflow and authority tests. |
| DEC-005.7 | What verification turnaround, escalation and retention rules apply, and what happens if provider evidence is unavailable? | Remain pending with reason; controlled escalation; reject with resubmission guidance | Determines reminders/support copy and evidence retention. Unavailable evidence must never cause automatic verified success. |

### PROPOSED — NOT APPROVED recommendation

Use an explicitly granted verification permission and an independent receiving-account evidence check; keep claims pending until that check succeeds. Preserve reference and decision history, apply accepted financial allocations atomically, and use a provider/account-aware duplicate policy. Consider a second authorized reviewer for sensitive reversals or conflicts, with thresholds and roles selected by the owner. This is a suggested control design, not approval of an admin/supplier verifier or a numeric threshold.

### Dependencies, modules, security and audit

FR-012/013/018/024 and payment reminders depend on this rule. Payment, billing, authorization and reporting modules must share approved evidence and allocation semantics. BR-002 defines balances and BR-005 defines refunds; DEC-009 grants roles, DEC-010 sets retention and DEC-011 selects trusted execution.

Required guards: the claimant cannot self-mark paid without an independently authorized verification operation; a rejected or pending reference contributes no verified credit; duplicate/concurrent processing cannot allocate the same verified value twice; wallet credentials are never collected. Audit claimant/reference identity, verifier, independent evidence reference, original and corrected decision, amount/currency, reason, policy version and server time. Restrict provider references and supporting evidence; avoid them in notifications or routine logs.

### Provisional acceptance scenarios

| ID | Given / When / Then | Approval dependency |
|---|---|---|
| AC-BR003-01 | Given an own-bill payment claim, when it is submitted, then it remains pending; only an actor with the approved verification permission can verify it after required independent checks. | DEC-005.1/.2/.5 |
| AC-BR003-02 | Given two simultaneous claims matching the approved duplicate key, when both are processed, then the verified money is allocated no more than once and the other result is explicit. | DEC-005.3/.4 |
| AC-BR003-03 | Given amount/receiving-account mismatch or unavailable evidence, when a verifier evaluates the claim, then the approved rejection/pending/escalation path occurs and no unjustified credit is created. | DEC-005.2/.4/.7 |
| AC-BR003-04 | Given a previously verified claim needing correction, when the authorized correction process runs, then required second approval is enforced if selected, original history remains and balances/reports reconcile. | DEC-005.5/.6; BR-002 |

**Independent guard checks:** Customer attempts to edit verified state, another customer's bill, verifier identity or allocation amount must fail. Pending must not be displayed as paid or settled.

**Implementation blocked:** No final verifier grants, reference uniqueness schema, evidence storage model, correction workflow, allocation command or second-approval threshold may be finalized without decisions.

## BR-004 — Delivery assignment

**Status:** Pending Decision. **Decision:** DEC-006. **Owner:** Business owner/authorized stakeholder — to be identified. **Approval evidence:** None supplied. **Source:** E-01, E-02, E-03.

### Confirmed facts

Delivery personnel see assigned deliveries, necessary customer locations/addresses and schedules, and update status. Administrators manage delivery personnel and monitor orders. The confirmed delivery sequence is **Pending → Picked Up → On The Way → Delivered**. Live GPS is later scope. The source does not assign dispatch authority or specify automatic assignment, capacity, acceptance, reassignment or failed-delivery policy.

### Detailed decision questions and alternatives

| Subdecision | Exact question / required answer | Alternatives to evaluate | Consequences and dependent work |
|---|---|---|---|
| DEC-006.1 | Who creates/changes assignments, for which supplier/order scope? Is assignment manual, automatic, courier-claimed or hybrid? | Authorized admin dispatcher; authorized supplier dispatcher; rule-based assignment; controlled courier claim | Controls authority, concurrency and UI. Automatic routing would require criteria; GPS must not be silently added. Blocks dispatch command and role matrix. |
| DEC-006.2 | Which couriers are eligible: account status, approval, shift/availability, service area, supplier association or capacity? | Minimal active approved-courier filter; scheduled availability; approved area/capacity constraints | Additional fields require actual operational meaning and ownership. Blocks candidate queries and eligibility validation. |
| DEC-006.3 | How is workload measured and capped, and what breaks ties? Who can override it? | Manual judgement; outstanding-delivery count; time/area-based workload with explicit limits | More automation requires trustworthy data and testable algorithms. No capacity number or fairness guarantee is assumed. |
| DEC-006.4 | Must a courier accept an assignment? Can they reject it, by when, and what happens when no courier is available? | Immediate assignment; acceptance window; dispatch queue/escalation | Affects assignment state separately from delivery progress. Do not add an unapproved fifth delivery state. |
| DEC-006.5 | Who may reassign at each delivery stage, with what reason and handoff evidence? When does old access end? | Before pickup only; controlled post-pickup handoff; separate exceptional correction | Reassignment may expose addresses or lose custody. Blocks assignment history, access revocation and handoff tests. |
| DEC-006.6 | What happens when delivery fails, customer is absent, address is incorrect, food is lost or a courier is unavailable after pickup? | Record exception and seek authorized resolution; reschedule; return/refund/cancel under approved policies | Define exception handling alongside the confirmed four-state chain; do not silently rename or extend it. BR-005 controls financial consequences. |
| DEC-006.7 | What schedule precision and address data are necessary, and who may correct them? | Service date/window; defined appointment; customer-provided address and explicit correction | Influences privacy and successful handoff without assuming map APIs or live tracking. Blocks minimal courier data contract. |

### PROPOSED — NOT APPROVED recommendation

Start with explicitly authorized manual assignment to eligible couriers and preserve assignment history. Validate current assignment on every sensitive read/update; make reassignment a recorded operation with a reason and defined handoff. Represent operational exceptions separately while preserving the confirmed delivery sequence, unless the owner explicitly approves a revised scope. Do not choose the dispatcher role, workload limit, acceptance window or failure outcome without approval.

### Dependencies, modules, security and audit

FR-019/020/021/022 and delivery notifications depend on this rule. Delivery, administration, authorization and order modules must share assignment/version checks. DEC-009 defines courier onboarding, DEC-014 defines preparation/handoff and BR-005 defines cancellation/refund consequences.

Required guards: only currently authorized participants can read sensitive delivery details; a courier cannot update arbitrary work; concurrent reassignment and status changes must be resolved consistently; historical events retain actor/time. Audit assignment creator, original/new courier, order, reason, schedule, prior/new assignment state and authoritative timestamp. Notification payloads must not contain full customer addresses. A user's phone clock cannot establish pickup/delivery authority.

### Provisional acceptance scenarios

| ID | Given / When / Then | Approval dependency |
|---|---|---|
| AC-BR004-01 | Given eligible/ineligible couriers and an order, when the approved dispatcher/method assigns work, then only a policy-eligible courier is selected and the schedule/context is available. | DEC-006.1/.2/.3/.7 |
| AC-BR004-02 | Given a current assignment, when it is reassigned at a permitted lifecycle point, then the old courier loses further sensitive access/update authority and the new courier receives it with recorded history. | DEC-006.5 |
| AC-BR004-03 | Given a valid active assignment, when a courier advances Pending, Picked Up, On The Way and Delivered in order, then each permitted transition is recorded once; a skipped/backward transition is rejected. | Confirmed delivery sequence; pickup prerequisites depend on DEC-014 |
| AC-BR004-04 | Given no eligible courier, rejection or a failed delivery, when the exceptional path occurs, then the approved escalation/resolution is explicit, no fabricated Delivered state is recorded and financial consequences follow BR-005. | DEC-006.4/.6; BR-005 |

**Independent guard checks:** Unassigned or revoked courier requests fail at the trusted boundary. A stale notification or client state cannot restore old assignment authority or overwrite newer progress.

**Implementation blocked:** No final assignment authority, candidate/capacity schema, automatic algorithm, acceptance timer, reassignment policy or failed-delivery outcome may be finalized while the decisions remain open.

## BR-005 — Cancellation and refund policy

**Status:** Pending Decision. **Decision:** DEC-007. **Owner:** Business owner/authorized stakeholder — to be identified. **Approval evidence:** None supplied. **Source:** E-01, E-02, E-03.

### Confirmed facts

The source explicitly identifies cancellation and refund rules as requiring definition before implementation. Orders, subscriptions, pauses, monthly bills and manual payment references are current scope. No cancellation entitlement, fee, refund amount, approving actor, payout method or completion deadline is supplied. An online gateway is later scope, so a recorded refund cannot be represented as automatically executed through bKash/Nagad integration.

### Detailed decision questions and alternatives

| Subdecision | Exact question / required answer | Alternatives to evaluate | Consequences and dependent work |
|---|---|---|---|
| DEC-007.1 | Who may request and approve cancellation: customer, supplier, admin or other operator? Which reasons and service-failure cases apply? | Customer self-service within rules; staff approval; supplier inability exception; combination | Separates request authority from approval and prevents arbitrary cancellation of another person's service. Blocks permissions and request handling. |
| DEC-007.2 | Is cancellation for one order, one meal/slot, selected dates, the entire subscription or only future obligations? | Whole order; selected obligations; subscription termination with effective date | Must distinguish cancellation from BR-001 pause. Determines effects on generated orders, cooking totals and delivery assignments. |
| DEC-007.3 | What eligibility/deadline applies at each preparation/delivery/payment stage? Are exceptions allowed and by whom? | Before preparation only; progressively restricted after preparation/pickup; authorized exception | Locks lifecycle transitions and prevents claiming cancellation after Delivered without a separate dispute/correction path. Needs exact stage/time rules. |
| DEC-007.4 | Are cancellation fees, nonrefundable charges, supplier compensation, partial refunds or credits allowed? How is each amount calculated and rounded? | Full unused-value credit; defined fee/partial amount; no refund in specified cases; approved hybrid | Must align BR-002 and avoid invented entitlement or fee. Blocks financial adjustment formula and customer disclosures. |
| DEC-007.5 | Who requests/approves a refund, what independent approval is needed, and what separates request, approval and actual completion? | Single approved authority; second approval for defined cases; explicit operational separation | Approval is not proof of external money movement. Blocks refund authority and lifecycle contract; thresholds are not assumed. |
| DEC-007.6 | How is an approved refund performed outside the app, to which authorized destination, by whom, and what completion evidence/reference is required? | Manual authorized provider transfer with recorded evidence; approved future bill credit; another explicitly chosen method | No automatic provider execution exists in current scope. Destination validation/privacy and independent proof are required before marking completion. |
| DEC-007.7 | How are failed, delayed, duplicate, disputed, reversed or corrected refunds handled? What time limit/escalation applies? | Remain approved/pending execution with reason; retry with idempotent evidence; separate correction/review | Prevents repeated payout and premature completion. Needs traceable adjustment and external transaction evidence. |
| DEC-007.8 | What happens to cooking demand, courier assignments, notifications and previously billed/paid records after accepted cancellation? | Exclude future eligible obligations with audit; keep irreversible historical events; explicit manual handoff resolution | Operational and financial effects must use the same approved decision. A canceled request must not silently erase custody, delivered history or payment evidence. |

### PROPOSED — NOT APPROVED recommendation

Keep cancellation requests, accepted cancellation decisions, refund requests, refund approvals and evidenced refund completion conceptually distinct. Preserve historical charges, payments and service events; record approved adjustments and external refund evidence. Never mark a refund complete solely because a request or approval exists. Use explicitly authorized manual execution for any provider refund within the current reference-only scope. The actor, eligibility, fee, amount, destination and approval requirements remain owner decisions.

### Dependencies, modules, security and audit

FR-006/007/008/012/013/016/018/019/020/024 and notifications may be affected. Orders, subscriptions, fulfillment, billing, payment, delivery and administration must agree on the effective service obligations and financial effects. BR-001 distinguishes pause from cancellation; BR-002 defines exact amount/rounding; BR-003 defines verified money and corrections; BR-004 defines custody/reassignment consequences.

Required guards: unauthorized actors cannot cancel another customer's service or approve their own refund without explicit authority; retries cannot create duplicate credits or payouts; approval does not equal external completion; canceled/adjusted history is retained. Audit actor, request and reason, affected obligations, pre/post state, approving actor(s), original/adjusted amounts, policy version, external completion evidence reference and time. Store refund destination data only if required and restrict access; never request wallet PINs or OTPs.

### Provisional acceptance scenarios

| ID | Given / When / Then | Approval dependency |
|---|---|---|
| AC-BR005-01 | Given an order/subscription at each relevant lifecycle stage, when each permitted actor requests whole or meal-specific cancellation, then eligibility, scope and effective obligations match the approved rule. | DEC-007.1/.2/.3 |
| AC-BR005-02 | Given approved fee/refund fixtures and previously verified payments, when a cancellation is accepted, then the exact adjustment is computed once and historical charges/receipts remain traceable. | DEC-007.4/.8; BR-002/BR-003 |
| AC-BR005-03 | Given a refund request and required approvals, when it is approved but external transfer evidence is absent, then it is not shown as completed; completion follows only the approved evidence process. | DEC-007.5/.6 |
| AC-BR005-04 | Given duplicate retries, failed external execution or a correction, when recovery occurs, then no duplicate payout/credit is recorded, approved escalation applies and reports reconcile. | DEC-007.7; BR-002/BR-003 |

**Independent guard checks:** Request, approval and completion must remain distinguishable. A successful database write is not proof of an external refund. Cross-user cancellation/refund requests must be denied.

**Implementation blocked:** No final cancellation/refund schema, eligibility matrix, fee calculation, approving role, external-refund method or completion state may be finalized before approval.

## Cross-rule consistency and data-design gate

| Dependency | Required consistency check before approval |
|---|---|
| Pause ↔ billing | Every accepted exclusion has one approved financial effect; a pause cannot accidentally produce both a credit and extension unless expressly intended. |
| Billing ↔ verification | Bill balance derives from approved charges/adjustments and independently verified allocations, not customer claims. |
| Verification ↔ refunds | Refunded amounts refer to verified original money and cannot be spent/allocated twice; corrections retain the source trail. |
| Assignment ↔ cancellation | Cancellation does not erase an active custody/handoff obligation; the authorized operational resolution is explicit. |
| Cancellation ↔ pause | The same dated obligation cannot receive two benefits for one excluded meal without an expressly approved rule. |
| Preparation ↔ pauses/cancellation | Cutoff/override rules agree with what has already been prepared, assigned or picked up. |
| All rules ↔ time/history | Use one approved service timezone and policy-effective date model; protect historical accepted terms and server decision timestamps. |

The [database design](../database/DATABASE_DESIGN.md), [data dictionary](../database/DATA_DICTIONARY.md), [service contract](../api/API_SPECIFICATION.md) and diagrams are **candidate designs**. Their entity names support discussion, not a final schema. Do not generate production rules, migrations, validators or monetary/state handlers from this draft as though the policy gate had passed.

## Approval record and next review

No completed approvals are recorded. For each decision, the stakeholder must provide: selected alternatives; exact times/amounts/roles/formulas and permitted exceptions; name and authority of approver; effective date; evidence reference; and the expected examples at boundary cases. The engineering team must then reconcile all five rules together, update version history, replace provisional acceptance conditions with concrete fixtures, and obtain an independent consistency review before finalizing dependent schema and implementation.

The current document preparation can be completed while these decisions remain open. It does not establish a finalized business baseline, implemented policies, passed acceptance tests, or permission to deploy.

## Extended register: BR-006…BR-026

The 2026-10-30 scope introduces twenty-one further business rules, each PENDING with the same approval discipline as BR-001…BR-005 (selected option, every parameter, approver identity and authority, effective date, evidence, no approval from silence). They are registered in full — question, existing evidence, alternatives, PROPOSED recommendation, business/technical/risk impact, owner, status, affected documents — in [POLICY_DECISION_REGISTER.md](POLICY_DECISION_REGISTER.md):

| Rule | Subject |
|---|---|
| BR-006 | Service-credit eligibility, calculation and use |
| BR-007 | Delivery charges |
| BR-008 | Subscription and promotional discounts |
| BR-009 | Platform commission and service fee |
| BR-010 | Supplier earning recognition event |
| BR-011 | Rider delivery compensation |
| BR-012 | COD eligibility and limits |
| BR-013 | COD remittance deadlines, overdue and recovery |
| BR-014 | Payout thresholds, frequency and holds |
| BR-015 | Disputes and chargebacks |
| BR-016 | Unpaid subscription handling and suspension |
| BR-017 | Meal substitutions, upgrades and downgrades |
| BR-018 | Tax calculation |
| BR-019 | Credit expiry |
| BR-020 | Financial approval limits and maker-checker |
| BR-021 | Multi-kitchen subscriptions |
| BR-022 | Cutoff rules and service time |
| BR-023 | Dual-role accounts |
| BR-024 | Kitchen discontinuity and compliance lapse |
| BR-025 | Legal status of credits, stored value and customer funds |
| BR-026 | Netting of rider COD obligation against rider earnings |

This register (BR-001…BR-005) and the extended register (BR-006…BR-026) together form the complete business-policy decision gate for the four-application platform. Neither register may be bypassed by an architecture, screen or test document; every one links back here or to the extended register rather than inventing a value.
