# Use cases

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (supersedes 0.1 · 2026-10-28; original UC-001…025 kept unchanged) |
| Owner | Requirements and planning author |
| Purpose | Detailed use cases for all four applications, extending the original Android-only catalogue with UC-026…050 for the subscription, credit, payment, partner-finance and Accounts domains. |
| Applies to | CUS, PAR, ADM, ACC, BE |
| Depends on | [Functional requirements](FUNCTIONAL_REQUIREMENTS.md), [acceptance criteria](ACCEPTANCE_CRITERIA.md), [policy decision register](POLICY_DECISION_REGISTER.md) |
| Status | Draft for review; no use case is implemented. |

Each use case describes intended first-release behavior, not an available feature. All actors must be authenticated and authorized unless the operation is registration/sign-in/recovery itself. Policy-dependent paths below are conditional on the explicit approval evidence required by [BUSINESS_RULES](BUSINESS_RULES.md); they are not implementable as final rules yet. Conceptual entity labels refer to the [provisional data dictionary](../database/DATA_DICTIONARY.md).

## UC-001 — Account registration and sessions

- **Requirement / actor / module:** FR-001 / All roles / identity.
- **Trigger and preconditions:** Actor initiates the named task; dependencies DEC-009; Firebase Authentication are satisfied; only authorized records are accessible.
- **Inputs and validation:** Provider-approved credentials and recovery destination; validate required fields and provider errors without logging secrets.
- **Normal behavior:** Register or authenticate; establish identity; load the authoritative role and account state; show the permitted dashboard. Recovery follows the provider flow and returns a generic acknowledgement.
- **Outputs / postcondition:** Its permitted dashboard opens and sign-out removes protected local view state. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Invalid credentials, disabled identity or expired/revoked authorization must not expose protected data. A failed recovery attempt must not disclose whether an account exists. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** Provider identity plus users/{uid}; no application password storage.
- **Audit / privacy:** Record privileged onboarding and account disabling; exclude credentials and session tokens.
- **Verification:** AC-001, TEST-001; not run.

## UC-002 — Profile management

- **Requirement / actor / module:** FR-002 / Authenticated user / profiles.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-001; FR-003 are satisfied; only authorized records are accessible.
- **Inputs and validation:** Name, phone, email and address; define field length and supported phone/address formats before form implementation.
- **Normal behavior:** Load own profile; edit permitted fields; validate; persist; show acknowledged saved values. Preserve a draft if saving fails.
- **Outputs / postcondition:** The confirmed profile update appears without changing any role or existing order snapshot. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Another user’s profile, role fields and approval state cannot be changed through profile editing. Conflicting or rejected updates do not show success. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** users/{uid}; order address snapshots remain historically stable after later profile edits.
- **Audit / privacy:** Audit sensitive identity changes; do not put full addresses or phone numbers in diagnostic logs.
- **Verification:** AC-002, TEST-002; not run.

## UC-003 — Role-based authorization

- **Requirement / actor / module:** FR-003 / All roles / authorization.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-001; DEC-009 are satisfied; only authorized records are accessible.
- **Inputs and validation:** Authenticated subject, role/approval state, requested resource and operation.
- **Normal behavior:** Resolve subject permissions; validate role plus ownership or assignment; authorize the individual read or write; reject unauthorized requests regardless of UI route.
- **Outputs / postcondition:** Only the fields required to complete that assignment are available. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Default-deny unknown roles, unapproved suppliers, disabled accounts, cross-customer records, cross-supplier records and unassigned courier records. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** Authoritative account authorization state; immutable actor identity on audit records.
- **Audit / privacy:** Audit role grants, supplier approvals and administrative authorization changes.
- **Verification:** AC-003, TEST-003; not run.

## UC-004 — Browse meal plans

- **Requirement / actor / module:** FR-004 / Customer / catalog.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-001; FR-003; FR-014; FR-015 are satisfied; only authorized records are accessible.
- **Inputs and validation:** Plan category and selection; publishable content and valid monetary representation.
- **Normal behavior:** Load eligible offerings; present truthful price and availability; open a plan detail; route to ordering or monthly subscription as appropriate.
- **Outputs / postcondition:** The customer can inspect each category and its price, dates and availability. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Unavailable, unpublished or unapproved-supplier offerings cannot be newly ordered. Empty catalog and failed load are distinguishable. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** Read plans and supplier publication/approval state.
- **Audit / privacy:** No routine browsing audit containing personal data is required.
- **Verification:** AC-004, TEST-004; not run.

## UC-005 — Daily and weekly menus

- **Requirement / actor / module:** FR-005 / Customer / catalog.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-004; FR-014 are satisfied; only authorized records are accessible.
- **Inputs and validation:** Service date or week and supplier/plan context; validate calendar dates in the approved service timezone.
- **Normal behavior:** Select a day or week; read published menu items; show food names, prices where relevant and availability.
- **Outputs / postcondition:** Its service dates and daily items are visible in Bangla and English UI. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** No menu is shown as available merely because a network call failed. Stale or partial content is labelled and cannot override current purchase validation. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** Read menu publication, food and plan associations.
- **Audit / privacy:** Supplier menu modifications are audited under FR-014.
- **Verification:** AC-005, TEST-005; not run.

## UC-006 — Monthly subscriptions

- **Requirement / actor / module:** FR-006 / Customer / subscriptions.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-004; DEC-003; DEC-004; DEC-007; DEC-008; policies BR-001, BR-002, BR-005 approved where applicable are satisfied; only authorized records are accessible.
- **Inputs and validation:** Package, start date, required service details and operation identifier; validate availability and approved date/coverage rules.
- **Normal behavior:** Review package and policy; submit once; trusted operation validates; persist the subscription and its applicable plan/price policy snapshot; display acknowledgement.
- **Outputs / postcondition:** Exactly one matching subscription is created and its interval and status are visible. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Invalid date ranges, unavailable plans, unauthorized customer identifiers and conflicting duplicate requests cannot create inconsistent subscriptions. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** subscriptions with immutable customer/plan/price policy snapshot; generated obligations are traceable to a subscription and service date.
- **Audit / privacy:** Audit subscription creation and authorized lifecycle changes.
- **Verification:** AC-006, TEST-006; not run.

## UC-007 — Meal order placement

- **Requirement / actor / module:** FR-007 / Customer / orders.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-004; FR-015; DEC-003; DEC-007; DEC-008; policies BR-002, BR-005 approved where applicable are satisfied; only authorized records are accessible.
- **Inputs and validation:** Food/plan identifiers, quantity, service date and address; validate positive quantities and applicable ordering deadlines.
- **Normal behavior:** Review items and total; submit with a stable request identifier; validate availability, ownership and pricing; atomically create the order; return order identity.
- **Outputs / postcondition:** One order exists with server-validated total, service date and address snapshot. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Client-supplied totals, another customer ID, unavailable items, invalid quantities or competing writes cannot produce an incorrect accepted order. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** orders and item/price/address snapshots; link subscription obligations where applicable to prevent duplicate counting.
- **Audit / privacy:** Record order creation, actor, authoritative totals and later lifecycle changes.
- **Verification:** AC-007, TEST-007; not run.

## UC-008 — Pause selected meal dates

- **Requirement / actor / module:** FR-008 / Customer / subscriptions.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-006; DEC-003; DEC-004; DEC-007; DEC-008; policies BR-001, BR-002, BR-005 approved where applicable are satisfied; only authorized records are accessible.
- **Inputs and validation:** Subscription ID, selected service dates and request ID; validate membership in the subscription interval and approved cutoff.
- **Normal behavior:** Display eligible dates and policy effect; submit; verify current authoritative time and state; persist accepted date exclusions; reflect cooking and billing consequences exactly once.
- **Outputs / postcondition:** The accepted pause excludes only its intended meal obligation and applies the specified bill effect once. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Late, out-of-range, duplicate or foreign-subscription pause requests cannot silently alter delivery obligations. Failed requests preserve confirmed prior state. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** mealPauses linked to subscription and date/slot; obligations derive exclusions consistently.
- **Audit / privacy:** Audit pause acceptance/rejection reason, policy version and actor without exposing customer details.
- **Verification:** AC-008, TEST-008; not run.

## UC-009 — Order history

- **Requirement / actor / module:** FR-009 / Customer / orders.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-007 are satisfied; only authorized records are accessible.
- **Inputs and validation:** Authenticated customer and bounded page cursor; optional supported date/status filters must preserve ownership constraints.
- **Normal behavior:** Query own history; show newest relevant records and details; load additional pages without duplicate or missing stable records.
- **Outputs / postcondition:** History and details contain only that customer’s records and retained snapshots. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Changing a cursor or order ID cannot reveal another customer’s history. Empty history differs from loading failure. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** Read orders and authorized linked payment/bill summaries.
- **Audit / privacy:** Routine history reads do not require a personal-data audit trail.
- **Verification:** AC-009, TEST-009; not run.

## UC-010 — Delivery status tracking

- **Requirement / actor / module:** FR-010 / Customer / delivery.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-007; FR-020 are satisfied; only authorized records are accessible.
- **Inputs and validation:** Own order identity and current delivery state/version.
- **Normal behavior:** Open tracking; read authorized progress; update the timeline from committed delivery events; label stale/offline data.
- **Outputs / postcondition:** The customer sees that status and update time for the correct order. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Uncommitted local transitions or push-notification text cannot be treated as authoritative proof of delivery. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** Read own delivery summary and authorized events.
- **Audit / privacy:** State changes are audited under FR-020.
- **Verification:** AC-010, TEST-010; not run.

## UC-011 — Ratings and reviews

- **Requirement / actor / module:** FR-011 / Customer / reviews.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-007; FR-020 are satisfied; only authorized records are accessible.
- **Inputs and validation:** Own order ID, rating within approved scale and bounded review text.
- **Normal behavior:** Check eligibility; collect rating/comment; validate; persist review with customer and order linkage; show saved feedback.
- **Outputs / postcondition:** One valid rating/review is stored with the correct order and supplier. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Foreign, nonexistent or ineligible orders and duplicate attempts cannot create unauthorized or duplicated reviews. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** reviews associated with order and supplier; publication visibility depends on DEC-013.
- **Audit / privacy:** Audit moderation or administrative changes separately from the review author.
- **Verification:** AC-011, TEST-011; not run.

## UC-012 — Monthly bills and payment status

- **Requirement / actor / module:** FR-012 / Customer / billing.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-006; FR-007; FR-008; FR-013; DEC-003; DEC-005; DEC-007; DEC-008; policies BR-002, BR-003, BR-005 approved where applicable are satisfied; only authorized records are accessible.
- **Inputs and validation:** Own billing period and bill identity; monetary values use exact arithmetic after currency is confirmed.
- **Normal behavior:** Read authoritative bill version; present charge/adjustment provenance and payment allocations; show balance and status derived from verified records.
- **Outputs / postcondition:** Itemized bill totals and outstanding balance match that fixture exactly. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** A submitted payment reference alone cannot mark a bill paid. Stale calculations cannot silently overwrite a newer bill. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** bills, bill lines and linked verified payment allocations; preserve historical versions/adjustments.
- **Audit / privacy:** Audit bill generation, adjustments, verification and allocation changes.
- **Verification:** AC-012, TEST-012; not run.

## UC-013 — bKash/Nagad payment references

- **Requirement / actor / module:** FR-013 / Customer; designated verifier / payments.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-012; DEC-003; DEC-005; DEC-007; DEC-008; policies BR-002, BR-003, BR-005 approved where applicable are satisfied; only authorized records are accessible.
- **Inputs and validation:** Provider, reference, claimed amount, bill identity and permitted supporting fields; never request wallet PIN, OTP or credentials.
- **Normal behavior:** Submit evidence once; persist pending verification; authorized verifier checks external evidence and records reason/outcome; apply accepted allocation atomically.
- **Outputs / postcondition:** It appears pending and only a permitted verifier can apply a verified payment allocation. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Reference reuse, amount mismatch, unauthorized verification and cross-customer bill targeting cannot credit a bill. Mere reference format is not proof of payment. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** paymentReferences, verification outcome and allocations; precise deduplication key policy is DEC-005.
- **Audit / privacy:** Audit every submitted reference, verification decision and adjustment using restricted access.
- **Verification:** AC-013, TEST-013; not run.

## UC-014 — Supplier menus and packages

- **Requirement / actor / module:** FR-014 / Approved supplier/cook / catalog.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-021; DEC-003; DEC-008; policies BR-002 approved where applicable are satisfied; only authorized records are accessible.
- **Inputs and validation:** Supplier-owned items, package details, service dates and exact prices; required content and date associations must be valid.
- **Normal behavior:** Prepare or edit offering; validate; publish/update; customer catalog reflects committed published values. Existing order and subscription snapshots remain stable.
- **Outputs / postcondition:** Eligible customers can view the committed offerings without changing earlier purchases. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** A supplier cannot edit another supplier’s content, approve itself or rewrite prior order prices through catalog edits. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** foods, menus and plans with supplier ownership and publication/version state.
- **Audit / privacy:** Record publication, price and availability-relevant changes.
- **Verification:** AC-014, TEST-014; not run.

## UC-015 — Meal availability

- **Requirement / actor / module:** FR-015 / Approved supplier/cook / catalog.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-014 are satisfied; only authorized records are accessible.
- **Inputs and validation:** Own offering, availability state and current version.
- **Normal behavior:** Change availability; persist authoritative state; reflect in catalog; validate state again during order or subscription creation.
- **Outputs / postcondition:** New purchases are prevented after the authoritative change. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** A stale customer screen does not override unavailable state. Concurrent updates must not silently restore an older value. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** foods/plans availability and version metadata.
- **Audit / privacy:** Record supplier availability changes affecting accepted service.
- **Verification:** AC-015, TEST-015; not run.

## UC-016 — Subscriptions and daily cooking requirements

- **Requirement / actor / module:** FR-016 / Approved supplier/cook / fulfillment.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-006; FR-007; FR-008; FR-014; DEC-003; DEC-004; DEC-007; DEC-008; policies BR-001, BR-002, BR-005 approved where applicable are satisfied; only authorized records are accessible.
- **Inputs and validation:** Supplier identity and service date; approved obligation, pause and cancellation policies.
- **Normal behavior:** Read eligible obligations; resolve source links; group meal quantities; display totals and underlying orders/subscriptions with preparation relevance.
- **Outputs / postcondition:** Daily totals equal the approved eligible quantities exactly once. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Paused meals, duplicated generated orders or another supplier’s obligations cannot inflate counts. Recalculation after policy/state change is consistent. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** Derived daily demand from authoritative orders, subscriptions and pauses; any materialized totals must carry provenance/version.
- **Audit / privacy:** Audit changes affecting counts; do not log customer addresses in aggregate reports.
- **Verification:** AC-016, TEST-016; not run.

## UC-017 — Incoming orders and cooking status

- **Requirement / actor / module:** FR-017 / Approved supplier/cook / fulfillment.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-007; FR-016; DEC-014; policies BR-001, BR-004, BR-005 approved where applicable are satisfied; only authorized records are accessible.
- **Inputs and validation:** Own order identity, intended preparation transition and expected version.
- **Normal behavior:** Read incoming queue; open order; validate supplier and current state; commit allowed preparation transition; expose committed result to relevant customer/admin/courier views.
- **Outputs / postcondition:** The committed cooking state is visible to authorized participants. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** A supplier cannot alter another supplier’s orders, customer payment verification or courier-only delivery state. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** Order preparation state and immutable transition events.
- **Audit / privacy:** Record actor, prior/new state, server time and reason when required.
- **Verification:** AC-017, TEST-017; not run.

## UC-018 — Supplier earnings and payment history

- **Requirement / actor / module:** FR-018 / Approved supplier/cook / reporting.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-012; FR-013; DEC-003; DEC-005; DEC-007; policies BR-002, BR-003, BR-005 approved where applicable are satisfied; only authorized records are accessible.
- **Inputs and validation:** Supplier and reporting period; approved gross/net/fees/refunds/settlement definitions.
- **Normal behavior:** Read authorized transactions and adjustments; compute/report totals from the approved basis; expose supporting rows and pending verification separately.
- **Outputs / postcondition:** Supplier totals reconcile to the selected basis and pending items are distinguished. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Unverified references cannot be presented as settled supplier receipts. Another supplier’s totals or private payment details remain inaccessible. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** Derived financial view from bill/payment/order records; settlement records only if policy later requires them.
- **Audit / privacy:** Audit financial adjustments, not every aggregate screen refresh.
- **Verification:** AC-018, TEST-018; not run.

## UC-019 — Assigned delivery worklist

- **Requirement / actor / module:** FR-019 / Delivery personnel / delivery.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-007; FR-021; DEC-006; DEC-008; policies BR-004 approved where applicable are satisfied; only authorized records are accessible.
- **Inputs and validation:** Authenticated courier and active assignment; assignment creation/reassignment rules await DEC-006.
- **Normal behavior:** Load assigned worklist; show schedule and allowed delivery details; open a delivery; ensure current assignment still authorizes sensitive reads and updates.
- **Outputs / postcondition:** That delivery’s schedule and necessary address are visible. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** A courier cannot view an unassigned delivery or keep updating after reassignment. Notification payloads must not expose full addresses. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** deliveryAssignments and permitted order/address snapshots.
- **Audit / privacy:** Audit assignment and reassignment with actor and time.
- **Verification:** AC-019, TEST-019; not run.

## UC-020 — Delivery lifecycle updates

- **Requirement / actor / module:** FR-020 / Currently assigned delivery personnel / delivery.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-019; DEC-006; DEC-014; policies BR-004, BR-005 approved where applicable are satisfied; only authorized records are accessible.
- **Inputs and validation:** Delivery identity, intended next state, expected version and request ID.
- **Normal behavior:** Validate identity, assignment and permitted current-to-next transition; atomically commit state/event; make it available to customer/admin and notification processing.
- **Outputs / postcondition:** Exactly one ordered event per accepted transition is persisted. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Skipped/backward transitions, stale competing updates and unassigned actors cannot mutate delivery. Retrying a successful request returns its original result. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** Delivery state/version plus append-only authorized events.
- **Audit / privacy:** Record old/new state, assigned actor, request identity and server timestamp.
- **Verification:** AC-020, TEST-020; not run.

## UC-021 — Administration of users and providers

- **Requirement / actor / module:** FR-021 / Admin / administration.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-001; FR-003; DEC-009 are satisfied; only authorized records are accessible.
- **Inputs and validation:** Target user, permitted administrative action, reason and expected current state.
- **Normal behavior:** Read relevant account; validate administrator authority; confirm sensitive action; update authoritative access state and audit record; enforce new permissions on subsequent requests.
- **Outputs / postcondition:** Supplier access changes according to approved policy and an audit event is recorded. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Self-approval, customer role escalation and unauthorized role edits are denied. Destructive user deletion and historical record treatment require approved retention policy. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** users, supplier approval/account state and administrative audit events.
- **Audit / privacy:** Mandatory actor, target, action, prior/new state and server timestamp.
- **Verification:** AC-021, TEST-021; not run.

## UC-022 — Administrative order monitoring

- **Requirement / actor / module:** FR-022 / Admin / administration.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-007; FR-017; FR-020 are satisfied; only authorized records are accessible.
- **Inputs and validation:** Authorized admin, period/status criteria and page cursor.
- **Normal behavior:** Load bounded order list; distinguish statuses; inspect a relevant order and its permitted event history.
- **Outputs / postcondition:** The admin can inspect their committed progress and relevant history. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Non-admin access is denied; partial loads and stale results are shown explicitly. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** Read orders and authorized related events/payment summaries.
- **Audit / privacy:** Audit administrative corrective operations separately if later approved.
- **Verification:** AC-022, TEST-022; not run.

## UC-023 — Complaints and resolution

- **Requirement / actor / module:** FR-023 / Customer or affected user; Admin / complaints.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; DEC-013; DEC-010 are satisfied; only authorized records are accessible.
- **Inputs and validation:** Complaint text, optional authorized order reference and category; validate bounded text and ownership.
- **Normal behavior:** Submit complaint; persist identity/context; admin reviews and records outcome; reporter sees permitted status and resolution.
- **Outputs / postcondition:** It is tracked and an admin can record a visible authorized resolution. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** A reporter cannot impersonate another user, read another private complaint or set the administrative resolution. Resolution must not imply an unapproved refund. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** complaints and response/status events with restricted visibility.
- **Audit / privacy:** Record handler, state change, resolution and time; redact sensitive free text from logs.
- **Verification:** AC-023, TEST-023; not run.

## UC-024 — Administrative revenue reports

- **Requirement / actor / module:** FR-024 / Admin / reporting.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-012; FR-013; FR-018; DEC-003; DEC-005; DEC-007; DEC-008; policies BR-002, BR-003, BR-005 approved where applicable are satisfied; only authorized records are accessible.
- **Inputs and validation:** Reporting period, approved timezone and accounting basis.
- **Normal behavior:** Query authoritative financial records; calculate/report totals with provenance; show period, basis and freshness.
- **Outputs / postcondition:** The revenue report reconciles exactly to the documented basis. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Duplicate payment evidence, pending verification and unrelated supplier data cannot be wrongly counted as verified revenue. Non-admin users cannot run global reports. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** Derived view of orders, bill lines, payment allocations and adjustments.
- **Audit / privacy:** Audit changes to financial source records and report configuration.
- **Verification:** AC-024, TEST-024; not run.

## UC-025 — Notifications

- **Requirement / actor / module:** FR-025 / Authorized recipients; trusted sender / notifications.
- **Trigger and preconditions:** Actor initiates the named task; dependencies FR-003; FR-005; FR-007; FR-010; FR-012; DEC-011; policies BR-002, BR-004 approved where applicable are satisfied; only authorized records are accessible.
- **Inputs and validation:** Committed domain event, authorized recipient and safe message template; reminder schedule and recipients require DEC-015.
- **Normal behavior:** Derive event from committed source; select permitted recipients; send from trusted infrastructure; on open, reauthorize and load current source data.
- **Outputs / postcondition:** A relevant safe notification can be sent and opens authorized current data. The user sees acknowledged state or an explicit failure.
- **Exceptional paths:** Duplicate/out-of-order pushes, invalid tokens, permission denial or provider failure cannot duplicate business actions or override authoritative state. Network/service failure returns a recoverable state without fabricated success.
- **Persistence / state:** Restricted device-token association, notification event/deduplication metadata and source reference; retention subject to DEC-010.
- **Audit / privacy:** Record redacted delivery outcome/event ID; never log tokens, full address or payment references.
- **Verification:** AC-025, TEST-025; not run.

## UC-026 — Kitchen discovery, search and profile

- **Requirement / actor / module:** FR-026 / Guest, customer / MOD-CAT.
- **Trigger and preconditions:** Guest or customer opens kitchen discovery (legacy P-02, new NC-01/NC-02); no authentication required for browsing.
- **Inputs and validation:** Search text, cuisine/zone filters, availability filter; validated against the approved kitchen catalogue only.
- **Normal behavior:** `searchKitchens` returns verified, publicly listed kitchens with zone and availability; selecting a card opens its detail (NC-02) with operating hours, delivery slots and reviews; every kitchen card resolves to a working destination (fixes the legacy P-02 dead end).
- **Outputs / postcondition:** A valid kitchen profile and its current menu are shown; guest state is preserved for a protect-and-resume sign-in.
- **Exceptional paths:** Empty catalogue, unsupported zone, expired kitchen verification, slow image delivery; none exposes private customer, supplier or payout data.
- **Persistence / state:** `ent.Kitchen`, `ent.ServiceZone`, `ent.SlotAvailability` (read-only to guests).
- **Audit / privacy:** No audit needed for anonymous reads; rate-limit abusive search volume (NFR-022).
- **Verification:** AC-026, TEST-026; not run.

## UC-027 — Supplier menu, variant and price-version management

- **Requirement / actor / module:** FR-027 / Approved supplier / MOD-CAT.
- **Trigger and preconditions:** Verified supplier opens Menu & Stock (legacy S-04/S-05, new NS-06); supplier approval state is active.
- **Inputs and validation:** Meal name (EN/BN), price (positive integer minor units), portions, slot availability, allergen tags, effective date for a price change.
- **Normal behavior:** `saveMealVariant`/`schedulePriceChange` validate and store a new price version with an effective date; already-issued quotes keep their original price snapshot (ADR-009); capacity checks run before publishing availability.
- **Outputs / postcondition:** The new price/variant is visible to customers from its effective date; historical orders are unaffected.
- **Exceptional paths:** A price change cannot retroactively alter an existing quote, invoice or active subscription obligation; a supplier cannot edit another supplier's kitchen.
- **Persistence / state:** `ent.Meal`, `ent.MealVariant`, `ent.PriceVersion`.
- **Audit / privacy:** Audit price-version author and effective date.
- **Verification:** AC-027, TEST-027; not run.

## UC-028 — One-time order and checkout

- **Requirement / actor / module:** FR-028 / Customer / MOD-ORD.
- **Trigger and preconditions:** Authenticated customer selects a meal (legacy C-04/C-05/C-07/C-08, new NC-14); address and delivery zone resolved.
- **Inputs and validation:** Meal/variant, quantity, delivery address, slot, payment method (COD or online); stock reservation created with an expiry.
- **Normal behavior:** `createQuote` → `confirmQuote` → `placeOneTimeOrder`; online payment follows UC-033; COD follows UC-034; the one-kitchen-per-cart rule from the legacy prototype is enforced unless BR-021 approves multi-kitchen.
- **Outputs / postcondition:** Order created in `Pending` with a confirmed quote; stock reservation consumed.
- **Exceptional paths:** Meal sold out, cutoff passed, address outside the kitchen's zone, stale quotation, concurrent stock race (resolved per INV and SC-20).
- **Persistence / state:** `ent.Cart`, `ent.Quote`, `ent.Order`, `ent.OrderItem`, `ent.StockReservation`.
- **Audit / privacy:** Audit order creation and payment method chosen; no card data stored.
- **Verification:** AC-028, TEST-028; not run.

## UC-029 — Custom subscription builder

- **Requirement / actor / module:** FR-029 / Customer / MOD-SUB.
- **Trigger and preconditions:** Authenticated customer opens the subscription builder (new NC-04/NC-05/NC-06); kitchen selected.
- **Inputs and validation:** Per-date, per-slot meal selection; weekday recurrence with exceptions; start date and duration; delivery address and window.
- **Normal behavior:** `createSubscriptionDraft` → `saveSubscriptionSchedule` builds an agreement with versioned schedule; `generateMealObligations` (scheduled job) creates individual dated obligations; a full schedule preview is shown before checkout.
- **Outputs / postcondition:** A Draft subscription agreement with a generated obligation set, pending payment confirmation.
- **Exceptional paths:** Unsupported combination of slots/kitchen/zone is rejected with an explanation before payment, not silently discarded.
- **Persistence / state:** `ent.Subscription`, `ent.SubscriptionVersion`, `ent.SubscriptionSchedule`, `ent.MealObligation`.
- **Audit / privacy:** Audit schedule creation and later changes with version history.
- **Verification:** AC-029, TEST-029; not run.

## UC-030 — Server quotation and price snapshot

- **Requirement / actor / module:** FR-030 / Customer, BE / MOD-PRC.
- **Trigger and preconditions:** Any checkout or schedule-change step reaches a payable total (legacy C-08/C-12, new NC-08).
- **Inputs and validation:** Selected items/obligations, discount eligibility, delivery policy, applicable tax configuration (off until BR-018 approved), credit application request.
- **Normal behavior:** `createQuote` computes an immutable snapshot (food subtotal, discount, delivery fee, service fee, tax line, credit applied, final payable) with an expiry; the client never computes the total itself (NFR-017).
- **Outputs / postcondition:** A quote record the customer can confirm; expiry re-quotes if exceeded.
- **Exceptional paths:** Expired quote, promotion invalidated by expiry (BR-008), price changed since quote creation.
- **Persistence / state:** `ent.Quote`.
- **Audit / privacy:** Quote snapshots are retained for invoice reconciliation (INV-18).
- **Verification:** AC-030, TEST-030; not run.

## UC-031 — Skip, pause, replace, upgrade or downgrade a scheduled meal

- **Requirement / actor / module:** FR-031 / Customer / MOD-SUB.
- **Trigger and preconditions:** Customer selects an eligible future meal obligation (legacy C-14/C-15, new NC-09/NC-10) before its configured cutoff (BR-022).
- **Inputs and validation:** Obligation id, requested change type, target replacement meal if applicable.
- **Normal behavior:** `quoteScheduleChange` computes the adjustment (credit, debit, or no financial effect per BR-006/BR-017); `confirmScheduleChange` applies it exactly once, keyed by a stable idempotency key (fixes the legacy double-skip gap, SC-04).
- **Outputs / postcondition:** Obligation state updated; at most one credit or charge created per origin (INV-08).
- **Exceptional paths:** Cutoff passed, meal already dispatched (no change without an explicit exception policy), duplicate/lost-response retry.
- **Persistence / state:** `ent.MealObligation`, `ent.Adjustment`, `ent.CreditTransaction`.
- **Audit / privacy:** Audit every schedule change with its adjustment reference.
- **Verification:** AC-031, TEST-031; not run.

## UC-032 — Customer service credit balance and history

- **Requirement / actor / module:** FR-032 / Customer / MOD-CRD.
- **Trigger and preconditions:** Customer opens the credit ledger (new NC-11) or redeems credit at checkout (new NC-16).
- **Inputs and validation:** Available credit balance, redemption amount requested (≤ available).
- **Normal behavior:** `reserveCredit` then `consumeCredit` atomically reduce the available balance and reduce the payable amount on a quote; history lists every issuance, hold, use, reversal and remaining balance with its source.
- **Outputs / postcondition:** Credit balance never goes negative (INV-07); consumption is atomic and single-use per transaction.
- **Exceptional paths:** Attempted double redemption, redemption exceeding balance, redemption against a closed/cancelled order.
- **Persistence / state:** `ent.CreditAccount`, `ent.CreditTransaction`.
- **Audit / privacy:** Every credit transaction is immutable and auditable; credit is never shown as cash (glossary).
- **Verification:** AC-032, TEST-032; not run.

## UC-033 — Online payment through the gateway abstraction

- **Requirement / actor / module:** FR-033 / Customer, BE / MOD-PAY.
- **Trigger and preconditions:** Customer selects online payment at checkout (legacy C-08/C-09); gateway abstraction configured in sandbox only in this phase.
- **Inputs and validation:** Confirmed quote id, selected channel (as actually offered by the configured merchant account).
- **Normal behavior:** `initiatePayment` creates a `PaymentIntent`; customer is redirected to the hosted page; `handleGatewayNotification` (server-to-server IPN) and `validateGatewayTransaction` are the only operations that may mark a payment Verified — a browser redirect alone never does (SC-13).
- **Outputs / postcondition:** Order/subscription activates only after server-side verification; unknown status is shown honestly pending reconciliation.
- **Exceptional paths:** Duplicate/out-of-order IPN, amount mismatch, timeout, cancelled/failed payment, closed browser before redirect completes.
- **Persistence / state:** `ent.PaymentIntent`, `ent.PaymentAttempt`, `ent.GatewayEvent`, `ent.GatewayVerification`.
- **Audit / privacy:** No gateway secret or full card data ever stored or logged.
- **Verification:** AC-033, TEST-033; not run.

## UC-034 — COD collection and remittance

- **Requirement / actor / module:** FR-034 / Customer, rider, Accounts / MOD-COD.
- **Trigger and preconditions:** Order eligible for COD under BR-012 (legacy C-08 COD option, new NR-03/NR-04/NR-05, NF-03/NF-04).
- **Inputs and validation:** Exact amount tendered, delivery reference, deposit reference on remittance.
- **Normal behavior:** `recordCodCollection` on delivery → due-for-remittance liability on the rider → `submitCodRemittance` → `verifyCodRemittance` by Accounts closes the liability; collected cash is never added to rider earnings (glossary).
- **Outputs / postcondition:** COD receivable reduced only by a verified remittance; discrepancies raise `flagCodDiscrepancy`.
- **Exceptional paths:** Partial remittance, overdue remittance, duplicate deposit-reference submission (rejected, INV-12), amount mismatch (SC-09).
- **Persistence / state:** `ent.CodCollection`, `ent.CodRemittance`.
- **Audit / privacy:** Every collection and remittance step is individually audited.
- **Verification:** AC-034, TEST-034; not run.

## UC-035 — Billing schedules, invoices and receipts

- **Requirement / actor / module:** FR-035 / Customer, Accounts / MOD-PAY.
- **Trigger and preconditions:** A billing event occurs (checkout, weekly/monthly cycle per BR-002) (legacy C-20/C-21, new NC-12/NC-13).
- **Inputs and validation:** Billing cycle configuration, prior payments, credits.
- **Normal behavior:** An invoice is generated from the quote snapshot; a receipt is issued only after a verified payment; both reconcile to the ledger (INV-18).
- **Outputs / postcondition:** Customer sees an accurate, line-itemised invoice and payment history.
- **Exceptional paths:** Invoice requested before a receipt exists is not shown as paid; partial payment coverage is shown honestly.
- **Persistence / state:** `ent.Invoice`, `ent.Receipt`.
- **Audit / privacy:** Invoices are immutable once issued; corrections are adjustments, not edits.
- **Verification:** AC-035, TEST-035; not run.

## UC-036 — Supplier earning recognition and statement

- **Requirement / actor / module:** FR-036 / Supplier, Accounts / MOD-SET.
- **Trigger and preconditions:** A fulfilled meal obligation reaches the approved recognition event (BR-010) (legacy S-08, new NS-01).
- **Inputs and validation:** Order/obligation reference, recognition milestone evidence.
- **Normal behavior:** `recognizeSupplierEarning` posts a journal crediting the supplier payable and debiting the service-rendered/COGS-equivalent account; the supplier dashboard separates expected, earned, held, eligible and settled figures (glossary qualifiers).
- **Outputs / postcondition:** Supplier payable balance reflects only recognised, non-disputed earnings.
- **Exceptional paths:** Unfulfilled or disputed obligations never contribute to the payable balance; recognition is never duplicated for one obligation.
- **Persistence / state:** `ent.SupplierEarning`, ledger journals.
- **Audit / privacy:** Every recognition event is traceable to its source order/obligation.
- **Verification:** AC-036, TEST-036; not run.

## UC-037 — Rider assignment, delivery and per-delivery earning

- **Requirement / actor / module:** FR-037 / Rider, Admin / MOD-DLV.
- **Trigger and preconditions:** A delivery requires assignment (legacy R-10/R-01, new NR-01); rider eligible and on duty.
- **Inputs and validation:** Assignment offer, acceptance, pickup confirmation, proof of delivery (OTP or photo).
- **Normal behavior:** `offerAssignment` → `acceptAssignment` (conflict-checked so two riders cannot hold the same assignment) → `confirmPickup` → `submitDeliveryProof` → `recognizeRiderEarning` on verified completion; `reassignDelivery` reverses/prorates the original expected earning per policy, never paying twice (SC-08, UC workflow WF-J).
- **Outputs / postcondition:** Exactly one confirmed earning per completed delivery.
- **Exceptional paths:** Rider breakdown mid-delivery, simultaneous pickup race, customer absent (UC-047).
- **Persistence / state:** `ent.DeliveryAssignment`, `ent.DeliveryEvent`, `ent.DeliveryProof`, `ent.RiderEarning`.
- **Audit / privacy:** Reassignment is always a recorded, reasoned operation.
- **Verification:** AC-037, TEST-037; not run.

## UC-038 — Payout request, maker-checker approval and settlement

- **Requirement / actor / module:** FR-038 / Supplier, rider, Accounts / MOD-SET.
- **Trigger and preconditions:** Eligible payable balance exists (legacy S-09/R-08/A-13, new NS-02/NS-03, NR-02, NF-07/NF-08).
- **Inputs and validation:** Requested amount (≤ eligible balance), approved payout destination.
- **Normal behavior:** `requestPayout` → `reviewPayout` → `approvePayout` (by a different principal than the preparer, NFR-016) → `createPayoutBatch` → `releasePayoutBatch` → `recordPayoutResult` only after independently confirmed external transfer.
- **Outputs / postcondition:** Payout never marked Settled before external confirmation; request alone never implies payment.
- **Exceptional paths:** Requested amount exceeds eligible balance, beneficiary verification fails, external transfer fails (retry/compensation, not duplicate payout).
- **Persistence / state:** `ent.PayoutRequest`, `ent.PayoutApproval`, `ent.SettlementBatch`, `ent.PayoutResult`.
- **Audit / privacy:** Maker and checker identities are always distinct and recorded.
- **Verification:** AC-038, TEST-038; not run.

## UC-039 — Refund, dispute and chargeback handling

- **Requirement / actor / module:** FR-039 / Customer, Admin, Accounts / MOD-LED.
- **Trigger and preconditions:** A dispute, chargeback or refund-eligible cancellation arises (legacy A-05, new NF-10).
- **Inputs and validation:** Evidence, affected order/obligation, requested remedy.
- **Normal behavior:** `initiateRefund` and `recordRefundResult` are kept distinct from `issueCredit`; a refund and an equivalent credit are never both granted for the same obligation (INV-17).
- **Outputs / postcondition:** A balanced reversing or adjusting journal; transparent receipt to the customer.
- **Exceptional paths:** Partial fulfilment (SC-14), disputed chargeback loss allocation (BR-015, pending).
- **Persistence / state:** `ent.Refund`, `ent.Dispute`, `ent.Adjustment`.
- **Audit / privacy:** Every decision records the approving actor and evidence reference.
- **Verification:** AC-039, TEST-039; not run.

## UC-040 — General ledger, journal entries and period close

- **Requirement / actor / module:** FR-040 / Accounts / MOD-LED.
- **Trigger and preconditions:** Any money-moving command posts a journal; a period close is initiated (legacy A-12, new NF-11/NF-12).
- **Inputs and validation:** Journal lines (balanced, INV-01), period boundary, reconciliation checklist.
- **Normal behavior:** `postJournal` is internal-only (never a direct client command); `closePeriod` locks the period after required checks; a late event posts to the next open period with an adjusting reference (SC-15), never backdated.
- **Outputs / postcondition:** Posted journals are immutable (INV-02); period close is evidenced and reversible only through governed `reopenPeriod`.
- **Exceptional paths:** Attempted edit of a posted line is rejected; attempted post to a closed period is rejected.
- **Persistence / state:** `ent.LedgerAccount`, `ent.JournalEntry`, `ent.JournalLine`, `ent.AccountingPeriod`.
- **Audit / privacy:** Every journal carries its originating command and actor.
- **Verification:** AC-040, TEST-040; not run.

## UC-041 — Gateway and COD reconciliation

- **Requirement / actor / module:** FR-041 / Accounts / MOD-LED.
- **Trigger and preconditions:** Periodic or on-demand reconciliation run (legacy A-12, new NF-02/NF-03/NF-13/NF-17).
- **Inputs and validation:** Gateway settlement statement, COD remittance records, ledger clearing accounts.
- **Normal behavior:** Reconciliation compares operational events to ledger postings and raises `ent.ReconciliationException` for mismatches, never silently correcting them.
- **Outputs / postcondition:** Every exception is assigned, investigated and resolved with an audit trail; matched items close cleanly.
- **Exceptional paths:** Duplicate callback already reconciled, amount mismatch, unmatched transfer.
- **Persistence / state:** `ent.ReconciliationItem`, `ent.ReconciliationException`.
- **Audit / privacy:** Reconciliation actions are themselves audited.
- **Verification:** AC-041, TEST-041; not run.

## UC-042 — Financial reporting and export

- **Requirement / actor / module:** FR-042 / Accounts, Admin (limited) / MOD-RPT.
- **Trigger and preconditions:** An authorised Accounts or bounded-Admin user requests a report (legacy A-14, new NF-14).
- **Inputs and validation:** Report type, period, filters, requester role.
- **Normal behavior:** `exportReport` produces revenue, collection, payout, liability, settlement, reconciliation and adjustment reports with provenance (NFR-028) directly from posted ledger data.
- **Outputs / postcondition:** Export carries a traceable source query, timestamp and requesting role.
- **Exceptional paths:** Unauthorised role requests a report with restricted financial detail — denied, not filtered client-side.
- **Persistence / state:** Derived read model over ledger and operational stores.
- **Audit / privacy:** Every export is logged with requester and scope.
- **Verification:** AC-042, TEST-042; not run.

## UC-043 — Admin Web operations console

- **Requirement / actor / module:** FR-043 / Admin / MOD-ADM.
- **Trigger and preconditions:** Authenticated Admin staff opens the operations console (legacy A-01/A-02/A-03/A-04, new NA-01/NA-02/NA-03/NA-04).
- **Inputs and validation:** Zone configuration, policy version, incident data, dispatch decisions.
- **Normal behavior:** `publishPolicyVersion`, `decideApplication`, `reassignDelivery` (dispatch) are available; financial settlement commands are not (moved to Accounts, conflict register C-06).
- **Outputs / postcondition:** Operational decisions are recorded with an immutable audit reference.
- **Exceptional paths:** Stale incident data, conflicting concurrent edits, revoked staff role mid-session.
- **Persistence / state:** `ent.PolicyVersion`, `ent.AuditEvent`, operational read models.
- **Audit / privacy:** All administrative decisions audited; no direct balance or payout access.
- **Verification:** AC-043, TEST-043; not run.

## UC-044 — Staff accounts, finance roles and segregation of duties

- **Requirement / actor / module:** FR-044 / Admin, Accounts Manager / MOD-AUTH.
- **Trigger and preconditions:** A new staff or finance account is invited, approved, suspended or removed (new NF-15).
- **Inputs and validation:** Invited identity, role grant (Finance Viewer / Accounts Operator / Accounts Manager / Payout Approver / Financial Auditor / bounded Super Admin), approval limit.
- **Normal behavior:** `grantStaffRole`/`revokeStaffRole` enforce that a preparer role and an approver role are never granted to the same person for the same limit tier (BR-020).
- **Outputs / postcondition:** Role grants are auditable and immediately effective, including revocation of in-flight sessions (NFR-029).
- **Exceptional paths:** Attempted self-grant of an approver role, attempted grant exceeding the grantor's own authority.
- **Persistence / state:** `ent.StaffAccount`, `ent.RoleGrant`.
- **Audit / privacy:** Every grant and revocation is permanently audited.
- **Verification:** AC-044, TEST-044; not run.

## UC-045 — Partner onboarding, documents and corrections

- **Requirement / actor / module:** FR-045 / Supplier applicant, rider applicant, Admin / MOD-AUTH.
- **Trigger and preconditions:** An applicant submits a multi-step application (legacy AU-09/AU-10/AU-11).
- **Inputs and validation:** Kitchen or vehicle fields, identity documents, conditional fields (for example trade licence for a Restaurant/Cloud kitchen type).
- **Normal behavior:** `saveApplication`/`saveEvidence` persist a draft; `decideApplication` (approve / reject / request information with a named section) drives the applicant's status screen; the legacy admin-shortcut bypass (AU-11 → A-07) is removed.
- **Outputs / postcondition:** Approval grants the appropriate partner workspace access only after server-side decision, never from a client-selected role.
- **Exceptional paths:** Expired documents, under-18 rider applicant, missing conditional field.
- **Persistence / state:** `ent.Application`, `ent.ApplicationDocument`.
- **Audit / privacy:** Every decision records reviewer identity and reason.
- **Verification:** AC-045, TEST-045; not run.

## UC-046 — Kitchen capacity and stock reservation

- **Requirement / actor / module:** FR-046 / Supplier, BE / MOD-CAT.
- **Trigger and preconditions:** A customer attempts to order the last available portion of a meal (new NS-05, scenario SC-20).
- **Inputs and validation:** Requested quantity, current capacity/stock.
- **Normal behavior:** `reserveStock` atomically decrements available capacity with an expiry; `releaseStock` returns unconfirmed reservations; overselling is impossible by construction.
- **Outputs / postcondition:** At most the available quantity is ever sold; a payment that succeeds after a stock failure is safely refunded, never fulfilled as two orders.
- **Exceptional paths:** Two concurrent customers reserving the last unit; reservation expiry during a slow checkout.
- **Persistence / state:** `ent.StockReservation`, `ent.KitchenCapacity`.
- **Audit / privacy:** Reservation conflicts are logged for capacity-planning review.
- **Verification:** AC-046, TEST-046; not run.

## UC-047 — Delivery proof and failure exceptions

- **Requirement / actor / module:** FR-047 / Rider, customer / MOD-DLV.
- **Trigger and preconditions:** Rider arrives for delivery but the customer cannot be reached, or proof cannot be captured (legacy R-03, new NR-06, scenario SC-21).
- **Inputs and validation:** Proof method (OTP or photo), waiting-time policy, escalation evidence.
- **Normal behavior:** `submitDeliveryProof` on success; `reportDeliveryFailure` on failure, which does not earn the rider's completion compensation and does not mark the order Delivered.
- **Outputs / postcondition:** Failed delivery is a distinct, honestly recorded outcome, never silently merged into the four confirmed delivery states.
- **Exceptional paths:** Rider claims delivery without proof (rejected); customer disputes a claimed delivery.
- **Persistence / state:** `ent.DeliveryProof`, `ent.DeliveryEvent`.
- **Audit / privacy:** Privacy-preserving contact attempts (masked numbers) are logged with timestamps.
- **Verification:** AC-047, TEST-047; not run.

## UC-048 — Live tracking with location consent

- **Requirement / actor / module:** FR-048 / Customer, rider / MOD-DLV.
- **Trigger and preconditions:** Customer opens live tracking for an active delivery (legacy C-18/R-01 MiniMap).
- **Inputs and validation:** Rider location consent status, active assignment ownership.
- **Normal behavior:** `updateRiderLocation` is only visible to the customer of the currently assigned delivery, never to other customers or after reassignment/completion; the prototype's animated sample is explicitly distinguished from a real location feed.
- **Outputs / postcondition:** Location is shown only while an authorised viewing relationship exists.
- **Exceptional paths:** Location permission denied (GPS-lost state), rider reassigned mid-delivery (old customer loses access immediately).
- **Persistence / state:** `ent.RiderLocation` (short-retention).
- **Audit / privacy:** Location access is logged; raw location history is not retained beyond the active delivery.
- **Verification:** AC-048, TEST-048; not run.

## UC-049 — Cross-app localisation, theming and accessibility

- **Requirement / actor / module:** FR-049 / All roles / cross-cutting.
- **Trigger and preconditions:** Any user switches language, theme or device/band (legacy SH-05, scenario SC-18).
- **Inputs and validation:** Selected language (English/Bangla), theme (light/dark/system), device band.
- **Normal behavior:** In-progress form state, selected items, quantities and date context survive a language switch; text expands without clipping; touch targets and contrast remain within policy (NFR-003).
- **Outputs / postcondition:** Every user-visible string, including financial and legal text, renders correctly in both languages.
- **Exceptional paths:** Long Bangla strings, narrow compact-band device, assistive technology enabled.
- **Persistence / state:** UI preference state only; no business data.
- **Audit / privacy:** None required.
- **Verification:** AC-049, TEST-049; not run.

## UC-050 — Canonical time-zone and cutoff evaluation

- **Requirement / actor / module:** FR-050 / BE / MOD-POL.
- **Trigger and preconditions:** Any command that depends on a delivery date, slot or cutoff (all order/subscription commands), independent of device clock or time zone.
- **Inputs and validation:** Canonical UTC timestamp, Asia/Dhaka service date derivation, slot identifier (never a translated label), active policy version.
- **Normal behavior:** All cutoff and date comparisons are evaluated at the trusted boundary using the server's canonical clock, never the client's; a lunch obligation is never reinterpreted as a dinner obligation after a language or device-time-zone change.
- **Outputs / postcondition:** Consistent, policy-versioned cutoff decisions across every app and every device.
- **Exceptional paths:** Cross-midnight order placement, device clock set to a different time zone, daylight-neutral Bangladesh calendar edge cases, kitchen operating-hours change mid-cycle.
- **Persistence / state:** `ent.PolicyVersion` (cutoff parameters).
- **Audit / privacy:** Policy version changes are audited with effective date and publishing actor.
- **Verification:** AC-050, TEST-050; not run.

