# Acceptance criteria

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (supersedes 0.1 · 2026-10-28; original AC-001…025 kept unchanged) |
| Owner | Requirements and planning author |
| Purpose | Given/When/Then acceptance designs for all four applications, extending the original catalogue with AC-026…050 and provisional AC-BR006…AC-BR026 scenarios. |
| Applies to | CUS, PAR, ADM, ACC, BE |
| Depends on | [Use cases](USE_CASES.md), [business rules](BUSINESS_RULES.md), [policy decision register](POLICY_DECISION_REGISTER.md) |
| Status | Draft for review; none is evidence of implemented or executed behaviour. |

These are verification designs. None is evidence of implemented behavior. The positive scenario for a policy-dependent requirement is **provisional**, because “approved policy” is not yet a fulfilled precondition. Denial of unauthorized access, truthful pending-payment status and preservation of the confirmed four-state delivery sequence are engineering guardrails that must remain regardless of which business options are selected.

[BUSINESS_RULES](BUSINESS_RULES.md) defines detailed provisional AC-BR scenarios and blocks finalizing dependent calculations, cutoffs, authority assignments and schemas. TEST identifiers link to the future [test catalogue](../testing/TEST_CASES.md).

## AC-001 — Account registration and sessions

**Trace:** FR-001, UC-001, TEST-001.

- **Positive:** Given required authorization and a valid active account authenticates, when the actor completes the described operation, then its permitted dashboard opens and sign-out removes protected local view state.
- **Rejection / boundary:** Given a disabled or unauthenticated identity requests protected data, when the request is evaluated, then access is denied at the trusted boundary.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-002 — Profile management

**Trace:** FR-002, UC-002, TEST-002.

- **Positive:** Given required authorization and a user edits valid own contact details, when the actor completes the described operation, then the confirmed profile update appears without changing any role or existing order snapshot.
- **Rejection / boundary:** Given a user includes an admin role in a profile update, when the request is evaluated, then the complete unauthorized update is rejected.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-003 — Role-based authorization

**Trace:** FR-003, UC-003, TEST-003.

- **Positive:** Given required authorization and a courier requests an actively assigned delivery, when the actor completes the described operation, then only the fields required to complete that assignment are available.
- **Rejection / boundary:** Given a customer attempts a supplier, courier or admin write directly, when the request is evaluated, then the trusted boundary rejects it with no data mutation.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-004 — Browse meal plans

**Trace:** FR-004, UC-004, TEST-004.

- **Positive:** Given required authorization and published daily, weekly and monthly offerings exist, when the actor completes the described operation, then the customer can inspect each category and its price, dates and availability.
- **Rejection / boundary:** Given an offering is withdrawn after it was displayed, when the request is evaluated, then the subsequent purchase is rejected or requires a refreshed valid selection.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-005 — Daily and weekly menus

**Trace:** FR-005, UC-005, TEST-005.

- **Positive:** Given required authorization and a published menu exists for a selected week, when the actor completes the described operation, then its service dates and daily items are visible in Bangla and English UI.
- **Rejection / boundary:** Given a selected day has no published menu, when the request is evaluated, then a truthful empty state appears without inventing meals.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-006 — Monthly subscriptions

**Trace:** FR-006, UC-006, TEST-006; BR-001, BR-002, BR-005 (policy-dependent positive scenario is provisional).

- **Positive:** Given required authorization and an eligible customer selects an available monthly package under an approved policy, when the actor completes the described operation, then exactly one matching subscription is created and its interval and status are visible.
- **Rejection / boundary:** Given the same request is retried after a timeout, when the request is evaluated, then the original result is returned without a duplicate subscription.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-007 — Meal order placement

**Trace:** FR-007, UC-007, TEST-007; BR-002, BR-005 (policy-dependent positive scenario is provisional).

- **Positive:** Given required authorization and an eligible customer submits available meals, when the actor completes the described operation, then one order exists with server-validated total, service date and address snapshot.
- **Rejection / boundary:** Given the submitted total is tampered with or the same request is retried, when the request is evaluated, then the price is authoritatively validated and no duplicate order is created.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-008 — Pause selected meal dates

**Trace:** FR-008, UC-008, TEST-008; BR-001, BR-002, BR-005 (policy-dependent positive scenario is provisional).

- **Positive:** Given required authorization and a date is eligible under the approved pause policy, when the actor completes the described operation, then the accepted pause excludes only its intended meal obligation and applies the specified bill effect once.
- **Rejection / boundary:** Given the date is after the approved cutoff or belongs to another customer, when the request is evaluated, then the pause is rejected and cooking/billing obligations remain unchanged.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-009 — Order history

**Trace:** FR-009, UC-009, TEST-009.

- **Positive:** Given required authorization and a customer has multiple historical orders, when the actor completes the described operation, then history and details contain only that customer’s records and retained snapshots.
- **Rejection / boundary:** Given the customer requests another account’s order ID, when the request is evaluated, then the record is inaccessible.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-010 — Delivery status tracking

**Trace:** FR-010, UC-010, TEST-010.

- **Positive:** Given required authorization and a committed assigned-courier status change exists, when the actor completes the described operation, then the customer sees that status and update time for the correct order.
- **Rejection / boundary:** Given a stale notification arrives after a newer state, when the request is evaluated, then the current authoritative state is retained.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-011 — Ratings and reviews

**Trace:** FR-011, UC-011, TEST-011.

- **Positive:** Given required authorization and a delivered own order is eligible under the approved review policy, when the actor completes the described operation, then one valid rating/review is stored with the correct order and supplier.
- **Rejection / boundary:** Given a customer submits a review against another customer’s order, when the request is evaluated, then no review is created.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-012 — Monthly bills and payment status

**Trace:** FR-012, UC-012, TEST-012; BR-002, BR-003, BR-005 (policy-dependent positive scenario is provisional).

- **Positive:** Given required authorization and an approved billing fixture has known charges and verified payments, when the actor completes the described operation, then itemized bill totals and outstanding balance match that fixture exactly.
- **Rejection / boundary:** Given a customer submits an unverified payment reference, when the request is evaluated, then the bill remains unpaid or pending verification according to its verified balance.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-013 — bKash/Nagad payment references

**Trace:** FR-013, UC-013, TEST-013; BR-002, BR-003, BR-005 (policy-dependent positive scenario is provisional).

- **Positive:** Given required authorization and a valid own-bill reference is submitted, when the actor completes the described operation, then it appears pending and only a permitted verifier can apply a verified payment allocation.
- **Rejection / boundary:** Given a customer attempts to set verification state or reuse already allocated evidence, when the request is evaluated, then no unauthorized or duplicate financial credit occurs.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-014 — Supplier menus and packages

**Trace:** FR-014, UC-014, TEST-014; BR-002 (policy-dependent positive scenario is provisional).

- **Positive:** Given required authorization and an approved supplier publishes valid own menus and packages, when the actor completes the described operation, then eligible customers can view the committed offerings without changing earlier purchases.
- **Rejection / boundary:** Given the supplier targets another supplier’s item, when the request is evaluated, then the change is denied.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-015 — Meal availability

**Trace:** FR-015, UC-015, TEST-015.

- **Positive:** Given required authorization and a supplier marks an offering unavailable, when the actor completes the described operation, then new purchases are prevented after the authoritative change.
- **Rejection / boundary:** Given a customer purchases from an earlier available screen, when the request is evaluated, then the write fails safely and requests refreshed availability.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-016 — Subscriptions and daily cooking requirements

**Trace:** FR-016, UC-016, TEST-016; BR-001, BR-002, BR-005 (policy-dependent positive scenario is provisional).

- **Positive:** Given required authorization and fixtures include a subscription meal, one accepted pause and a direct order, when the actor completes the described operation, then daily totals equal the approved eligible quantities exactly once.
- **Rejection / boundary:** Given a generated order also references the already counted subscription obligation, when the request is evaluated, then the linked obligation is counted once.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-017 — Incoming orders and cooking status

**Trace:** FR-017, UC-017, TEST-017; BR-001, BR-004, BR-005 (policy-dependent positive scenario is provisional).

- **Positive:** Given required authorization and a supplier performs a legal transition for an own order, when the actor completes the described operation, then the committed cooking state is visible to authorized participants.
- **Rejection / boundary:** Given a supplier submits an invalid transition or foreign order, when the request is evaluated, then no unauthorized state change occurs.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-018 — Supplier earnings and payment history

**Trace:** FR-018, UC-018, TEST-018; BR-002, BR-003, BR-005 (policy-dependent positive scenario is provisional).

- **Positive:** Given required authorization and an approved financial fixture contains verified and pending records, when the actor completes the described operation, then supplier totals reconcile to the selected basis and pending items are distinguished.
- **Rejection / boundary:** Given a supplier tries to read another supplier’s report, when the request is evaluated, then the report is denied.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-019 — Assigned delivery worklist

**Trace:** FR-019, UC-019, TEST-019; BR-004 (policy-dependent positive scenario is provisional).

- **Positive:** Given required authorization and a courier has a current assignment, when the actor completes the described operation, then that delivery’s schedule and necessary address are visible.
- **Rejection / boundary:** Given the courier requests an unassigned or reassigned delivery, when the request is evaluated, then access to sensitive details and update operations is denied.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-020 — Delivery lifecycle updates

**Trace:** FR-020, UC-020, TEST-020; BR-004, BR-005 (policy-dependent positive scenario is provisional).

- **Positive:** Given required authorization and a currently assigned courier advances through each legal state, when the actor completes the described operation, then exactly one ordered event per accepted transition is persisted.
- **Rejection / boundary:** Given the courier attempts Pending directly to Delivered or a duplicate retry, when the request is evaluated, then the invalid jump is rejected and a retry creates no duplicate event.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-021 — Administration of users and providers

**Trace:** FR-021, UC-021, TEST-021.

- **Positive:** Given required authorization and an authorized admin approves a pending supplier, when the actor completes the described operation, then supplier access changes according to approved policy and an audit event is recorded.
- **Rejection / boundary:** Given a supplier or customer calls the same operation, when the request is evaluated, then the account state remains unchanged.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-022 — Administrative order monitoring

**Trace:** FR-022, UC-022, TEST-022.

- **Positive:** Given required authorization and orders span multiple service statuses, when the actor completes the described operation, then the admin can inspect their committed progress and relevant history.
- **Rejection / boundary:** Given a customer attempts the global monitoring query, when the request is evaluated, then the query is rejected.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-023 — Complaints and resolution

**Trace:** FR-023, UC-023, TEST-023.

- **Positive:** Given required authorization and an eligible reporter submits a valid complaint, when the actor completes the described operation, then it is tracked and an admin can record a visible authorized resolution.
- **Rejection / boundary:** Given the reporter attempts to resolve the complaint as admin, when the request is evaluated, then the mutation is denied.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-024 — Administrative revenue reports

**Trace:** FR-024, UC-024, TEST-024; BR-002, BR-003, BR-005 (policy-dependent positive scenario is provisional).

- **Positive:** Given required authorization and a fixed approved fixture includes payments, pending claims and adjustments, when the actor completes the described operation, then the revenue report reconciles exactly to the documented basis.
- **Rejection / boundary:** Given a pending reference or duplicate allocation is present, when the request is evaluated, then it does not inflate verified revenue.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-025 — Notifications

**Trace:** FR-025, UC-025, TEST-025; BR-002, BR-004 (policy-dependent positive scenario is provisional).

- **Positive:** Given required authorization and a committed event of each required type has a permitted recipient, when the actor completes the described operation, then a relevant safe notification can be sent and opens authorized current data.
- **Rejection / boundary:** Given delivery permission is denied or an old message is opened, when the request is evaluated, then core application access still works and protected or newer data remains authoritative.
- **Failure:** Given the authoritative service cannot acknowledge the operation, when the screen handles the failure, then it reports failure or pending confirmation accurately and does not fabricate a committed result.

## AC-026 — Kitchen discovery, search and profile

**Trace:** FR-026, UC-026, TEST-026.

- **Positive:** Given a verified kitchen with an active zone and availability, when a guest searches and opens its card, then the kitchen profile and its current menu open without requiring sign-in.
- **Rejection / boundary:** Given a kitchen outside the customer's service zone, when its card is opened, then the zone restriction is shown honestly rather than a working order path.
- **Failure:** Given the catalogue service cannot respond, when the screen handles the failure, then it shows a retry state, not an empty-looking success.

## AC-027 — Supplier menu, variant and price-version management

**Trace:** FR-027, UC-027, TEST-027.

- **Positive:** Given a verified supplier changes a meal's price with a future effective date, when an existing customer's order from before that date is viewed, then it still shows its original price snapshot.
- **Rejection / boundary:** Given a supplier attempts to edit another supplier's kitchen, when the request is evaluated, then it is rejected at the trusted boundary.
- **Failure:** Given the write cannot be acknowledged, when the screen handles the failure, then the draft is preserved and no partial price version is visible to customers.

## AC-028 — One-time order and checkout

**Trace:** FR-028, UC-028, TEST-028.

- **Positive:** Given an available meal and a valid delivery address, when a customer completes checkout with COD or a sandbox online payment, then exactly one order is created with its confirmed quote.
- **Rejection / boundary:** Given the meal sells out between quote and confirmation, when checkout is submitted, then the order is rejected with a clear reason and any payment attempt is not fulfilled against a sold-out item.
- **Failure:** Given the order service cannot acknowledge the request, when the screen handles the failure, then it reports failure/pending honestly and does not show a false success.

## AC-029 — Custom subscription builder

**Trace:** FR-029, UC-029, TEST-029.

- **Positive:** Given a customer selects different meals for different weekdays and slots, when the schedule is previewed and confirmed, then the generated obligations exactly match the selections, each at its correct price.
- **Rejection / boundary:** Given a selected combination is not permitted (for example, an unapproved cross-kitchen schedule under BR-021), when checkout is attempted, then the restriction is explained before payment, not after.
- **Failure:** Given obligation generation fails partway, when the screen handles the failure, then no partially generated schedule is shown as active.

## AC-030 — Server quotation and price snapshot

**Trace:** FR-030, UC-030, TEST-030.

- **Positive:** Given a selection of meals, discounts and a delivery policy, when a quote is requested, then its server-computed total exactly matches the later invoice, payment amount and ledger posting (INV-18).
- **Rejection / boundary:** Given a client sends a modified total, when the server processes the request, then the client-supplied total is ignored and the server snapshot is authoritative.
- **Failure:** Given the quote expires before confirmation, when checkout is attempted, then a fresh quote is required rather than honouring a stale price.

## AC-031 — Skip, pause, replace, upgrade or downgrade a scheduled meal

**Trace:** FR-031, UC-031, TEST-031; BR-006, BR-017 (policy-dependent positive scenario is provisional).

- **Positive:** Given an eligible future obligation before cutoff, when a skip is confirmed, then exactly one credit is created, referencing that obligation uniquely.
- **Rejection / boundary:** Given the same skip request is sent twice due to a lost response, when both arrive at the server, then only one credit is created and the client receives a stable receipt reference (SC-04).
- **Failure:** Given the obligation has already been dispatched, when a change is requested, then it is rejected unless an explicit exception policy permits it.

## AC-032 — Customer service credit balance and history

**Trace:** FR-032, UC-032, TEST-032; BR-006, BR-019, BR-025 (policy-dependent positive scenario is provisional).

- **Positive:** Given an available credit balance, when it is applied to a new order's quote, then the payable amount is reduced by exactly that amount and the balance is reduced atomically.
- **Rejection / boundary:** Given a redemption request exceeds the available balance, when it is evaluated, then it is rejected and the balance is never driven negative.
- **Failure:** Given the consumption command cannot be acknowledged, when the screen handles the failure, then the credit remains reserved, not lost or duplicated.

## AC-033 — Online payment through the gateway abstraction

**Trace:** FR-033, UC-033, TEST-033.

- **Positive:** Given a sandbox payment is initiated and the gateway sends a valid server-to-server notification, when the backend validates it, then the order/subscription activates only at that point, never at browser redirect.
- **Rejection / boundary:** Given a duplicate or out-of-order notification for the same transaction, when it is processed, then no second order activation or journal is created.
- **Failure:** Given the gateway returns an unknown status, when the screen handles it, then the customer sees an honest "awaiting confirmation" state, not a fabricated success or failure.

## AC-034 — COD collection and remittance

**Trace:** FR-034, UC-034, TEST-034; BR-012, BR-013, BR-026 (policy-dependent positive scenario is provisional).

- **Positive:** Given a rider collects the exact COD amount and later submits a remittance with a unique deposit reference, when Accounts verifies it, then the COD receivable closes exactly once.
- **Rejection / boundary:** Given the same deposit reference is submitted twice, when the second submission is processed, then it is rejected as a duplicate (INV-12).
- **Failure:** Given the collected amount does not match the invoiced amount, when the mismatch is reviewed, then the order is not marked fully paid and the discrepancy is routed for resolution (SC-09).

## AC-035 — Billing schedules, invoices and receipts

**Trace:** FR-035, UC-035, TEST-035; BR-002 (policy-dependent positive scenario is provisional).

- **Positive:** Given a verified payment against an invoice, when a receipt is generated, then its lines reconcile exactly to the recorded charges and payment.
- **Rejection / boundary:** Given no verified payment exists yet, when a receipt/PDF is requested, then none is produced; the invoice shows its true unpaid status.
- **Failure:** Given the billing service cannot respond, when the screen handles the failure, then cached, clearly labelled data is shown rather than a fabricated current balance.

## AC-036 — Supplier earning recognition and statement

**Trace:** FR-036, UC-036, TEST-036; BR-009, BR-010 (policy-dependent positive scenario is provisional).

- **Positive:** Given a delivery completes and meets the approved recognition event, when the supplier earning is recognised, then the supplier payable balance increases by exactly that amount, traceable to the source order.
- **Rejection / boundary:** Given an obligation is disputed or unfulfilled, when the supplier dashboard is viewed, then it is not counted in the earned/eligible balance.
- **Failure:** Given the recognition command is retried after a timeout, when it is processed, then it is not recognised twice for the same obligation.

## AC-037 — Rider assignment, delivery and per-delivery earning

**Trace:** FR-037, UC-037, TEST-037; BR-011 (policy-dependent positive scenario is provisional).

- **Positive:** Given a rider completes a verified delivery, when the earning is recognised, then exactly one confirmed earning entry exists for that delivery.
- **Rejection / boundary:** Given a delivery is reassigned after a breakdown, when both the original and replacement rider's state is checked, then only the replacement's completed delivery earns compensation (SC-08).
- **Failure:** Given two riders attempt pickup simultaneously, when the race is resolved, then only one assignment is confirmed and the other sees an honest "already taken" state.

## AC-038 — Payout request, maker-checker approval and settlement

**Trace:** FR-038, UC-038, TEST-038; BR-014, BR-020 (policy-dependent positive scenario is provisional).

- **Positive:** Given an eligible payable balance and an approved request, when a different principal approves and the batch is released, then the payout is marked Settled only after an independently confirmed external transfer.
- **Rejection / boundary:** Given the preparer and approver are the same principal, when approval is attempted, then it is rejected (NFR-016).
- **Failure:** Given the external transfer fails after approval, when the failure is processed, then the request returns to a reviewable state, not a lost or duplicated payout.

## AC-039 — Refund, dispute and chargeback handling

**Trace:** FR-039, UC-039, TEST-039; BR-005, BR-015, BR-025 (policy-dependent positive scenario is provisional).

- **Positive:** Given a partially fulfilled subscription is approved for a partial refund, when it is processed, then the refundable base is computed from unfulfilled obligations only and a balanced reversing journal is posted.
- **Rejection / boundary:** Given both a refund and an equivalent credit are requested for the same obligation, when the second is evaluated, then it is rejected as double compensation (INV-17).
- **Failure:** Given the gateway refund API is unavailable, when the screen handles it, then the refund remains in an honest pending state, not shown as completed.

## AC-040 — General ledger, journal entries and period close

**Trace:** FR-040, UC-040, TEST-040.

- **Positive:** Given a balanced journal is posted, when the ledger is queried, then debits equal credits exactly and the entry is immutable (INV-01, INV-02).
- **Rejection / boundary:** Given an attempt to edit a posted journal line directly, when it is evaluated, then it is rejected; only a reversing or adjusting entry is permitted.
- **Failure:** Given a late event arrives after period close, when it is processed, then it posts to the next open period with an adjusting reference, never backdated into the closed period.

## AC-041 — Gateway and COD reconciliation

**Trace:** FR-041, UC-041, TEST-041.

- **Positive:** Given matching gateway settlement and ledger clearing records, when reconciliation runs, then no exception is raised.
- **Rejection / boundary:** Given an unmatched transfer or duplicate callback, when reconciliation runs, then an exception is raised and assigned for review, never silently corrected.
- **Failure:** Given the gateway statement cannot be retrieved, when reconciliation is attempted, then it reports the gap honestly rather than assuming a match.

## AC-042 — Financial reporting and export

**Trace:** FR-042, UC-042, TEST-042.

- **Positive:** Given an authorised Accounts user requests a revenue report for a closed period, when it is generated, then every figure reconciles to posted journals with full provenance.
- **Rejection / boundary:** Given an unauthorised role requests the same report, when the request is evaluated, then it is denied at the trusted boundary, not merely hidden in the UI.
- **Failure:** Given the export service fails mid-generation, when the screen handles it, then no partial or misleading export file is produced.

## AC-043 — Admin Web operations console

**Trace:** FR-043, UC-043, TEST-043.

- **Positive:** Given an authorised Admin reassigns a delivery after an incident, when the reassignment is confirmed, then the operational state updates and no duplicate compensation results.
- **Rejection / boundary:** Given an Admin attempts a payout or journal-editing action, when it is evaluated, then it is rejected — that authority belongs to Accounts only.
- **Failure:** Given incident data is stale when acted on, when the action is submitted, then the system detects the staleness and requires a refresh rather than acting on outdated state.

## AC-044 — Staff accounts, finance roles and segregation of duties

**Trace:** FR-044, UC-044, TEST-044; BR-020 (policy-dependent positive scenario is provisional).

- **Positive:** Given a staff account is granted a bounded role, when it attempts an action within its limit, then the action succeeds and is audited.
- **Rejection / boundary:** Given the same account attempts to approve a payout it prepared, when the request is evaluated, then it is rejected (SC-16).
- **Failure:** Given a role grant command fails partway, when the screen handles it, then no partial or ambiguous role state is left active.

## AC-045 — Partner onboarding, documents and corrections

**Trace:** FR-045, UC-045, TEST-045.

- **Positive:** Given a complete, valid application, when it is approved, then the applicant gains access only to their approved workspace, never before a server decision.
- **Rejection / boundary:** Given an applicant attempts to reach a partner dashboard through a navigation shortcut before approval, when access is checked, then it is denied (fixes the legacy AU-11→A-07 shortcut).
- **Failure:** Given document upload fails mid-submission, when the screen handles it, then the draft is preserved for resubmission.

## AC-046 — Kitchen capacity and stock reservation

**Trace:** FR-046, UC-046, TEST-046.

- **Positive:** Given the last available unit of a meal, when two customers attempt to purchase it concurrently, then exactly one reservation succeeds and the other sees an honest sold-out state (SC-20).
- **Rejection / boundary:** Given a reservation expires before payment confirmation, when the customer retries, then a fresh reservation and quote are required.
- **Failure:** Given a payment succeeds after the stock failure was already reported, when this is detected, then a safe refund path is triggered, never a duplicate fulfilment.

## AC-047 — Delivery proof and failure exceptions

**Trace:** FR-047, UC-047, TEST-047; BR-011 (policy-dependent positive scenario is provisional).

- **Positive:** Given a rider captures valid delivery proof, when it is submitted, then the delivery is marked Delivered and the rider's earning is recognised.
- **Rejection / boundary:** Given the customer cannot be reached after the approved waiting period, when the rider reports the failure, then it is recorded as a distinct failed outcome, not as Delivered.
- **Failure:** Given the proof-capture step fails technically, when the screen handles it, then the delivery is not marked Delivered until proof is actually captured.

## AC-048 — Live tracking with location consent

**Trace:** FR-048, UC-048, TEST-048.

- **Positive:** Given an active delivery with a currently assigned rider, when the customer opens live tracking, then only that customer sees that rider's location for that delivery.
- **Rejection / boundary:** Given the delivery is reassigned, when the original customer's screen refreshes, then it no longer shows the previous rider's location.
- **Failure:** Given location permission is denied or unavailable, when the screen handles it, then it shows an honest GPS-unavailable state, never a simulated position presented as real.

## AC-049 — Cross-app localisation, theming and accessibility

**Trace:** FR-049, UC-049, TEST-049.

- **Positive:** Given a customer is mid-draft on a subscription schedule and switches from English to Bangla, when the screen re-renders, then all selections, quantities and dates are preserved and legible.
- **Rejection / boundary:** Given a long Bangla string on a compact-band device, when the screen renders, then no key action is clipped or hidden.
- **Failure:** Given a text-scaling or screen-reader setting is active, when a critical screen is used, then all actions remain operable and labelled.

## AC-050 — Canonical time-zone and cutoff evaluation

**Trace:** FR-050, UC-050, TEST-050; BR-022 (policy-dependent positive scenario is provisional).

- **Positive:** Given a cutoff policy and a request arriving just before, at and just after that cutoff in Asia/Dhaka time, when evaluated at the trusted boundary, then each result matches the approved rule regardless of the client's device time zone.
- **Rejection / boundary:** Given a customer's device clock is set to a different time zone, when a delivery date is displayed, then it still reflects the correct Asia/Dhaka service date, never a shifted one.
- **Failure:** Given the policy version changes mid-cycle, when an in-flight obligation is evaluated, then it uses the policy version that was active when it was created unless an explicit migration rule says otherwise.

## Provisional AC-BR006…AC-BR026 scenarios

Each row below is a provisional acceptance design for one of the extended business rules in [BUSINESS_RULES.md](BUSINESS_RULES.md) and [POLICY_DECISION_REGISTER.md](POLICY_DECISION_REGISTER.md). As with AC-BR001…AC-BR005, none of these can be finalised or executed until its linked decision is approved with exact values.

| ID | Given / When / Then | Approval dependency |
|---|---|---|
| AC-BR006-01 | Given an approved credit formula and an eligible skipped meal, when the skip is confirmed, then the credit amount matches the formula exactly and exactly one credit is created. | BR-006/DEC-016 |
| AC-BR007-01 | Given an approved delivery-fee policy and a mixed one-time/subscription order, when the fee is computed, then it matches the configured zone/trip rule exactly. | BR-007/DEC-017 |
| AC-BR008-01 | Given an approved discount and promotion-expiry rule, when a quote is created after the promotion's expiry, then the discount is excluded as specified. | BR-008/DEC-018 |
| AC-BR009-01 | Given an approved commission rate and a recognised supplier earning, when platform revenue is computed, then it equals the commission plus fees, never the gross customer collection. | BR-009/DEC-019 |
| AC-BR010-01 | Given an approved recognition event, when a delivery reaches that milestone, then the supplier earning is recognised at that moment and not before. | BR-010/DEC-020 |
| AC-BR011-01 | Given an approved rider compensation formula and a reassignment, when the original and replacement rider's earnings are computed, then only the completing rider is paid once. | BR-011/DEC-021 |
| AC-BR012-01 | Given approved COD eligibility limits, when an order exceeding the limit requests COD, then it is rejected with the configured reason. | BR-012/DEC-022 |
| AC-BR013-01 | Given an approved remittance deadline, when a rider's remittance is overdue, then the configured escalation state is shown. | BR-013/DEC-023 |
| AC-BR014-01 | Given an approved payout minimum and frequency, when a request below the minimum is submitted, then it is rejected with the configured reason. | BR-014/DEC-024 |
| AC-BR015-01 | Given an approved dispute-loss allocation rule, when a chargeback is resolved, then the loss is allocated exactly as configured. | BR-015/DEC-025 |
| AC-BR016-01 | Given an approved unpaid-subscription grace period, when it elapses without payment, then the configured suspension behaviour applies. | BR-016/DEC-026 |
| AC-BR017-01 | Given an approved substitution cutoff and price-difference rule, when a meal is replaced, then the price difference is charged or credited exactly once. | BR-017/DEC-027 |
| AC-BR018-01 | Given an approved tax configuration, when a quote is created, then the tax line matches the configured rate and version exactly. | BR-018/DEC-028 |
| AC-BR019-01 | Given an approved credit expiry period, when a credit exceeds that age, then it expires exactly as configured and not before. | BR-019/DEC-029 |
| AC-BR020-01 | Given an approved approval threshold, when an adjustment exceeds it, then dual approval is enforced with maker ≠ checker. | BR-020/DEC-030 |
| AC-BR021-01 | Given an approved multi-kitchen policy, when a customer attempts a cross-kitchen schedule, then the approved restriction or allowance applies consistently. | BR-021/DEC-031 |
| AC-BR022-01 | Given an approved cutoff-by-category policy, when different meal slots have different cutoffs, then each is evaluated independently and correctly. | BR-022/DEC-032 |
| AC-BR023-01 | Given an approved dual-role policy, when one identity holds both a supplier and a rider grant, then each workspace and balance remains independently authorised. | BR-023/DEC-033 |
| AC-BR024-01 | Given an approved kitchen-discontinuity policy, when a kitchen loses certification with active paid commitments, then the configured resolution path applies without erasing the commitments. | BR-024/DEC-034 |
| AC-BR025-01 | Given an approved legal determination on credit cash-out, when a customer requests cash for a credit balance, then only the approved behaviour (refusal or an approved cash-out path) is available. | BR-025/DEC-035 |
| AC-BR026-01 | Given an approved netting policy, when a rider has both an earned payable and an outstanding COD obligation, then netting occurs only if explicitly approved and recorded. | BR-026/DEC-036 |

## Requirements-phase exit criteria

The documentation handoff succeeds when all source features have stable identifiers, each maps to a use case and acceptance design, open decisions carry exact questions and owners, planned architecture/data/security/testing agree, and local document links and identifiers are validated. Business-policy approval and implementation acceptance remain separate gates. No numeric target in this package is a measured result.

