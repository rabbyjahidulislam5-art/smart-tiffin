# User stories

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (supersedes 0.1 · 2026-10-28; original US-001…025 kept unchanged) |
| Owner | Requirements and planning author |
| Purpose | Actor-level outcomes for all four applications, extending the original Android-only catalogue with the flexible subscription, credit, payment, partner-finance and Accounts stories. |
| Applies to | CUS, PAR, ADM, ACC |
| Depends on | [Functional requirements](FUNCTIONAL_REQUIREMENTS.md), [use cases](USE_CASES.md), [acceptance criteria](ACCEPTANCE_CRITERIA.md) |
| Status | Draft for review; no story is implemented. |

All stories retain the source proposal's first-release scope. They are intended outcomes awaiting implementation. Acceptance is in the matching AC and UC identifiers; [policy blockers](BUSINESS_RULES.md) and the [policy decision register](POLICY_DECISION_REGISTER.md) are explicit dependencies rather than invented defaults.

| Story | Actor and desired outcome | Benefit | Acceptance |
|---|---|---|---|
| US-001 | As all roles, I want account registration and sessions. | Identify users before granting access. | FR-001, UC-001, AC-001, TEST-001 |
| US-002 | As authenticated user, I want profile management. | Keep contact and delivery details usable. | FR-002, UC-002, AC-002, TEST-002 |
| US-003 | As all roles, I want role-based authorization. | Separate customer, supplier, courier and administrator responsibilities. | FR-003, UC-003, AC-003, TEST-003 |
| US-004 | As customer, I want browse meal plans. | Allow customers to compare daily, weekly and monthly offerings. | FR-004, UC-004, AC-004, TEST-004 |
| US-005 | As customer, I want daily and weekly menus. | Help customers know what meals are scheduled. | FR-005, UC-005, AC-005, TEST-005 |
| US-006 | As customer, I want monthly subscriptions. | Organize recurring meal commitments. | FR-006, UC-006, AC-006, TEST-006 |
| US-007 | As customer, I want meal order placement. | Capture meals and delivery details reliably. | FR-007, UC-007, AC-007, TEST-007 |
| US-008 | As customer, I want pause selected meal dates. | Exclude approved pauses from service obligations. | FR-008, UC-008, AC-008, TEST-008 |
| US-009 | As customer, I want order history. | Provide a reliable record of past and current meals. | FR-009, UC-009, AC-009, TEST-009 |
| US-010 | As customer, I want delivery status tracking. | Show progress without requiring live location tracking. | FR-010, UC-010, AC-010, TEST-010 |
| US-011 | As customer, I want ratings and reviews. | Collect feedback linked to real meal experiences. | FR-011, UC-011, AC-011, TEST-011 |
| US-012 | As customer, I want monthly bills and payment status. | Make amounts and payment evidence understandable. | FR-012, UC-012, AC-012, TEST-012 |
| US-013 | As customer; designated verifier, I want bkash/nagad payment references. | Record manual payment evidence without claiming gateway settlement. | FR-013, UC-013, AC-013, TEST-013 |
| US-014 | As approved supplier/cook, I want supplier menus and packages. | Give cooks ownership of their offered meals. | FR-014, UC-014, AC-014, TEST-014 |
| US-015 | As approved supplier/cook, I want meal availability. | Prevent acceptance of meals no longer offered. | FR-015, UC-015, AC-015, TEST-015 |
| US-016 | As approved supplier/cook, I want subscriptions and daily cooking requirements. | Turn orders and recurring commitments into actionable meal counts. | FR-016, UC-016, AC-016, TEST-016 |
| US-017 | As approved supplier/cook, I want incoming orders and cooking status. | Coordinate preparation with delivery readiness. | FR-017, UC-017, AC-017, TEST-017 |
| US-018 | As approved supplier/cook, I want supplier earnings and payment history. | Let suppliers understand earned and recorded payment amounts. | FR-018, UC-018, AC-018, TEST-018 |
| US-019 | As delivery personnel, I want assigned delivery worklist. | Give couriers the information needed for assigned service. | FR-019, UC-019, AC-019, TEST-019 |
| US-020 | As currently assigned delivery personnel, I want delivery lifecycle updates. | Maintain a shared trustworthy delivery timeline. | FR-020, UC-020, AC-020, TEST-020 |
| US-021 | As admin, I want administration of users and providers. | Control participation in the platform. | FR-021, UC-021, AC-021, TEST-021 |
| US-022 | As admin, I want administrative order monitoring. | Help administrators identify stalled service. | FR-022, UC-022, AC-022, TEST-022 |
| US-023 | As customer or affected user; admin, I want complaints and resolution. | Record service issues and handling outcomes. | FR-023, UC-023, AC-023, TEST-023 |
| US-024 | As admin, I want administrative revenue reports. | Provide interpretable platform-level financial reporting. | FR-024, UC-024, AC-024, TEST-024 |
| US-025 | As authorized recipients; trusted sender, I want notifications. | Inform users about relevant service events. | FR-025, UC-025, AC-025, TEST-025 |

## New stories (US-026…US-075)

| Story | Actor and desired outcome | Benefit | Acceptance |
|---|---|---|---|
| US-026 | As a guest or customer, I want to discover kitchens by cuisine, zone and verification status. | Find a trustworthy kitchen quickly. | FR-026, UC-026, AC-026, TEST-026 |
| US-027 | As a supplier, I want to manage meal variants, price versions and allergen information. | Keep the menu accurate and historically safe. | FR-027, UC-027, AC-027, TEST-027 |
| US-028 | As a customer, I want to order a single meal without committing to a subscription. | Try the service with no ongoing obligation. | FR-028, UC-028, AC-028, TEST-028 |
| US-029 | As a customer, I want to build a custom daily, weekly or monthly schedule with different meals on different days. | Match my real eating pattern instead of a fixed package. | FR-029, UC-029, AC-029, TEST-029 |
| US-030 | As a customer, I want a clear, itemised quote before I pay. | Know exactly what I am paying for and why. | FR-030, UC-030, AC-030, TEST-030 |
| US-031 | As a customer, I want to skip, pause, replace, upgrade or downgrade a future meal. | Adjust my plan without losing money unfairly. | FR-031, UC-031, AC-031, TEST-031 |
| US-032 | As a customer, I want a visible, non-cash service credit balance and history. | Trust that a skipped meal is accounted for. | FR-032, UC-032, AC-032, TEST-032 |
| US-033 | As a customer, I want to pay online through a trusted gateway. | Pay without manually proving a transaction. | FR-033, UC-033, AC-033, TEST-033 |
| US-034 | As a customer or rider, I want COD to work predictably, with clear limits and remittance handling. | Avoid confusion over who owes what. | FR-034, UC-034, AC-034, TEST-034 |
| US-035 | As a customer, I want billing schedules, invoices and receipts I can review later. | Keep a clear financial record. | FR-035, UC-035, AC-035, TEST-035 |
| US-036 | As a supplier, I want to see what I have actually earned, separate from what I might earn. | Avoid relying on money I have not yet earned. | FR-036, UC-036, AC-036, TEST-036 |
| US-037 | As a rider, I want delivery assignments and per-delivery earnings that are never duplicated on reassignment. | Be paid fairly without double payment risk. | FR-037, UC-037, AC-037, TEST-037 |
| US-038 | As a supplier or rider, I want to request a payout and track its approval. | Get paid through a trustworthy, auditable process. | FR-038, UC-038, AC-038, TEST-038 |
| US-039 | As a customer, I want disputes and refunds handled transparently. | Trust that problems are resolved fairly. | FR-039, UC-039, AC-039, TEST-039 |
| US-040 | As an Accounts Manager, I want a general ledger with reversible corrections and a period close. | Produce reliable financial statements. | FR-040, UC-040, AC-040, TEST-040 |
| US-041 | As an Accounts Operator, I want to reconcile gateway settlements and COD deposits against records. | Catch discrepancies before they become losses. | FR-041, UC-041, AC-041, TEST-041 |
| US-042 | As an Accounts Manager or bounded Admin, I want secured, exportable financial reports. | Report accurately to stakeholders. | FR-042, UC-042, AC-042, TEST-042 |
| US-043 | As an operations staff member, I want a desktop console for zones, policy configuration and incident dispatch. | Manage the platform efficiently on a real desktop. | FR-043, UC-043, AC-043, TEST-043 |
| US-044 | As an Admin or Accounts Manager, I want staff accounts and finance roles with segregation of duties. | Prevent one person from controlling money end to end. | FR-044, UC-044, AC-044, TEST-044 |
| US-045 | As a supplier or rider applicant, I want a clear, correctable application process. | Get approved without guessing what is wrong. | FR-045, UC-045, AC-045, TEST-045 |
| US-046 | As a supplier, I want capacity and stock limits enforced so I am never oversold. | Avoid promising meals I cannot cook. | FR-046, UC-046, AC-046, TEST-046 |
| US-047 | As a rider, I want a safe way to report a missing customer or failed delivery. | Resolve delivery problems without losing pay unfairly. | FR-047, UC-047, AC-047, TEST-047 |
| US-048 | As a customer, I want to see my delivery on a live map with a clear privacy boundary. | Know when my meal will arrive without feeling surveilled. | FR-048, UC-048, AC-048, TEST-048 |
| US-049 | As any user, I want the app fully usable in Bangla or English, on any supported device. | Use the service comfortably in my own language and device. | FR-049, UC-049, AC-049, TEST-049 |
| US-050 | As the platform, I want every cutoff and delivery date evaluated consistently regardless of device time zone. | Never deliver the wrong meal on the wrong day. | FR-050, UC-050, AC-050, TEST-050 |

Story splitting may create implementation tasks under a story, but must not remove the original outcome or silently defer a Must requirement. Cancellation and refund details remain open within BR-005 and BR-015; the new financial, subscription and partner stories remain open within BR-006…BR-026. No story is complete simply because this catalogue exists.

