# Functional requirements

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (supersedes 0.1 · 2026-10-28) |
| Owner | Requirements and planning author (documentation set) |
| Purpose | Specify all functional requirements of the four-application platform: FR-001…FR-025 retained and revised in place, FR-026…FR-050 added from the 2026-10-30 master prompt and prototype document. |
| Applies to | CUS, PAR-S, PAR-R, ADM, ACC, BE |
| Depends on | [Conventions and identifier register](../analysis/CONVENTIONS_AND_ID_REGISTER.md), [glossary](GLOSSARY_AND_TERMINOLOGY.md), [user roles](USER_ROLES.md), [business rules](BUSINESS_RULES.md), [policy decision register](POLICY_DECISION_REGISTER.md), [use cases](USE_CASES.md), [acceptance criteria](ACCEPTANCE_CRITERIA.md), [user stories](USER_STORIES.md), [complete screen inventory](../design/COMPLETE_SCREEN_INVENTORY.md), [API specification](../api/API_SPECIFICATION.md) |
| Authoritative policies | [BUSINESS_RULES.md](BUSINESS_RULES.md) (BR-001…BR-005) and [POLICY_DECISION_REGISTER.md](POLICY_DECISION_REGISTER.md) (BR-006…BR-026). This file never defines a policy value; it names the rule a behaviour depends on. |
| Status | Draft for review. Every requirement is Specified; none is implemented, and none has been tested. All BRs are PENDING. |

## 1. Reading this document

**Priority.** *Must* denotes scope priority for the requested product; it does not imply implementation, approval of an unresolved policy or a passed test. Blocking policies stop only the dependent behaviour (see the BR line of each requirement); independent modules proceed with configurable `policy.*` parameters that have no default value.

**Traceability convention.** FR-nnn maps to UC-nnn, AC-nnn, US-nnn and the planned TEST-nnn for every number 001…050 (for example FR-033 → UC-033 → AC-033 → US-033 → TEST-033). Workflow-level use cases UC-051 onward have their own AC and US numbers. This convention creates no execution evidence. The full chain (Requirement → Application → Module → Screen → Command → Entity → Business rule → Test → File) is in the [traceability matrix](REQUIREMENTS_TRACEABILITY_MATRIX.md), which is authoritative for the screen, command and entity columns if this file and the matrix differ.

**Provenance tags.** USER-REQ explicitly requested; OBSERVED seen in screenshots, the 94-screen React prototype (as reported by its documentation) or the current `app/`, `backend/`, `firebase/` files; PROPOSED engineering recommendation, not approved; PENDING an unresolved business or legal decision.

**Screens.** Legacy identifiers (P-, AU-, SH-, C-, S-, R-, A-, X-) are OBSERVED prototype registrations; identifiers beginning NC-, NS-, NR-, NA- and NF- are PROPOSED and are not confirmed routes. Shared screens (SH-nn) exist as one instance per application. The screen lists below are the primary mapping; the screen contract files are authoritative for behaviour.

**Commands.** Names follow the register: existing OBSERVED commands in `backend/functions/src/commands.js` are listed first; PROPOSED additions follow. Every command uses the envelope `{command, requestId, expectedVersion?, payload}` with an authenticated principal, role and ownership checks, an idempotency key, a canonical request fingerprint and an atomic receipt and audit event. Money-affecting commands also post balanced journals (ADR-006, ADR-008). Clients never write authoritative balances.

**Entities.** `ent.` names are PROPOSED canonical names (conventions section 8); stores are Firestore (FS) for operational data and a relational ledger store (PG) for finance, per the hybrid-datastore proposal (ADR-005).

## 2. Requirement index

| ID | Title | Module | Applications | Origin |
|---|---|---|---|---|
| FR-001 | Account registration and sessions | MOD-AUTH | CUS, PAR, ADM, ACC | Original, revised |
| FR-002 | Profile management | MOD-AUTH | all | Original, revised |
| FR-003 | Role-based authorization | MOD-AUTH | all | Original, revised |
| FR-004 | Browse meal plans | MOD-CAT | CUS | Original, revised |
| FR-005 | Daily and weekly menus | MOD-CAT | CUS | Original, revised |
| FR-006 | Monthly subscriptions | MOD-SUB | CUS | Original, generalised by FR-029 |
| FR-007 | Meal order placement | MOD-ORD | CUS | Original, revised |
| FR-008 | Pause selected meal dates | MOD-SUB | CUS | Original, revised |
| FR-009 | Order history | MOD-ORD | CUS | Original, revised |
| FR-010 | Delivery status tracking | MOD-DLV | CUS | Original, revised |
| FR-011 | Ratings and reviews | MOD-ORD | CUS | Original, revised |
| FR-012 | Monthly bills and payment status | MOD-PAY | CUS | Original, revised |
| FR-013 | bKash/Nagad payment references | MOD-PAY | CUS, ACC | Original, demoted to fallback |
| FR-014 | Supplier menus and packages | MOD-CAT | PAR-S | Original, revised |
| FR-015 | Meal availability | MOD-CAT | PAR-S | Original, revised |
| FR-016 | Subscriptions and daily cooking requirements | MOD-ORD | PAR-S | Original, revised |
| FR-017 | Incoming orders and cooking status | MOD-ORD | PAR-S | Original, revised |
| FR-018 | Supplier earnings and payment history | MOD-SET | PAR-S | Original, re-based on ledger |
| FR-019 | Assigned delivery worklist | MOD-DLV | PAR-R | Original, revised |
| FR-020 | Delivery lifecycle updates | MOD-DLV | PAR-R | Original, revised |
| FR-021 | Administration of users and providers | MOD-ADM | ADM | Original, split into FR-043/044/045 |
| FR-022 | Administrative order monitoring | MOD-ADM | ADM | Original, revised |
| FR-023 | Complaints and resolution | MOD-ADM | CUS, PAR, ADM | Original, revised |
| FR-024 | Administrative revenue reports | MOD-RPT | ADM, ACC | Original, re-based on ledger |
| FR-025 | Notifications | MOD-NOT | all | Original, revised |
| FR-026 | Kitchen discovery, search, filters and kitchen profile | MOD-CAT | CUS | New |
| FR-027 | Flexible meal, variant, price-version, allergen and slot-availability management by suppliers | MOD-CAT | PAR-S | New |
| FR-028 | One-time ordering and checkout without a subscription | MOD-ORD | CUS | New |
| FR-029 | Custom daily, weekly and monthly subscription builder, schedule preview and per-slot meal choice | MOD-SUB | CUS | New |
| FR-030 | Server quotation with immutable pricing snapshot, expiry and customer confirmation | MOD-PRC | CUS, BE | New |
| FR-031 | Subscription lifecycle and changes: skip, pause slot, resume, replace, upgrade or downgrade, cancel | MOD-SUB | CUS | New |
| FR-032 | Customer service credits: issue, reserve, consume, void, history (non-cash) | MOD-CRD | CUS, ACC | New |
| FR-033 | Online payment through the gateway abstraction (SSLCOMMERZ planned): initiate, server-validate, reconcile | MOD-PAY | CUS, BE, ACC | New |
| FR-034 | COD: eligibility, rider collection, remittance, verification, discrepancy handling | MOD-COD | CUS, PAR-R, ACC | New |
| FR-035 | Billing schedules, invoices, receipts and payment history | MOD-PAY | CUS, ACC | New |
| FR-036 | Supplier earnings: recognition events, balances, holds, statements | MOD-SET | PAR-S, ACC | New |
| FR-037 | Rider assignment, offer acceptance, earnings per delivery, reassignment without double payment | MOD-DLV | PAR-R, ADM | New |
| FR-038 | Payout requests, review, maker-checker approval, processing and external confirmation | MOD-SET | PAR, ACC | New |
| FR-039 | Refunds, disputes, chargebacks and adjustments | MOD-LED | CUS, ADM, ACC | New |
| FR-040 | General ledger (double-entry), journals, reversals and period close | MOD-LED | ACC | New |
| FR-041 | Reconciliation: gateway settlement, COD deposits, exceptions | MOD-LED | ACC | New |
| FR-042 | Finance reporting and secured export | MOD-RPT | ACC, ADM (limited) | New |
| FR-043 | Admin web operations: zones, policy configuration, incidents, dispatch, monitoring | MOD-ADM | ADM | New |
| FR-044 | Staff accounts, finance roles, segregation of duties, role-grant audit | MOD-AUTH | ADM, ACC | New |
| FR-045 | Partner onboarding: applications, documents, verification, corrections, expiry (extends FR-021) | MOD-AUTH | PAR, ADM | New |
| FR-046 | Kitchen capacity, stock reservation and oversell protection | MOD-CAT | PAR-S, BE | New |
| FR-047 | Delivery proof, missing customer and delivery exceptions | MOD-DLV | PAR-R, CUS | New |
| FR-048 | Live tracking and location consent, privacy-bounded | MOD-DLV | CUS, PAR-R | New |
| FR-049 | Localisation (English/Bangla), themes, responsive layouts and accessibility across apps | cross-cutting | all | New |
| FR-050 | Time zone, delivery date, slot identifiers and cutoff evaluation by trusted services | MOD-POL | BE, all | New |

## 3. Original requirements, retained and revised (FR-001…FR-025)

Revision principle: the intent of each requirement is kept; changes are limited to the four-application architecture, the ledger-backed finance model, the gateway position and the new identifiers. Every change is recorded in the [requirements change log](../analysis/REQUIREMENTS_CHANGE_LOG.md).

## FR-001 — Account registration and sessions

Support registration, sign-in, sign-out, recovery, session expiry and revoked-access handling for all five roles, using Firebase Authentication as the identity provider. Customers self-register; partner applicants register and then apply (FR-045); staff accounts are created only by invitation (FR-044). Phone verification uses a verified, expiring, rate-limited one-time code; a prototype shortcut that accepts any six digits is never carried forward. Web staff sessions require multi-factor authentication and an idle timeout (PROPOSED). Biometric unlock is a local convenience that never replaces server authentication.

- **Priority / module:** Must / MOD-AUTH.
- **Actors:** Guest, Customer, Supplier, Rider, Admin, Accounts sub-roles.
- **Applications:** CUS, PAR, ADM, ACC.
- **Business rules / decisions:** DEC-009 (providers, bootstrap, recovery, multi-role), BR-023 (dual-role). No BR defines credentials.
- **Preconditions:** Identity provider configured for the environment; account state readable at the trusted boundary.
- **Main behaviour:** Register or authenticate; establish identity; load the authoritative role grants and approval state; route to the permitted application and workspace; sign-out clears protected local view state and revokes the refresh token where supported.
- **Alternate / exceptions:** Invalid credentials, disabled or revoked identity, expired code, locked account, lost network and duplicate submit all fail without exposing protected data; recovery returns a generic acknowledgement and does not reveal whether an account exists. A visually selected account type never grants authorisation.
- **Screens:** AU-01…AU-08, AU-12 (CUS); AU-13 (staff secure sign-in, ADM and ACC instances); AU-11 (applicant status); SH-05 (sign-out).
- **Commands:** Provider sign-in flows (no command); `saveProfile`, `saveDevice` after sign-in; `grantStaffRole`, `revokeStaffRole` (FR-044).
- **Entities:** `ent.Principal`, `ent.Customer`, `ent.StaffAccount`, `ent.RoleGrant`, `ent.Device`.
- **Provenance:** USER-REQ (master prompt Phase 2 and authentication section); OBSERVED simulated auth in prototype AU-03, AU-05 (to be replaced).
- **Acceptance links:** AC-001, UC-001, US-001, TEST-001.
- **Status:** Specified; not implemented or executed.

## FR-002 — Profile management

Let users read and update their own name, phone, addresses, food preferences and notification preferences, and request identity-provider-controlled email changes where supported. Addresses are zone-validated and persisted (replacing the prototype's local-only addresses). Role and approval state are not editable profile fields. Sensitive changes for partners (payout owner, national identity, vehicle registration) require re-verification before taking effect.

- **Priority / module:** Must / MOD-AUTH.
- **Actors:** Any authenticated user.
- **Applications:** CUS, PAR, ADM, ACC.
- **Business rules / decisions:** DEC-010 (privacy, retention). BR-024 where a kitchen address change affects service zones.
- **Preconditions:** FR-001; FR-003.
- **Main behaviour:** Load own profile; edit permitted fields; validate; persist; show acknowledged values; keep a draft if saving fails; order and subscription address snapshots remain historically stable after later edits.
- **Alternate / exceptions:** A request that includes a role or approval field is rejected as a whole. An address outside every approved service zone is saved as an address but flagged as unserved at checkout (SC-19). A conflicting update returns a version conflict, not a silent overwrite.
- **Screens:** SH-08 (edit profile), C-02, C-03, C-23, C-24, SH-09; S-10; R-09; A-19.
- **Commands:** `saveProfile`, `saveAddress`, `savePreferences` (OBSERVED, working).
- **Entities:** `ent.Customer`, `ent.Supplier`, `ent.Rider`, `ent.StaffAccount`, `ent.Address`, `ent.ServiceZone`.
- **Provenance:** USER-REQ; OBSERVED prototype saves for C-02, C-03, C-24 are toasts only (known gap 16) and must become persisted.
- **Acceptance links:** AC-002, UC-002, US-002, TEST-002.
- **Status:** Specified; not implemented or executed.

## FR-003 — Role-based authorization

Enforce customer, supplier, rider, admin and accounts permissions, including Accounts sub-roles, at trusted data and operation boundaries in the backend. Application routing, navigation and visible controls use the same authoritative role and approval state but are never the enforcement point. Default deny for unknown roles. Admin and Super Admin have no implicit finance authority.

- **Priority / module:** Must / MOD-AUTH.
- **Actors:** All roles.
- **Applications:** CUS, PAR, ADM, ACC, BE.
- **Business rules / decisions:** DEC-009; BR-003, BR-004, BR-020, BR-023.
- **Preconditions:** FR-001; role grant records and claims present.
- **Main behaviour:** Resolve the subject's grants; validate role plus ownership or relationship (customer-to-record, supplier-to-kitchen, rider-to-active-assignment) and approval state for each read and write; return only fields required for the purpose.
- **Alternate / exceptions:** Unapproved suppliers, disabled accounts, cross-customer and cross-supplier records, unassigned rider records, wrong application for the role, and revoked grants are denied. Route guards alone are insufficient (known gap 20: the prototype had no role guard).
- **Screens:** AU-11, AU-12, AU-13, A-08, A-09, A-18, NF-15; every protected screen.
- **Commands:** All commands carry the check; `changeRole` (OBSERVED, policy-gated), `grantStaffRole`, `revokeStaffRole`, `suspendAccount`.
- **Entities:** `ent.Principal`, `ent.RoleGrant`, `ent.StaffAccount`, `ent.AuditEvent`.
- **Provenance:** USER-REQ; OBSERVED deny-by-default rules and policy-gated commands in the current code (not verified by this effort).
- **Acceptance links:** AC-003, AC-067, UC-003, US-003, TEST-003.
- **Status:** Specified; not implemented or executed.

## FR-004 — Browse meal plans

Display published plans (daily, weekly, monthly and custom-eligible templates) together with the kitchen, description, price, availability and relevant dates. Plans are kitchen-published templates the customer may adopt or customise; they are never a fixed package imposed on the customer. Guests may browse; a protected action preserves the selected kitchen, meal or plan and resumes it after sign-in.

- **Priority / module:** Must / MOD-CAT.
- **Actors:** Guest, Customer.
- **Applications:** CUS.
- **Business rules / decisions:** BR-002 (price basis); BR-021 (multi-kitchen); BR-024 (kitchen eligibility).
- **Preconditions:** FR-014, FR-015 supply published plans.
- **Main behaviour:** Load eligible offerings; show truthful price and availability; open a plan detail; route to ordering (FR-028) or to the subscription builder (FR-029).
- **Alternate / exceptions:** Unavailable, unpublished or unapproved-supplier offerings cannot be newly ordered; empty catalogue and failed load are distinguishable; expired offers and unsupported areas are explained. The prototype defect where plan and meal parameters from guest flows were ignored (known gap 2) is not carried forward.
- **Screens:** P-01, P-03, C-01, C-04, C-10, C-11, NC-01, NC-02.
- **Commands:** `searchKitchens` (read); `savePlan` (supplier side, OBSERVED).
- **Entities:** `ent.Plan`, `ent.Kitchen`, `ent.Meal`, `ent.PriceVersion`, `ent.SlotAvailability`.
- **Provenance:** USER-REQ; OBSERVED prototype P-03 plans use sample prices (never approved).
- **Acceptance links:** AC-004, UC-004, US-004, TEST-004.
- **Status:** Specified; not implemented or executed.

## FR-005 — Daily and weekly menus

Show daily and weekly menus linked to the responsible kitchen, per meal slot (breakfast, lunch, afternoon snack, dinner), including images, descriptions, variants, prices, allergens and dietary information, and distinguish published menus from missing or unavailable data.

- **Priority / module:** Must / MOD-CAT.
- **Actors:** Guest, Customer.
- **Applications:** CUS.
- **Business rules / decisions:** BR-022 (service dates, slots); DEC-008 time zone.
- **Preconditions:** FR-004; FR-014; FR-027.
- **Main behaviour:** Select a day or week and a kitchen; read published menu items by slot; show names (English and Bangla), prices, variants and availability; calendar dates evaluated in the approved service time zone.
- **Alternate / exceptions:** A failed network call never shows meals as available; stale or partial content is labelled and cannot override purchase-time validation; a day with no published menu shows a truthful empty state; a slot is always an identifier, never a translated label.
- **Screens:** P-02, C-04, C-05, C-06, NC-03, NC-02.
- **Commands:** `saveMenu` (supplier, OBSERVED); reads.
- **Entities:** `ent.Meal`, `ent.MealVariant`, `ent.SlotAvailability`, `ent.MealCategory`.
- **Provenance:** USER-REQ; OBSERVED.
- **Acceptance links:** AC-005, UC-005, US-005, TEST-005.
- **Status:** Specified; not implemented or executed.

## FR-006 — Monthly subscriptions

A monthly subscription is one billing-cycle case of the general subscription agreement defined by FR-029: customer, kitchen, plan snapshot, schedule rules, term, price terms, billing frequency and status, with the individual scheduled meals generated as meal obligations. Duration and billing frequency are independent settings. The effect of start date, duration, covered slots, billing and cancellation requires approved policies before the dependent behaviour is final.

- **Priority / module:** Must / MOD-SUB.
- **Actors:** Customer.
- **Applications:** CUS.
- **Business rules / decisions:** BR-001, BR-002, BR-005, BR-016, BR-021, BR-022; DEC-003, DEC-004, DEC-007, DEC-008.
- **Preconditions:** FR-003; FR-004; FR-029; FR-030.
- **Main behaviour:** Review the quote and schedule; confirm once; a trusted command creates the agreement (Pending Payment until payment or approved arrangement), its version and obligations; show acknowledgement.
- **Alternate / exceptions:** Invalid date ranges, unavailable plans, foreign customer identifiers and conflicting duplicate requests cannot create inconsistent subscriptions; a retry returns the original result.
- **Screens:** P-03, C-10, C-11, C-12, NC-04, NC-08, NC-13.
- **Commands:** `subscribe` (OBSERVED, policy-gated) superseded by `createSubscriptionDraft`, `saveSubscriptionSchedule`, `createQuote`, `confirmQuote`, `generateMealObligations`.
- **Entities:** `ent.Subscription`, `ent.SubscriptionVersion`, `ent.SubscriptionSchedule`, `ent.MealObligation`, `ent.Quote`, `ent.Invoice`.
- **Provenance:** USER-REQ (flexible subscriptions, no fixed package); PENDING policy values.
- **Acceptance links:** AC-006, UC-006, US-006, TEST-006.
- **Status:** Specified; not implemented or executed; dependent policy and schema provisional.

## FR-007 — Meal order placement

Place an order for available meals using an authoritative price snapshot, customer identity, service date and slot, delivery address and order state. Confirm only after the trusted write succeeds and, for online payment, only after server-side payment validation. FR-028 specifies the full one-time checkout; FR-007 is the foundational order write.

- **Priority / module:** Must / MOD-ORD.
- **Actors:** Customer.
- **Applications:** CUS.
- **Business rules / decisions:** BR-002, BR-005, BR-007, BR-012, BR-018, BR-022; DEC-003, DEC-007, DEC-008.
- **Preconditions:** FR-003; FR-004; FR-015; FR-030.
- **Main behaviour:** Review items and the confirmed quote; submit with a stable request identifier; validate availability, ownership, stock reservation and price; atomically create the order and obligations; return order identity.
- **Alternate / exceptions:** Client-supplied totals, another customer's identifier, unavailable items, invalid quantities and competing writes cannot produce an incorrect accepted order; a retry returns the original result.
- **Screens:** C-04, C-05, C-07, C-08, C-09, NC-14.
- **Commands:** `placeOrder` (OBSERVED, policy-gated) superseded by `placeOneTimeOrder`; `createQuote`, `confirmQuote`, `reserveStock`, `releaseStock`.
- **Entities:** `ent.Order`, `ent.OrderItem`, `ent.Quote`, `ent.StockReservation`, `ent.Address`.
- **Provenance:** USER-REQ; OBSERVED.
- **Acceptance links:** AC-007, UC-007, US-007, TEST-007.
- **Status:** Specified; not implemented or executed; dependent policy and schema provisional.

## FR-008 — Pause selected meal dates

Allow customers to request pauses for selected dates or slots in their own subscription. The cutoff, eligible slots, date range, reversal policy and financial effect are unresolved until BR-001 and the related billing decisions are supplied. FR-031 extends this requirement with skip, resume, replacement and cancellation; FR-050 defines how the cutoff is evaluated.

- **Priority / module:** Must / MOD-SUB.
- **Actors:** Customer.
- **Applications:** CUS.
- **Business rules / decisions:** BR-001, BR-002, BR-005, BR-006, BR-022; DEC-003, DEC-004, DEC-007, DEC-008.
- **Preconditions:** FR-006 or FR-029; FR-050.
- **Main behaviour:** Show eligible dates and the policy effect; submit; the trusted service evaluates the cutoff against authoritative time; accepted dates exclude only the intended meal obligation; the financial effect (credit, extension, none) applies exactly once as the approved rule dictates.
- **Alternate / exceptions:** Late, out-of-range, duplicate, overlapping or foreign-subscription requests do not alter delivery obligations; a failed request preserves prior state; a device clock never decides eligibility.
- **Screens:** C-01, C-10, C-13, C-14, NC-06, NC-09.
- **Commands:** `pauseMeals` (OBSERVED, policy-gated) superseded by `pauseSlots`, `skipMeals`, `resumeSubscription`.
- **Entities:** `ent.PauseRequest`, `ent.MealObligation`, `ent.Subscription`, `ent.Adjustment`, `ent.CreditTransaction`.
- **Provenance:** USER-REQ; PENDING (BR-001 values).
- **Acceptance links:** AC-008, UC-008, US-008, TEST-008.
- **Status:** Specified; not implemented or executed; dependent policy and schema provisional.

## FR-009 — Order history

List the customer's orders and subscription meal obligations with dates, item snapshots, totals, preparation and delivery state and payment state, with a bounded chronological result set, filters, and a detail view with invoice and receipt links.

- **Priority / module:** Must / MOD-ORD.
- **Actors:** Customer.
- **Applications:** CUS.
- **Business rules / decisions:** None directly; inherits visibility rules from DEC-010.
- **Preconditions:** FR-003; FR-007.
- **Main behaviour:** Query own history by cursor; show newest relevant records; open detail; move to tracking, invoice, review or complaint from the detail.
- **Alternate / exceptions:** Changing a cursor or an order identifier never reveals another customer's record; an empty history differs from a load failure; prototype status derived from the order identifier (OBSERVED) is replaced by real state.
- **Screens:** C-16, C-17, C-21, C-19, C-25, NC-15.
- **Commands:** Reads (bounded queries).
- **Entities:** `ent.Order`, `ent.OrderItem`, `ent.MealObligation`, `ent.Invoice`, `ent.Receipt`.
- **Provenance:** USER-REQ; OBSERVED.
- **Acceptance links:** AC-009, UC-009, US-009, TEST-009.
- **Status:** Specified; not implemented or executed.

## FR-010 — Delivery status tracking

Show the latest authoritative delivery state and its last update for the customer's order using the four confirmed states Pending, Picked Up, On The Way and Delivered. A failed or undeliverable outcome is an exception outcome, not a replacement for those four states (DEC-014). Status tracking is distinct from live location (FR-048).

- **Priority / module:** Must / MOD-DLV.
- **Actors:** Customer.
- **Applications:** CUS.
- **Business rules / decisions:** BR-004; DEC-014.
- **Preconditions:** FR-003; FR-007; FR-020.
- **Main behaviour:** Open tracking; read committed delivery events; update the timeline; label stale or offline data.
- **Alternate / exceptions:** Uncommitted local transitions or push text are never proof of delivery; a stale notification does not override a newer state.
- **Screens:** C-17, C-18, C-01.
- **Commands:** Reads of delivery events.
- **Entities:** `ent.DeliveryAssignment`, `ent.DeliveryEvent`.
- **Provenance:** USER-REQ; OBSERVED four-state chain.
- **Acceptance links:** AC-010, UC-010, US-010, TEST-010.
- **Status:** Specified; not implemented or executed.

## FR-011 — Ratings and reviews

Allow a customer to submit a rating and review tied to an eligible own order. Proposed eligibility is delivered orders with one review per order; scale, visibility, edits and moderation require DEC-013. The prototype's three-category star rating (OBSERVED, C-19) is a design reference only.

- **Priority / module:** Must / MOD-ORD.
- **Actors:** Customer; Admin (moderation, policy-gated).
- **Applications:** CUS, ADM.
- **Business rules / decisions:** DEC-013.
- **Preconditions:** FR-003; FR-007; FR-020.
- **Main behaviour:** Check eligibility; collect rating and comment; validate; persist with customer, order and kitchen linkage; show saved feedback; contribute to the kitchen profile when visibility rules allow (FR-026).
- **Alternate / exceptions:** Foreign, nonexistent or ineligible orders and duplicates create no review; prototype "not saved" behaviour (known gap 16) is replaced by persistence.
- **Screens:** C-19, C-17, C-05, C-06, NC-02.
- **Commands:** `submitReview` (OBSERVED, policy-gated).
- **Entities:** `ent.Review`, `ent.Order`, `ent.Kitchen`.
- **Provenance:** USER-REQ; PENDING DEC-013.
- **Acceptance links:** AC-011, UC-011, US-011, TEST-011.
- **Status:** Specified; not implemented or executed.

## FR-012 — Monthly bills and payment status

Display customer-specific bills and invoices for each billing cycle (weekly, monthly or per order) with itemized charges, credits and adjustments, total due, verified paid amount and payment status. FR-035 specifies billing schedules, invoices and receipts; FR-012 retains the customer-facing bill and status view. Calculation, period and allocation rules require BR-002.

- **Priority / module:** Must / MOD-PAY.
- **Actors:** Customer.
- **Applications:** CUS.
- **Business rules / decisions:** BR-002, BR-003, BR-005, BR-016, BR-018; DEC-003, DEC-005, DEC-007, DEC-008.
- **Preconditions:** FR-006; FR-007; FR-008; FR-035.
- **Main behaviour:** Read the authoritative invoice version; present charge and adjustment provenance and payment allocations; show balance and status derived only from verified records.
- **Alternate / exceptions:** A submitted payment reference or a browser redirect alone never marks a bill paid; stale calculations cannot overwrite a newer invoice; historical charges keep their accepted basis after catalogue price changes.
- **Screens:** C-20, C-21, NC-12, NC-13.
- **Commands:** Reads; `initiatePayment` (FR-033).
- **Entities:** `ent.Invoice`, `ent.Receipt`, `ent.PaymentIntent`, `ent.Adjustment`.
- **Provenance:** USER-REQ; PENDING BR-002.
- **Acceptance links:** AC-012, UC-012, US-012, TEST-012.
- **Status:** Specified; not implemented or executed; dependent policy and schema provisional.

## FR-013 — bKash/Nagad payment references

Retain bKash and Nagad payment-reference submission as an optional manual-evidence fallback for an own bill, shown as submitted, verified or rejected. It does not replace gateway payment (FR-033). A designated authorized verifier must independently verify evidence before paid amounts change; verifier identity, evidence and duplicate rules remain BR-003 and are unresolved. Wallet PINs, one-time codes and credentials are never collected.

- **Priority / module:** Must / MOD-PAY (fallback).
- **Actors:** Customer; designated verifier (PENDING).
- **Applications:** CUS, ACC (if BR-003 designates Accounts).
- **Business rules / decisions:** BR-002, BR-003, BR-005; DEC-003, DEC-005.
- **Preconditions:** FR-003; FR-012.
- **Main behaviour:** Submit evidence once; persist as pending; the verifier checks external evidence and records outcome and reason; an accepted allocation applies atomically and posts to the ledger as a verified collection.
- **Alternate / exceptions:** Reference reuse, amount mismatch, unauthorized verification and cross-customer bill targeting credit nothing; unavailable evidence stays pending, never auto-verified.
- **Screens:** C-22, C-12, C-20; verifier surface NF-02 (PROPOSED, only if BR-003 assigns Accounts).
- **Commands:** `submitPaymentReference`, `verifyPayment` (OBSERVED, policy-gated).
- **Entities:** `ent.PaymentIntent`, `ent.PaymentAttempt`, `ent.JournalEntry`. Where the manual verification decision is stored (a payment attempt of kind "manual evidence" or a dedicated record) is a database-design question for the data-model documents.
- **Provenance:** USER-REQ (original); demotion to fallback is PROPOSED; PENDING BR-003.
- **Acceptance links:** AC-013, UC-013, US-013, TEST-013.
- **Status:** Specified; not implemented or executed; dependent policy and schema provisional.

## FR-014 — Supplier menus and packages

Allow an approved supplier to create and update its kitchen profile, categories, foods, daily and weekly menus and plan templates, including names (English and Bangla), descriptions, images, schedules and valid prices. FR-027 specifies variants, price versions, allergens and slot availability. No kitchen, meal, price or subscription duration is hard-coded in business logic.

- **Priority / module:** Must / MOD-CAT.
- **Actors:** Approved supplier.
- **Applications:** PAR-S.
- **Business rules / decisions:** BR-002; BR-018 (tax display); DEC-003, DEC-008.
- **Preconditions:** FR-003; FR-045 (approved supplier); FR-027.
- **Main behaviour:** Prepare or edit an offering; validate; publish or schedule; the customer catalogue reflects committed published values; existing order and subscription snapshots remain unchanged.
- **Alternate / exceptions:** A supplier cannot edit another supplier's content, approve itself or rewrite prior prices; an expired hygiene or compliance document can block publishing under the approved policy (BR-024); prototype "not persisted" saves (known gap 13, 16) are replaced by durable writes.
- **Screens:** S-04, S-05, S-10, NS-06.
- **Commands:** `saveFood`, `savePlan`, `saveMenu` (OBSERVED, working); `saveKitchenProfile`, `saveMealVariant`, `schedulePriceChange`.
- **Entities:** `ent.Kitchen`, `ent.MealCategory`, `ent.Meal`, `ent.MealVariant`, `ent.PriceVersion`, `ent.Plan`.
- **Provenance:** USER-REQ; OBSERVED.
- **Acceptance links:** AC-014, UC-014, US-014, TEST-014.
- **Status:** Specified; not implemented or executed; dependent policy and schema provisional.

## FR-015 — Meal availability

Allow an approved supplier to update availability for its offerings, by meal, variant and slot, including a kitchen-level accepting-orders switch, and validate current availability during purchase. Quantity-based stock and capacity are specified by FR-046.

- **Priority / module:** Must / MOD-CAT.
- **Actors:** Approved supplier.
- **Applications:** PAR-S.
- **Business rules / decisions:** BR-022; BR-024.
- **Preconditions:** FR-003; FR-014.
- **Main behaviour:** Change availability; persist authoritative state with version; reflect in the catalogue; re-validate during quoting and ordering.
- **Alternate / exceptions:** A stale customer screen never overrides unavailability; concurrent updates cannot silently restore an older value; turning the kitchen offline with future commitments triggers the continuity workflow (BR-024, SC-07).
- **Screens:** S-01, S-04, S-12, NS-05.
- **Commands:** `setAvailability` (OBSERVED, working); `setSlotAvailability`.
- **Entities:** `ent.SlotAvailability`, `ent.Meal`, `ent.Kitchen`.
- **Provenance:** USER-REQ; OBSERVED.
- **Acceptance links:** AC-015, UC-015, US-015, TEST-015.
- **Status:** Specified; not implemented or executed.

## FR-016 — Subscriptions and daily cooking requirements

Show a supplier its subscription commitments and daily cooking requirements by service date, slot and meal or variant, combining generated subscription obligations and direct orders, excluding skips, pauses, replacements and cancellations, without double counting. Include forward commitments by date and a capacity view.

- **Priority / module:** Must / MOD-ORD.
- **Actors:** Approved supplier.
- **Applications:** PAR-S.
- **Business rules / decisions:** BR-001, BR-002, BR-005, BR-017; DEC-003, DEC-004, DEC-007, DEC-008.
- **Preconditions:** FR-006; FR-007; FR-008; FR-014; FR-029; FR-031.
- **Main behaviour:** Read eligible meal obligations for the supplier's kitchen; group quantities; display totals with underlying orders; show cancellation state per commitment.
- **Alternate / exceptions:** Paused, skipped or replaced obligations, duplicated generated orders, and another kitchen's obligations never inflate counts; recalculation after a change is consistent; customer address data is not shown in aggregate views.
- **Screens:** S-03, S-07, NS-04, S-01.
- **Commands:** `generateMealObligations` (scheduled job); reads.
- **Entities:** `ent.MealObligation`, `ent.SubscriptionSchedule`, `ent.Order`, `ent.KitchenCapacity`.
- **Provenance:** USER-REQ; OBSERVED S-03 and S-07 are static samples.
- **Acceptance links:** AC-016, UC-016, US-016, TEST-016.
- **Status:** Specified; not implemented or executed; dependent policy and schema provisional.

## FR-017 — Incoming orders and cooking status

Show incoming kitchen-owned orders and meal obligations and allow legal preparation updates. The observed prototype kitchen flow is Prepped, Preparing, Packed; the proposed backend preparation states are Pending, Preparing and Ready with a handoff step. Final transitions, refusal (decline with required reason) and handoff conditions require DEC-014. Preparation is a separate state dimension from delivery and payment.

- **Priority / module:** Must / MOD-ORD.
- **Actors:** Approved supplier.
- **Applications:** PAR-S.
- **Business rules / decisions:** BR-001, BR-004, BR-005; DEC-014.
- **Preconditions:** FR-003; FR-007; FR-016.
- **Main behaviour:** Read the incoming queue; accept or decline with a reason; advance preparation with the expected version; commit the transition and an immutable event; expose the result to the customer, admin and rider views; confirm readiness with a pickup code at rider handoff (FR-047 and NS-07).
- **Alternate / exceptions:** A supplier cannot alter another kitchen's orders, payment verification or rider-only delivery state; a decline never implies a refund outcome by itself; "Packed" requires confirmation.
- **Screens:** S-01, S-02, S-06, NS-07.
- **Commands:** `acceptOrder`, `declineOrder`, `advancePreparation` (OBSERVED, policy-gated); `recordHandoff`.
- **Entities:** `ent.Order`, `ent.MealObligation`, `ent.DeliveryEvent`, `ent.AuditEvent`.
- **Provenance:** USER-REQ; OBSERVED; PENDING DEC-014.
- **Acceptance links:** AC-017, UC-017, US-017, TEST-017.
- **Status:** Specified; not implemented or executed; dependent policy and schema provisional.

## FR-018 — Supplier earnings and payment history

Show supplier-scoped earnings and payment history that are ledger-backed: lifetime and today, per order and per subscription meal, pending, earned but unsettled, payout-eligible, disputed or held, completed payouts, with commission and adjustment breakdown. It distinguishes customer payments, supplier earnings and actual payouts. FR-036 specifies the earnings model; FR-038 the payout workflow.

- **Priority / module:** Must / MOD-SET.
- **Actors:** Approved supplier.
- **Applications:** PAR-S.
- **Business rules / decisions:** BR-002, BR-003, BR-005, BR-009, BR-010, BR-014.
- **Preconditions:** FR-003; FR-036.
- **Main behaviour:** Read the supplier's earning records and statements from the ledger-backed read model; each entry references its source obligation; pending items are shown separately.
- **Alternate / exceptions:** A supplier never sees another supplier's totals or private payment details; expected sales are not shown as withdrawable; sample figures from the prototype (S-08, S-09) are never displayed as real.
- **Screens:** S-08, S-09, NS-01, NS-03.
- **Commands:** Reads; `recognizeSupplierEarning` (system).
- **Entities:** `ent.SupplierEarning`, `ent.Hold`, `ent.PayoutRequest`, `ent.LedgerAccount`.
- **Provenance:** USER-REQ; OBSERVED S-08/S-09 static.
- **Acceptance links:** AC-018, UC-018, US-018, TEST-018.
- **Status:** Specified; not implemented or executed; dependent policy and schema provisional.

## FR-019 — Assigned delivery worklist

Show each rider's assigned deliveries and open offers with pickup and drop-off details, schedule, and necessary customer address information only for active assignments. Assignment method and authority remain BR-004. Live GPS is governed separately by FR-048.

- **Priority / module:** Must / MOD-DLV.
- **Actors:** Rider.
- **Applications:** PAR-R.
- **Business rules / decisions:** BR-004; DEC-006, DEC-008.
- **Preconditions:** FR-003; FR-007; FR-021 or FR-045 (approved rider); FR-037.
- **Main behaviour:** Load the assigned worklist; show schedule and allowed details; open a delivery; access is re-evaluated on every sensitive read.
- **Alternate / exceptions:** A rider cannot view an unassigned delivery or keep updating after reassignment; notification payloads omit full addresses; an off-duty rider receives no offers.
- **Screens:** R-01, R-06, R-10, R-02.
- **Commands:** `assignDelivery` (OBSERVED, policy-gated); `offerAssignment`, `acceptAssignment`.
- **Entities:** `ent.DeliveryAssignment`, `ent.Rider`, `ent.Order`, `ent.Address`.
- **Provenance:** USER-REQ; OBSERVED.
- **Acceptance links:** AC-019, UC-019, US-019, TEST-019.
- **Status:** Specified; not implemented or executed; dependent policy and schema provisional.

## FR-020 — Delivery lifecycle updates

Enforce the confirmed forward sequence Pending → Picked Up → On The Way → Delivered using authorized current assignments and committed state. Failed delivery, correction and reassignment are exception paths governed by FR-047, FR-037 and an approved policy, and never add a fifth delivery state.

- **Priority / module:** Must / MOD-DLV.
- **Actors:** Currently assigned rider.
- **Applications:** PAR-R.
- **Business rules / decisions:** BR-004, BR-005; DEC-006, DEC-014.
- **Preconditions:** FR-003; FR-019.
- **Main behaviour:** Validate identity, assignment and permitted transition; atomically commit state and an ordered event; make it available to the customer and admin views and to notification processing; Delivered requires proof (FR-047).
- **Alternate / exceptions:** Skipped or backward transitions, stale competing updates and unassigned actors cannot mutate delivery; a retry of a successful request returns the original result and creates no duplicate event.
- **Screens:** R-01, R-02, R-03, R-04.
- **Commands:** `advanceDelivery` (OBSERVED, policy-gated); `confirmPickup`, `submitDeliveryProof`.
- **Entities:** `ent.DeliveryAssignment`, `ent.DeliveryEvent`, `ent.DeliveryProof`.
- **Provenance:** USER-REQ (four states); OBSERVED.
- **Acceptance links:** AC-020, UC-020, US-020, TEST-020.
- **Status:** Specified; not implemented or executed; dependent policy and schema provisional.

## FR-021 — Administration of users and providers

Provide administrator functions to manage customers and partners, approve suppliers and riders, and suspend or reactivate accounts with explicit permissions and recorded outcomes. This requirement is retained as the umbrella; the details are specified by FR-043 (operations), FR-044 (staff and finance roles) and FR-045 (partner onboarding).

- **Priority / module:** Must / MOD-ADM.
- **Actors:** Admin.
- **Applications:** ADM.
- **Business rules / decisions:** DEC-009; BR-023; BR-024.
- **Preconditions:** FR-001; FR-003.
- **Main behaviour:** Read the account; validate admin authority; confirm sensitive action; update authoritative access state and write an audit event; enforce on subsequent requests.
- **Alternate / exceptions:** Self-approval, customer role escalation and unauthorized role edits are denied; deletion and treatment of historical records follow retention policy; prototype local-only suspend/reactivate (known gap) becomes a persisted, audited command.
- **Screens:** A-06, A-07, A-08, A-09, NA-03.
- **Commands:** `approveSupplier`, `changeRole` (OBSERVED, policy-gated); `decideApplication`, `suspendAccount`.
- **Entities:** `ent.Supplier`, `ent.Rider`, `ent.Application`, `ent.RoleGrant`, `ent.AuditEvent`.
- **Provenance:** USER-REQ; OBSERVED.
- **Acceptance links:** AC-021, UC-021, US-021, TEST-021.
- **Status:** Specified; not implemented or executed.

## FR-022 — Administrative order monitoring

Allow administrators to inspect orders, subscriptions and delivery state with bounded period and status queries and supporting detail, including late and disputed orders and fleet status. Monitoring does not grant an undefined ability to rewrite financial or delivery state. Financial detail is limited to the non-sensitive summary (NA-05).

- **Priority / module:** Must / MOD-ADM.
- **Actors:** Admin.
- **Applications:** ADM.
- **Business rules / decisions:** BR-004.
- **Preconditions:** FR-003; FR-007; FR-017; FR-020.
- **Main behaviour:** Load a bounded order list; distinguish preparation, delivery and payment states; open an order with its permitted event history.
- **Alternate / exceptions:** Non-admin access is denied; partial loads and stale results are shown explicitly; corrective operations, if later approved, are audited separately.
- **Screens:** A-10, A-11, A-01, NA-01.
- **Commands:** Reads.
- **Entities:** `ent.Order`, `ent.DeliveryEvent`, `ent.Invoice` (summary).
- **Provenance:** USER-REQ; OBSERVED.
- **Acceptance links:** AC-022, UC-022, US-022, TEST-022.
- **Status:** Specified; not implemented or executed.

## FR-023 — Complaints and resolution

Allow an affected user (customer, supplier or rider; eligible roles per DEC-013) to submit a complaint or report with appropriate service context and evidence, view its status and receive an administrative outcome; allow admin handling, with financial outcomes (credit, refund, adjustment) routed to the finance workflows of FR-039 rather than decided as one-tap money changes.

- **Priority / module:** Must / MOD-ADM.
- **Actors:** Customer or affected user; Admin.
- **Applications:** CUS, PAR, ADM.
- **Business rules / decisions:** DEC-013, DEC-010; BR-015; BR-005.
- **Preconditions:** FR-003.
- **Main behaviour:** Submit a complaint with category and optional own order reference; admin reviews and records the outcome; the reporter sees permitted status and resolution.
- **Alternate / exceptions:** A reporter cannot impersonate another user, read another private complaint or set the administrative resolution; a resolution never implies an unapproved refund; the prototype's static ticket status (SH-07) is replaced by real data.
- **Screens:** C-25, SH-06, SH-07, SH-04, A-02, A-03, A-05.
- **Commands:** `submitComplaint` (OBSERVED, working); `reportIncident` (OBSERVED, policy-gated).
- **Entities:** `ent.Complaint`, `ent.Ticket`, `ent.Dispute`, `ent.AuditEvent`.
- **Provenance:** USER-REQ; OBSERVED.
- **Acceptance links:** AC-023, UC-023, US-023, TEST-023.
- **Status:** Specified; not implemented or executed.

## FR-024 — Administrative revenue reports

Show revenue and operational reports for a selected period. Revenue is platform revenue recognised in the ledger (commission and fees), never gross customer collections. Admin sees operational reports and a limited financial overview; detailed financial reports are FR-042 in Accounts Web. Verified receipts, outstanding amounts and adjustments are separated.

- **Priority / module:** Must / MOD-RPT.
- **Actors:** Admin; Accounts (detailed).
- **Applications:** ADM, ACC.
- **Business rules / decisions:** BR-002, BR-003, BR-005, BR-009, BR-018; DEC-003, DEC-005, DEC-007, DEC-008.
- **Preconditions:** FR-003; FR-012; FR-018; FR-040; FR-042.
- **Main behaviour:** Query authoritative records and ledger aggregates; show period, basis, policy version and freshness; every total is derivable from posted journals (INV-20).
- **Alternate / exceptions:** Pending references, duplicate allocations and unrelated supplier data are never counted as verified revenue; non-admin users cannot run global reports; exports are redacted and guarded against spreadsheet formula injection.
- **Screens:** A-14, A-01, A-12 (reclassified as limited overview), NA-05, NA-06, NF-14.
- **Commands:** `exportRecords` (OBSERVED, policy-gated); `exportReport`.
- **Entities:** `ent.JournalEntry`, `ent.JournalLine`, `ent.Invoice`, `ent.AuditEvent`.
- **Provenance:** USER-REQ; OBSERVED A-14 static.
- **Acceptance links:** AC-024, UC-024, US-024, TEST-024.
- **Status:** Specified; not implemented or executed; dependent policy and schema provisional.

## FR-025 — Notifications

Provide order confirmations, delivery updates, menu updates, payment reminders and the new workflow events (credit issued, payout status, remittance due, application decision) through Firebase Cloud Messaging and an in-app notification centre, plus email where later approved. Notifications are generated from committed events through an outbox; the in-app record and the business record remain authoritative; denial of notification permission never blocks core journeys. Essential notifications cannot be disabled; optional ones can.

- **Priority / module:** Must / MOD-NOT.
- **Actors:** Authorized recipients; trusted sender.
- **Applications:** CUS, PAR, ADM, ACC, BE.
- **Business rules / decisions:** DEC-011, DEC-015; BR-002, BR-004.
- **Preconditions:** FR-003; FR-005; FR-007; FR-010; FR-012.
- **Main behaviour:** Derive an event from a committed source; select permitted recipients; send from trusted infrastructure with a minimal payload; on open, re-authorize and load current data; mark read and deep-link to the correct destination per role.
- **Alternate / exceptions:** Duplicate, out-of-order or stale pushes, invalid tokens, permission denial and provider failure cannot duplicate business actions or override authoritative state; payloads contain no full address, payment reference, code or password.
- **Screens:** SH-01, SH-09, SH-10 (per-application instances).
- **Commands:** `saveDevice`, `savePreferences` (OBSERVED, working); outbox delivery is internal.
- **Entities:** `ent.Notification`, `ent.Device`, `ent.OutboxEvent`, `ent.Setting`.
- **Provenance:** USER-REQ; OBSERVED SH-10 email history with Queued/Accepted/Delivered/Failed.
- **Acceptance links:** AC-025, UC-025, US-025, TEST-025.
- **Status:** Specified; not implemented or executed; dependent policy and schema provisional.

## 4. New requirements (FR-026…FR-050)

These requirements arise from the 2026-10-30 master prompt and the 94-screen prototype document. Unless stated otherwise their behaviour is USER-REQ in intent and PROPOSED in detail, and every policy value is PENDING.

## FR-026 — Kitchen discovery, search and profile

Let guests and customers search kitchens by cuisine, zone, verification status and availability, and open a working profile and menu from every result (fixing the legacy P-02 dead end).

- **Priority / module:** Must / MOD-CAT.
- **Actors:** Guest, Customer.
- **Applications:** CUS.
- **Business rules / decisions:** None blocking; BR-021 affects multi-kitchen scheduling downstream.
- **Preconditions:** Published, approved kitchen catalogue.
- **Main behaviour:** `searchKitchens` returns verified, zone-eligible kitchens; selecting a result opens NC-02 with menu, hours, slots and reviews.
- **Alternate / exceptions:** Empty catalogue, unsupported zone, expired verification, slow images; none exposes private data.
- **Screens:** P-02, NC-01, NC-02, NC-03.
- **Commands:** `searchKitchens` (PROPOSED, read).
- **Entities:** `ent.Kitchen`, `ent.ServiceZone`, `ent.SlotAvailability`.
- **Provenance:** USER-REQ; OBSERVED legacy P-02 non-clickable-card defect, explicitly fixed.
- **Acceptance links:** AC-026, UC-026, US-026, TEST-026.
- **Status:** Specified; not implemented.

## FR-027 — Supplier menu, variant and price-version management

Let an approved supplier manage meal categories, variants, portion sizes, photographs, allergen tags and price versions with effective dates, never altering an already-issued quote's price.

- **Priority / module:** Must / MOD-CAT.
- **Actors:** Approved Supplier.
- **Applications:** PAR-Supplier.
- **Business rules / decisions:** None blocking.
- **Preconditions:** Supplier approved (FR-045).
- **Main behaviour:** `saveMealVariant` and `schedulePriceChange` create a new `ent.PriceVersion` with an effective date; historical quotes keep their original snapshot.
- **Alternate / exceptions:** Invalid price (non-integer/negative) rejected; a supplier cannot edit another kitchen's catalogue.
- **Screens:** S-04, S-05, NS-06.
- **Commands:** `saveFood` (OBSERVED), `saveMealVariant`, `schedulePriceChange` (PROPOSED).
- **Entities:** `ent.Meal`, `ent.MealVariant`, `ent.PriceVersion`.
- **Provenance:** USER-REQ; OBSERVED legacy `saveFood` has no price field (gap closed by `saveMealVariant`).
- **Acceptance links:** AC-027, UC-027, US-027, TEST-027.
- **Status:** Specified; not implemented.

## FR-028 — One-time order and checkout

Let a customer buy a single meal or several meals for one delivery without a subscription, with COD or sandbox online payment.

- **Priority / module:** Must / MOD-ORD.
- **Actors:** Customer.
- **Applications:** CUS.
- **Business rules / decisions:** BR-012 (COD eligibility).
- **Preconditions:** Address validated, stock available.
- **Main behaviour:** `createQuote` → `confirmQuote` (reserves stock) → `placeOneTimeOrder`.
- **Alternate / exceptions:** Stock race (SC-20); out-of-zone address rejected before payment.
- **Screens:** C-07, C-08, NC-14.
- **Commands:** `createQuote`, `confirmQuote`, `placeOneTimeOrder` (PROPOSED); `placeOrder` kept as legacy alias.
- **Entities:** `ent.Quote`, `ent.Order`, `ent.OrderItem`, `ent.StockReservation`.
- **Provenance:** USER-REQ; OBSERVED legacy C-07/C-08 cart and checkout, now backed by a real quote.
- **Acceptance links:** AC-028, UC-028, US-028, TEST-028.
- **Status:** Specified; not implemented.

## FR-029 — Custom daily/weekly/monthly subscription builder

Let a customer build a fully custom schedule with different meals on different days and slots, or choose a daily/weekly/monthly template, never a fixed package.

- **Priority / module:** Must / MOD-SUB.
- **Actors:** Customer.
- **Applications:** CUS.
- **Business rules / decisions:** BR-001, BR-021, BR-022.
- **Preconditions:** Kitchen selected.
- **Main behaviour:** `createSubscriptionDraft` → `saveSubscriptionSchedule` (recurrence + exceptions) → `generateMealObligations` (scheduled job).
- **Alternate / exceptions:** Unsupported combination (e.g. unapproved multi-kitchen) explained before payment, never silently dropped.
- **Screens:** C-10, C-11, NC-04, NC-05, NC-06.
- **Commands:** `createSubscriptionDraft`, `saveSubscriptionSchedule`, `generateMealObligations` (PROPOSED); `subscribe` kept as legacy alias.
- **Entities:** `ent.Subscription`, `ent.SubscriptionVersion`, `ent.SubscriptionSchedule`, `ent.MealObligation`.
- **Provenance:** USER-REQ; OBSERVED legacy C-10/C-11 hard-coded single plan default, explicitly fixed (conflict register C-09).
- **Acceptance links:** AC-029, UC-029, US-029, TEST-029.
- **Status:** Specified; not implemented.

## FR-030 — Server quotation and immutable price snapshot

Compute every payable total on the server as an immutable, expiring snapshot that every downstream document (invoice, payment, journal, credit statement) traces to.

- **Priority / module:** Must / MOD-PRC.
- **Actors:** Customer, BE.
- **Applications:** CUS, BE.
- **Business rules / decisions:** BR-002, BR-007, BR-008, BR-009, BR-018.
- **Preconditions:** Selection made.
- **Main behaviour:** `createQuote` computes food subtotal, discount, delivery fee, service fee, tax (if approved) and credit lines; expires per `policy.quote.expiry`.
- **Alternate / exceptions:** Expired quote re-quoted, never honoured stale; client-supplied total ignored.
- **Screens:** C-08, C-12, NC-07, NC-08.
- **Commands:** `createQuote`, `confirmQuote` (PROPOSED).
- **Entities:** `ent.Quote`.
- **Provenance:** USER-REQ (pricing transparency governance section); PROPOSED ADR-009.
- **Acceptance links:** AC-030, UC-030, US-030, TEST-030.
- **Status:** Specified; not implemented.

## FR-031 — Skip, pause, replace, upgrade or downgrade a scheduled meal

Let a customer change an eligible future meal obligation before cutoff, with a server-computed adjustment (credit or charge), never changing a dispatched meal without an explicit exception policy.

- **Priority / module:** Must / MOD-SUB.
- **Actors:** Customer.
- **Applications:** CUS.
- **Business rules / decisions:** BR-001, BR-006, BR-017, BR-022.
- **Preconditions:** Obligation exists and is before cutoff.
- **Main behaviour:** `quoteScheduleChange` → `confirmScheduleChange`; `skipMeals`/`replaceMeal`/`pauseSlots`/`resumeSubscription` for the specific change types.
- **Alternate / exceptions:** Cutoff passed; already-dispatched meal blocked; duplicate request produces exactly one effect (SC-04).
- **Screens:** C-13, C-14, C-15, NC-05, NC-06, NC-09, NC-10.
- **Commands:** `skipMeals`, `pauseSlots`, `replaceMeal`, `resumeSubscription`, `quoteScheduleChange`, `confirmScheduleChange` (PROPOSED); `pauseMeals` kept as legacy alias.
- **Entities:** `ent.MealObligation`, `ent.Adjustment`, `ent.CreditTransaction`.
- **Provenance:** USER-REQ; OBSERVED legacy C-14/C-15 "not saved"/static gaps, explicitly fixed.
- **Acceptance links:** AC-031, UC-031, US-031, TEST-031.
- **Status:** Specified; not implemented.

## FR-032 — Customer service credits

Maintain a non-cash credit balance (available/reserved/consumed/expired) per customer, with full history, atomic redemption, and never a duplicate credit for the same origin.

- **Priority / module:** Must / MOD-CRD.
- **Actors:** Customer.
- **Applications:** CUS, ACC.
- **Business rules / decisions:** BR-006, BR-019, BR-025.
- **Preconditions:** An approved adjustment source exists.
- **Main behaviour:** `issueCredit` (internal), `reserveCredit`/`consumeCredit`/`releaseCredit` at checkout, `voidCredit`/`expireCredits` for corrections.
- **Alternate / exceptions:** Balance never negative; redemption exceeding balance rejected.
- **Screens:** C-20, C-23, NC-11, NC-16, NC-17.
- **Commands:** `issueCredit`, `reserveCredit`, `consumeCredit`, `releaseCredit`, `voidCredit`, `expireCredits` (PROPOSED).
- **Entities:** `ent.CreditAccount`, `ent.CreditTransaction`.
- **Provenance:** USER-REQ (credits ≠ cash wallet, explicit governance rule).
- **Acceptance links:** AC-032, UC-032, US-032, TEST-032.
- **Status:** Specified; not implemented.

## FR-033 — Online payment through a gateway abstraction (SSLCOMMERZ, sandbox)

Initiate a sandbox payment and activate the paid order/subscription only after server-to-server validation, never from a browser redirect alone.

- **Priority / module:** Must / MOD-PAY.
- **Actors:** Customer, BE.
- **Applications:** CUS, BE, ACC.
- **Business rules / decisions:** BR-003 (manual-reference context only; this FR is the gateway path).
- **Preconditions:** A confirmed quote exists.
- **Main behaviour:** `initiatePayment` → gateway redirect → `handleGatewayNotification` (IPN) → `validateGatewayTransaction`.
- **Alternate / exceptions:** Duplicate/out-of-order IPN deduplicated; amount mismatch rejected; unknown status shown honestly (SC-13).
- **Screens:** C-08, C-09, NC-14.
- **Commands:** `initiatePayment`, `handleGatewayNotification`, `validateGatewayTransaction` (PROPOSED); no real credentials used.
- **Entities:** `ent.PaymentIntent`, `ent.PaymentAttempt`, `ent.GatewayEvent`, `ent.GatewayVerification`.
- **Provenance:** USER-REQ (SSLCOMMERZ named gateway, future integration only).
- **Acceptance links:** AC-033, UC-033, US-033, TEST-033.
- **Status:** Specified; not implemented; no sandbox credential used.

## FR-034 — Cash on delivery (four distinct models)

Support COD for eligible one-time orders, per-scheduled-meal, approved weekly collection, and approved monthly settlement, each modelled and limited separately; rider-collected cash is never rider income.

- **Priority / module:** Must / MOD-COD.
- **Actors:** Customer, Rider, Accounts.
- **Applications:** CUS, PAR-Rider, ACC.
- **Business rules / decisions:** BR-012, BR-013, BR-016, BR-026.
- **Preconditions:** Order/obligation flagged COD-eligible per its model.
- **Main behaviour:** `recordCodCollection` → `submitCodRemittance` → `verifyCodRemittance`; discrepancies via `flagCodDiscrepancy`/`resolveCodDiscrepancy`.
- **Alternate / exceptions:** Duplicate deposit reference rejected (INV-12); shortfall never silently absorbed (SC-09).
- **Screens:** C-08, NC-14, NR-03, NR-04, NR-05, NF-03, NF-04.
- **Commands:** `recordCodCollection`, `submitCodRemittance`, `verifyCodRemittance`, `flagCodDiscrepancy`, `resolveCodDiscrepancy` (PROPOSED).
- **Entities:** `ent.CodCollection`, `ent.CodRemittance`.
- **Provenance:** USER-REQ (four distinct models, explicit instruction never to conflate them).
- **Acceptance links:** AC-034, UC-034, US-034, TEST-034.
- **Status:** Specified; not implemented.

## FR-035 — Billing schedules, invoices and receipts

Produce invoices and receipts from the quote/payment record, never before a payment is actually verified, reconciling exactly to recorded charges and payments.

- **Priority / module:** Must / MOD-PAY.
- **Actors:** Customer, Accounts.
- **Applications:** CUS, ACC.
- **Business rules / decisions:** BR-002.
- **Preconditions:** Billing cycle configured.
- **Main behaviour:** Invoice generated from the quote snapshot; receipt issued only after verified payment.
- **Alternate / exceptions:** Invoice/PDF never produced before a receipt exists (fixes legacy "always available" gap).
- **Screens:** C-20, C-21, NC-12, NC-13.
- **Commands:** Read-model only; triggered by payment-verification commands.
- **Entities:** `ent.Invoice`, `ent.Receipt`.
- **Provenance:** USER-REQ; OBSERVED legacy C-21 gap.
- **Acceptance links:** AC-035, UC-035, US-035, TEST-035.
- **Status:** Specified; not implemented.

## FR-036 — Supplier earning recognition

Recognise a supplier's earning only at the approved milestone (BR-010), showing expected/earned/held/eligible/settled separately, never as one undifferentiated figure.

- **Priority / module:** Must / MOD-SET.
- **Actors:** Supplier, Accounts.
- **Applications:** PAR-Supplier, ACC.
- **Business rules / decisions:** BR-009, BR-010.
- **Preconditions:** Recognition milestone defined.
- **Main behaviour:** `recognizeSupplierEarning` posts a journal crediting the supplier payable and the platform revenue split.
- **Alternate / exceptions:** Disputed/unfulfilled obligations excluded from eligible balance.
- **Screens:** S-08, NS-01, NF-05.
- **Commands:** `recognizeSupplierEarning` (PROPOSED, system).
- **Entities:** `ent.SupplierEarning`.
- **Provenance:** USER-REQ; OBSERVED legacy S-08 static sample figures, explicitly fixed (conflict register C-07).
- **Acceptance links:** AC-036, UC-036, US-036, TEST-036.
- **Status:** Specified; not implemented.

## FR-037 — Rider assignment, delivery and earnings

Offer/accept assignments with conflict prevention, confirm pickup and proof of delivery, and recognise exactly one earning per completed delivery even after a reassignment.

- **Priority / module:** Must / MOD-DLV.
- **Actors:** Rider, Admin.
- **Applications:** PAR-Rider, ADM.
- **Business rules / decisions:** BR-011.
- **Preconditions:** Rider approved and on duty.
- **Main behaviour:** `offerAssignment` → `acceptAssignment` → `confirmPickup` → `submitDeliveryProof` → `recognizeRiderEarning`; `reassignDelivery` reverses/prorates as policy requires.
- **Alternate / exceptions:** Simultaneous pickup race resolved to one rider (SC-08); no double payment on reassignment (WF-J).
- **Screens:** R-01, R-10, NR-01.
- **Commands:** `offerAssignment`, `acceptAssignment`, `confirmPickup`, `submitDeliveryProof`, `recognizeRiderEarning`, `reassignDelivery` (PROPOSED).
- **Entities:** `ent.DeliveryAssignment`, `ent.DeliveryEvent`, `ent.RiderEarning`.
- **Provenance:** USER-REQ; OBSERVED legacy R-10 offer/accept flow.
- **Acceptance links:** AC-037, UC-037, US-037, TEST-037.
- **Status:** Specified; not implemented.

## FR-038 — Payout requests with maker-checker approval

Let a supplier or rider request a payout of their eligible balance, approved by a different principal than the requester, settled only after an independently confirmed external transfer.

- **Priority / module:** Must / MOD-SET.
- **Actors:** Supplier, Rider, Accounts Operator, Payout Approver.
- **Applications:** PAR, ACC.
- **Business rules / decisions:** BR-014, BR-020.
- **Preconditions:** Eligible balance ≥ requested amount.
- **Main behaviour:** `requestPayout` → `reviewPayout` → `approvePayout` (≠ requester) → `createPayoutBatch` → `releasePayoutBatch` → `recordPayoutResult`.
- **Alternate / exceptions:** Self-approval rejected (SC-16); failed external transfer never silently retried as a new payout.
- **Screens:** S-09, NS-02, NS-03, NR-02, NF-07, NF-08.
- **Commands:** `requestPayout`, `reviewPayout`, `approvePayout`, `createPayoutBatch`, `releasePayoutBatch`, `recordPayoutResult` (PROPOSED).
- **Entities:** `ent.PayoutRequest`, `ent.PayoutApproval`, `ent.SettlementBatch`, `ent.PayoutResult`.
- **Provenance:** USER-REQ (maker-checker explicit requirement).
- **Acceptance links:** AC-038, UC-038, US-038, TEST-038.
- **Status:** Specified; not implemented.

## FR-039 — Refunds, disputes and chargebacks

Handle refunds, disputes and chargebacks as independent workflows, never granting a refund and an equivalent credit for the same obligation.

- **Priority / module:** Must / MOD-LED.
- **Actors:** Customer, Admin, Accounts.
- **Applications:** CUS, ADM, ACC.
- **Business rules / decisions:** BR-005, BR-015, BR-025.
- **Preconditions:** A refund-eligible event exists.
- **Main behaviour:** `initiateRefund` → `recordRefundResult`; disputes reviewed via `placeHold`/`requestAdjustment`.
- **Alternate / exceptions:** Double compensation rejected (INV-17, SC-14).
- **Screens:** A-05, NF-10.
- **Commands:** `initiateRefund`, `recordRefundResult` (PROPOSED).
- **Entities:** `ent.Refund`, `ent.Dispute`, `ent.Adjustment`.
- **Provenance:** USER-REQ.
- **Acceptance links:** AC-039, UC-039, US-039, TEST-039.
- **Status:** Specified; not implemented.

## FR-040 — General ledger, journals and period close

Maintain a double-entry ledger with immutable posted journals, reversal-only correction, and a governed period-close/reopen process.

- **Priority / module:** Must / MOD-LED.
- **Actors:** Accounts.
- **Applications:** ACC.
- **Business rules / decisions:** BR-020.
- **Preconditions:** None (foundational).
- **Main behaviour:** `postJournal` (internal only); `closePeriod`/`reopenPeriod` with maker-checker.
- **Alternate / exceptions:** No posting to a closed period; late events post to the next open period with an adjusting reference (SC-15).
- **Screens:** NF-11, NF-12.
- **Commands:** `postJournal`, `reverseJournal`, `closePeriod`, `reopenPeriod` (PROPOSED, internal/governed).
- **Entities:** `ent.LedgerAccount`, `ent.JournalEntry`, `ent.JournalLine`, `ent.AccountingPeriod`.
- **Provenance:** USER-REQ (double-entry model explicit requirement).
- **Acceptance links:** AC-040, UC-040, US-040, TEST-040.
- **Status:** Specified; not implemented.

## FR-041 — Gateway and COD reconciliation

Compare operational events and external statements against ledger postings, raising an exception on any mismatch, never auto-correcting.

- **Priority / module:** Must / MOD-LED.
- **Actors:** Accounts.
- **Applications:** ACC.
- **Business rules / decisions:** None blocking directly.
- **Preconditions:** Gateway/COD records exist.
- **Main behaviour:** `reconcileGatewayStatement` compares records; mismatches raise `ent.ReconciliationException`.
- **Alternate / exceptions:** Duplicate callback already reconciled; unmatched transfer flagged, not guessed.
- **Screens:** NF-02, NF-03, NF-13, NF-17.
- **Commands:** `reconcileGatewayStatement` (PROPOSED).
- **Entities:** `ent.ReconciliationItem`, `ent.ReconciliationException`.
- **Provenance:** USER-REQ.
- **Acceptance links:** AC-041, UC-041, US-041, TEST-041.
- **Status:** Specified; not implemented.

## FR-042 — Financial reporting and secured export

Produce revenue, collection, payout, liability, settlement and reconciliation reports with provenance, restricted to authorised finance roles.

- **Priority / module:** Must / MOD-RPT.
- **Actors:** Accounts, Admin (limited).
- **Applications:** ACC, ADM.
- **Business rules / decisions:** None blocking directly.
- **Preconditions:** Authorised role.
- **Main behaviour:** `exportReport` queries posted ledger data with a provenance block (NFR-028).
- **Alternate / exceptions:** Unauthorised role denied at the command layer, never merely hidden.
- **Screens:** A-14, NF-14, NA-06.
- **Commands:** `exportReport` (PROPOSED).
- **Entities:** Derived read model over ledger and operational stores.
- **Provenance:** USER-REQ.
- **Acceptance links:** AC-042, UC-042, US-042, TEST-042.
- **Status:** Specified; not implemented.

## FR-043 — Admin Web operations console

Provide a desktop operations console for zones, policy configuration, incident dispatch and monitoring, with no implicit financial authority.

- **Priority / module:** Must / MOD-ADM, MOD-POL.
- **Actors:** Admin.
- **Applications:** ADM.
- **Business rules / decisions:** BR-006…026 (policy publication).
- **Preconditions:** Invited Admin account.
- **Main behaviour:** `publishPolicyVersion`, `decideApplication`, `reassignDelivery` available; financial settlement commands are not.
- **Alternate / exceptions:** An Admin attempt at a payout/journal action is rejected (SC-16, conflict register C-06).
- **Screens:** A-01…19, NA-01…06.
- **Commands:** `publishPolicyVersion`, `decideApplication`, `reassignDelivery`, `saveSettings` (OBSERVED/PROPOSED).
- **Entities:** `ent.PolicyVersion`, `ent.AuditEvent`.
- **Provenance:** USER-REQ (desktop-first, real administration, not a stretched mobile dashboard).
- **Acceptance links:** AC-043, UC-043, US-043, TEST-043.
- **Status:** Specified; not implemented.

## FR-044 — Staff accounts, finance roles and segregation of duties

Invite, grant, revoke and suspend staff/finance accounts with role grants that enforce preparer ≠ approver.

- **Priority / module:** Must / MOD-AUTH.
- **Actors:** Admin, Accounts Manager, Super Admin.
- **Applications:** ADM, ACC.
- **Business rules / decisions:** BR-020.
- **Preconditions:** Super Admin or Accounts Manager authority.
- **Main behaviour:** `grantStaffRole`/`revokeStaffRole`/`suspendAccount`; revocation immediately invalidates in-flight privileged sessions (NFR-029).
- **Alternate / exceptions:** Self-grant of an approver role rejected (SC-16).
- **Screens:** NF-15.
- **Commands:** `grantStaffRole`, `revokeStaffRole`, `suspendAccount` (PROPOSED).
- **Entities:** `ent.StaffAccount`, `ent.RoleGrant`.
- **Provenance:** USER-REQ.
- **Acceptance links:** AC-044, UC-044, US-044, TEST-044.
- **Status:** Specified; not implemented.

## FR-045 — Partner onboarding, documents and corrections

Preserve the multi-step supplier/rider application with documents, correction cycles, and server-authorised decisions, removing the legacy applicant-shortcut bypass.

- **Priority / module:** Must / MOD-AUTH.
- **Actors:** Supplier applicant, Rider applicant, Admin.
- **Applications:** PAR, ADM.
- **Business rules / decisions:** None blocking directly; extends FR-021.
- **Preconditions:** None.
- **Main behaviour:** `saveApplication`/`saveEvidence` (draft) → `decideApplication` (approve/reject/request-info).
- **Alternate / exceptions:** Legacy AU-11→A-07 shortcut removed; access granted only after a server decision.
- **Screens:** AU-09, AU-10, AU-11, NA-03.
- **Commands:** `saveApplication`, `saveEvidence` (OBSERVED, gated), `decideApplication` (PROPOSED).
- **Entities:** `ent.Application`, `ent.ApplicationDocument`.
- **Provenance:** USER-REQ; OBSERVED legacy StepForm engine, preserved.
- **Acceptance links:** AC-045, UC-045, US-045, TEST-045.
- **Status:** Specified; not implemented.

## FR-046 — Kitchen capacity and stock reservation

Enforce capacity/stock limits with atomic reservation so a meal is never oversold, with safe recovery if a payment completes after a stock failure.

- **Priority / module:** Must / MOD-CAT.
- **Actors:** Supplier, BE.
- **Applications:** PAR-Supplier, BE.
- **Business rules / decisions:** None blocking directly.
- **Preconditions:** Capacity configured.
- **Main behaviour:** `reserveStock` (atomic, TTL-bounded) / `releaseStock`.
- **Alternate / exceptions:** Two customers racing for the last unit resolved to exactly one (SC-20); a late-succeeding payment is refunded, not double-fulfilled.
- **Screens:** NS-05.
- **Commands:** `reserveStock`, `releaseStock`, `saveCapacity` (PROPOSED, internal/system).
- **Entities:** `ent.StockReservation`, `ent.KitchenCapacity`.
- **Provenance:** USER-REQ.
- **Acceptance links:** AC-046, UC-046, US-046, TEST-046.
- **Status:** Specified; not implemented.

## FR-047 — Delivery proof and failure exceptions

Require OTP or photo proof for a Delivered state, and record a failed delivery as a distinct, honest outcome, never silently merged into Delivered.

- **Priority / module:** Must / MOD-DLV.
- **Actors:** Rider, Customer.
- **Applications:** PAR-Rider, CUS.
- **Business rules / decisions:** BR-011, DEC-014.
- **Preconditions:** Rider at the delivery location.
- **Main behaviour:** `submitDeliveryProof` (success) / `reportDeliveryFailure` (failure, with waiting-time and contact-attempt evidence).
- **Alternate / exceptions:** No rider compensation for an unproven delivery.
- **Screens:** R-03, NR-06.
- **Commands:** `submitDeliveryProof`, `reportDeliveryFailure` (PROPOSED).
- **Entities:** `ent.DeliveryProof`, `ent.DeliveryEvent`.
- **Provenance:** USER-REQ; OBSERVED legacy R-03.
- **Acceptance links:** AC-047, UC-047, US-047, TEST-047.
- **Status:** Specified; not implemented.

## FR-048 — Live tracking with location consent

Show a rider's live location only to the customer of the currently assigned delivery, with access revoked immediately on reassignment or completion, clearly distinguished from a simulated animation.

- **Priority / module:** Must / MOD-DLV.
- **Actors:** Customer, Rider.
- **Applications:** CUS, PAR-Rider.
- **Business rules / decisions:** None blocking directly.
- **Preconditions:** Active assignment, rider consent.
- **Main behaviour:** `updateRiderLocation` (rate-limited); visibility scoped to the current assignment.
- **Alternate / exceptions:** GPS unavailable shown honestly; access revoked on reassignment.
- **Screens:** C-18.
- **Commands:** `updateRiderLocation` (PROPOSED).
- **Entities:** `ent.RiderLocation`.
- **Provenance:** USER-REQ; OBSERVED legacy C-18 animated-sample gap, explicitly flagged.
- **Acceptance links:** AC-048, UC-048, US-048, TEST-048.
- **Status:** Specified; not implemented.

## FR-049 — Cross-app localisation, theming and accessibility

Preserve full English/Bangla parity, light/dark theming, and accessibility across all four applications, with in-progress state surviving a language switch.

- **Priority / module:** Must / cross-cutting.
- **Actors:** All roles.
- **Applications:** CUS, PAR, ADM, ACC.
- **Business rules / decisions:** None blocking directly.
- **Preconditions:** None.
- **Main behaviour:** Every string has an English and Bangla variant; draft state (selections, quantities, dates) survives a language switch (SC-18).
- **Alternate / exceptions:** No clipped text at either language's longest form.
- **Screens:** All.
- **Commands:** None (UI state).
- **Entities:** None.
- **Provenance:** USER-REQ.
- **Acceptance links:** AC-049, UC-049, US-049, TEST-049.
- **Status:** Specified; not implemented.

## FR-050 — Canonical time-zone and cutoff evaluation

Evaluate every cutoff and service date at the trusted backend from a canonical UTC instant and the Asia/Dhaka calendar, regardless of the client's device time zone or language.

- **Priority / module:** Must / MOD-POL.
- **Actors:** BE.
- **Applications:** BE, all (consumers).
- **Business rules / decisions:** BR-022.
- **Preconditions:** Policy version published.
- **Main behaviour:** Server-side comparison of the obligation's cutoff instant to the canonical clock, using the policy version active when the obligation was created.
- **Alternate / exceptions:** Cross-midnight and device-time-zone-mismatch cases produce the same server decision.
- **Screens:** All (cutoff-dependent).
- **Commands:** Internal to every cutoff-dependent command.
- **Entities:** `ent.PolicyVersion`.
- **Provenance:** USER-REQ (time and cutoff policy governance section).
- **Acceptance links:** AC-050, UC-050, US-050, TEST-050.
- **Status:** Specified; not implemented.
