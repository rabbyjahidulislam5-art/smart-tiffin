# Project roadmap

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (M0…M5 kept as history; M6+ added for the four-application programme) |
| Owner | Requirements and planning author |
| Purpose | Milestones from the original documentation phase through the four-application, finance-enabled delivery. |
| Depends on | [Implementation plan](IMPLEMENTATION_PLAN.md), [risk register](RISK_REGISTER.md) |
| Status | Planning document; no milestone beyond M0 is claimed complete. |

## Historical milestones (kept)

| Milestone | Outcome | Scope and task references | Exit evidence |
|---|---|---|---|
| M0 — Requirements package | Four roles, all source features, policy gaps and verification obligations are reviewable | TASK-001–004; FR-001–025 | Document inventory, traceability, link checks; this was the 2026-10-28 delivery |
| M1 — Decisions and secure foundation | An Android user can authenticate and reach only the authorized dashboard in Bangla or English | TASK-005, TASK-101/102; FR-001–003 | Approved policy inputs needed; device launch; authentication and direct-access negative tests |
| M2 — Catalogue and ordering | Supplier menus, customer browsing and ordering function on real data | TASK-103/104 | — |
| M3 — Subscriptions and billing | Monthly subscriptions, pauses and bills reconcile | TASK-105/106 | — |
| M4 — Delivery and admin | Delivery lifecycle and admin management function | TASK-108/110 | — |
| M5 — Release readiness | Integrated bilingual accessibility and reliability validation | TASK-112/113 | — |

## New milestones (M6…M12, 2026-10-30 scope)

| Milestone | Outcome | Task references | Exit evidence |
|---|---|---|---|
| M6 — Documentation refinement (this delivery) | Four-application requirements, architecture, finance domain, screen inventory, scenarios and verification are complete and internally consistent | TASK-114…TASK-120 | This package: [verification/FINAL_VERIFICATION_REPORT.md](../verification/FINAL_VERIFICATION_REPORT.md) |
| M7 — Shared foundation and backend ledger | Shared packages, command envelope and ledger schema exist in code | TASK-121 | Clean build, formatter/analyzer pass, schema migration dry run |
| M8 — Customer App | Kitchen discovery, ordering, custom subscriptions, credits, sandbox payment/COD on real data | TASK-122 | Device/browser evidence, negative tests |
| M9 — Partner App | Supplier and rider workspaces, earnings, COD collection on real data | TASK-123 | Device evidence, dual-role negative tests |
| M10 — Admin Web | Operations console, approvals, policy configuration on real data | TASK-124 | Desktop browser evidence |
| M11 — Accounts Web | Ledger, reconciliation, payout maker-checker, reporting on real data | TASK-125 | Desktop browser evidence, financial invariant tests (INV-01…20) |
| M12 — SSLCOMMERZ sandbox and release readiness | Sandbox gateway integration verified; full bilingual accessibility validation; visual PDF produced from real captures | TASK-126…128 | Sandbox transaction logs, PDF manifest, release checklist |

Each new milestone's exit evidence must be recorded with a dated, tested revision; no milestone past M6 is claimed reached by this documentation effort.
