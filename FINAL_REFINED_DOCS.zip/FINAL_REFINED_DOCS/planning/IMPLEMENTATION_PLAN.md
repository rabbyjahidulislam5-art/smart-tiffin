# Implementation plan

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (supersedes 1.0, scoped to one app) |
| Owner | Requirements and planning author |
| Purpose | Vertical delivery slices across the four applications and shared backend, with their policy and dependency gates. |
| Depends on | [Product delivery plan](PRODUCT_DELIVERY_PLAN.md), [dependency map](DEPENDENCY_MAP.md), [policy decision register](../requirements/POLICY_DECISION_REGISTER.md) |
| Status | Planning document; [TASKS.md](../TASKS.md) carries live status. |

## Independent preparation and decision gates

Android-first and Bangla+English remain confirmed for the two mobile apps; Admin Web and Accounts Web additionally require a desktop-first responsive baseline (NFR-013). BR-001 meal pause, BR-002 billing, BR-003 payment verification, BR-004 delivery assignment, BR-005 cancellation/refunds, and the extended BR-006…BR-026 (credits, delivery fees, commission, earning recognition, COD, payouts, disputes, tax, approval limits, and the rest) are all Pending Decision in [BUSINESS_RULES.md](../requirements/BUSINESS_RULES.md) and [POLICY_DECISION_REGISTER.md](../requirements/POLICY_DECISION_REGISTER.md). No cutoff hour, credit formula, commission rate, payout threshold, tax rate or refund policy is approved.

## Vertical slices (PROPOSED order)

| Slice | Scope | Blocked by | Apps |
|---|---|---|---|
| S0 | Shared packages, backend command envelope, ledger schema skeleton (no live data) | None independent | BE |
| S1 | Auth, profile, role resolution across all four apps | DEC-009, DEC-033 (dual-role) | All |
| S2 | Kitchen discovery, menu, variants, price versions | None independent | CUS, PAR-Supplier |
| S3 | One-time ordering and quote engine | BR-022 (cutoff) for full behaviour; UI/schema can proceed | CUS, BE |
| S4 | Custom subscription builder and meal obligations | BR-001, BR-021, BR-022 | CUS, BE |
| S5 | Service credits | BR-006, BR-019, BR-025 | CUS, ACC |
| S6 | Online payment (sandbox) and COD | BR-003, BR-012, BR-013 | CUS, PAR-Rider, ACC |
| S7 | Supplier/rider earnings | BR-009, BR-010, BR-011 | PAR, ACC |
| S8 | Payouts (maker-checker) | BR-014, BR-020 | PAR, ACC |
| S9 | Ledger, reconciliation, period close | BR-002, BR-009 | ACC |
| S10 | Refunds, disputes, chargebacks | BR-005, BR-015, BR-025 | CUS, ADM, ACC |
| S11 | Admin Web operations, approvals, policy configuration | DEC-009, DEC-013 | ADM |
| S12 | Accessibility, bilingual, responsive hardening across all apps | None independent | All |
| S13 | SSLCOMMERZ sandbox integration | Credentials supplied by the user; never before this phase | CUS, BE |

A slice may proceed with schemas, fixtures and UI while its policy is open, but the policy-dependent behaviour itself stays blocked exactly as before — this plan does not relax that rule for the new slices.

## What this plan does not do

It does not finalise a schema, command or financial calculation against a guessed policy value, and it does not claim any slice has started.
