# Dependency map

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (supersedes 1.0, single-app scope) |
| Owner | Requirements and planning author |
| Purpose | What must resolve before what, across the four-application, finance-enabled scope. |
| Depends on | [Assumptions and constraints](../requirements/ASSUMPTIONS_AND_CONSTRAINTS.md), [policy decision register](../requirements/POLICY_DECISION_REGISTER.md) |
| Status | Planning document. |

| Dependency | Enables | Work that can proceed independently |
|---|---|---|
| DEC-001 Android-first; DEC-002 Bangla+English — resolved | Mobile build scope, strings, layouts for CUS and PAR | Requirements verification and all technical contracts |
| NFR-013 desktop-first baseline (PROPOSED) | ADM and ADW layout and component decisions | Desktop component and table design |
| DEC-009 identity and role approval details (extended by DEC-033 dual-role) | FR-001–003/044/045 and every protected operation across five roles | Authentication scaffolding, explicit authorization interface; no self-granted privileged roles |
| ADR-005 hybrid datastore (PROPOSED) | Ledger, payout, reconciliation schema | Firestore operational schema for non-financial entities can proceed in parallel |
| BR-006/DEC-016 credit formula | Credit issuance and redemption commands | Credit account/transaction schema shape (without a value) |
| BR-009/DEC-019, BR-010/DEC-020 commission and recognition event | Supplier earning recognition, platform revenue reporting | Earning record schema (without recognition timing) |
| BR-012/DEC-022, BR-013/DEC-023 COD eligibility and remittance deadline | COD checkout option, rider remittance workflow | COD collection/remittance schema shape |
| BR-014/DEC-024, BR-020/DEC-030 payout thresholds and approval limits | Payout request/approval/batch commands | Maker-checker role model (without numeric limits) |
| BR-002/DEC-003, BR-018/DEC-028 billing basis and tax | Invoice/quote line computation | Quote snapshot structure (without a formula) |
| BR-022/DEC-032 cutoff policy | Subscription change windows, order cutoffs | Canonical time-zone evaluation mechanism (without the cutoff value) |
| SSLCOMMERZ sandbox credentials (user-supplied, future) | Any real sandbox transaction test | The entire gateway abstraction and IPN contract design |
| TASK-010 app/lib layout reconciliation | Clean four-app monorepo restructuring | Continued documentation of the target layout |

Every "work that can proceed independently" entry is a design/schema activity, never a finalized financial calculation or an approved default.
