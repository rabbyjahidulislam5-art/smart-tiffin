# Technical execution plan

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (supersedes 1.0, which specified one Flutter app with ChangeNotifier and a single Node/Firebase backend) |
| Owner | Architecture lead |
| Purpose | State the concrete technical approach for building the four applications and shared backend, once implementation is separately authorised. |
| Depends on | [Multi-app architecture](../architecture/MULTI_APP_ARCHITECTURE.md), [backend domain design](../architecture/BACKEND_DOMAIN_DESIGN.md), [ADR-004](../adr/004-four-app-monorepo.md), [ADR-005](../adr/005-hybrid-datastore.md) |
| Status | Planning document; no execution has occurred. |

## What changed and why

**Spec:** this plan and [design/COMPLETE_SCREEN_INVENTORY.md](../design/COMPLETE_SCREEN_INVENTORY.md). The 2026-10-28 plan specified a single Flutter application with `ChangeNotifier` state management and a `Navigator`-based single-app route presentation, with one shared component system rendering "custom role dashboards." That architecture is superseded: the user's 2026-10-30 request requires four separate applications. This document restates the technical approach for that scope.

## Architecture (PROPOSED)

- **Four Flutter applications**, each its own package/binary, sharing the packages listed in [planning/PRODUCT_DELIVERY_PLAN.md](PRODUCT_DELIVERY_PLAN.md). State management per app is the project's own choice at implementation time (not specified as `ChangeNotifier` globally); this plan does not mandate a single state-management library across apps, since Admin Web and Accounts Web have materially different data-table-heavy needs from the two mobile apps.
- **Navigation:** per-app route registries with role guards; Flutter Web apps use proper browser history (back/forward, deep links), unlike the legacy prototype's in-memory stack navigator.
- **Backend:** the existing Cloud Functions `executeCommand` callable is extended with the full command set in [api/API_SPECIFICATION.md](../api/API_SPECIFICATION.md), still behind the trusted command boundary (ADR-002, extended).
- **Data:** Firestore for operational/read models; a PROPOSED managed PostgreSQL instance for the double-entry ledger, payouts and COD remittance (ADR-005); an outbox pattern keeps the two stores consistent (see [database/DATA_CONSISTENCY.md](../database/DATA_CONSISTENCY.md)).
- **Design rendering:** screen specifications in [design/screens/](../design/screens/) drive each app's widget tree; no shared "custom role dashboard" renderer spans all four apps, since their layouts (mobile card UI vs. desktop data tables) differ materially.

## Development design scenarios

Design scenarios (mock data, illustrative BDT figures, sandbox gateway responses) remain visibly labelled and separated from any real Firebase/PostgreSQL execution, exactly as the prior plan required. This remains true across all four apps.

## Sequencing

Execution order follows [planning/PRODUCT_DELIVERY_PLAN.md](PRODUCT_DELIVERY_PLAN.md) §"Delivery sequence" and [planning/IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md). No step here authorises skipping a BR/DEC approval gate.

## What this plan does not do

It does not choose a specific state-management package, does not configure a cloud project, and does not claim any code has been written under this architecture. Use continuation instructions ("go and work", "go and apply") authorise proceeding without repeated confirmation on independent documentation and design work; they do not supply a BR policy value or cloud configuration, and they do not authorise skipping this plan's own sequencing.
