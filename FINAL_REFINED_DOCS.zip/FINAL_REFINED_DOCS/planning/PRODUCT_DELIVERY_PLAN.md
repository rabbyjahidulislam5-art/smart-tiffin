# Product delivery plan

| Field | Value |
|---|---|
| Revision | 3.0 · 2026-10-30 (supersedes 2.0, which recommended one combined Android/Firebase app) |
| Owner | Requirements and planning author |
| Purpose | State what is being delivered — four Flutter applications on one shared backend — and in what order, superseding the single-app recommendation. |
| Applies to | CUS, PAR, ADM, ACC, BE |
| Depends on | [Project scope](../requirements/PROJECT_SCOPE.md), [multi-app architecture](../architecture/MULTI_APP_ARCHITECTURE.md), [implementation plan](IMPLEMENTATION_PLAN.md) |
| Status | Documentation refinement delivered now; implementation is a later, separately approved phase. |

## What changed and why

The 2026-10-28 plan recommended "one Android-first Flutter/Firebase application for Customer, Supplier/Cook, Delivery Rider and Admin." The 2026-10-30 user-supplied master prompt (now a primary requirement, see the corrected [source material register](../requirements/SOURCE_MATERIAL_REGISTER.md)) requires four separate applications — **Customer App**, **Partner App** (supplier and rider workspaces), **Admin Web**, **Accounts Web** — on one shared backend, plus a flexible subscription/credit/payment/ledger domain the single-app plan never covered. This plan is rewritten accordingly; it does not merely add a paragraph to the old one.

## Intent and source precedence

Deliver four Flutter applications and one shared backend, in English and Bangla, preserving the legacy prototype's visual identity (warm orange customer, green supplier, blue rider, indigo admin, a new restrained Accounts accent) and every still-valid FR-001–FR-025, extended by FR-026–FR-050. Design every destination (legacy 94 screens plus 55 proposed screens) before implementing it. Produce a final visual PDF with actual rendered screens, after implementation and visual verification — not as part of this documentation phase.

## The four applications and the backend

| Application | Platform | Audience | Scope highlights |
|---|---|---|---|
| Customer App | Flutter, Android first (iOS-ready architecture) | Guests and customers | Kitchen discovery, flexible ordering/subscriptions, credits, payments, tracking (see [customer-app/](../customer-app/)) |
| Partner App | Flutter, Android | Suppliers and riders (two protected workspaces, one binary) | Kitchen ops, deliveries, earnings, payouts, COD collection (see [partner-app/](../partner-app/)) |
| Admin Web | Flutter Web, desktop-first | Operations/governance staff | Monitoring, approvals, policy configuration, incident dispatch, limited finance overview (see [admin-web/](../admin-web/)) |
| Accounts Web | Flutter Web, desktop-first | Accounts & Finance staff | Ledger, reconciliation, settlement, payouts, refunds, reporting (see [accounts-web/](../accounts-web/)) |
| Shared backend | Firebase Auth + Firestore + Cloud Functions (trusted boundary) + a PROPOSED managed PostgreSQL ledger | All four apps | One domain model, one command set (see [architecture/MULTI_APP_ARCHITECTURE.md](../architecture/MULTI_APP_ARCHITECTURE.md), [ADR-005](../adr/005-hybrid-datastore.md)) |

## Delivery sequence (recommended, PROPOSED)

1. **Foundation:** shared packages (auth contracts, domain models, design tokens, localisation, API clients, validation, money formatting, test utilities); backend command envelope and ledger foundations (ADR-006, ADR-008, ADR-009).
2. **Customer App:** kitchen discovery/menu, ordering, custom subscription engine, credits, COD/online payment UI (sandbox only).
3. **Partner App:** supplier workspace first (menu, orders, earnings), then rider workspace (assignments, COD collection, earnings).
4. **Admin Web:** operations console, approvals, policy configuration, incident dispatch.
5. **Accounts Web:** finance dashboard, ledger, reconciliation, payout maker-checker, reporting.
6. **SSLCOMMERZ integration:** only after sandbox credentials are supplied by the user during backend implementation; never initiated in this phase.

Each stage is gated by the relevant BR/DEC approvals in [BUSINESS_RULES.md](../requirements/BUSINESS_RULES.md) and [POLICY_DECISION_REGISTER.md](../requirements/POLICY_DECISION_REGISTER.md); a stage may be designed while its dependent policy remains Pending, but may not be finalised against a guessed value.

## Monorepo layout (PROPOSED, flagged against current code reality)

```
smart_tiffin/
  apps/
    customer_app/
    partner_app/
    admin_web/
    accounts_web/
  packages/
    auth_contracts/
    domain_models/
    design_tokens_ui/
    localization/
    api_clients/
    validation/
    error_handling/
    notification_interfaces/
    money_format/
    test_utils/
  backend/
    functions/        (existing: executeCommand, extended per api/API_SPECIFICATION.md)
  firebase/            (existing: rules, indexes)
```

**Flagged mismatch (carried from the 2026-10-28 plan, still open):** the real code at `app/lib` is laid out as `app/, data/, design/, ui/`, a single combined app — not the `lib/core, lib/l10n, lib/features/*` layout earlier plans proposed, and not yet the four-app monorepo above. See [architecture/CODE_REALITY_SNAPSHOT.md](../architecture/CODE_REALITY_SNAPSHOT.md) and [architecture/REACT_TO_FLUTTER_MIGRATION.md](../architecture/REACT_TO_FLUTTER_MIGRATION.md). TASK-010 in [TASKS.md](../TASKS.md) tracks reconciling or restructuring it; this plan does not restructure code.

## Screen design scope

Legacy 94 screens (authoritative, [source digest](../analysis/SOURCE_LEGACY_PROTOTYPE_DIGEST.md)) plus 55 proposed screens (NC-19, NS-7, NR-6, NA-6, NF-17) are fully specified in [design/COMPLETE_SCREEN_INVENTORY.md](../design/COMPLETE_SCREEN_INVENTORY.md) and the per-group files in [design/screens/](../design/screens/). The earlier 129-family planning inventory is retained as history and reconciled one-to-one in [design/INVENTORY_RECONCILIATION.md](../design/INVENTORY_RECONCILIATION.md); nothing from it is lost.

## PDF deliverable

A single visual PDF capturing every screen, state and language variant is a **later deliverable**, produced only after the Flutter applications exist and are visually verified. See [design/PDF_PRODUCTION_PLAN.md](../design/PDF_PRODUCTION_PLAN.md). Nothing is rendered by this documentation phase.

## What this plan does not do

It does not implement code, configure Firebase/PostgreSQL projects, connect SSLCOMMERZ, approve a BR/DEC value, or claim a test has run. [TASKS.md](../TASKS.md) and [planning/IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md) carry the actual task sequencing.
