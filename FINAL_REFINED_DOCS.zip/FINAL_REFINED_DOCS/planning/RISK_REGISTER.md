# Risk register

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (RISK-001…013 kept unchanged; RISK-014…045 added) |
| Owner | Requirements and planning author |
| Purpose | Extend the original risk register with the finance, gateway, multi-app and migration risks introduced by the four-application scope. |
| Depends on | [Policy decision register](../requirements/POLICY_DECISION_REGISTER.md), [threat model](../security/THREAT_MODEL.md), [financial security](../security/FINANCIAL_SECURITY.md) |
| Status | Draft for review. |

Assessment date: 2026-10-28, extended 2026-10-30. Likelihood and impact are qualitative planning assessments, not measured incident rates. Owners below name responsibilities; named individuals have not been assigned. No risk acceptance is implied by inclusion in this table.

| ID | Risk and affected scope | Likelihood / impact | Owner | Mitigation and detection | State |
|---|---|---|---|---|---|
| RISK-001 | Pending BR-001–005 become accidental business policy in code | High / high | Product owner + lead | Require approved values and versions before dependent implementation; link tests to approved scenarios | Open; dependent tasks blocked |
| RISK-002 | Client changes its role, verifies itself or reads another user's data; FR-003/013/021 | Medium / critical | Security/backend | Deny unauthorized direct SDK operations; test every role/object pair and server authority | Open; controls only specified |
| RISK-003 | Races create duplicate orders, pauses, references or charges | Medium / high | Orders/finance | Idempotency identity, atomic boundaries, state preconditions; TEST-103–107 | Open |
| RISK-004 | Cooking demand and billing disagree after a pause/correction | High / high | Subscriptions/finance | Shared approved policy version, immutable records and reconciliation fixtures | Open; BR-001/002/005 required |
| RISK-005 | A courier retains addresses after reassignment or sees unrelated financial data | Medium / high | Delivery/security | Minimal assignment projection, backend access expiry, reassignment tests | Open |
| RISK-006 | Unicode, text scaling or long translations make core actions unusable | Medium / medium | Client/QA | Both languages in widget/device tests; Bangla shaping and TalkBack manual review | Open |
| RISK-007 | Push delivery failure is treated as order/payment failure or success | Medium / medium | Notifications | Persist authoritative business record separately; idempotent notifications; in-app refresh | Open |
| RISK-008 | Firebase costs exceed unprovided budget or region selection conflicts with needs | Unknown / high | Product/release owner | DEC-010 before provisioning; representative workload and cost limits; no paid deployment now | Open |
| RISK-009 | SDK/tooling or Android target incompatibility blocks later builds | Medium / medium | Client lead | Audit installed environment, select supported versions and minimum Android target, verify clean build | Open; no build claimed |
| RISK-010 | Sensitive addresses, payment references or credentials enter logs/test data | Medium / high | All contributors | Synthetic fixtures, redaction, least access, secret review and retention decisions | Open |
| RISK-011 | Course deadline, team capacity and release destination remain unspecified | Unknown / high | Project owner | Obtain timeline/capacity and destination before committing delivery dates | Open |
| RISK-012 | Documentation is mistaken for a tested application | Medium / high | Lead | Keep phase and evidence boundaries explicit in tracker, reports and final handoff | Mitigated by explicit labeling; review ongoing |
| RISK-013 | A security-rule change or data migration breaks older clients | Medium / high | Backend/release | Backward-compatible contract review; upgrade and recovery tests before release | Future release risk |

## New risks (RISK-014…045, 2026-10-30 scope)

| ID | Risk and affected scope | Likelihood / impact | Owner | Mitigation and detection | State |
|---|---|---|---|---|---|
| RISK-014 | Pending BR-006…026 become accidental financial policy in code (credit formula, commission, cutoffs, thresholds) | High / high | Product owner + finance lead | Same discipline as RISK-001, extended to all 21 new rules; no implementation without recorded approval | Open; dependent tasks blocked |
| RISK-015 | A duplicate credit, payment, remittance or payout is created by a retried/duplicated request | Medium / critical | Backend/finance | Idempotent command envelope, unique origin constraints (INV-04/08/12); SCT-xx-L/C test class per scenario | Open; design only |
| RISK-016 | Firestore and the PostgreSQL ledger silently diverge (an operational event with no matching journal, or vice versa) | Medium / critical | Backend | Outbox pattern, reconciliation job raising exceptions, never auto-correcting (NFR-026) | Open; design only |
| RISK-017 | A gateway callback is forged, replayed, or trusted from a browser redirect instead of server-to-server validation | Medium / critical | Security/payments | Signature/validation on every inbound notification, idempotent processing, never trust redirect (NFR-017, SC-13) | Open; design only |
| RISK-018 | Rider-held COD cash is confused with rider income, inflating earnings or hiding a shortfall | Medium / high | Finance/product | Strict terminology (glossary), independent balances, SC-09/SC-12 test scenarios | Open; design only |
| RISK-019 | A single staff account can both prepare and approve a payout or adjustment | Medium / critical | Accounts/security | Maker-checker enforcement at the command layer, not just the UI (NFR-016, SC-16) | Open; design only |
| RISK-020 | Admin Web is granted de facto payout/ledger authority through a broad "super admin" role | Medium / high | Security | Explicitly bounded Super Admin privileges; Accounts-only settlement commands (conflict register C-06) | Open; design only |
| RISK-021 | The managed PostgreSQL ledger introduces unbudgeted operating cost or an unapproved second cloud dependency | Unknown / high | Product/release owner | ADR-005 remains PROPOSED pending cost comparison with a Firestore-only alternative | Open |
| RISK-022 | Four separate Flutter apps and shared packages develop circular dependencies, blocking independent releases | Medium / medium | Engineering | Acyclic dependency map review (NFR-023) before each package release | Open; design only |
| RISK-023 | The legacy 94-screen and the 129-family planning inventories are merged incorrectly, losing a control or state | High / high | Design lead | Two-way reconciliation table with every family mapped (see [inventory reconciliation](../design/INVENTORY_RECONCILIATION.md)) | Mitigated by explicit reconciliation; review ongoing |
| RISK-024 | A desktop (Admin/Accounts) financial table overflows or clips on a narrower window, hiding a figure or action | Medium / high | Design/QA | Adaptive financial-table strategy (NFR-020), responsive QA matrix | Open; design only |
| RISK-025 | SSLCOMMERZ integration details are assumed from memory rather than official documentation, causing an incorrect contract | Medium / high | Payments lead | Verify against official SSLCOMMERZ developer documentation before implementation (see [references/SOURCES.md](../references/SOURCES.md)) | Open; verification pending |
| RISK-026 | A credit or refund is granted twice for the same skipped/cancelled obligation | Medium / critical | Finance | Unique adjustment-origin constraint (INV-08, INV-17), idempotent commands | Open; design only |
| RISK-027 | Dual-role (supplier and rider) accounts share a mutable balance or leak cross-role notifications | Medium / high | Security | Independent per-workspace balances and notification scoping (BR-023, SC-25) | Open; design only |
| RISK-028 | A kitchen loses certification or goes offline with active paid commitments and no defined resolution, causing silent data loss | Medium / high | Product/operations | BR-024 decision gate; managed resolution queue design (SC-07, SC-17) | Open; policy pending |
| RISK-029 | Legal/regulatory exposure from treating service credits as stored value without legal review | Low / critical | Legal/finance | BR-025 held open; no cash-out path implemented until reviewed | Open; policy pending |
| RISK-030 | A period is closed with an unreconciled exception, misstating a financial report | Medium / high | Accounts | Mandatory reconciliation checklist before `closePeriod` (NFR-014, SC-15) | Open; design only |
| RISK-031 | Migration from the current single combined `app/` to the four-app monorepo breaks existing (even if unverified) code | Medium / medium | Engineering | TASK-010 tracked separately; no destructive restructuring without a migration plan | Open |
| RISK-032 | Accessibility/bilingual regressions on the two new desktop web apps, which have no legacy prototype reference | Medium / medium | Design/QA | Dedicated desktop accessibility and responsive QA matrix (NFR-013, NFR-020) | Open; design only |
| RISK-033 | Rate-limiting is absent on quote creation or OTP, enabling abuse or denial-of-service-style load | Medium / medium | Security | NFR-022; defined per-principal/IP limits | Open; design only |
| RISK-034 | A test or document overstates completion by citing an unexecuted scenario as passing | Medium / high | QA/lead | Explicit planned-vs-executed labelling (TEST_RESULTS.md); verification report cross-check | Mitigated by explicit labelling; review ongoing |
| RISK-035 | COD remittance overdue handling has no defined deadline, so cash exposure grows unbounded in practice once implemented | Medium / high | Finance | BR-013 decision gate; escalation state machine designed, not defaulted | Open; policy pending |
| RISK-036 | A supplier's or rider's payable balance is shown before the approved recognition event, misleading them about available funds | Medium / high | Finance/product | BR-010/BR-011 decision gate; glossary qualifiers (expected/earned/eligible/settled) enforced in every UI | Open; policy pending |
| RISK-037 | Multi-kitchen subscriptions are allowed inconsistently across screens before BR-021 is approved | Low / medium | Product | One-kitchen-per-agreement default documented everywhere until approved otherwise | Open; policy pending |
| RISK-038 | Desktop keyboard/shortcut interactions are designed inconsistently across Admin Web and Accounts Web | Low / medium | Design | Shared component specifications (see [design/COMPONENT_SPECIFICATIONS.md](../design/COMPONENT_SPECIFICATIONS.md)) | Open; design only |
| RISK-039 | A scenario's financial arithmetic example is mistaken for an approved rate or fee | Medium / medium | Documentation lead | Every figure labelled HYPOTHETICAL per the [conventions register](../analysis/CONVENTIONS_AND_ID_REGISTER.md) | Mitigated by explicit labelling |
| RISK-040 | Firestore security rules are not extended to cover the new entity types before any implementation begins | Medium / high | Security/backend | Rules review required as part of each slice in [IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md) | Open; future release risk |
| RISK-041 | Export/report provenance is omitted, making a financial report impossible to trace back to its source query | Low / medium | Accounts | NFR-028 provenance requirement | Open; design only |
| RISK-042 | A staff role grant or revocation does not immediately invalidate an in-flight privileged session | Medium / high | Security | NFR-029; session invalidation test | Open; design only |
| RISK-043 | The Accounts Web desktop identity visually clashes with or is confused for the Admin Web identity, causing operational mistakes | Low / medium | Design | Distinct, restrained Accounts accent defined in [design/DESIGN_SYSTEM.md](../design/DESIGN_SYSTEM.md) | Open; design only |
| RISK-044 | The 25 cross-system scenarios are treated as executed tests rather than planned test designs | Medium / high | QA/lead | Explicit SCT-xx identifiers kept in the "planned" test catalogue until actually run | Mitigated by explicit labelling |
| RISK-045 | Course/project deadline, team capacity and hosting destination for four apps (not one) remain unspecified, risking an unrealistic schedule | Unknown / high | Project owner | Obtain timeline/capacity/destination for the full four-app scope before committing delivery dates | Open |

Escalate active unauthorized access or financial-integrity failures as release blockers. For any accepted residual risk, add the decision-maker, rationale, affected release, mitigation deadline and review date. No owner approval has been supplied for accepting these risks.
