# Release plan

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (supersedes 1.0, Android-only) |
| Owner | Requirements and planning author |
| Purpose | Define release readiness and channels for four applications instead of one, including the two desktop web applications. |
| Depends on | [Project roadmap](PROJECT_ROADMAP.md), [deployment guide](../deployment/DEPLOYMENT_GUIDE.md), [release checklist](../deployment/RELEASE_CHECKLIST.md) |
| Status | Planning document; no release has occurred. |

## Documentation handoff (unchanged criterion, now four-application scope)

The package is ready for review when the requirements cover all five roles (Customer, Supplier, Rider, Admin, Accounts) and FR-001–050, BR-001–026 remain clearly Pending Decision, the four-application/Bangla/English scope is consistent, canonical files and traceability resolve, and the documented verification report identifies exactly what was checked. Requirements review does not approve a payment policy, a ledger design, or start deployment.

## Release channels (PROPOSED)

| Application | Channel | Notes |
|---|---|---|
| Customer App | Android (Play Store internal/closed testing track initially); iOS architecture reserved | Mobile release |
| Partner App | Android (separate internal testing track from Customer) | Mobile release; supplier and rider workspaces ship together in one binary |
| Admin Web | Restricted web hosting, invite-only access, no public signup | Desktop web release |
| Accounts Web | Restricted web hosting, invite-only access, MFA required, stricter network/access controls than Admin Web | Desktop web release |
| Backend | Firebase project + PostgreSQL instance, staged dev/staging/prod | Shared by all four |

## Go-live gates (extends the original gate list)

In addition to the original NFR/accessibility/device gates: no SSLCOMMERZ production credential may be introduced before a separately approved go-live decision; every financial invariant (INV-01…INV-20) has a passing automated test against real (non-sandbox) data structures; every BR-001…BR-026 value needed for the features in that release has recorded approval evidence; the Accounts Web maker-checker control has been independently verified by someone other than its implementer.

## What this plan does not do

It does not set a date, budget, or hosting provider; it does not claim a release has been prepared or executed.
