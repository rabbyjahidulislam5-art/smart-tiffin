# Partner App UI/UX

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Partner App domain author |
| Purpose | Preserve the legacy green (supplier) and blue (rider) identities, define large-control/safety-shortcut patterns for the rider workspace, and state responsive/accessibility rules specific to PAR. |
| Applies to | PAR |
| Depends on | [design/DESIGN_SYSTEM.md](../design/DESIGN_SYSTEM.md), [analysis/SOURCE_LEGACY_PROTOTYPE_DIGEST.md](../analysis/SOURCE_LEGACY_PROTOTYPE_DIGEST.md) §6 |
| Status | PROPOSED — NOT APPROVED. |

## Preserved identity

Green supplier / blue rider role colours; glass components; QuickActions tiles per workspace; `MiniMap`, `SosBtn`, `StockList`, `ReqCard` patterns carried into Flutter equivalents per [architecture/REACT_TO_FLUTTER_MIGRATION.md](../architecture/REACT_TO_FLUTTER_MIGRATION.md).

## Clearly separated navigation (USER-REQ)

The Partner App's navigation root branches by the caller's active role grant (workspace claim), never by a tab the user could tap into the wrong role; a dual-role principal (BR-023) switches workspace through an explicit, re-authorised action, not a silent tab.

## Large controls and safety shortcuts (rider workspace)

Rider-facing primary actions (confirm pickup, submit proof, SOS) use large touch targets and a persistent, always-reachable SOS entry point, carried from the legacy prototype's header placement.

## Clear financial separation (both workspaces)

Every earnings screen visually separates "earned" from "projected" (supplier) and "compensation" from "COD liability" (rider), using distinct colour/label treatment, never the same number restyled.

## Responsive, dark mode, Bangla, accessibility

Same bands and token system as Customer App; rider screens prioritise one-handed, glanceable layouts given on-the-move use.

## Acceptance and verification

Design-only. Verification requires a visual review confirming the earned/projected and compensation/COD-liability distinctions are visually, not just textually, different.
