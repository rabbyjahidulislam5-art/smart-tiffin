# Partner App architecture

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Partner App specification owner (author D2) |
| Purpose | Define how the Partner App resolves a signed-in person to the supplier workspace, the rider workspace, or the application journey; how the two workspaces stay isolated; and how sessions, role switching, notifications, offline use and location sharing behave. |
| Applies to | PAR (PAR-S supplier workspace, PAR-R rider workspace). The Customer App, Admin Web and Accounts Web are referenced only where they exchange data with the Partner App. |
| Depends on | [Conventions and ID register](../analysis/CONVENTIONS_AND_ID_REGISTER.md), [glossary](../requirements/GLOSSARY_AND_TERMINOLOGY.md), [policy register](../requirements/POLICY_DECISION_REGISTER.md), [user roles](../requirements/USER_ROLES.md), [multi-app architecture](../architecture/MULTI_APP_ARCHITECTURE.md), [security architecture](../architecture/SECURITY_ARCHITECTURE.md), [authorization](../api/AUTHORIZATION.md), [ADR-011 roles, claims and sessions](../adr/011-roles-claims-and-sessions.md), [navigation architecture](../design/NAVIGATION_ARCHITECTURE.md) |
| Authoritative policies | BR-023 (dual-role accounts, PENDING), BR-004 (delivery assignment, PENDING), BR-024 (kitchen discontinuity and compliance lapse, PENDING); DEC-009 (identity and roles), DEC-012 (offline behaviour), DEC-014 (preparation and delivery exceptions). Policy text lives in [BUSINESS_RULES.md](../requirements/BUSINESS_RULES.md) and the [policy register](../requirements/POLICY_DECISION_REGISTER.md) only. |
| Status | Draft for review. Nothing in this file is implemented or approved. The structure is PROPOSED, derived from USER-REQ (master prompt phase 2, item 2). The OBSERVED baseline is one combined Flutter app (`app/`, package `smart_tiffin`), see [code reality snapshot](../architecture/CODE_REALITY_SNAPSHOT.md). |

Module specifications that build on this file: [supplier modules](SUPPLIER_MODULES.md), [rider modules](RIDER_MODULES.md), [supplier earnings](SUPPLIER_EARNINGS.md), [rider earnings](RIDER_EARNINGS.md), [COD collection](COD_COLLECTION.md), [Partner UI/UX](PARTNER_UI_UX.md). Screen-level contracts are in [supplier screens](../design/screens/SUPPLIER_SCREENS.md), [rider screens](../design/screens/RIDER_SCREENS.md) and [partner application screens](../design/screens/PARTNER_APPLICATION_SCREENS.md); this file links to them instead of repeating them.

## 1. Scope and provenance

| Statement | Tag |
|---|---|
| The Partner App is a separate Android Flutter app containing two protected workspaces: Supplier/Kitchen Partner and Rider/Delivery Partner. | USER-REQ |
| Role-based authentication routes a signed-in person to the correct workspace. | USER-REQ |
| Shared authentication, UI, localisation and infrastructure are allowed; permissions, operations, dashboards and financial balances are independent. | USER-REQ |
| Application forms, document verification and admin approval are preserved and improved. | USER-REQ |
| The prototype's screens S-01…S-12, R-01…R-10, AU-09…AU-11 are the visual and behavioural reference. Prototype behaviour (in-memory navigation, hard-coded data, no role guard) is not production behaviour. | OBSERVED |
| Customer and Partner are separate mobile apps; the Customer App is not described here. | USER-REQ |
| One binary versus two binaries, the package names, and the router and state-management choice are not decided. This file records the constraints any choice must satisfy. | PROPOSED, open (see section 13) |
| Whether one person may hold both partner grants is undecided. | PENDING (BR-023) |

## 2. Application boundaries

### 2.1 What is shared and what is isolated

| Concern | Shared across both workspaces | Isolated per workspace |
|---|---|---|
| Identity | Sign-in, recovery, session renewal, one `ent.Principal` per person, device registration (`ent.Device`) | The grant a request relies on (`ent.RoleGrant` for supplier or rider) |
| Design | Design tokens, glass and card components, typography, icons, localisation resources (English and Bangla), accessibility helpers | Workspace accent (green supplier, blue rider), navigation graph, dashboard composition |
| Infrastructure | API client for the single `executeCommand` envelope, error mapping, idempotency key generation, secure storage, logging without personal data, notification receiver, connectivity monitor, amount formatting | Cache partitions, listeners and streams, notification channels, in-memory view state |
| Data | Read-only reference data (zones, slot identifiers, policy parameter names) | Operational data: supplier sees kitchen, menu, orders, obligations; rider sees assignments and custody. No shared mutable record between workspaces. |
| Money | Money formatting and the shared qualifier vocabulary (paid, pending, posted, held, reserved, disputed, available) | Balances: supplier payable (`ent.SupplierEarning`) and rider payable (`ent.RiderEarning`) are separate accounts. Rider-held COD cash (`ent.CodCollection`) is a third, company-owned category and is never part of rider income. |
| Notifications | Device token registration | Channels, inbox contents, unread counters, deep-link targets |
| Profile | Name, language, theme, security settings | Kitchen profile and documents (supplier); vehicle, documents, emergency contact and location consent (rider) |

### 2.2 Proposed module layout (PROPOSED)

The layout below states dependency direction only. Directory and package names are decided when implementation starts (see [monorepo and build ownership](../setup/MONOREPO_AND_BUILD_OWNERSHIP.md)).

```mermaid
flowchart TD
  Shell["Partner shell: bootstrap, session resolver, router, workspace host"]
  Onboard["Partner onboarding feature: AU-09 to AU-11"]
  Sup["Supplier workspace feature"]
  Rid["Rider workspace feature"]
  Shared["Shared packages: auth contracts, role permissions, domain models, design tokens and UI, localisation, API client, validation, error handling, notification interfaces, amount formatting, test utilities"]
  Shell --> Onboard
  Shell --> Sup
  Shell --> Rid
  Onboard --> Shared
  Sup --> Shared
  Rid --> Shared
  Shell --> Shared
```

Rules that follow from the diagram:

1. The supplier workspace and the rider workspace never import each other. Anything both need moves into a shared package, and shared packages never import a workspace (no circular imports).
2. Presentation is separate from business behaviour and from Firebase data access. Workspaces call repositories that speak the command and read-model contracts; widgets do not call Firebase directly.
3. Domain models in shared packages are generated or hand-written from the same contracts the other apps use (one domain model, ADR-004). Boundary data is parsed into typed models with explicit error results; unknown enum values fail closed rather than defaulting.
4. All money is an integer count of BDT minor units (INV-03); formatting to two decimals happens only at display.
5. Exactly one state-management approach and one router are selected for the whole app when implementation begins; no overlapping frameworks are added speculatively.

## 3. Startup and role resolution

### 3.1 Principle

A visually selected account type never grants authorisation. The workspace opened is a function of server-validated state: authentication status, principal status, active role grants, application state and document validity. Custom claims may speed up the first route decision, but the canonical grant and principal record is checked at startup, after token refresh and by every command (see [authorization](../api/AUTHORIZATION.md) and [ADR-011](../adr/011-roles-claims-and-sessions.md)). A cached claim alone cannot enforce an immediate suspension. Route guards are a usability measure, not security.

### 3.2 Resolution flow

```mermaid
flowchart TD
  Start["App start or token refresh"] --> Session{"Valid session?"}
  Session -- "no" --> SignIn["AU-03 sign in"]
  Session -- "yes" --> Principal{"Principal active?"}
  Principal -- "suspended or removed" --> Ended["Access-ended view, sign-out only"]
  Principal -- "active" --> Grants["Read active partner grants from the server"]
  Grants --> HasGrant{"Active supplier or rider grant?"}
  HasGrant -- "none" --> App{"Application on record?"}
  App -- "none" --> Choose["AU-12 partner type choice with P-04 explanations"]
  App -- "Draft" --> Form["AU-09 or AU-10 at saved step"]
  App -- "Submitted or In Review" --> Status["AU-11 pending"]
  App -- "Information Requested" --> Fix["AU-11 then fix mode for the requested section"]
  App -- "Rejected" --> Rej["AU-11 rejected view"]
  HasGrant -- "one grant" --> One{"Which?"}
  One -- "supplier" --> S01["S-01 kitchen dashboard"]
  One -- "rider" --> R01["R-01 active deliveries"]
  HasGrant -- "two grants" --> Dual{"BR-023 outcome"}
  Dual -- "allowed" --> Pick["Workspace chooser, last used preselected"]
  Dual -- "not allowed" --> Block["Server blocks the second grant; single workspace opens"]
```

### 3.3 Routing outcomes

| # | Server-validated situation | Destination | Notes |
|---|---|---|---|
| 1 | No session, expired session, or revoked refresh token | AU-03 | Only a safe route intent (a screen type and an opaque id) is kept; it is re-authorised after sign-in. |
| 2 | Principal suspended, disabled or removed | Access-ended view (see [shared screens](../design/screens/SHARED_SCREENS.md)) | Fail closed. Shows only a support entry and sign-out. No cached business data is rendered. |
| 3 | Signed in, no partner grant, no application | AU-12 (partner type choice), with P-04 role explanations | AU-12 in the Partner App offers Kitchen or Delivery only. Customer sign-up lives in the Customer App. The choice records an intent, not a grant. |
| 4 | Application is Draft | AU-09 (kitchen) or AU-10 (rider) at the saved step | Drafts are stored server-side as `ent.Application` in Draft state (the prototype stored them in local storage only). |
| 5 | Application is Submitted or In Review | AU-11 pending view | No access to S-xx or R-xx routes. |
| 6 | Application is Information Requested | AU-11 with an "Update application" action that opens only the requested section | Reviewer message shown verbatim. |
| 7 | Application is Rejected | AU-11 rejected view with the reason | A new application is possible only as policy allows (parameter `policy.application.reapply_wait_days`, DEC-009). |
| 8 | Approved with exactly one active grant | S-01 (supplier) or R-01 (rider) | The grant, not a stored preference, decides. |
| 9 | Two active grants | Workspace chooser (only if BR-023 allows two grants) | Section 5. |
| 10 | Grant active but restricted (for example expired document, grant suspended, hold from a continuity case) | The workspace opens in restricted mode: read access plus the actions needed to resolve the restriction | The restriction reason comes from the server. The client never decides eligibility. |
| 11 | Account holds only a customer grant | Not served by the Partner App. The Partner App offers the application journey if BR-023 allows one identity to hold customer and partner grants; otherwise it explains that a separate identity is needed | The Customer App's "Apply as a Cook / Rider" entry (prototype C-23, OBSERVED) hands off to the Partner App. |

## 4. Application and under-review journey (AU-09, AU-10, AU-11)

Full screen contracts: [partner application screens](../design/screens/PARTNER_APPLICATION_SCREENS.md). The reviewer side is in [approval workflows](../admin-web/APPROVAL_WORKFLOWS.md).

### 4.1 Applicant state model

States follow the glossary: Draft, Submitted, In Review, Information Requested, Approved, Rejected. Only the server changes state after Draft (`saveApplication` for applicant edits, `decideApplication` for reviewer decisions).

```mermaid
stateDiagram-v2
  [*] --> Draft
  Draft --> Submitted: applicant submits all steps
  Submitted --> InReview: reviewer opens the dossier
  InReview --> InformationRequested: reviewer asks for a section
  InformationRequested --> Submitted: applicant resubmits the section
  InReview --> Approved: reviewer approves after checklist
  InReview --> Rejected: reviewer rejects with reason
  Rejected --> [*]
  Approved --> [*]
```

### 4.2 Journey requirements

| Requirement | Detail | Tag |
|---|---|---|
| Kitchen application has six steps | Personal; Kitchen; Operations and menu; Payout; Documents; Agreement and review. Conditional fields (trade licence for Restaurant or Cloud kitchen; hygiene certificate, shown as "Conditional, policy pending") are server-defined requirements, not client assumptions. | OBSERVED, preserved |
| Rider application has eight steps | Personal (age at least 18); Address and zone; Emergency contact; Vehicle (Motorcycle, Bicycle, Walker; licence, registration and insurance only for Motorcycle); Availability and phone (shifts, GPS consent checkbox); Payout; Documents; Review and agree. | OBSERVED, preserved |
| Drafts | Draft saved after each step and on explicit "Save draft". Draft contents are personal data and follow retention rules ([data retention](../database/DATA_RETENTION.md)). | PROPOSED (prototype used device-local storage) |
| Documents | Uploaded through `saveEvidence` into protected storage. Files are never public; the applicant sees a thumbnail or file name and status, not another person's file. | PROPOSED |
| Minimal data | Collect only justified identity fields (master prompt, authentication and onboarding). Payout details are masked after entry (for example last four digits) and carry the warning "Never share your PIN or password". | USER-REQ, OBSERVED |
| Review step | Per-step Edit links, full validation on submit, jump to the first invalid step. | OBSERVED, preserved |
| Fix mode | Only the requested section opens; Next goes to Review; the reviewer's message is quoted; resubmission clears the request and appends history "Updated and resubmitted". | OBSERVED, preserved |
| Status screen AU-11 | Timeline (Submitted, In review, Decision); history card; Contact support; Sign out. For Approved, the "Open my dashboard" action appears only after the server reports an active grant. | OBSERVED, extended |
| Prototype shortcut removed | The prototype's note linking "Admin, A-07" from the applicant journey does not exist in the product. The applicant can never reach reviewer routes, and a pending applicant can never open S-01 or R-01 (prototype gap 20: no role guard). | USER-REQ (AU-11 instruction) |
| Reference | Each submission gets an application reference (prototype format `ST-APP-xxxx` is OBSERVED, final format PROPOSED). | OBSERVED |
| Notifications | Submitted, information requested, approved and rejected produce a notification in the applicant's inbox. Message text is generic; no document content or identity numbers. | PROPOSED |
| Language | Language choice is persisted and applies to the application (prototype gap 19). | PROPOSED |

### 4.3 Approval effect

On approval the server (not the client) creates the grant (`ent.RoleGrant`), the partner record (`ent.Supplier` and `ent.Kitchen`, or `ent.Rider` and `ent.Vehicle`) and an audit event. The next token refresh or startup resolution opens the workspace. Until then the app polls or receives a notification and re-runs section 3.2. A client can never create a grant.

## 5. Dual-role handling (BR-023, PENDING)

The question "may one person be both supplier and rider?" is undecided. The design supports both outcomes without a rewrite.

| Aspect | If dual partner grants are allowed | If not allowed |
|---|---|---|
| Parameter | `policy.roles.dual_partner_allowed` (no default value) | same parameter, opposite value |
| Second application | Permitted; reviewed independently by NA-03 | Server refuses to create it and explains why |
| Startup | Workspace chooser (section 3.2) | Single workspace |
| Identity | One `ent.Principal`, two `ent.RoleGrant` records, each with its own approval history | One grant |
| Data | Two independent record sets. No shared mutable balance, no shared notification channel, no shared documents unless the person uploads them again | n/a |
| Financial | Two separate payable accounts. A payout from one never uses the other. COD custody belongs to the rider workspace only | n/a |

Rules that apply in both outcomes:

1. Every command is authorised against the grant that command requires (for example `acceptOrder` needs an active supplier grant on the owning kitchen; `acceptAssignment` needs an active rider grant on the assignment). Holding one grant never authorises an action of the other, and the active tab or workspace is never an input to authorisation.
2. A person with both grants can see a conflict between their own duties (for example, accepting a delivery from their own kitchen). Whether this is allowed is part of BR-004 and BR-023 and is PENDING; the server rejects any assignment that the approved rule forbids, and the UI shows the server reason.
3. Suspending one grant does not suspend the other unless the principal itself is suspended.
4. Each workspace has its own profile fields, documents and payout destinations. Payout destinations are not shared across workspaces.

## 6. Session and role-switching rules (SC-25)

| Rule | Detail | Tag |
|---|---|---|
| Single sign-in, explicit switch | Switching workspace is an explicit action (profile or drawer: "Switch to Delivery" or "Switch to Kitchen"). Swiping or tab selection never changes workspace. | PROPOSED |
| Switch procedure | (1) Check the target grant with the server and refresh the token. (2) Cancel the current workspace's listeners and streams. (3) Clear the current workspace's in-memory sensitive state (balances, addresses, documents, cached statements). (4) Open the target workspace root. Nothing is carried over (unread counts, filters, drafts). | PROPOSED |
| No leakage | Notification badges, titles and counters are per workspace. A supplier-workspace notification does not appear in the rider inbox. | USER-REQ (authentication and onboarding) |
| Guard while on duty | A rider cannot switch away while a delivery is Picked Up or On The Way, because custody of food or cash is open. The app explains why and offers "Return to delivery". Whether this block is desirable is an open decision. | PROPOSED, open |
| Persisted preference | The last-used workspace may be remembered per account as a convenience only. It is validated against the current grants on every start. | PROPOSED |
| Sign-out | Ends the whole session: both workspaces, listeners, local caches, scheduled local work and the device-token registration for this principal. The next person on the device sees nothing from the previous person. | PROPOSED |
| Session expiry | On expiry or revocation the app returns to AU-03 and shows no protected content, including in the recent-apps snapshot (privacy screen on Android). | PROPOSED |
| Role revocation | When a grant is revoked or suspended, the next command fails with a permission result, the cached data for that workspace is purged, and the user lands on the resolution flow. Revocation is not delayed until token expiry because commands check the canonical record. | USER-REQ (revocation effects), PROPOSED mechanism |
| Device change | A sign-in on a new device registers a new `ent.Device`; step-up verification is required before payout-destination changes. | PROPOSED |
| Step-up | Sensitive profile changes (payout owner, NID, bank or wallet, vehicle registration) require "Confirm it's you" re-verification before the change is accepted (prototype SH-08 behaviour, OBSERVED) and set the profile into re-verification review by Admin. | OBSERVED, extended |

Scenario SC-25 acceptance (summary; full test design is in the scenario file listed in the [scenario index](../scenarios/SCENARIO_INDEX.md)): access follows the verified grants, not a tab; notifications, profile fields and financial accounts are role-scoped; logout and session expiry end both workspaces.

## 7. Navigation per workspace

One router is selected when implementation starts. Constraints: a navigation stack per primary tab; Android back closes an overlay, then pops a detail screen, then returns to the workspace root, and never reopens a signed-out protected screen; reselecting a tab returns to its root. Back during a submitting command never cancels a committed server operation or loses the request identifier. Route namespaces are `/auth/...`, `/partner/apply/...`, `/supplier/...` and `/rider/...`. The record id in a route is never trusted by itself.

| Workspace | Primary destinations (tabs) | Observed in prototype | Notes |
|---|---|---|---|
| Supplier (green) | Dashboard S-01; Menu S-04; Orders S-06; Earnings S-08 | Same four tabs | Secondary: cooking requirements S-03, order request S-02, commitments S-07 with forecast NS-04, capacity NS-05, price manager NS-06, handoff NS-07, payout history S-09, kitchen profile S-10, documents S-11, operating settings S-12. |
| Rider (blue) | Deliveries R-01; History R-07; Earnings and cash R-08; Profile R-09 | Three tabs (R-01, R-07, R-09) | PROPOSED: Earnings and cash becomes a fourth tab so that compensation and COD custody have a permanent, separate home. This is a change from the OBSERVED prototype and is confirmed in the rider screen contracts. Secondary: turn-by-turn R-02, proof R-03, delivered R-04, SOS R-05, queue R-06, offer R-10, ledger NR-01, payout NR-02, COD NR-03 to NR-05, dispute NR-06. |
| Shared in both | SH-01 notifications, SH-02 chat, SH-04 help, SH-05 settings, SH-06 report a problem, SH-07 ticket status, SH-08 edit profile, SH-09 notification settings, SH-10 email history | Instances `SH-xx@PAR-S` and `SH-xx@PAR-R` | Content scoped to the server-enforced role. |

Navigation never skips approval, and a deep link or notification tap goes through the same authorisation as a normal entry.

## 8. Notifications and deep links

| Topic | Rule |
|---|---|
| Channels | Separate Android notification channels per workspace and per urgency: supplier (new request, cutoff, commitment change, document expiry, payout status); rider (assignment offer, reassignment, SOS acknowledgement, remittance due, discrepancy inquiry, payout status). |
| Payload | Generic lock-screen text. No customer address, phone number, payment reference, balance or document content. The payload carries a type, an opaque record id and the workspace tag. |
| Tap handling | Store only the safe intent; require sign-in if needed; fetch and authorise the target; if the grant or assignment no longer exists show a neutral "no longer available" view without revealing the record. A duplicate tap does not navigate or write twice. A stale notification cannot restore an old assignment. |
| Preferences | SH-09: essential notifications (security, assignment, payout status) cannot be disabled; optional ones can. Preferences are persisted per workspace (prototype toggles were local only). |
| Delivery guarantees | Push is best effort; the inbox (SH-01) is the source of truth. Push failure never rolls back a committed change. |
| Priority | Assignment offers use high-priority delivery with an expiry carried as a server timestamp; the client displays remaining time from the server clock, not the device clock. |

See [event and notification design](../api/EVENT_AND_NOTIFICATION_DESIGN.md) for the backend side.

## 9. Offline behaviour and GPS

### 9.1 Offline (DEC-012)

The proposed baseline (DEC-012, PROPOSED) is: critical mutations are online-confirmed; cached reads are labelled with an "as of" time; nothing is queued as a success.

| Action class | Offline behaviour |
|---|---|
| Reads (dashboards, queue, history, statements) | Show last cached data with an offline banner and the cached timestamp. Balances show "as of" and a refresh action. Never present cached data as live. |
| Supplier state changes (accept or decline, stage, stock, online status, price schedule) | Blocked while offline with a reason beside the control. No queued success. |
| Rider assignment accept and decline | Blocked offline (the offer would expire; conflict risk). |
| Rider evidence capture (proof photo, OTP entry, COD collection record, receipt image) | PROPOSED exception: capture is kept in an encrypted local outbox as "Not yet confirmed". It carries its original `requestId`, a capture timestamp and the client-measured offline duration. It is sent when connectivity returns. The delivery stays On The Way and the cash stays unrecorded on the server until acknowledgement. The UI never says Delivered or Collected before the server acknowledges. Whether this exception is acceptable is open under DEC-012 and the evidence-handling rules in [COD collection](COD_COLLECTION.md). |
| SOS | Attempts server delivery; if offline, offers the device dialler for emergency calls and an SMS fallback, and says clearly that dispatch has not been notified. |
| Unknown outcome (timeout or lost response) | Same `requestId` is retried; the app asks the server for the receipt; the state is shown as "Checking" and resolves to Committed or Rejected (see the interaction-state contract in [navigation architecture](../design/NAVIGATION_ARCHITECTURE.md)). |

### 9.2 GPS and location (FR-048, rider workspace)

| Rule | Detail | Tag |
|---|---|---|
| Consent first | A plain-language disclosure screen explains what is collected, when, who can see it and how long it is kept, before the Android permission dialog. The GPS checkbox in AU-10 is an informed intent, not consent for background use. | USER-REQ (live maps distinguish permitted GPS collection from continuous exposure), PROPOSED UI |
| Scope | Location is sampled only while the rider is On duty with an accepted assignment, and shared with the customer only while the delivery is On The Way. It stops on delivery completion, going off duty, consent withdrawal or sign-out. Other riders and suppliers never see it. | PROPOSED |
| Frequency and retention | Parameters `policy.location.update_interval_seconds` and `policy.location.retention_days` (no values; DEC-010). Samples are `ent.RiderLocation` and are minimised. | PENDING |
| Permission states | Not asked, Granted while in use, Granted always, Denied, Revoked, GPS off. Each state has a visible indicator on R-01 (prototype GPS toggle, OBSERVED, becomes a real status). | PROPOSED |
| Core job without GPS | Denial or GPS loss never blocks the core delivery flow: the address, contact and proof steps still work. The customer's tracking shows a "Location unavailable" note instead of a stale marker. | PROPOSED |
| Honest tracking | The prototype's animated sample marker (C-18) is not tracking. Real tracking shows the last update time and degrades to status-only (FR-010) when stale. | OBSERVED, corrected |
| Battery and data | Sampling uses the lowest accuracy that meets the product need and pauses when stationary. Any performance claim must be measured under approved conditions; none is claimed here. | PROPOSED |
| Provider | The maps and routing provider and its cost are an open integration decision recorded in an ADR. | PENDING (integration roadmap) |

## 10. Data access and consistency boundaries

1. The Partner App speaks to the single backend (`executeCommand` envelope with `command`, `requestId`, `expectedVersion?`, `payload`) for all writes, and reads role-scoped read models. It never writes balances, grants, approval state, assignments or ledger data.
2. Every state-changing action creates its `requestId` when the user opens the confirmation, reuses it on retry, and disables the control while submitting. A lost response is resolved by re-sending the same request, never by sending a new one.
3. Updates carry `expectedVersion`. A version conflict shows what changed and offers refresh before retry. It never overwrites silently.
4. Listeners (streams) are created when a screen or workspace becomes visible and disposed when it leaves. Controllers are disposed. Mounted state is checked before updating UI after an async gap. Side effects never run during widget build.
5. Cache partitions are keyed by principal and workspace, encrypted at rest where the platform allows, and wiped on sign-out and grant revocation.
6. Time shown to users uses the service time zone rules ([time and cutoff policy](../architecture/TIME_AND_CUTOFF_POLICY.md)). Cutoff decisions are made by the server. Slot identifiers (`slot.breakfast`, `slot.lunch`, `slot.snack`, `slot.dinner`) are never derived from translated labels.

## 11. Screens, commands and entities

| Area | Screens | Commands (registered names) | Entities |
|---|---|---|---|
| Application | AU-03, AU-09, AU-10, AU-11, AU-12, P-04 | `saveApplication`, `saveEvidence`, `saveProfile`, `saveDevice` | `ent.Application`, `ent.ApplicationDocument`, `ent.Principal`, `ent.Device` |
| Role resolution | AU-03, workspace chooser (a state of AU-12 or SH-05, defined in screen contracts) | none (read of grants); grant creation by `decideApplication` and `changeRole` | `ent.RoleGrant`, `ent.Principal` |
| Supplier workspace | S-01…S-12, NS-01…NS-07 | see [supplier modules](SUPPLIER_MODULES.md) | see that file |
| Rider workspace | R-01…R-10, NR-01…NR-06 | see [rider modules](RIDER_MODULES.md) | see that file |
| Shared | SH-01, SH-02, SH-04…SH-10 (per workspace instance) | `saveSettings` (preferences), `submitComplaint` | `ent.Notification`, `ent.Ticket`, `ent.Complaint` |

Registered commands with no entry for a needed function are listed as register gaps in section 13.

## 12. Acceptance conditions

1. A signed-in person with no partner grant cannot open any S-xx, NS-xx, R-xx or NR-xx route, including by deep link, notification tap or restored navigation state (tests SCT-25-P, and permission tests for each route namespace).
2. After approval, the workspace opens only after the server reports the grant; a client-side edit of any stored role or workspace preference changes nothing.
3. With dual grants (if BR-023 allows), switching workspace clears the previous workspace's in-memory data and listeners, shows no notification or balance from the other workspace, and each command is authorised against its own grant (SCT-25-N, SCT-25-C).
4. With a revoked grant, the next command fails closed and cached workspace data is purged without waiting for token expiry (SCT-25-P).
5. A pending, information-requested or rejected applicant sees only the AU-11 views and cannot reach reviewer routes.
6. Sign-out and session expiry leave no protected content in memory, cache, recent-apps snapshot or notification inbox of the next user.
7. Offline: critical actions are blocked or clearly shown as "Not yet confirmed"; no screen shows a success state before server acknowledgement; retries reuse the original `requestId`.
8. Location is collected only under the consent and scope rules in section 9.2, and its absence never blocks a delivery.
9. Every acceptance item above is executed against a real Flutter build before it is recorded as passing; this file records design only (see [test strategy](../testing/TEST_STRATEGY.md)).

## 13. Open decisions and register gaps

| Item | Description | Linked decision |
|---|---|---|
| Dual-role accounts | Whether one identity may hold supplier and rider grants, and whether customer plus partner on one login is allowed | BR-023 / DEC-033 |
| Assignment authority | Who creates assignments and whether riders can claim work; affects offer and conflict screens | BR-004 / DEC-006 |
| Switch block while on duty | Whether a rider may switch workspace with an open delivery | open design decision, refer to BR-023 |
| Offline evidence outbox | Whether proof, COD collection and receipt captures may be stored locally as "Not yet confirmed" | DEC-012 |
| Preparation and handoff states | Cooking states and handoff semantics | DEC-014 |
| One binary or two | Whether the two workspaces ship in one binary (stated by the master prompt) or as flavours of one codebase | PROPOSED structure; confirm in a monorepo ADR |
| Router and state management | Single choices to be recorded in an ADR | ADR-004 |
| Maps, routing and call-masking providers | Cost, privacy and operational choice | integration roadmap |
| Register gaps | No registered command for kitchen online status, rider duty status or assignment decline; the API author decides whether these are new names or decision values of existing commands | [conventions](../analysis/CONVENTIONS_AND_ID_REGISTER.md) section 6 |
