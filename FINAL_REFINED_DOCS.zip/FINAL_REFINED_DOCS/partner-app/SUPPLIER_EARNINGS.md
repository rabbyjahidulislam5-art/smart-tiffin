# Supplier earnings (Partner App)

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Partner App domain author |
| Purpose | Define the supplier-facing earnings balances, statement detail and payout request flow. |
| Applies to | PAR (supplier workspace) |
| Depends on | [database/FINANCIAL_DATA_MODEL.md](../database/FINANCIAL_DATA_MODEL.md), [api/COMMANDS_EARNINGS_AND_PAYOUTS.md](../api/COMMANDS_EARNINGS_AND_PAYOUTS.md), BR-009, BR-010 |
| Status | PROPOSED — NOT APPROVED. |

## Balance classes shown (glossary §4 qualifiers)

Expected (projected from committed future obligations, informational only); earned (recognised per BR-010's approved milestone); held (restricted by a dispute/compliance hold); eligible (earned minus held minus already-settled); settled (confirmed by external transfer). The legacy S-08 static sample figures are replaced by these five ledger-backed numbers, shown separately, never merged (fixes conflict register C-07).

## Statement detail (NS-01)

Every earning entry links to its source order/obligation and the exact recognition event that triggered it, with any platform deduction (commission, BR-009) itemised.

## Payout request flow (NS-02, NS-03)

Open Earnings → view eligible balance → request an amount (≤ eligible) → select/confirm an approved destination → submit → track through Accounts' review/approval/batch/settlement (never shown as completed before `recordPayoutResult` confirms external transfer, per [accounts-web/PAYOUT_MANAGEMENT.md](../accounts-web/PAYOUT_MANAGEMENT.md)).

## Acceptance and verification

Design-only. Verification requires SC-01 (prepaid service before fulfilment) and SC-07 (kitchen discontinuity) to show the correct earned-vs-expected distinction.
