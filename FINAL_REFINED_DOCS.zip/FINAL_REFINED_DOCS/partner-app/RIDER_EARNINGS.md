# Rider earnings (Partner App)

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Partner App domain author |
| Purpose | Define the rider-facing earnings balances, per-delivery breakdown and payout flow, strictly separated from COD custody. |
| Applies to | PAR (rider workspace) |
| Depends on | [database/FINANCIAL_DATA_MODEL.md](../database/FINANCIAL_DATA_MODEL.md), BR-011, BR-026 |
| Status | PROPOSED — NOT APPROVED. |

## Balance classes shown

Expected/assigned (projected, no withdrawable value); confirmed (recognised on verified delivery completion, `ent.RiderEarning`); eligible (confirmed minus holds minus settled); settled. Shown **alongside but never combined with** the rider's COD liability (see [COD_COLLECTION.md](COD_COLLECTION.md)) — fixes the legacy prototype's illustrative, undifferentiated "earnings" statistic (conflict register C-07).

## Per-delivery breakdown (NR-01)

Every delivery shows its own expected, confirmed and (if applicable) reversed amount, with a dispute-correction path for an eligible error.

## Payout flow (NR-02)

Request a withdrawal against the eligible balance only; the screen explicitly shows the separate COD liability so a rider never mistakes "cash I'm holding" for "money I can request."

## Reassignment (no double payment, Workflow WF-J)

If a delivery is reassigned, the original rider's expected earning is reversed (if it had been recognised prematurely) and only the completing rider is paid (SC-08).

## Acceptance and verification

Design-only. Verification requires SC-12 (rider payout while COD owed) to display the two balances independently and never net them without an explicit BR-026 approval.
