# Rider modules (Partner App)

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Partner App domain author |
| Purpose | Define the rider workspace: duty status, assignment offers, pickup, navigation, proof of delivery, SOS, queue and history. |
| Applies to | PAR (rider workspace) |
| Depends on | [partner-app/PARTNER_APP_ARCHITECTURE.md](PARTNER_APP_ARCHITECTURE.md), [api/COMMANDS_DELIVERY.md](../api/COMMANDS_DELIVERY.md) |
| Status | PROPOSED — NOT APPROVED. |

## 1. Duty status and assignment offers

Legacy R-01 duty toggle preserved; going off-duty is confirmed, going on-duty is immediate. `offerAssignment`/`acceptAssignment` prevent two riders from holding the same assignment (conflict resolved by first-accept-wins; the losing rider sees an honest "already taken" state, SC-08).

## 2. Pickup and navigation

`confirmPickup` after kitchen handoff (`recordHandoff`); turn-by-turn (legacy R-02) remains a navigation aid, not a source of authoritative delivery state.

## 3. Proof of delivery (R-03)

OTP or photo, with the privacy safeguard that the OTP is never logged in clear and a photo evidence reference is stored, not inlined in a command payload (16 KB cap). `submitDeliveryProof` is the only path to Delivered.

## 4. Missing customer / delivery failure (NR-06, SC-21)

A documented waiting-time policy and privacy-preserving contact attempt (masked number) precede `reportDeliveryFailure`; this never silently becomes a Delivered state.

## 5. SOS (R-05)

Safety contact and incident flow preserved from the legacy prototype; the real emergency destination and responsible operator must be approved before this is anything more than a design (no arbitrary emergency number).

## 6. Queue and history (R-06, R-07)

Upcoming offers and completed-delivery history, filterable by period (fixes the legacy "Today/This week" filter that did nothing).

## Acceptance and verification

Design-only. Verification requires SC-08 (simultaneous pickup race) and SC-21 (missing customer) to produce their documented outcomes.
