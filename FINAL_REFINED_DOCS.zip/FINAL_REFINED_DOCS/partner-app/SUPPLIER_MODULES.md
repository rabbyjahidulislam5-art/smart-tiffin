# Supplier workspace modules

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Partner App specification owner (author D2) |
| Purpose | Specify every module of the Supplier/Kitchen Partner workspace: what each does, which rules bind it, which commands and entities it uses, and how it behaves when things go wrong. |
| Applies to | PAR-S (Partner App, supplier workspace) |
| Depends on | [Partner App architecture](PARTNER_APP_ARCHITECTURE.md), [supplier screens](../design/screens/SUPPLIER_SCREENS.md), [conventions](../analysis/CONVENTIONS_AND_ID_REGISTER.md), [glossary](../requirements/GLOSSARY_AND_TERMINOLOGY.md), [functional requirements](../requirements/FUNCTIONAL_REQUIREMENTS.md), [data flow](../architecture/DATA_FLOW.md), [time and cutoff policy](../architecture/TIME_AND_CUTOFF_POLICY.md) |
| Authoritative policies | BR-001 (pause and skip), BR-004 (assignment), BR-005 (cancellation), BR-007 (delivery charges), BR-010 (earning recognition), BR-017 (substitutions), BR-022 (cutoff), BR-024 (kitchen discontinuity and compliance lapse); DEC-014 (preparation and delivery exceptions). All PENDING. |
| Status | Draft for review. Nothing is implemented or approved. Prototype status letters (I interactive, U UI-only, S simulated) describe the legacy React prototype only. |

Earnings and payout behaviour is specified in [supplier earnings](SUPPLIER_EARNINGS.md). Kitchen-side pickup meets the rider side in [rider modules](RIDER_MODULES.md). Reviewer behaviour for documents is in [approval workflows](../admin-web/APPROVAL_WORKFLOWS.md).

## 1. Module map

| Module | Purpose | Screens | Provenance |
|---|---|---|---|
| M1 Kitchen dashboard and online status | See and control whether the kitchen takes orders; see the day at a glance | S-01 | OBSERVED (I), extended |
| M2 Orders and requests | Accept or decline one-time order requests; list all orders | S-02, S-06 | OBSERVED, extended |
| M3 Preparation stages | Move accepted work through legal preparation states | S-02 (stage timeline), S-01 (kitchen flow) | OBSERVED, DEC-014 PENDING |
| M4 Cooking requirements | Daily quantities to cook, by slot and meal | S-03 | OBSERVED (U), made live |
| M5 Menu and stock | Categories, meals, variants, photos, availability, stock | S-04, S-05 | OBSERVED, made durable |
| M6 Price and version manager | Schedule price changes without touching paid quotes | NS-06 | PROPOSED |
| M7 Capacity scheduler | Daily and slot production limits and closures | NS-05 | PROPOSED |
| M8 Subscription commitments and forecast | Future portions committed by date | S-07, NS-04 | OBSERVED (U), PROPOSED forecast |
| M9 Pickup handoff | Hand the meal to the assigned rider with verification | NS-07 | PROPOSED |
| M10 Kitchen profile, documents and expiry | Public profile, verification documents, renewals | S-10, S-11 | OBSERVED, extended |
| M11 Operating settings | Meal times, working days, capacity link, payout destination link | S-12 | OBSERVED (not saved), made durable |
| M12 Earnings and payouts | Balances, statements, payout requests, history | S-08, S-09, NS-01, NS-02, NS-03 | see [supplier earnings](SUPPLIER_EARNINGS.md) |
| M13 Notifications and support | Inbox, chat, help, tickets, settings | SH-01, SH-02, SH-04…SH-10 (@PAR-S) | OBSERVED |

Legacy control preservation: every control listed for S-01…S-12 in the prototype appears in the tables below or in the linked screen contract. The migration action per legacy screen is recorded in the complete screen inventory; the tables here state the proposed action.

| Legacy screen | Proposed action | Summary |
|---|---|---|
| S-01 | Extend | Live status, cooking batches, accept and decline retained; earned and available balances shown separately |
| S-02 | Reuse | Request detail with decline reason sheet, accept, stage timeline, mark packed (now "Ready") |
| S-03 | Extend | Made live from obligations |
| S-04 | Extend | Durable persistence, capacity check, impact analysis |
| S-05 | Extend | Durable persistence, price through price versions |
| S-06 | Reuse | New, Cooking, Handed off lists become live |
| S-07 | Extend | Real commitments by date, portion, slot, cancellation state |
| S-08 | Replace | Ledger-backed expected, earned, held, eligible, settled |
| S-09 | Extend | Submitted, approved, processing, failed, settled distinguished |
| S-10 | Extend | Profile with verified badge tied to document state |
| S-11 | Extend | Real upload, expiry, review states |
| S-12 | Extend | Durable settings; payout account handled as a sensitive change |

## 2. M1 Kitchen dashboard and online status (S-01, SH-01 entry)

| Element | Behaviour |
|---|---|
| Header | Eyebrow "Kitchen live" or "Kitchen offline"; notification bell with unread count from the inbox (not a constant); avatar and kitchen name open S-10. |
| Online toggle | Switching on: server checks the kitchen is verified, documents are valid, today's menu exists. Switching off: confirmation "Go offline?" explaining what stops (new one-time order requests and new customer purchases of this kitchen's meals) and what does not (existing prepaid subscription obligations and accepted orders remain commitments). If future commitments exist, a reason category and expected return date or "unknown" are required and a continuity case is opened for Admin review (BR-024, scenario SC-07). The kitchen is not allowed to cancel commitments by going offline. |
| Quick actions | Menu S-04, Orders S-06, Cooking S-03; More: Earnings S-08, Commitments S-07, Payouts S-09, Kitchen profile S-10, Documents S-11, Operating S-12, Alerts SH-09, Support SH-04 (OBSERVED, preserved). Added: Capacity NS-05, Price manager NS-06, Forecast NS-04, Handoff NS-07. |
| Stat tiles | Today's orders (to S-06) and Today's earnings (to S-08). The earnings tile shows the qualifier ("Expected today" or "Earned today") and "as of" time. Earned and available balances are two separate figures (prototype instruction for S-01). |
| Cooking summary | Next cooking batch header and batches open S-03. |
| Kitchen flow | Stage control for the active batch uses the preparation states in M3; the Ready step asks for confirmation. |
| Live order requests | Request cards (M2). Pending count opens S-06. |
| Today's menu and stock | List of today's items with availability toggles (to S-05 for edit, S-04 for full list). |
| Alerts strip | Document expiring, continuity case open, payout hold, capacity exceeded, requests about to expire. Each alert has one action. |
| States | Loading skeleton, empty ("No orders yet today"), offline banner with cached time, kitchen suspended (restricted mode with reason), permission denied, session expired. |

Command used for online status: no command is registered for a kitchen-level availability change. The registered `setAvailability` changes a food item's availability (OBSERVED, working). The kitchen-level change is reported as a register gap (see section 15).

## 3. M2 Orders and requests (S-02, S-06)

### 3.1 Two kinds of work

| Kind | Source | Does the supplier accept it? | Notes |
|---|---|---|---|
| One-time order | `ent.Order` placed by a customer (FR-028) | Yes, within the acceptance window (parameter `policy.supplier.acceptance_window_minutes`, DEC-014, no default) | Decline requires a reason; effect on the customer and any payment follows BR-005. |
| Subscription meal obligation | `ent.MealObligation` generated from an `ent.Subscription` | No. It is a prior commitment visible in cooking requirements and the forecast. | The supplier can report inability only through the continuity process (BR-024); there is no per-meal decline button. This stops a supplier cancelling paid commitments one by one. |

### 3.2 Request card and detail (S-02)

| Element | Behaviour |
|---|---|
| Card content | Order reference, slot and delivery window, items with variant and quantity, special notes and allergen flags, order value to the kitchen in the supplier's own terms (food value; platform deductions appear only in earnings), time left to respond. No customer phone number or full address. A customer first name or reference is enough for the kitchen. |
| Accept | `acceptOrder` with `expectedVersion`. The card turns to "Accepted" only after the server confirms. If the request expired, was taken back, or the stock changed, the response is shown with a refresh. |
| Decline | Opens the decline sheet. Reason required from a fixed list (out of stock, capacity full, kitchen closed, cannot meet the window, other with a note of at least five characters). `declineOrder`. The effect statement is shown before confirm ("The customer will be told this order cannot be prepared") without inventing refund terms (BR-005). |
| Expiry | If the acceptance window passes, the server applies the approved expiry behaviour (PENDING DEC-014). The UI shows "Expired" and never "Declined by you". |
| After acceptance | Stage timeline, Mark Ready, rows for area, window, "Call customer (masked)" and "Message rider" (to SH-02). Calling uses the masked relay once a call-masking provider is chosen; until then the control is hidden rather than exposing a number. |
| Orders list (S-06) | Tabs New, Cooking, Handed off (prototype static, now live); cards open S-02; a "Commitments" link opens S-07. |
| Concurrency | If two devices act on the same card, the second sees the newer state. Duplicate taps use the same `requestId`. |

### 3.3 Provisional acceptance

Given a pending one-time request, when the supplier accepts, then exactly one acceptance is recorded, the order state changes once, and the customer is notified after commit. Given a duplicate tap on a slow network, one change results and the second tap shows the same receipt (scenario pattern SCT-04-L applied to acceptance).

## 4. M3 Preparation stages

The prototype shows a kitchen-flow control with Prepped, Preparing and Packed (OBSERVED). The glossary meal-obligation sub-states are Preparing, Ready and Handed Off. Final cooking transitions are PENDING under DEC-014.

```mermaid
stateDiagram-v2
  [*] --> Accepted
  Accepted --> Preparing: advancePreparation
  Preparing --> Ready: advancePreparation after confirmation
  Ready --> HandedOff: recordHandoff
  HandedOff --> [*]
  Preparing --> Accepted: correction by authorised exception only
```

| Rule | Detail |
|---|---|
| Mapping from prototype | Packed corresponds to Ready (PROPOSED). Prepped is an optional supplier-side checklist step shown inside Preparing (not a separate legal state) until DEC-014 decides. |
| Forward only | Transitions go forward one step at a time through `advancePreparation` with `expectedVersion`. A backward correction needs an authorised exception with a reason and an audit entry (DEC-014). |
| Preparation is not delivery | Preparation state and delivery state are separate dimensions. Ready does not mean Picked Up. The confirmed delivery chain Pending, Picked Up, On The Way, Delivered is not touched by the kitchen. |
| Confirmation at Ready | The Ready step shows what is being declared ("All items packed and sealed for pickup") and requires confirmation, as the prototype did for Packed. |
| Customer visibility | Customers see preparation progress only as far as product design allows; this module only records it. |
| Late change | If the customer cancels or the obligation is changed before Ready, the card shows the new state and the reason; cooking totals (M4) update. |

## 5. M4 Cooking requirements (S-03)

| Element | Behaviour |
|---|---|
| Aggregation | For a selected service date and slot: portions per meal and variant = eligible subscription obligations plus accepted direct orders, excluding approved pauses, skips and applicable cancellations, without double counting (FR-016). Derived from `ent.MealObligation` and `ent.OrderItem`. |
| Segmented control | Slot selector (Breakfast, Lunch, Snack, Dinner) using slot identifiers, not translated labels. Only slots the kitchen offers appear. |
| Progress | Progress bars per meal for prepared versus required portions. Prepared counts are entered by the kitchen and are informational; they do not change obligation state. |
| Ingredients | The prototype showed static ingredients. Ingredient totals appear only when the supplier has entered per-variant quantities; otherwise only portions and allergen notes are shown. (PROPOSED) |
| Change feed | "Changed since you last looked" lists pauses, skips, replacements and cancellations that altered today's or tomorrow's totals, with the time of change and whether the cutoff has already passed. |
| Freeze marker | After the slot cutoff (policy BR-001/BR-022, evaluated by the server) totals are marked Final and later changes are highlighted as exceptions. |
| Offline | Last cached totals are shown labelled with their time. |
| Acceptance | Daily totals equal approved eligible quantities exactly once (AC-016); a paused or skipped obligation is excluded; an obligation is never counted both as an order and as a subscription meal. |

## 6. M5 Menu and stock (S-04, S-05)

| Capability | Detail | Commands | Entities |
|---|---|---|---|
| Categories and meals | Create, edit, archive meals with English and Bangla names (English required, Bangla recommended), description, ingredient and allergen information, photo | `saveFood`, `saveMenu`, `savePlan` (OBSERVED, working) | `ent.MealCategory`, `ent.Meal`, `ent.Plan` |
| Variants | Portion sizes and options, each with its own price version | `saveMealVariant` | `ent.MealVariant` |
| Slot availability | Which slots (breakfast, lunch, snack, dinner) and which weekdays a meal is offered; temporarily unavailable flag with optional until-time | `setSlotAvailability`, `setAvailability` | `ent.SlotAvailability` |
| Daily and weekly menus | Compose menus per date and slot from the kitchen's meals | `saveMenu` | `ent.Meal`, menu records |
| Stock | Supplier enters available quantity per meal per slot per date. The platform reserves stock atomically for customers (FR-046, scenario SC-20); the supplier sees quantity available, reserved and remaining. | `reserveStock`, `releaseStock` are server-internal | `ent.StockReservation` |
| Photos | Upload with size and type limits; failure shows a fallback and retry; no broken-image state affecting action reach | `saveEvidence`-style upload to protected media storage (storage rules) | media records |

Rules:

1. No kitchen, meal, price or subscription duration is hard-coded in business logic (USER-REQ).
2. Saves are durable: the prototype's Save toast (S-05) is replaced by acknowledged persistence. The screen shows Saved only after the server confirms, and keeps the draft on failure.
3. Stock and availability changes run a capacity and commitment check. Lowering stock below existing reservations, or marking unavailable a meal that has future subscription obligations, shows an impact preview (number of obligations, dates, customers affected, without personal data) and either blocks the change or routes it into the continuity process (BR-024). The supplier cannot silently strand paid commitments.
4. Delete is archive: a meal referenced by history or obligations is archived and hidden from new purchases, never erased.
5. Day chips in the meal form (static in the prototype) now store real weekday availability.
6. Stale edits: saving over a newer version shows the difference and requires a refresh.
7. Price fields on the meal form do not write a price directly. They create a price version through M6 so that paid quotations keep their snapshot (ADR-009, INV-18).

## 7. M6 Price and version manager (NS-06)

| Element | Behaviour |
|---|---|
| Price history | For each meal variant: version list with effective-from date, value in BDT minor units (shown with two decimals), author, reason, and the number of active commitments and open quotes still bound to earlier versions. |
| Schedule a change | `schedulePriceChange` with an effective date and time. The earliest allowed effective time is governed by `policy.price_change.minimum_notice_hours` (no default value) and by the cutoff rules (BR-022). Changes take effect for new quotations only. |
| Paid quotations | Existing quotations and obligations keep their price snapshot after menu changes (USER-REQ pricing transparency; ADR-009). The screen states this next to the Schedule action. |
| Subscriptions | Whether a price change reaches future obligations of an existing subscription (renewal versus immediate) is a pricing and billing decision (BR-002, BR-008) and is not decided here. The screen shows the policy result returned by the server. |
| Audit | Every version records the author identity, time and reason. A scheduled but not yet effective version can be cancelled; an effective version cannot be edited, only superseded. |
| Validation | Price greater than zero in minor units; effective time in the future; no overlap of effective ranges per variant. Currency is fixed (BDT, DEC-008 PROPOSED). |
| Notifications | Customers with affected renewals or drafts are informed through the Customer App by the platform, not by the supplier. |

## 8. M7 Capacity scheduler (NS-05)

| Element | Behaviour |
|---|---|
| Capacity grid | Per date and slot: maximum portions (and optional per-meal maximum), closures (holiday, maintenance), and the count already committed by obligations and orders. Capacity is `ent.KitchenCapacity`; saved with `saveCapacity`. |
| Recurring defaults | Operating settings (M11) supply default capacity per slot and working days; the scheduler overrides single dates. |
| Impossible ordering | Capacity at or below commitments blocks new purchases. The scheduler rejects a reduction below existing commitments and offers the continuity process instead (BR-024). |
| Alerts | When a change affects subscribers, the platform (not the supplier app) decides notification text and timing; the supplier sees "N customers will be informed". |
| Cutoff | Capacity edits near a cutoff use the server's time. The screen shows the cutoff time (BR-022) and says when a date has become locked. |
| Concurrency | Stock reservations by customers continue while the supplier edits; save uses `expectedVersion` and never overwrites reservations. |

## 9. M8 Subscription commitments and forecast (S-07, NS-04)

| Element | Behaviour |
|---|---|
| Commitments list (S-07) | Future obligations of this kitchen only, grouped by date and slot: portions, meal and variant, state (Scheduled, Skipped, Replaced, Cancelled), and whether the cutoff has passed. Customer identity is a short reference; no addresses or phone numbers. |
| Cancellation state | Pauses, skips and cancellations are visible as state changes with timestamps; they reduce totals once. |
| Forecast (NS-04) | Calendar and table of future portions by date, slot, meal and delivery window, with capacity overlay. A user can see which dates exceed capacity and which cancellations are still possible before cutoff. |
| Resource planning | Totals are advisory for purchasing and staffing; they are not orders and carry no payment promise. |
| Honesty | Forecast figures come from obligations only. Expected earnings from the forecast are labelled "Expected" and are not balances. |
| Privacy | A supplier cannot read another supplier's subscriptions or any customer's payment data. |

## 10. M9 Pickup handoff (NS-07)

| Step | Behaviour |
|---|---|
| Readiness | The handoff screen lists orders and obligations in state Ready for the assigned rider, with item counts and seal check boxes (items counted, containers sealed). |
| Rider identity | Shows the assigned rider's first name, photo and vehicle type from the current assignment. Only the current assignee is accepted. |
| Pickup code | The rider shows a short-lived code tied to the current assignment. The kitchen enters or scans it. The code changes when the assignment changes. (PROPOSED) |
| Confirm | `recordHandoff` records the custody transfer (time, kitchen user, rider, items). It sets the obligation to Handed Off. It does not complete the delivery; the rider's `confirmPickup` moves the delivery from Pending to Picked Up. |
| Mismatch | Wrong rider, missing items, or damaged packaging: record an exception with a reason and photo; the system notifies dispatch. The kitchen must not hand over to an unassigned person. |
| Races (scenario SC-08) | If a replaced rider reappears, the server rejects the old assignment; the screen shows "This rider is no longer assigned" and no custody is recorded. Two riders cannot both be accepted. |
| No premature completion | Handoff never sets Delivered, never recognises earnings, and never closes COD. |

## 11. M10 Kitchen profile, documents and expiry (S-10, S-11, scenario SC-17)

| Element | Behaviour |
|---|---|
| Profile (S-10) | Kitchen name, description, service areas (from approved zones), operating hours, slots, photos, contact. Public fields are separated from private fields. Edit opens SH-08 (extended). |
| Sensitive changes | Business name, payout owner and NID changes require re-verification (OBSERVED prototype flow "Confirm it's you") and enter a review queue for Admin (NA-03). The old value stays in force until approved. |
| Verified badge | The badge is derived from document state. It is not a stored flag the supplier can change. A kitchen with an expired required document shows "Verification expired", never "Verified". |
| Documents (S-11) | List: identity (NID front/back), kitchen photos, trade licence (where conditional), hygiene certificate (where conditional). Each shows status (Uploaded, In review, Verified, Expiring, Expired, Rejected), expiry date, reviewer message. Upload renewal via `saveEvidence`. Files are in protected storage; viewing is limited to the owner and reviewers. |
| Expiry warnings | Alerts begin at `policy.documents.expiry_warning_days` (no default value) before expiry, on S-01 and by notification. |
| On expiry | Under the proposed approach (BR-024, PENDING): new orders are blocked, paid commitments enter a managed-resolution queue, the supplier sees which commitments are affected and the case status, Admin reviews, and customers are told through the platform. The supplier cannot clear the block by uploading a file; only an approved review does. |
| Financial effect | Earnings for obligations that cannot be fulfilled are not recognised; a payout hold may be placed (BR-014, BR-015). The supplier sees a hold with its reason (see [supplier earnings](SUPPLIER_EARNINGS.md)). |
| Client bypass | No client-side path can restore ordering. State comes from the server. |

## 12. M11 Operating settings (S-12)

| Setting | Behaviour |
|---|---|
| Meal time shifts | Slots offered and cooking windows. Stored as slot identifiers with local times in the service time zone ([time policy](../architecture/TIME_AND_CUTOFF_POLICY.md)). |
| Working days | Weekday patterns, plus closures through M7. |
| Maximum tiffins | Default capacity per slot, feeding M7. |
| Payout account | Opens the payout destination management in the earnings module. Changes are sensitive: step-up verification, Accounts verification of the beneficiary, and a hold period `policy.payout.destination_change_hold_hours` (no default). Masked display only. |
| Persistence | Replaces the prototype toast. Save shows success only after acknowledgement; failure keeps edits. Command: `saveSettings` (registered, policy-gated). |
| Effect on commitments | Reducing offered slots or days that have future obligations triggers the impact preview and the continuity process (BR-024). |

## 13. Scenario treatment

### SC-07 Supplier kitchen stops accepting orders

| Moment | Supplier workspace |
|---|---|
| Request received | Supplier sets Offline with a reason while commitments exist. |
| Command accepted | The kitchen stops receiving new one-time orders at once. A continuity case is created; existing obligations are untouched. |
| Decision (not the supplier) | Admin chooses among options such as fulfil as scheduled, temporary hold, contact customers, authorised replacement kitchen with customer consent, or cancel with credit (BR-024, BR-005, BR-006). Approver and policy are PENDING. |
| Supplier view | Case status (Open, Under review, Resolved), list of affected obligations, no ability to cancel them, and instructions. Earnings for unfulfilled obligations are not recognised. |
| Financial reconciliation | Payments stay as prepaid obligations until fulfilled, credited or refunded under approved policy; rider assignments for affected obligations are held by Admin (NA-04). |
| Failure cases | Supplier goes offline while the app is offline: the action is blocked with a reason. Supplier closes the app: the server state remains; the kitchen status reads the server on next start. |

### SC-17 Supplier loses hygiene certification

Documented in M10. Acceptance: a badge never shows Verified when a required document is expired; ordering stays blocked until an approved review; commitments move to managed resolution; a client edit cannot change the state.

## 14. Screens, commands, entities and acceptance

### 14.1 Commands used

| Registered command | Use | Status in the register |
|---|---|---|
| `acceptOrder`, `declineOrder`, `advancePreparation` | M2, M3 | OBSERVED, policy-gated (DEC-014, BR-005) |
| `saveFood`, `savePlan`, `saveMenu`, `setAvailability` | M5 | OBSERVED, working |
| `saveMealVariant`, `setSlotAvailability`, `schedulePriceChange`, `saveCapacity` | M5 to M7 | PROPOSED |
| `reserveStock`, `releaseStock` | M5 (server-internal) | PROPOSED |
| `recordHandoff` | M9 | PROPOSED |
| `saveKitchenProfile`, `saveEvidence`, `saveSettings`, `saveProfile` | M10, M11 | OBSERVED or PROPOSED per the register |
| `requestPayout` and read models of `ent.SupplierEarning` | M12 | PROPOSED |

### 14.2 Entities touched

`ent.Supplier`, `ent.Kitchen`, `ent.Meal`, `ent.MealCategory`, `ent.MealVariant`, `ent.PriceVersion`, `ent.SlotAvailability`, `ent.KitchenCapacity`, `ent.StockReservation`, `ent.Plan`, `ent.Order`, `ent.OrderItem`, `ent.MealObligation`, `ent.DeliveryAssignment`, `ent.ApplicationDocument`, `ent.Hold`, `ent.SupplierEarning`, `ent.Notification`, `ent.AuditEvent`.

### 14.3 Acceptance conditions

1. A supplier reads and writes only their own kitchen's data. A request for another supplier's order, obligation, menu or earnings returns a permission result and discloses nothing (tests SCT-07-P and SCT-11-P patterns).
2. Accept or decline of a request produces exactly one state change under duplicate taps and retries; success is shown only after acknowledgement.
3. Cooking totals equal eligible obligations plus accepted orders, with each counted once.
4. A price change never alters a paid quotation or an existing obligation snapshot.
5. Going offline never cancels a commitment; it opens a continuity case when commitments exist.
6. Expiry of a required document blocks new orders and shows Verification expired, and the supplier cannot clear this client-side.
7. Handoff only succeeds for the current assignee and never sets Delivered.
8. Every supplier screen renders loading, empty, error, offline, denied and stale states, in English and Bangla, at large text scale (see [Partner UI/UX](PARTNER_UI_UX.md)).
9. These conditions are verified only by executed tests recorded in the testing documents; this file records the design.

## 15. Open decisions and register gaps

| Item | Linked decision |
|---|---|
| Acceptance window length and the expiry outcome of an unanswered request | DEC-014, BR-004 |
| Final cooking states and the meaning of Prepped | DEC-014 |
| Who approves continuity options for a stopped kitchen, and what the customer is owed | BR-024, BR-005, BR-006 |
| Cutoffs for pause, skip and supplier-side change | BR-001, BR-022 |
| Whether a price change reaches existing subscriptions | BR-002, BR-008 |
| Minimum notice for price changes | PENDING, parameter `policy.price_change.minimum_notice_hours` |
| Call-masking provider for customer and rider contact | integration roadmap |
| Register gap: no command for kitchen-level availability (online status). Candidate: extend `setAvailability` or register a kitchen availability command. | API register |
| Register gap: ingredient and recipe quantities have no entity | database design |
