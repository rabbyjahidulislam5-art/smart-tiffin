# Cash-on-delivery payment workflow

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Payments architect |
| Purpose | Separately define the four COD models the master prompt requires, each with its own eligibility, limit, remittance and discrepancy handling. |
| Depends on | [Payment architecture](PAYMENT_ARCHITECTURE.md), [api/COMMANDS_PAYMENTS_AND_COD.md](../api/COMMANDS_PAYMENTS_AND_COD.md), [glossary §4](../requirements/GLOSSARY_AND_TERMINOLOGY.md) |
| Authoritative policies | BR-012 (eligibility/limits), BR-013 (remittance deadlines), BR-016 (unpaid/postpaid), BR-026 (netting) — all PENDING |
| Status | PROPOSED — NOT APPROVED. No numeric limit or deadline is set. |

## 1. The four models (never conflated)

| Model | Collection unit | Remittance cadence | Governing rule |
|---|---|---|---|
| **M1 — Individual order** | One one-time order | Per delivery, immediately due for remittance | BR-012 |
| **M2 — Per scheduled meal** | One `ent.MealObligation` | Per delivery, immediately due | BR-012 |
| **M3 — Approved weekly collection** | All of a customer's COD-eligible obligations in a week | Weekly batch, one remittance | BR-012 + explicit approval |
| **M4 — Approved monthly settlement/postpaid** | All of a customer's COD-eligible obligations in a month | Monthly, against an approved credit limit | BR-012 + BR-016 |

A customer, order or obligation is tagged with exactly one model at creation time; the UI and the commands behave differently per model (the legacy prototype's single COD checkbox is explicitly superseded).

## 2. State machine (per collection)

```mermaid
stateDiagram-v2
  Recorded --> Confirmed: recordCodCollection
  Confirmed --> DueForRemittance
  DueForRemittance --> PartiallyRemitted: submitCodRemittance (partial)
  DueForRemittance --> RemittedPendingVerification: submitCodRemittance (full)
  PartiallyRemitted --> RemittedPendingVerification: further submission
  RemittedPendingVerification --> Verified: verifyCodRemittance
  DueForRemittance --> Overdue: policy.cod.remittance_deadline_hours elapsed
  RemittedPendingVerification --> Disputed: flagCodDiscrepancy
  Disputed --> Verified: resolveCodDiscrepancy (matched)
  Disputed --> WrittenOff: resolveCodDiscrepancy (approved write-off)
```

## 3. Eligibility and limits (BR-012, PENDING)

Per-order and outstanding-balance limits are named parameters (`policy.cod.max_order_amount`, `policy.cod.max_outstanding_per_customer`) with no approved value. Until approved, M1 is treated as the only enabled model; M2–M4 remain designed but disabled.

## 4. Remittance deadline and overdue handling (BR-013, PENDING)

`policy.cod.remittance_deadline_hours` governs when a `DueForRemittance` collection becomes `Overdue`, triggering the `cod.remittance_overdue` notification (see [api/EVENT_AND_NOTIFICATION_DESIGN.md](../api/EVENT_AND_NOTIFICATION_DESIGN.md)) to both the rider and Accounts. Overdue status never auto-blocks a rider's payout by itself — any such link requires an explicit BR-026 netting approval.

## 5. Discrepancy handling (SC-09)

A mismatch between the invoiced amount, the amount the rider reports collecting, and the amount actually remitted is never resolved by adjusting the rider's personal earnings record. `flagCodDiscrepancy` creates a distinct case reviewed by Accounts; `resolveCodDiscrepancy` requires an AcMgr decision (checking an AcOp-prepared resolution) and posts either `codWrittenOff` (an approved loss) or `adjustmentPosted` (a correction), never a silent balance edit.

## 6. Rider-held cash is never rider income

Collected cash belongs to the company until remitted and verified (glossary). A rider's earnings dashboard (see [partner-app/RIDER_EARNINGS.md](../partner-app/RIDER_EARNINGS.md)) shows the COD liability separately from the earned-compensation balance, with no automatic offset (BR-026 PENDING, SC-12).

## Acceptance and verification

Design-only. Verification requires: each of the four models producing its documented collection/remittance cadence in a simulated test; a duplicate deposit reference rejected (INV-12); a discrepancy never silently absorbed into rider earnings.

## Open decisions

BR-012, BR-013, BR-016, BR-026 — all PENDING, no value approved.
