# Pricing and billing engine

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Payments architect |
| Purpose | Define the quote line structure, delivery-fee policies by purchase type, billing models, and a worked HYPOTHETICAL example whose totals agree across quote, invoice, payment and ledger. |
| Depends on | [ADR-009](../adr/009-quote-and-price-snapshots.md), [database/FINANCIAL_DATA_MODEL.md](../database/FINANCIAL_DATA_MODEL.md), [glossary](../requirements/GLOSSARY_AND_TERMINOLOGY.md) |
| Authoritative policies | BR-002 (billing basis), BR-007 (delivery fees), BR-008 (discounts), BR-009 (commission), BR-018 (tax) — all PENDING |
| Status | PROPOSED — NOT APPROVED. All figures HYPOTHETICAL. |

## 1. Quote line structure (server-authoritative, ADR-009)

Every `ent.Quote` separately itemises: food subtotal; quantity/variant adjustments; subscription or promotional discount (BR-008); delivery charge (BR-007); platform service fee; tax (BR-018, off until approved); applied service credit (negative line); prior adjustment reference if any; final payable. No line is computed client-side (NFR-017).

## 2. Delivery fee policies by purchase type (BR-007, PENDING)

| Purchase type | Policy shape (PROPOSED, no value) |
|---|---|
| One-time order | `policy.delivery.one_time_fee` per zone band |
| Daily plan | `policy.delivery.daily_fee` per zone band, may differ from one-time |
| Weekly subscription | `policy.delivery.weekly_fee` per trip, with a grouped-delivery discount if multiple slots ship together |
| Monthly subscription | `policy.delivery.monthly_fee`, same grouping rule |
| Multiple meals delivered together | One `policy.delivery.grouped_trip_fee`, not one fee per meal |
| Separate deliveries per slot | `policy.delivery.per_slot_fee`, when a customer explicitly requests separate trips |
| Distance/zone | `policy.delivery.zone_band[]`, keyed by `ent.ServiceZone` |

## 3. Billing models (BR-002, PENDING)

One-time payment at checkout; weekly prepaid (billed at the start of each week); monthly prepaid (billed at subscription start/renewal); approved pay-on-delivery (COD models in [COD_PAYMENT_WORKFLOW.md](COD_PAYMENT_WORKFLOW.md)); future recurring billing where technically supported. **Subscription duration and payment frequency are independent settings** (glossary): a monthly-duration agreement may be billed weekly if BR-002 approves that combination.

## 4. Revised quotations and customer confirmation

Any plan change produces a new quote with a visible before/after comparison; the customer must explicitly confirm before a new amount is charged (USER-REQ: never silently charge a new amount).

## 5. Worked example (HYPOTHETICAL, BDT, integer minor units)

A customer subscribes to a monthly lunch+dinner plan.

| Line | Amount (minor units) | Amount (BDT) |
|---|---|---|
| Food subtotal (26 lunches + 26 dinners, illustrative per-meal prices) | 650,000 | 6,500.00 |
| Subscription discount (illustrative 5%) | −32,500 | −325.00 |
| Delivery fee (illustrative grouped monthly rate) | 102,500 | 1,025.00 |
| Platform service fee (illustrative) | 0 | 0.00 |
| Tax | 0 (BR-018 not approved) | 0.00 |
| **Quote total** | **720,000** | **7,200.00** |

This exact 720,000 figure is the one posted in [database/FINANCIAL_DATA_MODEL.md](../database/FINANCIAL_DATA_MODEL.md) §6's worked ledger example, demonstrating INV-18 (quote = invoice = payment = journal total). All rates are illustrative and **not approved**.

## 6. Separation of supplier earnings, rider payouts and company revenue

None of the three is derived from the customer total directly; each is computed from its own recognition event (BR-009, BR-010, BR-011) against the posted journals, never as a percentage guessed at checkout time.

## Acceptance and verification

Design-only. Verification requires an automated test that the worked-example totals reconcile across every downstream document (INV-18) and that a revised quotation always requires explicit customer confirmation before charging a different amount.

## Open decisions

BR-002, BR-007, BR-008, BR-009, BR-018 — all PENDING.
