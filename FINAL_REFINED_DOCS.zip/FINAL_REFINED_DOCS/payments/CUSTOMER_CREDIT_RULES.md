# Customer credit rules

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Payments architect |
| Purpose | Define the credit classes, formulas (as named parameters), worked HYPOTHETICAL examples, and the hard rule that credit is never cash. |
| Depends on | [Glossary](../requirements/GLOSSARY_AND_TERMINOLOGY.md) §1, [database/FINANCIAL_DATA_MODEL.md](../database/FINANCIAL_DATA_MODEL.md), [ADR-006](../adr/006-double-entry-ledger.md) |
| Authoritative policies | BR-006 (eligibility/formula), BR-017 (substitutions), BR-019 (expiry), BR-025 (legal status) — all PENDING |
| Status | PROPOSED — NOT APPROVED. All figures HYPOTHETICAL. |

## 1. Credit classes (never merged)

| Class | Source | Can it ever be cash? |
|---|---|---|
| Service credit | Approved skip/pause/cancellation adjustment (BR-006) | No, unless BR-025 is separately approved |
| Promotional credit | Marketing incentive, its own eligibility | No, unless separately approved |
| Gateway refund | Actual money returned via the gateway | Yes — but this is not a "credit", it is cash (see [payments/PAYMENT_ARCHITECTURE.md](PAYMENT_ARCHITECTURE.md)) |

Storing these separately (`ent.CreditTransaction.type`) prevents a promotional incentive from silently becoming a cash refund (SC-23).

## 2. Formula templates (BR-006, PENDING — no value approved)

| Scenario | Formula shape (PROPOSED) |
|---|---|
| Skip one meal | `creditMinor = obligation.priceSnapshot.foodMinor * policy.credit.skip_factor` (delivery-fee component per BR-007 outcome) |
| Skip several meals | Sum of the single-meal formula per obligation, one credit transaction per origin (INV-08) |
| Pause a slot | No credit unless the paused slot was already paid and BR-006 approves a pause-credit path |
| Upgrade (customer pays more) | `chargeMinor = newPrice - oldPrice`, charged, not credited |
| Downgrade (customer pays less) | `creditMinor = oldPrice - newPrice`, per BR-017 |
| Partial cancellation | `creditMinor = sum(unfulfilled obligation prices) - approved fee (BR-005)` |
| Credit utilisation | `consumeCredit` reduces `creditAccount.availableMinor` by exactly the amount applied to a new quote; never partially "spent" without a corresponding quote-line reduction |

## 3. Worked examples (HYPOTHETICAL, BDT minor units)

- Skip one lunch priced at 25,000 minor units (250.00 BDT) with an illustrative `skip_factor` of 1.0 (full food value, no delivery-fee component): credit = 25,000. This is the example used in [database/FINANCIAL_DATA_MODEL.md](../database/FINANCIAL_DATA_MODEL.md) §6.
- Downgrade from a 30,000-unit dinner to a 22,000-unit dinner: credit = 8,000, applied to the next invoice.
- Upgrade from a 20,000-unit dinner to a 28,000-unit dinner: charge = 8,000, collected before the obligation is confirmed, per [ADR-009](../adr/009-quote-and-price-snapshots.md).

All figures are illustrative only; no `skip_factor` or fee percentage is approved.

## 4. No double compensation (INV-17)

A refund and a credit are never both granted for the same obligation; `initiateRefund` checks for an existing `creditIssued` against the same `originId` and rejects with `double_compensation` if found (see [api/ERROR_RESPONSES.md](../api/ERROR_RESPONSES.md)).

## 5. Expiry (BR-019, PENDING)

No credit expires by default. If BR-019 is approved with an expiry period, `expireCredits` (a scheduled job) posts a `void`-type transaction per expired credit, never silently zeroing the balance without a transaction record.

## 6. Legal status (BR-025, PENDING)

Credits are never cash-out-able, transferable, or treated as stored value until BR-025 is approved following legal review (see [security/AUDIT_AND_COMPLIANCE.md](../security/AUDIT_AND_COMPLIANCE.md)).

## Acceptance and verification

Design-only. Verification requires: INV-07 (never negative), INV-08 (one credit per origin) and INV-17 (no double compensation) each demonstrated by an automated test once implemented.

## Open decisions

BR-006, BR-017, BR-019, BR-025 — all PENDING.
