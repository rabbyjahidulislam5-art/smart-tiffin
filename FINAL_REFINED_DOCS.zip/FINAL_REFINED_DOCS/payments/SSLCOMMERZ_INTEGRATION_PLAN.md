# SSLCOMMERZ integration plan

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Payments architect |
| Purpose | Prepare the complete SSLCOMMERZ integration architecture (initiation, hosted redirect, IPN, validation, refund boundary) behind the gateway abstraction, with no real credentials or transactions in this phase. |
| Depends on | [Payment architecture](PAYMENT_ARCHITECTURE.md), [ADR-007](../adr/007-payment-gateway-abstraction-and-cod.md), [api/COMMANDS_PAYMENTS_AND_COD.md](../api/COMMANDS_PAYMENTS_AND_COD.md) |
| Status | PROPOSED — NOT APPROVED. No SSLCOMMERZ credential, sandbox or live, has been requested or used by this effort. The integration details below are marked **to verify before implementation** against SSLCOMMERZ's own current official documentation; none has been independently re-confirmed by this documentation pass. |

## 1. Scope

This plan covers only sandbox-ready architecture. Real credentials are supplied later, directly by the user, during backend implementation — never requested here.

## 2. Flow (to verify against official SSLCOMMERZ documentation before implementation)

```mermaid
sequenceDiagram
  participant C as Customer App
  participant BE as Trusted backend
  participant SG as SSLCOMMERZ (sandbox)
  C->>BE: initiatePayment(quoteId)
  BE->>SG: session initiation request (store id/password — sandbox only)
  SG-->>BE: gateway session + redirect URL
  BE-->>C: redirect URL
  C->>SG: customer completes payment on hosted page
  SG->>BE: IPN (server-to-server notification)
  BE->>BE: validateGatewayTransaction (signature/validation, amount/currency/status check)
  SG-->>C: browser redirect to success/fail/cancel URL (NEVER trusted alone)
  BE->>C: order/subscription activates only after IPN + validation succeed
```

## 3. Environment separation

Sandbox and live credentials are stored in separate secret scopes (ADR-007, [security/SECRETS_MANAGEMENT.md](../security/SECRETS_MANAGEMENT.md)); the backend selects its scope from a deployment environment variable, never a client-supplied flag. No live scope is populated in this phase.

## 4. Validation contract (to verify)

- The IPN/notification payload is a POST from SSLCOMMERZ's servers; it must be re-validated by calling SSLCOMMERZ's own validation API (transaction id, amount, currency, store id match) before being trusted — the IPN body alone is not sufficient (to verify exact fields/endpoint against current official documentation).
- A transaction's status is one of the eleven states in [requirements/GLOSSARY_AND_TERMINOLOGY.md](../requirements/GLOSSARY_AND_TERMINOLOGY.md) §4; an unrecognised or unexpected gateway status maps to `Unknown`, never to `Verified` by default.
- Refunds (to verify against the official refund API) are initiated from the trusted backend only, recorded as `ent.Refund`, and their actual completion is confirmed by a subsequent gateway status check, mirroring the "never mark settled before confirmation" rule used for payouts.

## 5. Mock-gateway test cases (planned, not executed)

| Case | Expected handling |
|---|---|
| Successful sandbox payment with valid IPN | Order/subscription activates; `paymentVerified` journal posted |
| IPN arrives before the browser redirect | Order activates on the IPN alone; redirect is cosmetic |
| IPN arrives twice (duplicate) | Second IPN deduplicated by `gwevt` key; no duplicate journal |
| IPN amount does not match the quote | `amount_mismatch`; payment stays `Awaiting Confirmation` |
| Browser closed before redirect | No effect; IPN alone drives state when it arrives |
| Customer cancels on the hosted page | Payment moves to `Cancelled`; quote remains usable until its own expiry |
| Gateway returns an unrecognised status string | Mapped to `Unknown`; Accounts notified for manual review |
| Validation API itself is unreachable | Payment stays `Awaiting Confirmation`; retried with backoff, never guessed |

## 6. What this plan explicitly does not do

Request, store or use a real SSLCOMMERZ merchant account, store ID, password, or any live transaction. Every field name, endpoint and validation step above that is not already OBSERVED in the existing codebase is marked **to verify** and must be checked against SSLCOMMERZ's current official developer documentation before a single line of integration code is written (see [references/SOURCES.md](../references/SOURCES.md)).

## Acceptance and verification

Design-only. Verification requires: a sandbox transaction completing through the full flow above in a non-production environment; every mock case in §5 producing its documented outcome.
