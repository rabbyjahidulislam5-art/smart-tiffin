# Payment architecture

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Payments architect (author C1); decision owners per policy register |
| Purpose | Define the gateway-independent payment architecture: abstraction port, payment intent/attempt/event model, the eleven payment states and their transitions, environment separation, server-side validation, idempotency, refund boundary, reconciliation and unknown-status handling. |
| Applies to | BE (payment module MOD-PAY), CUS (payment screens C-08, C-09, C-20, C-21, C-22, NC-12, NC-13, NC-14, NC-17), ACC (NF-02, NF-13, NF-17), ADM (read-only status) |
| Depends on | [Conventions](../analysis/CONVENTIONS_AND_ID_REGISTER.md), [glossary](../requirements/GLOSSARY_AND_TERMINOLOGY.md), [policy register](../requirements/POLICY_DECISION_REGISTER.md), [SSLCOMMERZ integration plan](SSLCOMMERZ_INTEGRATION_PLAN.md), [COD workflow](COD_PAYMENT_WORKFLOW.md), [pricing and billing](PRICING_AND_BILLING.md), [credit rules](CUSTOMER_CREDIT_RULES.md), [financial data model](../database/FINANCIAL_DATA_MODEL.md), [payment commands](../api/COMMANDS_PAYMENTS_AND_COD.md), [ADR-007](../adr/007-payment-gateway-abstraction-and-cod.md), [ADR-008](../adr/008-idempotent-command-envelope.md) |
| Authoritative policies | BR-002 (billing), BR-003 (verification), BR-005 (cancellation and refunds), BR-015 (disputes), BR-016 (unpaid handling), BR-020 (approval limits), BR-025 (legal status of funds) — all PENDING; this file defines mechanisms, never policy values |
| Status | Draft for review. Nothing in this file is implemented, tested, approved or legally reviewed. No gateway is connected. All amounts are HYPOTHETICAL BDT in integer minor units. |

Provenance tags used below: **USER-REQ**, **OBSERVED**, **PROPOSED**, **PENDING** as defined in the conventions. Gateway facts carry an additional marker: **[V]** verified against an official SSLCOMMERZ page on 2026-10-30, **[A]** assumed, **[R]** recommended, **[TV]** to be verified before implementation. The verification detail is in the [integration plan](SSLCOMMERZ_INTEGRATION_PLAN.md).

## 1. Scope and non-goals

In scope (USER-REQ, master prompt phase 7): integration architecture, gateway abstraction, payment lifecycle and validation contracts, environment configuration without secrets, sandbox/live separation, secure callback and IPN handling, server-side validation, status reconciliation, refund boundary, mock-gateway test design.

Out of scope here: gateway-specific field names and sequences (integration plan), cash on delivery (COD workflow), price computation (pricing file), credit mechanics (credit file), payout to suppliers and riders (Accounts-web payout files), ledger chart of accounts (financial data model).

Current baseline (OBSERVED): the existing `executeCommand` callable returns `failed-precondition` for `verifyPayment` and `submitPaymentReference`; there is no payment webhook, no gateway client, and no Postgres ledger. Customer-facing collections `bills` and `paymentReferences` are read-only to their owner under the Firestore Rules. Everything below is new design.

## 2. Architectural principles

| # | Principle | Source | Consequence |
|---|---|---|---|
| P1 | **A browser redirect is never confirmation.** Success, fail and cancel return URLs only tell the server that the customer came back. | USER-REQ | The only path to `Verified` is a server-to-server validation performed by the trusted backend (section 7). |
| P2 | The payable amount is whatever the confirmed quote snapshot says, never what the client sends. | USER-REQ, INV-18 | `initiatePayment` takes an invoice reference, not an amount. |
| P3 | Money is an integer count of minor units; decimals exist only at the gateway boundary and the customer display. | INV-03 | Gateway decimal strings are parsed exactly (no floating point) and compared with integers. |
| P4 | One gateway-neutral domain model; the gateway is an adapter. | USER-REQ | SSLCOMMERZ is the first adapter; a mock adapter is mandatory for tests; a manual-evidence adapter may exist for BR-003 fallback. |
| P5 | Every state change is a conditional write on the previous state and version (compare-and-set), in the same transaction as its ledger posting and audit event. | INV-04, ADR-008 | Concurrent notifications cannot double-apply. |
| P6 | Uncertain is a state, not an error. `Unknown` is held honestly until evidence resolves it. | USER-REQ | No invented success, no silent failure, no new attempt while a prior attempt may have succeeded. |
| P7 | Sandbox and live are different worlds that never share credentials, records or ledgers. | USER-REQ | `environment` is an immutable attribute of every payment record (section 6). |
| P8 | Secrets live only in the trusted backend runtime. | USER-REQ, SEC-024 | Clients hold public configuration only. See [secrets management](../security/SECRETS_MANAGEMENT.md). |
| P9 | Refund requested is not refund completed; approval is not execution. | BR-005 | Separate states and separate actors (section 10). |

## 3. Component view

```mermaid
flowchart LR
  subgraph Clients
    CUS["Customer App / web"]
    ACC["Accounts Web"]
  end
  subgraph Backend["Trusted backend (MOD-PAY)"]
    CMD["Command boundary: initiatePayment, initiateRefund, recordRefundResult"]
    HOOK["Gateway endpoints: return handler and notification handler"]
    VAL["Validation service: validateGatewayTransaction"]
    PORT["PaymentGateway port"]
    SSL["SslcommerzAdapter"]
    MOCK["MockGatewayAdapter (test only)"]
    MAN["ManualEvidenceAdapter (optional, BR-003)"]
    FSM["Payment state machine"]
    LED["Ledger posting (MOD-LED)"]
    OUT["Outbox and notifications"]
    REC["Reconciliation job: reconcileGatewayStatement"]
  end
  GW["SSLCOMMERZ hosted page and APIs"]
  CUS --> CMD
  CMD --> FSM
  CMD --> PORT
  PORT --> SSL
  PORT --> MOCK
  PORT --> MAN
  SSL --> GW
  GW --> HOOK
  CUS -. browser redirect .-> HOOK
  HOOK --> VAL
  VAL --> PORT
  VAL --> FSM
  FSM --> LED
  FSM --> OUT
  OUT --> CUS
  REC --> PORT
  REC --> FSM
  ACC --> REC
```

The payment module owns intents, attempts, gateway events, verifications, refunds and disputes (`ent.PaymentIntent`, `ent.PaymentAttempt`, `ent.GatewayEvent`, `ent.GatewayVerification`, `ent.Refund`, `ent.Dispute`). Authoritative storage is the transactional ledger store (PG, PROPOSED in ADR-005/006). Firestore holds only read-model projections (for example a `paymentStatus` display field on the order or invoice) written by outbox events; clients never write them.

## 4. Gateway abstraction (the `PaymentGateway` port)

The port is a contract between the payment module and any adapter. It is described here in language-neutral terms; it is not code. Adapters translate to and from provider specifics and never contain business rules.

| Operation | Inputs (domain terms) | Result | Notes |
|---|---|---|---|
| `createSession` | environment, merchant transaction id, amount (minor units), currency, customer snapshot reference, return URLs (success, fail, cancel), notification URL, optional metadata | provider session reference, redirect URL, optional provider expiry | Customer snapshot carries only fields the provider requires; minimised. Metadata never carries secrets or personal data. |
| `parseNotification` | raw inbound request | normalised event: merchant transaction id, provider status, provider references, claimed amount/currency, authenticity pre-check result | Pre-check (source allowlist, optional provider signature fields) is a filter, not authority (section 7). |
| `validateTransaction` | provider validation reference and/or merchant transaction id | normalised verification: provider status, merchant transaction id, amount (exact decimal), currency, provider transaction reference, risk signal, raw-payload digest | The authoritative confirmation call. |
| `queryTransaction` | merchant transaction id or provider session reference | zero or more normalised verifications | Recovery path for lost notifications and Unknown state. |
| `initiateRefund` | provider transaction reference, merchant refund id, amount, remarks | provider refund reference, provider refund status | Idempotent on merchant refund id. |
| `queryRefund` | provider refund reference | provider refund status | |
| `fetchSettlement` | period | normalised settlement lines | [TV] SSLCOMMERZ settlement report format and access method not found on the pages retrieved; may be a merchant-panel download. |
| `capabilities` | environment | supported channels, currencies, minimum and maximum amount | Static configuration plus [TV] merchant-account confirmation. |

Adapter error contract: every operation returns one of `ok`, `rejected` (provider answered, request invalid), `unavailable` (timeout, 5xx, network), or `inconsistent` (answer violates the contract). `unavailable` and `inconsistent` never map to a payment outcome; they feed the Unknown handling in section 11. Timeouts are explicit and bounded; retries are bounded with backoff (parameters in the configuration, not guessed here).

Adapters:

| Adapter | Purpose | Status |
|---|---|---|
| `SslcommerzAdapter` | Selected gateway (USER-REQ). Hosted redirect, IPN, validation API, query, refund. | PROPOSED design; not connected |
| `MockGatewayAdapter` | Deterministic scripted provider for automated tests: success, failure, cancel, duplicate, delayed, out-of-order, amount tamper, currency tamper, risk-flagged, unavailable, malformed. | PROPOSED; mandatory before any real adapter test |
| `ManualEvidenceAdapter` | Optional bKash/Nagad reference fallback (legacy FR-013) where a human with the BR-003 verifier authority checks independent provider evidence. Never produces `Verified` without that verification record. | PENDING BR-003; may be dropped |

## 5. Domain model

### 5.1 Entities

| Entity | Purpose | Key fields (PROPOSED) | Notes |
|---|---|---|---|
| `ent.PaymentIntent` | The platform's intention to collect one specific amount against one invoice. Survives retries. | intent id; environment; invoice id; customer id; purpose (`invoice`, `instalment`, `revision_delta`); amount (minor units); currency; quote snapshot hash; state; state version; open attempt id; created, expires, verified timestamps; verified amount; refunded amount; request id | At most one non-terminal intent per invoice (partial unique constraint). Amount equals the invoice amount due (INV-18). |
| `ent.PaymentAttempt` | One try at paying an intent through the provider. | attempt id; intent id; attempt number; merchant transaction id; provider session reference; provider transaction reference; provider validation reference; state; redirect issued and closed timestamps; close reason | Merchant transaction id is opaque, unique per environment, contains no personal data, and is generated by the platform. A new attempt is allowed only under the rules in section 8. |
| `ent.GatewayEvent` | Immutable receipt of every inbound signal: redirect, notification, query answer, manual evidence. | event id; environment; source; received timestamp; raw-payload digest and protected reference; extracted merchant transaction id and provider status; dedupe key; processing result (`processed`, `duplicate`, `rejected`, `error`); linked attempt id | Raw payloads are stored in restricted storage with redaction; logs never contain them (SEC-034). |
| `ent.GatewayVerification` | Result of a server-to-server validation call and the platform decision about it. | verification id; attempt id; provider validation and transaction references; provider status; amount; currency; risk level and title; decision (`accepted`, `rejected`, `held`); reason code; checks evidence (which of V1…V10 passed); verified timestamp; journal entry id | Unique on (environment, provider transaction reference). |
| `ent.Refund` | A refund request and its execution (section 10). | refund id; payment intent id; amount; reason code; requested, approved, executed, confirmed by; provider refund reference; state (`requested`, `approved`, `processing`, `confirmed`, `failed`, `rejected`); journal entry id | Always linked to a `Verified` payment. |
| `ent.Dispute` | Chargeback or customer dispute linked to a payment (BR-015). | dispute id; payment intent id; origin; evidence references; state; outcome; journal entry id | Creation by Accounts or admin staff; gateway-originated notices are [TV]. |
| `ent.RequestReceipt` | Idempotency record for each command (ADR-008). | principal, request id, fingerprint, result | Shared with every module. |

### 5.2 Relationships and constraints

- Invoice 1 — N intents (over time), at most one non-terminal; intent 1 — N attempts, at most one open (non-terminal) attempt; attempt 1 — N gateway events; attempt 1 — 0..N verifications; intent 1 — N refunds; intent 1 — N disputes.
- Unique: (environment, merchant transaction id); (environment, provider transaction reference) on verifications; (principal, request id) on receipts; dedupe key on gateway events.
- A verified provider transaction reference can belong to exactly one attempt, ever. A second claim is a forgery or replay signal (misconduct scenario M-03 in the [threat model](../security/THREAT_MODEL.md)).

### 5.3 Customer-facing status grouping

Customers never see raw state names. Bilingual labels come from translation resources (FR-049); the mapping is fixed here so that every screen agrees.

| Payment state | Customer group | Next action offered |
|---|---|---|
| Pending, Initiated | Payment not completed | Continue payment, change method, cancel |
| Awaiting Confirmation | Confirming your payment | Wait; no second payment button |
| Verified | Paid | View receipt |
| Failed, Cancelled, Expired | Payment not completed | Try again (creates a new attempt where allowed) |
| Unknown | Confirming your payment (longer than usual) | Contact support; reference shown |
| Refunded, Partially Refunded | Refunded / partly refunded | View refund status (NC-17) |
| Disputed | Under review | Contact support |

## 6. Environments and configuration (no secrets)

### 6.1 Separation rules

1. `environment` (`sandbox` or `live`) is a mandatory, immutable attribute on intents, attempts, gateway events, verifications, refunds and the journals they post. A record never changes environment.
2. Each deployment target is bound to exactly one gateway environment at startup. The service refuses to start (fail closed) if the configured gateway host, the credential set label and the deployment environment disagree.
3. Sandbox credentials and live credentials are different secrets, in different secret scopes, readable by different runtime identities ([secrets management](../security/SECRETS_MANAGEMENT.md)). [V] The official page states that store identifiers and credentials differ between sandbox and live and that sandbox transactions are test transactions with no accounting effect.
4. Sandbox-environment records are excluded from finance reports and from the production ledger. Staging may post to a staging ledger so that posting logic is exercised; that ledger is never merged into production.
5. A sandbox or mock verification can never satisfy a live intent, and vice versa. The `environment` check is validation step V2 (section 7).

| Deployment | Gateway mode | Ledger | Notes |
|---|---|---|---|
| Local development and automated tests | `MockGatewayAdapter` only | Disposable test ledger | No network to the provider. |
| Shared development / staging | Provider sandbox [V] | Staging ledger | Test cards and test OTP values come from the provider sandbox page; they are not copied into this repository. |
| Production | Provider live | Production ledger | Enabled only after the go-live gates below. |

Go-live gates for the live adapter (all PENDING): merchant agreement and live store provisioning; business approval of BR-002/003/005; legal review items in [audit and compliance](../security/AUDIT_AND_COMPLIANCE.md); sandbox test evidence recorded in `testing/TEST_RESULTS.md`; static egress address registered with the provider if refunds are used [V: refund endpoints require a registered public IP in the live system]; incident runbooks reviewed.

### 6.2 Configuration keys (names only; values are never in documentation or source control)

| Key | Kind | Description |
|---|---|---|
| `payment.gateway.provider` | config | `sslcommerz` or `mock` |
| `payment.gateway.environment` | config | `sandbox` or `live` (must match deployment) |
| `payment.sslcommerz.api_base` | config | Provider API host for the bound environment [V: separate sandbox and live hosts exist] |
| `payment.sslcommerz.store_id` | **secret reference** | Name of the secret-store entry; never the value |
| `payment.sslcommerz.store_credential` | **secret reference** | Name of the secret-store entry; never the value |
| `payment.return_base_url` | config | Public HTTPS base for the return handler |
| `payment.notification_url` | config | Public HTTPS URL of the notification handler |
| `payment.source_allowlist_ref` | config | Reference to the provider source-address list maintained from the current official page (defence in depth only) |
| `policy.payment.intent_expiry_minutes` | policy parameter (BR-002) | How long an intent stays payable. No value approved. |
| `policy.payment.max_attempts_per_intent` | policy parameter (BR-002) | Upper bound on attempts per intent. |
| `policy.payment.unknown_query_schedule` | policy parameter | Backoff schedule for status queries. |
| `policy.payment.unknown_escalation_minutes` | policy parameter | Age after which Unknown goes to Accounts review. |
| `policy.payment.risk_review_action` | policy parameter (BR-003) | What happens to a risk-flagged but provider-valid payment. |
| `policy.payment.late_success_handling` | policy parameter (BR-003, BR-005) | What happens to a valid payment arriving after expiry or failure. |
| `policy.payment.min_online_amount_minor`, `policy.payment.max_online_amount_minor` | policy parameter + provider limit | [V] the official page states a transaction amount range of 10.00 to 500000.00 BDT; the merchant account may differ [TV]. |
| `policy.payment.enabled_channels` | config | Channels actually enabled on the merchant account [TV]. The static chips in prototype screen C-22 are not authoritative. |

## 7. Server-side validation (the confirmation rule)

### 7.1 The redirect is not confirmation

| Signal | What the platform may do | What it must not do |
|---|---|---|
| Customer returns to the success URL | Record a `ReturnObserved` gateway event; trigger a validation call; show "Confirming your payment" | Mark the intent `Verified`; release the order to the kitchen; issue a receipt; consume credit |
| Customer returns to the fail or cancel URL | Record the event; trigger a status query | Mark the intent `Failed` or `Cancelled` from the URL alone (the customer may have paid elsewhere, or the URL may be forged) |
| Notification (IPN) says valid | Record the event; call the validation API | Trust any field in the notification body as final |
| No signal at all | Query the provider on the Unknown schedule | Wait forever or guess |

### 7.2 Validation checklist (all must pass before `Verified`)

| Step | Check | Failure result |
|---|---|---|
| V1 | The merchant transaction id exists, belongs to exactly one open attempt, and that attempt belongs to an intent in a state that can be verified (`Initiated`, `Awaiting Confirmation`, `Unknown`) | `rejected`; gateway event marked `rejected`; anomaly raised |
| V2 | The attempt's `environment` equals the adapter's bound environment and the credential set label | `rejected`; critical alert (cross-environment replay) |
| V3 | Provider status from the validation or query call (not from the notification body) is "valid". A repeat call that returns "already validated" is accepted only if a verification for the same provider reference already exists and matches (idempotent replay); it never posts again | Other statuses map to Failed, Cancelled, Expired or `held`/Unknown as in section 8 |
| V4 | Amount: the provider amount parsed as an exact decimal and converted to minor units equals the intent amount, exactly | Mismatch: `held`, state stays `Awaiting Confirmation` with reason `AMOUNT_MISMATCH`; Accounts exception; never partially accepted |
| V5 | Currency equals the intent currency (BDT). [V] The provider reports an initiation currency, an initiation amount, a conversion rate and a settlement currency; the adapter must map them so that the customer-agreed BDT amount is what is compared | Mismatch: `held`, reason `CURRENCY_MISMATCH` |
| V6 | Risk signal: [V] the provider returns a risk level (0 low, 1 high) and a title, and advises holding the service and collecting verification documents when the level is high. A high-risk valid payment is not accepted automatically; decision is `held` and the intent stays `Awaiting Confirmation` with reason `RISK_REVIEW` until an authorised Accounts reviewer decides (`policy.payment.risk_review_action`, PENDING) | `held`; item appears in NF-13 |
| V7 | Uniqueness: no other verification exists for the same (environment, provider transaction reference) unless it is this attempt's own replay | `rejected`; anomaly "provider reference reuse" (misconduct scenario M-03) |
| V8 | The response conforms to the typed schema (required fields present, numeric/decimal formats valid); unknown extra fields are ignored and recorded | Non-conforming: adapter result `inconsistent`; Unknown handling |
| V9 | Transport: HTTPS to the configured host only, certificate validation enabled, credentials from the secret store | Config error; fail closed |
| V10 | Atomicity: the state change, the `GatewayVerification` row, the ledger posting (Dr payment clearing, Cr customer prepaid obligation, and any credit settlement) and the audit event commit in one transaction keyed by the attempt id | Transaction aborts; nothing partial; retry is safe |

Metadata echoed by the provider (the optional merchant-defined value fields [V]) may help correlation but is never an authority: all identity decisions use the platform's own records.

### 7.3 Authenticity pre-checks (defence in depth)

The notification endpoint is publicly reachable by necessity. Pre-checks reduce noise but never replace V1–V10: provider source-address allowlisting [V: the official page lists provider source addresses for sandbox and production; copy from the current page, do not hard-code from this document]; optional signature fields supplied with the notification [V: present; the algorithm is not specified on the current v4 page, while the older v3.5 page describes an MD5-based check; MD5 is weak and the check requires handling the store credential in the handler, so it is optional and non-authoritative [R]]; request size limits; content-type and schema checks; rate limiting that does not block legitimate provider traffic.

## 8. State model

### 8.1 The eleven states (USER-REQ list; definitions PROPOSED)

| State | Meaning | Terminal? |
|---|---|---|
| Pending | Intent created from a confirmed quote; no provider session yet | No |
| Initiated | Provider session created and a redirect URL issued to the customer | No |
| Awaiting Confirmation | A signal arrived (return, notification, or risk hold) but server validation has not finished or has not accepted | No |
| Verified | Server validation passed V1–V10; money is confirmed received by the gateway; ledger posted | No (can be refunded or disputed) |
| Failed | The provider reported a failed payment, confirmed by validation or query | Yes for this intent |
| Cancelled | The customer or the system cancelled; confirmed against the provider where a session existed | Yes |
| Expired | Intent or session lifetime passed with no completed payment, confirmed by query | Yes |
| Refunded | Total confirmed refunds equal the verified amount | Yes (financially) |
| Partially Refunded | Confirmed refunds are greater than zero and less than the verified amount | No |
| Disputed | A chargeback or dispute is open against the verified payment | No |
| Unknown | The outcome cannot be determined after validation and query retries, or provider answers conflict | No |

Attempts use the subset Initiated, Awaiting Confirmation, Verified, Failed, Cancelled, Expired, Unknown. Intent state is derived from the attempt outcomes and from refund and dispute records, and it is updated by the state machine, not by clients.

### 8.2 Transition table

| ID | From | To | Trigger | Guard | Evidence that counts | Side effects |
|---|---|---|---|---|---|---|
| PT-01 | (none) | Pending | `initiatePayment` accepted | Invoice confirmed and unpaid; no non-terminal intent for the invoice; amount within provider range; idempotency key new | Confirmed quote snapshot and invoice | Receipt written; audit event |
| PT-02 | Pending | Initiated | Adapter `createSession` returns ok | Attempt count under `policy.payment.max_attempts_per_intent`; no unresolved prior attempt | Provider session response | Attempt created; redirect URL returned to client |
| PT-03 | Pending | Failed | `createSession` returns `rejected` | Provider answered with a refusal | Provider response | Customer sees "not completed"; may retry |
| PT-04 | Pending | Expired | Intent lifetime passes before initiation | `policy.payment.intent_expiry_minutes` | Server clock | Stock and credit reservations released |
| PT-05 | Pending | Cancelled | Customer or system cancels | No session exists | Command | Reservations released |
| PT-06 | Initiated | Awaiting Confirmation | Return handler or notification received | Event recorded | Gateway event (not proof of payment) | Validation job enqueued |
| PT-07 | Awaiting Confirmation | Verified | Validation passes V1–V10 | Compare-and-set on intent version | Provider validation response matching the platform's records | Journal posted; order released or subscription scheduled; receipt; credit consumed; notification |
| PT-08 | Initiated, Awaiting Confirmation | Failed | Validation or query returns failed | Provider status is terminal failure | Validation or query response | Reservations released; attempt closed |
| PT-09 | Initiated, Awaiting Confirmation | Cancelled | Query returns cancelled | As above | Query response | As above |
| PT-10 | Initiated, Awaiting Confirmation | Expired | Lifetime passed and query shows no completed payment | Query succeeded and says not paid or expired | Query response | As above |
| PT-11 | Initiated, Awaiting Confirmation | Unknown | Validation or query unavailable or inconsistent beyond the retry schedule; conflicting answers | Retries exhausted | Adapter result `unavailable` or `inconsistent` | Alert; Accounts exception after `policy.payment.unknown_escalation_minutes`; no new attempt allowed |
| PT-12 | Unknown | Verified, Failed, Cancelled, Expired | Later query or Accounts-resolved evidence gives a definite answer | Same checks as PT-07/08/09/10; manual resolution needs two-person approval above the BR-020 limit | Provider answer, merchant-panel evidence, or settlement line | Resolution recorded with reason code |
| PT-13 | Verified | Partially Refunded | Refund confirmed for part of the amount | Sum of confirmed refunds < verified amount | Provider refund confirmation (not request or approval) | Refund journal; INV-17 check |
| PT-14 | Verified, Partially Refunded | Refunded | Confirmed refunds reach the verified amount | Sum equals verified amount | As above | As above |
| PT-15 | Verified, Partially Refunded, Refunded | Disputed | Dispute recorded | Authorised staff action with evidence | Dispute record | Hold placed on related payables if policy (BR-015) |
| PT-16 | Disputed | Verified, Partially Refunded, Refunded | Dispute resolved | Decision recorded; maker-checker | Decision record and provider/bank evidence | Reversal or release journals |
| PT-17 | Failed, Cancelled, Expired | (exception path) | A valid payment is later confirmed for a closed intent (late success) | Validation passes V1–V10 for the closed attempt | Provider validation | Money is recorded as received in payment clearing as an **unapplied customer payment**, the intent is not silently revived, and an Accounts exception is raised; outcome per `policy.payment.late_success_handling` (options: apply to the same obligation if still valid, hold for customer decision, refund). PENDING BR-003/BR-005. |

Forbidden transitions (rejected by the state machine and tested): any transition out of a terminal state except PT-17 and PT-15; Pending directly to Verified; Verified directly to Failed; any state to Verified without a `GatewayVerification` row; Refunded back to Verified.

```mermaid
stateDiagram-v2
  [*] --> Pending: initiatePayment
  Pending --> Initiated: session created
  Pending --> Failed: session refused
  Pending --> Expired: intent lifetime passed
  Pending --> Cancelled: cancelled before session
  Initiated --> AwaitingConfirmation: return or notification observed
  Initiated --> Failed: query says failed
  Initiated --> Cancelled: query says cancelled
  Initiated --> Expired: query says not paid after lifetime
  Initiated --> Unknown: no definite answer
  AwaitingConfirmation --> Verified: validation passes all checks
  AwaitingConfirmation --> Failed: validation says failed
  AwaitingConfirmation --> Cancelled: query says cancelled
  AwaitingConfirmation --> Expired: query says expired
  AwaitingConfirmation --> Unknown: no definite answer
  Unknown --> Verified: resolved with evidence
  Unknown --> Failed: resolved with evidence
  Unknown --> Cancelled: resolved with evidence
  Unknown --> Expired: resolved with evidence
  Verified --> PartiallyRefunded: partial refund confirmed
  Verified --> Refunded: full refund confirmed
  PartiallyRefunded --> Refunded: remaining refund confirmed
  Verified --> Disputed: dispute opened
  PartiallyRefunded --> Disputed: dispute opened
  Disputed --> Verified: dispute resolved for platform
  Disputed --> PartiallyRefunded: partial loss
  Disputed --> Refunded: full loss
  Failed --> [*]
  Cancelled --> [*]
  Expired --> [*]
  Refunded --> [*]
```

(`AwaitingConfirmation`, `PartiallyRefunded` are the diagram identifiers for "Awaiting Confirmation" and "Partially Refunded". The late-success exception PT-17 is deliberately not drawn as a state change because it never revives a closed intent.)

### 8.3 New attempts after a failure

A customer may start a new attempt on the same intent (while it is within lifetime) or a new intent only if every earlier attempt is definitively closed: Failed, Cancelled or Expired **by provider confirmation**. If any attempt is `Initiated`, `Awaiting Confirmation` or `Unknown`, the platform first queries the provider; if the answer is not definitive the customer sees "Confirming your payment" and no second payment can start. This prevents the double-charge pattern in which a customer pays on a slow first attempt while a second attempt is created.

### 8.4 Link to commercial lifecycles

| Domain object | Effect of `Verified` | Effect of `Failed`, `Cancelled`, `Expired` |
|---|---|---|
| One-time order (WF-A) | Order released to the kitchen (subject to stock reservation still valid) | Reservation released after expiry (SC-20); order not placed |
| Subscription agreement (WF-C, WF-D) | `Pending Payment` becomes `Scheduled`; meal obligations generated | Remains `Pending Payment` until expiry, then `Expired` |
| Revision delta (WF-F) | Schedule change confirmed and applied | Original schedule remains; no fulfilment of both meals |
| Credit application | Reserved credit becomes consumed (single atomic step) | Reservation released |

## 9. Idempotency and replay

| Surface | Mechanism |
|---|---|
| `initiatePayment` | Command envelope (principal, request id, canonical fingerprint) per ADR-008; plus the partial unique constraint "one non-terminal intent per invoice". A repeated call returns the stored result, including the same redirect URL while the attempt is open. A call with the same request id and different input fails with a conflict. |
| Return handler | Records an event per observation; processing is a no-op on the state machine if the attempt is already past `Initiated`. |
| Notification handler | Responds quickly after durably recording the event (receive first, process asynchronously). Dedupe key = (environment, merchant transaction id, provider status, provider transaction reference if present). A duplicate is stored as `duplicate` and has no side effect. Out-of-order events are safe because every decision re-queries or re-validates instead of trusting the payload, and state changes are compare-and-set. |
| Validation | Keyed by attempt id; the unique constraint on the provider transaction reference makes the posting exactly-once even under concurrent workers. |
| Refund | `initiateRefund` idempotent on the merchant refund id; the provider call is made at most once per refund id; retries query the refund status first. |
| Scheduled jobs | Unknown-resolver and reconciliation jobs lock per attempt/day and are re-runnable. |

[TV] The official pages retrieved do not state whether the provider resends a notification, how often, what response it expects (the example shows an arbitrary message), or what it does on a duplicate merchant transaction id at session creation. The design therefore assumes duplicates, delays, omissions and any ordering, and does not depend on provider retries: the Unknown resolver and daily reconciliation are the safety net [R].

## 10. Refund boundary

1. A refund is an outbound money movement and a new financial command (`initiateRefund`, `recordRefundResult`); it is never a side effect of cancelling an order.
2. Entitlement (who may be refunded, how much, which fees are retained, credit versus cash) comes only from approved BR-005 and BR-006 rules. Until approved, the command stays policy-gated and blocked, as `requestCancellation` is today (OBSERVED).
3. Preconditions: the payment is `Verified` or `Partially Refunded`; requested amount is at most the remaining refundable base (INV-17: refund plus credit issued for one obligation is at most the paid refundable base); the refundable base counts only the cash portion that was actually paid through the gateway; any portion that was paid with credit returns as credit.
4. Actors: Accounts Operator prepares; Payout/Refund approver approves above `policy.approval.limit.refund` (BR-020); the maker cannot be the checker (INV-15). Admin staff can request or recommend but cannot approve or execute.
5. Execution: the trusted backend calls the adapter once per merchant refund id. Provider acceptance is `processing`, not `confirmed`. [V] The refund API distinguishes initiation statuses (success, failed, processing) from a later refund-status query (refunded, processing, cancelled).
6. Completion: the refund is `confirmed`, and the payment state moves to Partially Refunded or Refunded, only after provider confirmation by status query (or Accounts-verified bank/statement evidence for manual cases). Customer screen NC-17 shows provider confirmation only when present.
7. Failure and delay: `failed` leaves the payment unchanged and the refund open for retry or an alternative method (credit, manual transfer) with a new approval; no duplicate refund is possible because of the merchant refund id.
8. [TV] Partial refund support, refund time limits and fees are not stated on the retrieved pages (the API has an amount parameter). [V] The refund endpoints require the caller's public IP to be registered in the live system, which constrains hosting: the refund caller needs a stable egress address (inference [A]; relevant to the DEC-011 runtime decision).
9. Refund and credit are alternatives for the same entitlement. Issuing both for the same obligation beyond the paid refundable base is blocked by INV-17 ([credit rules](CUSTOMER_CREDIT_RULES.md) section 9).

## 11. Unknown-status handling

| Step | Rule |
|---|---|
| Detect | Validation/query `unavailable` or `inconsistent` beyond `policy.payment.unknown_query_schedule`; contradictory provider answers; amount/currency anomalies that are not merely mismatches; unresolved Awaiting Confirmation older than the schedule |
| Hold | State becomes `Unknown`; the order or subscription is **not** released and **not** cancelled; reservations stay held within their own lifetime rules (an expired reservation does not kill a possibly paid order; it flags the exception) |
| Tell the user | Customer sees "Confirming your payment" with the payment reference; they are told not to pay again; support can see the same reference |
| Keep trying | Scheduled status queries; every answer stored as a gateway event |
| Escalate | After `policy.payment.unknown_escalation_minutes`, an item appears in NF-13 with owner, age and evidence; severity rises with age and amount |
| Resolve | Definite provider answer (PT-12), or Accounts evidence from merchant panel or settlement line, approved under maker-checker above the BR-020 limit; reason code mandatory |
| Never | Invent success to calm a customer; mark Failed when money may have moved; allow a second attempt on the same invoice before resolution; auto-refund an Unknown without evidence |

Runbook: [gateway outage runbook](../operations/GATEWAY_OUTAGE_RUNBOOK.md).

## 12. Reconciliation

| Level | Compare | Frequency (parameter) | Exceptions |
|---|---|---|---|
| L1 operational | Each `Verified` intent against its single verification, journal and invoice; each open attempt against its age | Continuous check + daily job | `verified_without_journal`, `journal_without_verification`, `stuck_awaiting`, `unknown_aged` |
| L2 provider | Provider settlement or transaction report against `ent.GatewayVerification` and `ent.Refund` (`reconcileGatewayStatement`) | Daily or per settlement batch | `missing_in_platform` (paid at provider, unknown here), `missing_at_provider`, `amount_mismatch`, `duplicate_provider_reference`, `late_payment`, `fee_mismatch`, `refund_mismatch` |
| L3 bank | Bank credits against provider settlement batches | Per settlement | `unmatched_bank_credit`, `short_settlement`, `settlement_timing` |

INV-05 (verified gateway receipts equal clearing postings by transaction id) is checked at L1 and L2. Screens: NF-02 (matching), NF-13 (exceptions), NF-17 (provider statement). Corrections are new journals or adjustments, never edits of posted data (INV-02). [TV] Settlement report format, timing, fee deduction and withholding behaviour are not stated on the pages retrieved and must come from the merchant agreement and panel.

## 13. Failure modes and expected behaviour

| Case | Expected behaviour | Scenario tag (planned) |
|---|---|---|
| Customer closes browser after paying | Notification or query verifies; order proceeds; app shows paid on next load | SCT-13-L |
| Forged success URL hit | Event recorded; validation finds no provider payment; state unchanged; anomaly | SCT-13-P / SCT-13-X |
| Notification replayed ten times | One verification, one journal, nine `duplicate` events | SCT-13-C |
| Notification before redirect, or redirect before notification | Same outcome either order | SCT-13-C |
| Provider says valid but amount differs | `held`, `AMOUNT_MISMATCH`, exception; no fulfilment | SCT-13-X |
| Provider returns risk level high with valid status | `held`, `RISK_REVIEW`, Accounts decides | SCT-13-X |
| Validation API timeout during peak | Unknown after retries; honest customer message | SCT-13-R |
| Payment arrives after expiry | Unapplied payment plus exception (PT-17) | SCT-13-R |
| Two workers validate concurrently | Unique constraint and compare-and-set give one winner | SCT-13-C |
| Stock gone before payment confirms | Verified payment with failed reservation: safe refund or hold path (SC-20) | SCT-20-R |
| Refund request repeated | One provider call per merchant refund id | SCT-14-C |

## 14. Acceptance and verification conditions

Nothing here is executed. Conditions to be proven (planned, tracked in [financial test cases](../testing/FINANCIAL_TEST_CASES.md) and [integration test cases](../testing/INTEGRATION_TEST_CASES.md); invariant tests TEST-201…260):

1. Mock-adapter tests cover every row of section 13 and every allowed and forbidden transition in section 8.2.
2. A test proves no code path sets `Verified` without a `GatewayVerification` row that passed V1–V10.
3. Concurrency tests (parallel notifications, parallel validation) show exactly one journal per provider transaction reference.
4. Amount parsing tests use boundary decimals (for example values with one, two and three decimal places, leading zeros, large values) and show exact comparison.
5. Environment tests show a sandbox verification cannot settle a live intent.
6. Reconciliation tests show every injected inconsistency produces the intended exception.
7. Sandbox evidence (after credentials are supplied during implementation) is recorded with date, revision and result in `testing/TEST_RESULTS.md`; until then the status is "not executed".

## 15. Open decisions and cross-references

| Item | Decision / owner | Blocks |
|---|---|---|
| Intent lifetime, attempt limit, query schedule, escalation age | BR-002 / business owner and finance | Timers and stock reservation coupling |
| Handling of risk-flagged valid payments | BR-003 / business owner | V6 behaviour |
| Late success handling | BR-003, BR-005 | PT-17 |
| Refund entitlement, partial refund method, fees | BR-005, BR-006 | Refund command |
| Dispute allocation | BR-015 | PT-15/16 consequences |
| Ledger treatment of risk-held receipts and unapplied payments | Ledger design (ADR-006, financial data model) | Journal templates |
| Runtime choice and static egress for refund IP registration | DEC-011 | Refund adapter deployment |
| Provider facts marked [TV] | Merchant onboarding | Adapter finalisation |

Related: [SSLCOMMERZ plan](SSLCOMMERZ_INTEGRATION_PLAN.md), [COD workflow](COD_PAYMENT_WORKFLOW.md), [pricing and billing](PRICING_AND_BILLING.md), [credit rules](CUSTOMER_CREDIT_RULES.md), [financial security](../security/FINANCIAL_SECURITY.md), [threat model](../security/THREAT_MODEL.md), [Accounts reconciliation](../accounts-web/PAYMENT_RECONCILIATION.md), [scenario index](../scenarios/SCENARIO_INDEX.md).
