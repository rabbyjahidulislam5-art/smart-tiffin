# Test strategy

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 |
| Owner | QA lead (testing author F1); evidence recording owner: primary agent |
| Purpose | Define how the four Smart Tiffin applications, the shared backend and the financial ledger are verified: test layers, environments, mock gateway, deterministic fixtures, entry and exit criteria, evidence recording, traceability, per-screen verification and the split between automation and manual architectural review. |
| Applies to | CUS (Customer App), PAR (Partner App: supplier and rider workspaces), ADM (Admin Web), ACC (Accounts Web), BE (shared backend, Firestore operational store and Postgres ledger store), DEV (design and QA tooling) |
| Depends on | [Conventions and identifier register](../analysis/CONVENTIONS_AND_ID_REGISTER.md), [glossary](../requirements/GLOSSARY_AND_TERMINOLOGY.md), [policy decision register](../requirements/POLICY_DECISION_REGISTER.md), [acceptance criteria](../requirements/ACCEPTANCE_CRITERIA.md), [non-functional requirements](../requirements/NON_FUNCTIONAL_REQUIREMENTS.md), [master prompt digest](../analysis/SOURCE_MASTER_PROMPT_DIGEST.md), [legacy prototype digest](../analysis/SOURCE_LEGACY_PROTOTYPE_DIGEST.md) |
| Authoritative policies | [BR-001 to BR-005](../requirements/BUSINESS_RULES.md) and [BR-006 to BR-026](../requirements/POLICY_DECISION_REGISTER.md). All are PENDING; no test in this package may assume an approved value. |
| Status | Draft for review. **This document designs verification only. No product test described here has been executed by this documentation effort.** Actual outcomes belong in [TEST_RESULTS.md](TEST_RESULTS.md). |

Companion files: [test cases](TEST_CASES.md) (TEST-001 to TEST-199), [financial test cases](FINANCIAL_TEST_CASES.md) (TEST-201 to TEST-260), [integration test cases](INTEGRATION_TEST_CASES.md) (gateway, COD, outbox, and the SCT scenario index), [UI/UX test checklist](UI_UX_TEST_CHECKLIST.md), [test results](TEST_RESULTS.md) and [bug reports](BUG_REPORTS.md).

## 1. Principles

1. **Planned is not executed.** Every case in this folder is PLANNED unless [TEST_RESULTS.md](TEST_RESULTS.md) records an execution with evidence. A document review, an agent opinion, a diagram or a compile success is never a passed test.
2. **Independent oracles.** Expected results come from approved acceptance criteria and independently derived fixtures (hand-computed integer arithmetic written in the test design), never from calling the same production calculation under test.
3. **Policy-blocked tests stay blocked.** A case that depends on an unapproved rule is labelled `BLOCKED-BY BR-nnn`. The structural behaviour (for example "the credit is created exactly once") can be exercised with a clearly labelled test-only policy fixture; the final expected number cannot be asserted as product truth until the rule is approved. Test-only policy fixtures are never copied into product defaults. See [section 11](#11-handling-policy-blocked-cases).
4. **Server authority.** UI visibility is never an authorisation test. Every authorisation case is exercised against the trusted boundary (callable commands, Firestore and Storage rules, ledger service), not only against hidden buttons.
5. **Money is integers.** All financial expectations are integer BDT minor units (paisa). All BDT amounts in this folder are HYPOTHETICAL unless a policy register entry says otherwise (none does).
6. **Synthetic data only.** No real customer, partner, phone number, address, payment reference or SSLCOMMERZ store identifier appears in any fixture. The names, phone numbers and figures visible in the supplied screenshots are not test fixtures (see [screenshot action audit](../design/SCREENSHOT_ACTION_AUDIT.md)).
7. **Honest status vocabulary.** Case states are PLANNED, BLOCKED-BY BR-nnn (or DEC-nnn), EXECUTED-RECORDED (evidence in TEST_RESULTS), and for existing repository tests OBSERVED-CLAIM (the repository reports a result that this effort did not re-run). No other status is allowed.

Provenance tags follow the [conventions](../analysis/CONVENTIONS_AND_ID_REGISTER.md): USER-REQ, OBSERVED, PROPOSED, PENDING. Layer names, environments, tools and criteria in this strategy are **PROPOSED** unless a row says OBSERVED.

## 2. Test layers (pyramid) for four apps, backend and ledger

```mermaid
flowchart TB
  L9["L9 Release gate: full evidence review"]
  L8["L8 Scenario tests SCT (SC-01 to SC-25 x six case types)"]
  L7["L7 Manual architectural and UX review"]
  L6["L6 Device and browser integration (Android, desktop browsers)"]
  L5["L5 Integration: gateway mock, COD, outbox, emulators, Postgres"]
  L4["L4 Widget, semantics and golden tests"]
  L3["L3 Contract tests: command envelope, rules, DB constraints"]
  L2["L2 Domain and ledger unit tests: pure functions, invariants"]
  L1["L1 Static checks: format, analyzer, links, identifiers"]
  L1 --> L2 --> L3 --> L4 --> L5 --> L6 --> L8 --> L9
  L3 --> L5
  L7 --> L9
```

The base is wide and cheap (static, unit, contract); the top is narrow and expensive (devices, scenarios, release review). A defect found at a higher layer that could have been caught lower produces a new lower-layer test.

| Layer | Verification scope | CUS | PAR (S / R) | ADM | ACC | BE-FS (operational) | BE-PG (ledger) | Environment |
|---|---|---|---|---|---|---|---|---|
| L1 Static | Formatter, analyzer, lockfile consistency, documentation links and identifier uniqueness, secret scan patterns | yes | yes | yes | yes | yes | yes | E0 |
| L2 Unit (pure) | Boundary parsing, policy arithmetic with injected parameters, integer money, date/cutoff/slot logic with an injected clock, state machines, retry classification | yes | yes | yes | yes | yes | yes (journal builders, invariant checks) | E1 |
| L3 Contract | Command envelope (`{command, requestId, expectedVersion?, payload}`), unknown-field rejection, fingerprint conflict, Firestore/Storage rules, Postgres constraints (unique origin, balanced journal, immutability), error taxonomy | - | - | - | - | yes | yes | E2, E3 |
| L4 Widget / semantics / golden | Every screen contract, validation, loading/empty/success/error/offline/denied states, EN/BN, theme, text scale, focus order, semantics labels, overflow | yes | yes | yes | yes | - | - | E1 with controlled repositories |
| L5 Integration | Mock gateway scripts, COD collection and remittance, FS-to-PG outbox, scheduled jobs, notification doubles, authz across commands | yes (flows) | yes | yes | yes | yes | yes | E2, E3, E4 |
| L6 Device / browser | Real route and back stacks, keyboards, lifecycle, permissions, locale and time-zone changes, Flutter Web layouts, desktop browsers, print and export | Android | Android | browser | browser | - | - | E4, E5 |
| L7 Manual review | Architecture and policy consistency, visual identity, copy and Bangla quality, accessibility with assistive technology | yes | yes | yes | yes | yes | yes | n/a |
| L8 Scenario (SCT) | SC-01 to SC-25, six case types each (see [integration test cases](INTEGRATION_TEST_CASES.md) section 6) | yes | yes | yes | yes | yes | yes | E3, E4 |
| L9 Release gate | Evidence completeness, no open blocking defect, policy approvals recorded | all | all | all | all | all | all | E5 or E6 |

### 2.1 Focus by component

| Component | Primary risks the tests target |
|---|---|
| CUS | Forged totals, stale quotes, duplicate taps (skip, pay), guest-to-authenticated intent preservation, address outside zone, honest pending-payment display, credit application, schedule preview correctness, Bangla expansion on small phones |
| PAR supplier workspace | Foreign-object edits, capacity and stock races, price-version snapshots, earnings shown as ledger-backed (not sample), payout request lifecycle, document expiry effects |
| PAR rider workspace | Assignment races and reassignment, proof of delivery tamper resistance, COD collection versus earnings separation, location consent, remittance and discrepancy flows |
| ADM | Staff role separation, no finance authority, bulk-action safety, approval and incident workflows, policy configuration versioning, desktop table behaviour |
| ACC | Maker-checker, ledger immutability, reconciliation correctness, period close, payout execution only after external confirmation, secure export |
| BE operational store | Idempotent commands, atomic writes, version races, rules denial, outbox emission, scheduled-job idempotency |
| BE ledger store | Balanced journals, immutable lines, unique origins, closed-period guard, conservation across customer, supplier, rider, platform and gateway |
| Cross-store | FS-to-PG outbox consistency, lost-response retry, partial-failure recovery, drift detection |

## 3. Environments

All environments are PROPOSED. None is provisioned today; the repository contains local Firebase emulator configuration only (OBSERVED: `firebase.json`, `backend/functions`).

| Env | Name | Purpose | Data | Gateway | Clock | Secrets |
|---|---|---|---|---|---|---|
| E0 | Static | Documentation and source static checks | none | none | n/a | none |
| E1 | Local unit | Pure Dart and JavaScript tests, widget tests with fake repositories | in-memory synthetic fixtures | none | injected fixed clock | none |
| E2 | Local emulators | Firebase Auth, Firestore, Functions and Storage emulators with the demo project (`demo-smart-tiffin` is the OBSERVED convention); rules and command tests | synthetic, reset per run | mock gateway in process | controllable service clock | none; emulator refuses to run without its host variable (OBSERVED in backend README) |
| E3 | Local ledger | Ephemeral Postgres database created per run (migrations applied from the migration strategy), constraint and invariant tests, outbox relay tests | synthetic, destroyed after run | mock gateway | controllable | none |
| E4 | Integrated dev | Emulators + Postgres + mock gateway service + notification doubles; Android emulator and desktop browsers against it | synthetic | mock gateway (full scripted behaviours) | controllable | development-only, never production |
| E5 | Sandbox | Real development cloud project; SSLCOMMERZ sandbox only after sandbox credentials are supplied during backend implementation; real Android devices | synthetic, no real customers | gateway sandbox, never live | real | held in the secret store; never in source, logs or bundles |
| E6 | Staging (optional) | Production-like rehearsal for release, migration and rollback | anonymised or synthetic | sandbox | real | secret store |

Rules: no test may run against production; no test writes into the documentation tree unless explicitly flagged (see [section 12](#12-existing-automated-assets-observed)); service-account keys are never packaged in an app; each environment has its own Firebase project, Postgres instance and gateway credentials.

## 4. Mock gateway (SSLCOMMERZ abstraction double)

SSLCOMMERZ is the selected future gateway; it is **not connected** and no real credentials exist. The mock implements the gateway abstraction defined by the payment architecture ([payment architecture](../payments/PAYMENT_ARCHITECTURE.md), [SSLCOMMERZ integration plan](../payments/SSLCOMMERZ_INTEGRATION_PLAN.md), ADR-007), not the vendor's wire format. Vendor field names, signature rules and status codes must be verified against current official SSLCOMMERZ documentation before the real adapter is written; this strategy asserts none of them.

Design requirements for the mock:

1. **Contract fidelity.** It exposes the same operations as the abstraction: initiate payment (returns a redirect target and a gateway transaction reference), deliver server-to-server notification (IPN-style), validate transaction (server-side lookup), initiate refund and report refund result, and produce a settlement statement.
2. **Scripted behaviours**, selectable per test by name: `gw.success`, `gw.failed`, `gw.cancelled`, `gw.expired`, `gw.duplicate_notification`, `gw.late_out_of_order`, `gw.amount_mismatch`, `gw.currency_mismatch`, `gw.unknown_status`, `gw.timeout_initiate`, `gw.timeout_validate`, `gw.no_notification` (browser returns, no server message), `gw.notification_without_redirect`, `gw.forged_notification`, `gw.double_payment`, `gw.risk_flag`, `gw.refund_success`, `gw.refund_pending`, `gw.refund_failed`, `gw.statement_mismatch`, `gw.outage`. The expected system reaction to each is in [integration test cases](INTEGRATION_TEST_CASES.md) section 3.
3. **Deterministic identifiers and timing.** Gateway transaction references are generated from a seeded counter; delays and ordering are driven by the injected clock, never by wall-clock sleeps.
4. **Fault injection** for lost responses: the mock can commit its own state and drop the reply (the system under test must recover), and the test harness can drop the system's reply to the client after commit (the L case).
5. **Browser redirect is never a source of truth.** The mock can return the customer to the app with a "success" redirect while withholding the server notification; the system must remain in Awaiting Confirmation.
6. **No real identifiers.** All store identifiers, keys and URLs are obviously fake and rejected by a startup guard if they resemble live configuration.
7. **Other doubles** use the same style: notification provider (delivery, failure, duplicate), SMS/OTP provider, maps and location feed, document-verification service, and a bank/MFS payout processor (accepted, confirmed, failed, returned later).

## 5. Deterministic fixtures

Fixture sets are named with a dotted `fixture.<name>.v<n>` label (documentation-local naming, not a global identifier range) and are versioned. A test states the fixture and version it uses.

| Fixture | Content | Notes |
|---|---|---|
| `fixture.actors.v1` | Synthetic principals: customers `cus_a`, `cus_b`; suppliers `sup_a`, `sup_b` (each with a kitchen); riders `rid_a`, `rid_b`; Admin staff `adm_ops`, `adm_super`; Accounts staff `acc_viewer`, `acc_operator`, `acc_manager`, `acc_approver`, `acc_auditor`; a pending applicant; a revoked principal; a disabled principal | Separate identity for every role; a maker and a checker are always distinct identities |
| `fixture.catalogue.v1` | Two kitchens in different service zones; meals per slot (`slot.breakfast`, `slot.lunch`, `slot.snack`, `slot.dinner`); variants; price versions with effective dates; allergens; sold-out and capacity-limited meals | All prices HYPOTHETICAL integers (paisa) |
| `fixture.policy.v1` | Test-only values for every named parameter a test needs (for example `policy.delivery.fee_one_time`, `policy.commission.rate_bps`, `policy.cod.remittance_deadline_hours`), each labelled HYPOTHETICAL | Lives only in test code; the parameter names come from the policy register |
| `fixture.clock.v1` | Controlled service clock with canonical UTC instants and `Asia/Dhaka` service dates; named instants: just before, at and just after a cutoff; cross-midnight; month boundary; period close | Device clock changes are simulated separately and must not affect results |
| `fixture.finance.v1` | The worked financial example set used by [financial test cases](FINANCIAL_TEST_CASES.md): meal prices, fees, commission, rider fee, orders O1 to O5, subscription S1 | Defined once there; other documents cite it |
| `fixture.gateway.v1` | Seeded gateway transaction references and scripted behaviour table | Section 4 |
| `fixture.geo.v1` | Served and unserved zones, addresses inside, on the boundary of and outside zones | Synthetic coordinates only |
| `fixture.documents.v1` | Synthetic kitchen and rider documents (valid, expiring, expired, wrong type) | No real identity documents |

Rules: fixtures are immutable once referenced by an executed result (a change creates a new version); no fixture contains real personal data; expected values are written next to the fixture, with the arithmetic shown, so a reviewer can verify them by hand.

## 6. Traceability

Trace chain (master prompt phase 19): Requirement (FR/NFR) to Application to Module (MOD-xxx) to Screen to Backend command to Entity to Business rule to Test to Documentation file. The maintained matrix is [requirements traceability matrix](../requirements/REQUIREMENTS_TRACEABILITY_MATRIX.md); this folder supplies the Test column.

| Identifier | Meaning | Where defined |
|---|---|---|
| TEST-001 to TEST-025 | Baseline functional cases for FR-001 to FR-025 | [TEST_CASES.md](TEST_CASES.md) |
| TEST-026 to TEST-099 | Functional cases for FR-026 to FR-050 | [TEST_CASES.md](TEST_CASES.md) |
| TEST-101 to TEST-117 | Cross-feature cases referenced by the roadmap | [TEST_CASES.md](TEST_CASES.md) |
| TEST-118 to TEST-199 | Security (118-139), non-functional (140-159), UI, accessibility and localisation (160-184), time zone and cutoff (185-199) | [TEST_CASES.md](TEST_CASES.md) |
| TEST-201 to TEST-260 | Financial invariant and conservation cases, mapped one-to-many onto INV-01 to INV-20 | [FINANCIAL_TEST_CASES.md](FINANCIAL_TEST_CASES.md) |
| SCT-nn-N/P/C/L/X/R | Scenario tests for SC-nn: Normal, insufficient Permission, Concurrent update, Lost response with committed server effect, inconsistent third-party (X) response, Recovery after partial failure | [INTEGRATION_TEST_CASES.md](INTEGRATION_TEST_CASES.md) section 6; full Given/When/Then in the scenario files ([scenario index](../scenarios/SCENARIO_INDEX.md)) |
| INV-01 to INV-20 | Financial invariants | [conventions](../analysis/CONVENTIONS_AND_ID_REGISTER.md) section 7; authoritative text in the [financial data model](../database/FINANCIAL_DATA_MODEL.md) |

Rules:

- Every FR and NFR has at least one TEST; every TEST names the FR/AC (or INV/SC) it verifies and any BR that blocks it.
- Every INV has at least two TEST-2xx cases (one positive, one violation attempt); the matrix is in [financial test cases](FINANCIAL_TEST_CASES.md) section 3.
- Every SC-01 to SC-25 has six SCT identifiers; "P" or "X" doubles as the abuse test required by the master prompt.
- Every financial command in the [API specification](../api/API_SPECIFICATION.md) has an idempotency case (INV-04) and a journal-balance case (INV-01).
- A TEST that cannot be linked to a requirement is removed or the requirement is added; orphan tests are a review finding.

## 7. Per-screen verification (X-02 style) mapped to nine checks

The legacy prototype's X-02 report (OBSERVED, legacy digest) verifies each screen against nine checks: Design, Responsive, Overflow, Icons/Buttons, Navigation, Light/Dark, EN/BN, Functional UI and Screenshot. A row is PASS only if all nine are ticked and FAIL if any is crossed. Every row started PENDING and no screen was ever marked PASS (known gap 22). The Flutter-era process keeps the nine checks and adds evidence:

| X-02 check | Verified by | Automation | Manual evidence |
|---|---|---|---|
| Design | Token, spacing, role colour and glass conformance to the [design system](../design/DESIGN_SYSTEM.md) | Golden diff of the screen against an approved baseline | Reviewer sign-off against the legacy visual reference |
| Responsive | Layout in each size class (compact below 600, medium 600 to 839, expanded 840 to 1199, large 1200 and above) | Widget test at fixed viewports | Screenshot per viewport |
| Overflow | No clipped text, no render overflow, controls remain inside their container | Widget test asserts no exception and no overflow at each viewport, language and 200% scale | Screenshot review of internal scrolling |
| Icons/Buttons | Every icon has a label, every control has a valid action, touch target at least 48 logical pixels | Semantics test for labels; size assertion | TalkBack/keyboard pass |
| Navigation | Every control reaches a defined destination or documented disabled reason; no dead end | Route-reachability test over the screen's action list | Walkthrough on device |
| Light/Dark | Contrast and legibility in both themes including composited glass | Contrast computation on rendered pixels where feasible | Screenshot review |
| EN/BN | Both languages present, no clipping, Bangla shaping intact | Golden at both locales; key-parity test | Native-speaker review for quality claims |
| Functional UI | States and behaviour work (loading, empty, success, error, offline, denied) | Widget tests for each state | Manual check with real backend responses (E4/E5) |
| Screenshot | A stored screenshot per route proves the above | CI artifact capture | Human review of every capture |

Rules for the per-screen record (full template in [UI/UX test checklist](UI_UX_TEST_CHECKLIST.md) section 5):

1. One record per screen contract: 94 legacy IDs and 55 proposed IDs (NC 19, NS 7, NR 6, NA 6, NF 17) = 149; shared screens SH-xx are verified once per app instance (for example `SH-01@CUS`).
2. All rows start PENDING. A PASS requires all nine checks ticked **with an evidence link**; compile success, a green unit test alone, or "looks fine" is not evidence.
3. A FAIL creates a defect record in [BUG_REPORTS.md](BUG_REPORTS.md) and the screen is re-verified after the fix.
4. Policy-blocked behaviour on a screen is recorded as BLOCKED for the Functional UI check, not PASS.
5. A screen that depends on a simulated prototype interaction (status S) is not marked verified until the real backend interaction exists.

## 8. Manual architectural review versus automation

The master prompt phase 19 lists 30 verification checks. They are not all automatable. Static checks (S) can be automated once a checker is permitted; manual architectural review (M) requires a human reading across documents; executed tests (T) can run only after implementation. None of the T checks has run.

| # | Check | S | M | T (future) |
|---|---|---|---|---|
| 1 | All four applications documented | count of app documents | cross-document coherence | - |
| 2 | Roles and permissions correct | - | matrix review | TEST-118, TEST-119 |
| 3 | Original valid features preserved | - | diff of old versus new requirements | - |
| 4 | Every new requirement represented | ID coverage | wording | TEST-026 to TEST-099 |
| 5 | Every prototype screen has a destination or migration mapping | ID coverage | mapping quality | TEST-177, TEST-178 |
| 6 | Every new screen included | ID coverage | content | TEST-178 |
| 7 | No navigation to undefined destinations | reference audit of screen IDs | - | TEST-177 |
| 8 | Subscription logic flexible | - | review for hard-coded durations | TEST-035 to TEST-037 |
| 9 | Skip and credit calculations consistent | - | formula review | TEST-218, TEST-219, SCT-04-x |
| 10 | Weekly and monthly billing defined | - | review (BR-002 pending) | TEST-053, TEST-191 |
| 11 | COD and online separated | - | review | TEST-047 to TEST-052 |
| 12 | SSLCOMMERZ marked future | search for contradicting claims | review | - |
| 13 | Credits are not cash | search for cash-out wording | policy review (BR-025) | TEST-044 to TEST-046 |
| 14 | Supplier and rider earnings separated | - | ledger design review | TEST-220 to TEST-223 |
| 15 | COD collections are not rider income | - | review | TEST-222, TEST-223 |
| 16 | Company revenue differs from gross collections | - | review | TEST-228, TEST-229 |
| 17 | Accounts complete | module coverage | review | TEST-068 to TEST-076 |
| 18 | Admin and Accounts permissions non-conflicting | - | matrix review | TEST-119, TEST-120 |
| 19 | Payouts require correct approval and confirmation | - | workflow review | TEST-230 to TEST-234 |
| 20 | Failures, refunds, disputes, reversals handled | - | review | TEST-065 to TEST-067, TEST-237 to TEST-239 |
| 21 | Database entities match the business | entity name consistency | review | TEST-151 |
| 22 | APIs match the domain and permissions | command-name consistency | review | TEST-118 |
| 23 | Every financial operation has ledger impact | - | review of command-to-journal table | TEST-201 to TEST-210 |
| 24 | Conservation and reconciliation invariants testable | - | review | TEST-247 to TEST-260 |
| 25 | Mobile and desktop responsive | - | design review | TEST-160 to TEST-164 |
| 26 | English and Bangla preserved | key parity (future) | review | TEST-165, TEST-109 |
| 27 | Mermaid valid | fence and syntax check | render review | - |
| 28 | Links valid | link check | - | - |
| 29 | No old assumptions silently authoritative | search for superseded terms | conflict register review | - |
| 30 | No unsupported claims of implementation or testing | forbidden-phrase search | review of [TEST_RESULTS.md](TEST_RESULTS.md) | - |

The repository has a documentation verifier (`node scripts/verify_docs.mjs`, OBSERVED). It was written for the earlier 129-family inventory and 80-file documentation set, and it checks local links, baseline identifiers and screen/control references only. It cannot validate legal approval, anchors, diagram rendering, UI coverage or application behaviour. Its earlier passing results do not transfer to the rewritten set (see [TEST_RESULTS.md](TEST_RESULTS.md) and defect DOC-13 in [BUG_REPORTS.md](BUG_REPORTS.md)). **This documentation effort did not run it.**

Manual architectural review is recorded as review evidence, never as a passed test. Reviews cover: policy consistency across BR-001 to BR-026, ledger design against INV-01 to INV-20, authorisation matrices, visual identity preservation, Bangla copy quality, and legal questions (which only qualified advisers can close).

## 9. Entry and exit criteria

No numeric coverage or performance threshold is invented here. Numeric targets that exist (NFR-003 contrast 4.5:1 and 48 logical-pixel targets, NFR-004 latency, NFR-010 RPO/RTO) are proposed in the NFRs and remain unmeasured.

| Level | Entry criteria | Exit criteria |
|---|---|---|
| Unit (L2) | Requirement and AC identified; parameters named; fixture defined | All cases for the module pass; no skipped case without a recorded reason; invariants covered |
| Contract (L3) | Command and rule definitions stable; migrations applied | Every command has allowed-role, denied-role, foreign-object, revoked-actor, idempotent-replay, changed-payload and version-race cases passing |
| Widget/golden (L4) | Screen contract and design baseline approved | Nine X-02 checks have automated evidence for the screen at the defined viewport tier; goldens reviewed by a human |
| Integration (L5) | E2 to E4 environment up; mock gateway scripts available; fixtures loaded | Gateway, COD and outbox cases pass; no duplicate journal, order, credit or payout in any case |
| Device/browser (L6) | A build identity exists; reference devices chosen (DEC-001) | Critical journeys run on every selected configuration with recorded OS, device, build and locale |
| Scenario (L8) | Scenario file complete; dependent policy approved or fixture-labelled | SCT-nn-N/P/C/L/X/R for the scenario each executed with evidence, or BLOCKED with a recorded reason |
| Security | Threat model and authorisation matrix reviewed | Every role/object negative passes; zero unauthorised successful operation in the defined suite (NFR-007); secret scan clean |
| Financial | Chart of accounts and journal templates final; fixtures hand-verified | All INV cases pass; trial balance of the fixture day is zero-sum; reconciliation examples tie out |
| Accessibility/UI | Checklist rows prepared | Every critical route has TalkBack and keyboard evidence; 200% text scale and contrast measurements recorded; exceptions reported, not hidden |
| Release | All of the above for the release scope | Every Must acceptance criterion of the release verified; no open blocking security, financial or navigation defect; every BLOCKED item either approved and tested or removed from release scope; unrun checks listed as blockers; live GPS, gateway and payout rails labelled later scope until their own integration acceptance passes |

Suspension rule: any journal imbalance, duplicate financial effect, cross-role data exposure or forged-success acceptance found at any level stops the affected release scope until fixed and the affected checks are re-run.

## 10. Evidence recording

Each execution is recorded in [TEST_RESULTS.md](TEST_RESULTS.md) (summary and index) and, for large artefacts, in the evidence store chosen at implementation (PROPOSED: CI artifact storage with a Markdown index per run). A record contains:

1. Test identifier (TEST, SCT or INV) and the requirement it verifies.
2. Artifact identity: commit hash or build number, package versions, backend revision, migration version, policy fixture version. Git currently has no commits, so no revision exists to cite yet.
3. Environment (E0 to E6), tool versions (Flutter, Dart, Node, Java, emulator, Postgres), device or browser model and OS, locale, theme, text scale.
4. Fixtures and clock instants used.
5. Exact command or manual steps; exit code.
6. Expected result and actual result.
7. Log and screenshot paths; redaction status (no secrets, no real personal data).
8. Result: PASS, FAIL or BLOCKED with reason; linked defect IDs.
9. Retest after fix: new record, never an edit of the old one.

Never mark a planned case as passed; never delete a failed record; never weaken a test to obtain a green report; rerun affected checks after every fix.

## 11. Handling policy-blocked cases

1. Each BLOCKED-BY case lists the register entry that must be approved (BR-001 to BR-026). Approval means the evidence the [policy register](../requirements/POLICY_DECISION_REGISTER.md) requires: selected option, every parameter, approver and authority, effective date and policy version, evidence, accepted exceptions.
2. While blocked, a **structural** variant may run against `fixture.policy.v1` to prove the mechanism (exactly-once, atomicity, authorisation). Its expected amounts are labelled HYPOTHETICAL and are not product truth.
3. When the rule is approved, the case is unblocked by replacing fixture values with the approved parameters and re-deriving the expected arithmetic independently; the old HYPOTHETICAL result is retired.
4. A recommendation (PROPOSED) is never used as an expected value as if it were approved.

## 12. Existing automated assets (OBSERVED)

The repository already contains tests (not re-run by this effort): three Node test files in `backend/functions/test` (command core, Firestore/Storage rules, real Firestore transaction) and eight Dart test files in `app/test`. Their content, the results the repository reports, and the limits of those claims are listed in [TEST_RESULTS.md](TEST_RESULTS.md) sections 3 to 5. Planning consequences recorded here:

- The Dart tests verify design-spec data (inventory completeness, bilingual content, policy tags) and a few widget renders, not product behaviour. They are valuable regression checks for the screen library but do not satisfy any TEST-001 to TEST-199 case by themselves.
- Two Dart tests read `../docs/design/SCREEN_INVENTORY.md`, and the render test can write images and a manifest under `../docs/design/renders` when capture flags are set. They are coupled to the previous 129-family inventory and to the `docs/` tree. When the 94 + 55 screen inventory becomes authoritative they must be re-pointed; tests must not write into the documentation tree by default (defect DOC-10, DOC-14).
- The backend tests are the seed of the L3 contract layer for the existing command envelope; they must be extended, not replaced, for the new commands.

## 13. Defect handling

Failures follow [BUG_REPORTS.md](BUG_REPORTS.md): reproducible record, expected versus actual, affected requirement and screen, severity rationale, retest evidence. Severity ranks money, security and cross-role exposure above cosmetic issues. Defects are not a second task tracker; work status lives in [TASKS.md](../TASKS.md).

## 14. Acceptance and verification conditions for this strategy

This strategy is acceptable when: every FR, NFR, INV, SC and screen group maps to at least one planned case; no case claims execution; every policy-dependent case names its BR; environments and doubles are specified well enough to build; and the evidence format is usable by an independent reviewer. These conditions are about the documentation only. Product verification requires executing the cases.

## 15. Open decisions affecting testing

| Item | Question | Owner | Register |
|---|---|---|---|
| Minimum Android version and reference devices | Which OS levels and devices form the matrix? | Product owner | DEC-001, NFR-001 |
| Scale and performance conditions | Users, orders, peak hours for load tests | Product owner | DEC-010, NFR-004 |
| Accessibility target | Which standard and level (for example a WCAG level) is the commitment beyond the NFR-003 proposals? | Product owner | NFR-003 |
| Bangla translation sign-off | Who is the native reviewer and what glossary applies? | Product owner | DEC-002 |
| Postgres test tooling and CI infrastructure | Ephemeral database mechanism, runners, artifact retention | Engineering | ADR-005, [CI/CD](../deployment/CI_CD.md) |
| Sandbox availability | When SSLCOMMERZ sandbox credentials are supplied and what the sandbox supports | Product owner | [integration plan](../payments/SSLCOMMERZ_INTEGRATION_PLAN.md) |
| Policy approvals | BR-001 to BR-026 | Business owner | [policy register](../requirements/POLICY_DECISION_REGISTER.md) |
| Web assistive-technology matrix | Which desktop screen readers and browsers? | Product owner | NFR-003 extension |
