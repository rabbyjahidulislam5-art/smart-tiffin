# Defects and review findings

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (DOC-01…06 kept unchanged; DOC-07…09 added) |
| Owner | Testing author |
| Status | Documentation defects found and fixed during this rewrite; no product defect is claimed. |

2026-10-30. Live work status remains in TASKS.md; this file records reproducible defects, not a second task tracker.

| Finding | Reproduction / impact | Handling / evidence |
|---|---|---|
| DOC-01 | `node scripts/verify_docs.mjs` fails MODULE_NOT_FOUND | Restore documentation verifier; exact rerun evidence in planning review |
| DOC-02 | Original index links to absent design, test, diagram, file-map and source/evidence documents | Restore substantive planning documents; run local-link check; do not reconstruct nonexistent historical test results |
| DOC-03 | A-01 profile/settings had no own Admin profile editor | Added A-27 with entry from A-01/A-20, FR-002 mapping |
| DOC-04 | A-25/A-26 lacked inbound navigation | Added settings entry links, keeping permission gates |
| DOC-05 | Flutter render phase preceded its rendering scaffold | Moved minimal rendering foundation into design phase prerequisites |
| DOC-06 | Instructions asserted a Graphify graph that is absent | Recorded actual absence in AGENTS.md; graph rebuild/update evidence separately recorded |

## New documentation defects found during the 2026-10-30 rewrite

| Finding | Reproduction / impact | Handling / evidence |
|---|---|---|
| DOC-07 | `requirements/SOURCE_MATERIAL_REGISTER.md` stated the master prompt and legacy prototype were "not adopted", contradicting the user's explicit 2026-10-30 instruction | Rewritten; see [conflict register C-04](../analysis/CONFLICT_REGISTER.md) |
| DOC-08 | Several architecture documents stated "no application exists", contradicting the OBSERVED `app/`/`backend/`/`firebase/` code on disk | Corrected across `architecture/*`, `PROJECT_STATUS.md`; see [conflict register C-03](../analysis/CONFLICT_REGISTER.md) |
| DOC-09 | The 129-family planning inventory and the legacy 94-screen prototype IDs shared prefixes with different meanings, risking silent ID collision | Resolved by making the legacy 94 IDs authoritative and citing the planning inventory as `F129/<id>`; see [design/INVENTORY_RECONCILIATION.md](../design/INVENTORY_RECONCILIATION.md) |

No product defect count is claimed because there is no product execution. Future defects require expected/actual behavior, reproduction, affected requirement/screen, severity rationale and retest evidence.
