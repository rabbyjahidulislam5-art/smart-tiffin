# UI/UX test checklist

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Testing author |
| Purpose | Device/theme/language/text-scale test matrix and the nine X-02 checks, extended per [design/SCREEN_VERIFICATION_CHECKLIST.md](../design/SCREEN_VERIFICATION_CHECKLIST.md). |
| Depends on | [design/RESPONSIVE_LAYOUTS.md](../design/RESPONSIVE_LAYOUTS.md), [design/ACCESSIBILITY.md](../design/ACCESSIBILITY.md) |
| Status | Planned, none executed. |

## Device/theme/language matrix

| Dimension | Values tested |
|---|---|
| Device (mobile) | Small Android 360×740, Phone 390×844, Large phone 430×932, Phone landscape 844×390, Tablet 820×1180 (legacy Hub device list) |
| Device (desktop) | Laptop 1280×800, Wide monitor 1440×900+ |
| Theme | Light, Dark, System |
| Language | English, Bangla (including longest-string cases) |
| Text scale | 100%, 200% |
| Assistive tech | Screen reader (TalkBack/VoiceOver on mobile, NVDA/VoiceOver on desktop), keyboard-only (desktop) |
| Motion | Reduced motion enabled |

## Per-route checks (the 14 checks, per design/SCREEN_VERIFICATION_CHECKLIST.md)

Design, Responsive, Overflow, Icons/Buttons, Navigation, Light/Dark, EN/BN, Functional UI, Screenshot, Permission, Accessibility, Internationalisation, Navigation-completeness, Evidence.

## Desktop-specific additions (Admin Web, Accounts Web)

Real data tables with sortable headers verified at both device widths; keyboard-only operability for every financial approval action; glass panel contrast verified over food imagery on the two mobile apps specifically (not applicable to the desktop apps, which use opaque surfaces for data-dense regions).

## Evidence requirement

Per-route screenshot evidence is required before a row may be marked PASS; a compile success or a code review is not evidence (per [design/SCREEN_VERIFICATION_CHECKLIST.md](../design/SCREEN_VERIFICATION_CHECKLIST.md)'s PASS rule).

## Acceptance

Design-only. No route has been checked by this effort.
