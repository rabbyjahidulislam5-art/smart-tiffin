# Acceptance test designs

| Field | Value |
|---|---|
| Revision | 2.0 · 2026-10-30 (TEST-001…025, 101…117 kept unchanged; TEST-026…050 added) |
| Owner | Testing author |
| Depends on | [Acceptance criteria](../requirements/ACCEPTANCE_CRITERIA.md), [Financial test cases](FINANCIAL_TEST_CASES.md), [Integration test cases](INTEGRATION_TEST_CASES.md) |
| Status | All cases planned, not executed. |

2026-10-30 · **All product cases below are planned, not executed.** Each TEST-001–025 inherits the exact setup and expected outcome from matching UC/AC identifiers in [acceptance criteria](../requirements/ACCEPTANCE_CRITERIA.md). Policy dependencies are in [traceability](../requirements/REQUIREMENTS_TRACEABILITY_MATRIX.md); no test bypasses them.

| Test | Action / observable expected result | Required negative or edge case |
|---|---|---|
| TEST-001 | Register/sign in/recover/sign out through selected provider; route by authoritative access | Invalid credentials, provider failure, expired/revoked session; no role from tab |
| TEST-002 | Edit own permitted profile fields; confirmed value persists | Foreign profile and role-field edits rejected; existing order address snapshot unchanged |
| TEST-003 | Exercise every operation with permitted role/object | Signed out, wrong role, foreign object, disabled actor and forged role all denied |
| TEST-004 | Browse daily/weekly/monthly published plans and details | Unpublished/unavailable plan cannot be purchased; missing image and empty data |
| TEST-005 | Select daily/weekly menu and service dates | Missing menu distinct from load failure; EN/BN labels and dates |
| TEST-006 | Subscribe using approved service/price terms; one committed subscription | Retry/timeout/overlap and changed offer; no guessed term/proration |
| TEST-007 | Review trusted quote and place order; preserve item/address/price snapshots | Tampered total, sold-out race, duplicate request, lost acknowledgment |
| TEST-008 | Request selected-date/slot pauses under approved BR-001 | Before/equal/after cutoff, overlap, foreign subscription, preparation conflict |
| TEST-009 | Read own paginated history and detail | Foreign IDs, equal-time pagination, deleted catalog with preserved snapshots |
| TEST-010 | Read own delivery states/update times | Stale/offline and permission loss; never display status as live GPS |
| TEST-011 | Submit permitted rating/review and retrieve it | Ineligible/foreign order, duplicate, out-of-range rating, moderation rules |
| TEST-012 | Read itemized bill and verified balance | Approved independent totals; pending claims do not reduce verified balance |
| TEST-013 | Submit bKash/Nagad claim, verify/reject with approved authority/evidence | Client paid-state edit, duplicate/concurrent reference, mismatch, correction |
| TEST-014 | Supplier saves/publishes owned foods/menus/plans | Foreign supplier edit, invalid price/date, accepted history not rewritten |
| TEST-015 | Change availability and recheck it at purchase | Stale purchase, failed switch write, capacity race if extension approved |
| TEST-016 | Derive cooking demand from eligible obligations once | Pause/cancellation exclusions, repeated generation, date/slot boundaries |
| TEST-017 | Accept/manage preparation through approved states | Illegal/backward/stale transition, decline policy, wrong supplier |
| TEST-018 | Read supplier earnings/history using approved basis | Foreign report, pending versus verified/payout distinction, reconciliation |
| TEST-019 | Read own current assignments/schedules/minimal address projection | Unassigned/old rider access denied after reassignment |
| TEST-020 | Advance Pending → Picked Up → On The Way → Delivered | Skipped/backward/duplicate/stale/foreign transition and assignment race |
| TEST-021 | Authorized admin handles supplier/user/rider management | Self-approval, unapproved privilege grant, missing reason/evidence, audit |
| TEST-022 | Filter and inspect orders across permitted administrative scope | Unbounded query, unauthorized write, stale page and safe detail navigation |
| TEST-023 | Submit own complaint and record allowed resolution | Foreign private case, invalid transition, replacement credit without authority |
| TEST-024 | Report period revenue against independently reconciled facts | Pending claims excluded; source/basis/date changes; private exports if approved |
| TEST-025 | Deliver permitted event notification and open authorized resource | Push denied, duplicate/out-of-order, signed out, missing/foreign target, stale token |

## Cross-feature cases referenced by the roadmap

| Test | Setup/action/assertion |
|---|---|
| TEST-101 | Identity sessions across app restart, sign-out, revocation and recovery; protected data never leaks to next account |
| TEST-102 | Role/object matrix across Rules and trusted handlers; assert explicit denials, not merely hidden buttons |
| TEST-103 | Claimant and approved verifier are distinct fixtures; forbidden self-verification and duplicate allocation fail |
| TEST-104 | Controlled server clock at exact approved pause boundaries; client clock changes do not alter eligibility |
| TEST-105 | Same obligations drive pause, cooking and billing outputs; no repeated exclusions/benefits |
| TEST-106 | Reassign while old rider updates; one authorized outcome and immediate future access revocation |
| TEST-107 | Independently calculated charge/payment/adjustment/earnings/revenue fixtures reconcile exactly |
| TEST-108 | Notification retries/token changes/deep-link authorization; business state does not depend on FCM arrival |
| TEST-109 | Every unique view in EN/BN, large text, long content and selected widths; no lost control or garbled shaping |
| TEST-110 | Measure NFR startup/list/scroll conditions in profile/release build, with real samples and device identity |
| TEST-111 | Inspect bundles/logs/notifications/caches for prohibited secrets/private data; test sign-out isolation |
| TEST-112 | Replay and lose acknowledgment of order/payment/delivery commands; one committed effect per request identity |
| TEST-113 | Offline, retry, stale response and process restart preserve truth and recoverable drafts |
| TEST-114 | Concurrent stock/order/permission updates; reject stale writes and prevent overselling if capacity approved |
| TEST-115 | Background/resume/dispose during requests; cancel owned listeners and avoid after-dispose UI updates |
| TEST-116 | TalkBack, focus, 48px targets, composited contrast, reduced motion/transparency and 200% text |
| TEST-117 | Clean restore/build and nonproduction backup/restore exercise; record actual package/device/revision and measured recovery |

## New functional cases (TEST-026…050, FR-026…050)

| Test | Action / observable expected result | Required negative or edge case |
|---|---|---|
| TEST-026 | Search/filter kitchens; open a working kitchen detail from every card | No dead-end card (fixes legacy P-02 gap); empty catalogue, unsupported zone |
| TEST-027 | Supplier creates a meal variant with price version, effective-dated | Past order keeps its original price snapshot after a later price change |
| TEST-028 | Place a one-time order (COD and sandbox online) | Stock race (SC-20); zone-ineligible address rejected |
| TEST-029 | Build a custom schedule with different meals per day/slot; preview matches generated obligations | Unsupported combination explained before payment, not silently discarded |
| TEST-030 | Create a quote; totals agree with later invoice/payment/journal (INV-18) | Expired quote rejected; client-modified total ignored |
| TEST-031 | Skip/pause/replace/upgrade/downgrade an eligible obligation | Cutoff passed; already-dispatched meal rejected |
| TEST-032 | View and redeem credit balance | Redemption exceeding balance rejected; balance never negative |
| TEST-033 | Initiate a sandbox payment; activation only after server-side IPN validation | Browser-redirect-only never activates; duplicate IPN deduplicated |
| TEST-034 | COD collection → remittance → verification across all four models | Duplicate deposit reference rejected; shortfall never silently absorbed |
| TEST-035 | View invoice/receipt only after a verified payment | Receipt never produced before verification |
| TEST-036 | Supplier earning recognised only at the approved milestone | Disputed/unfulfilled obligation excluded from eligible balance |
| TEST-037 | Rider assignment/reassignment with no double payment | Simultaneous pickup race resolved to one rider |
| TEST-038 | Payout request → maker-checker approval → batch → settled | Self-approval rejected; settled only after external confirmation |
| TEST-039 | Refund/dispute/chargeback handled without double compensation | Refund + existing credit for same obligation rejected |
| TEST-040 | Post a balanced journal; attempt a direct edit of a posted line | Edit rejected; only reversal/adjustment permitted |
| TEST-041 | Reconcile gateway/COD records; mismatch raises an exception | No auto-correction of a raised exception |
| TEST-042 | Export a financial report with provenance | Unauthorised role denied at the command layer |
| TEST-043 | Admin reassigns a delivery from the operations console | Admin attempt at a payout/journal action rejected |
| TEST-044 | Grant/revoke a staff role; in-flight session invalidated on revoke | Self-grant of an approver role rejected |
| TEST-045 | Partner application reviewed with a persisted checklist | Applicant cannot bypass review via any route |
| TEST-046 | Stock reservation prevents overselling the last unit | Payment completing after stock failure triggers a safe refund |
| TEST-047 | Delivery failure recorded distinctly from Delivered | Rider cannot mark Delivered without proof |
| TEST-048 | Live tracking visible only to the current assignment's customer | Access revoked immediately on reassignment/completion |
| TEST-049 | Full bilingual/responsive pass on a critical screen | No clipped text at either language's longest form |
| TEST-050 | Cutoff/date evaluated consistently regardless of device time zone | Cross-midnight and device-time-zone-mismatch cases produce the same server decision |

The final PDF/capture audit is a separate required check: every expanded screen/state/control must map to a readable rendered page. Product tests and visual audit both remain unrun. See [FINANCIAL_TEST_CASES.md](FINANCIAL_TEST_CASES.md) for TEST-201…260 (financial invariants) and [INTEGRATION_TEST_CASES.md](INTEGRATION_TEST_CASES.md) for the SCT-nn scenario test index and mock-gateway cases.
