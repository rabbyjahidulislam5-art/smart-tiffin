# Integration test cases

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Testing author |
| Purpose | Mock-gateway test cases, COD collection/remittance integration cases, FS↔PG outbox consistency cases, and the full SCT-nn scenario test index mapping to SC-01…SC-25. |
| Depends on | [payments/SSLCOMMERZ_INTEGRATION_PLAN.md §5](../payments/SSLCOMMERZ_INTEGRATION_PLAN.md), [scenarios/SCENARIO_INDEX.md](../scenarios/SCENARIO_INDEX.md) |
| Status | All planned, none executed. |

## 1. Mock SSLCOMMERZ cases

See [payments/SSLCOMMERZ_INTEGRATION_PLAN.md §5](../payments/SSLCOMMERZ_INTEGRATION_PLAN.md) for the eight mock cases (successful payment, early IPN, duplicate IPN, amount mismatch, closed browser, customer cancellation, unrecognised status, unreachable validation API); each is executed here as TEST-INT-01…08 once a sandbox environment exists.

## 2. COD integration cases

| Test | Case |
|---|---|
| TEST-INT-09 | Full M1 (individual order) collection→remittance→verification cycle |
| TEST-INT-10 | M3 (weekly batch) collection cycle |
| TEST-INT-11 | Duplicate deposit reference rejected across two different rider sessions |
| TEST-INT-12 | Partial remittance leaves the correct remaining liability |

## 3. FS↔PG outbox consistency cases

| Test | Case |
|---|---|
| TEST-INT-13 | A Firestore delivery-completion event correctly triggers a PostgreSQL earning-recognition journal via the outbox |
| TEST-INT-14 | A PostgreSQL payout settlement correctly triggers a Firestore read-model update |
| TEST-INT-15 | An outbox consumer crash and restart processes each event exactly once |
| TEST-INT-16 | A reconciliation sweep correctly flags an injected mismatch between the two stores, without auto-correcting it |

## 4. Scenario test index (SCT-nn-<type>)

Every scenario SC-01…SC-25 (see [scenarios/SCENARIO_INDEX.md](../scenarios/SCENARIO_INDEX.md)) defines six case types in its own file: **N** normal, **P** insufficient permission, **C** concurrent update, **L** lost response with successful server commit, **X** inconsistent third-party response, **R** recovery after partial failure. P or X doubles as the scenario's abuse test. This file indexes them; the full Given/When/Then for each lives in the scenario's own `## 8. Acceptance and integration tests` section.

| Scenario | SCT prefix | Case types defined |
|---|---|---|
| SC-01…SC-25 | `SCT-01-*` … `SCT-25-*` | N, P, C, L, X, R each (150 cases total across all 25 scenarios) |

## 5. What must agree after every integration test

Database constraints (unique keys, balanced journals), notifications (exactly one per event id), audit records (one per accepted/denied command), journals (exactly one per idempotency key), and read models (reconcilable to posted journals, INV-20) — the same checklist each scenario file states in its own §8.1-equivalent.

## Acceptance

Design-only. None of the above has been executed; execution requires the sandbox gateway, a PostgreSQL test instance, and the backend commands implemented.
