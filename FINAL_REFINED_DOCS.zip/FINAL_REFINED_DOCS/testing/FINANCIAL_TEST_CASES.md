# Financial test cases (TEST-201…260)

| Field | Value |
|---|---|
| Revision | 1.0 · 2026-10-30 |
| Owner | Testing author |
| Purpose | Map TEST-201…260 onto INV-01…INV-20 (one-to-many), with Given/When/Then and HYPOTHETICAL BDT worked arithmetic in integer minor units, including conservation, idempotency/duplicate/concurrency and lost-response cases. |
| Depends on | [Conventions §7](../analysis/CONVENTIONS_AND_ID_REGISTER.md), [database/FINANCIAL_DATA_MODEL.md](../database/FINANCIAL_DATA_MODEL.md) |
| Status | All planned, none executed. |

## Mapping (INV → TEST range)

| Invariant | Tests | Given/When/Then summary |
|---|---|---|
| INV-01 (balanced journals) | TEST-201…203 | Given any posted journal, when its lines are summed, then debits = credits exactly, for a simple payment, a split-commission posting, and a multi-line refund. |
| INV-02 (immutability) | TEST-204…205 | Given a posted journal line, when a direct edit is attempted, then it is rejected; only `reverseJournal`/`approveAdjustment` succeed. |
| INV-03 (integer minor units) | TEST-206 | Given any monetary field, when a float or negative value is submitted, then it is rejected as `invalid_input`. |
| INV-04 (idempotency key) | TEST-207…209 | Given a repeated `requestId` for a payment, a credit, and a payout request, when resent, then exactly one effect each, response `outcome: replayed`. |
| INV-05 (gateway dedupe) | TEST-210 | Given a duplicated IPN for one transaction, when both arrive, then one journal only (SC-13). |
| INV-06 (prepaid obligation formula) | TEST-211…212 | Given a HYPOTHETICAL 720,000-paisa monthly quote, when 180,000 is fulfilled, then `customer_prepaid_obligation` = 540,000 exactly. |
| INV-07 (credit never negative) | TEST-213 | Given a credit balance of 10,000, when a 15,000 redemption is attempted, then it is rejected, balance unchanged. |
| INV-08 (one credit per origin) | TEST-214…215 | Given a skip request sent twice (SC-04), when both arrive, then exactly one credit of the computed amount. |
| INV-09 (supplier payable formula) | TEST-216 | Given recognised earnings 162,000, holds 20,000, settled 50,000, when the eligible balance is computed, then it equals 92,000. |
| INV-10 (rider compensation independent of COD) | TEST-217 | Given a rider's confirmed compensation 4,500 and COD liability 145,000, when both are displayed, then they are shown as two independent figures, never summed or netted without an explicit BR-026 approval. |
| INV-11 (COD receivable formula) | TEST-218 | Given invoiced COD 20,000, verified remittance 15,000, when the receivable is computed, then it equals 5,000 open. |
| INV-12 (one verification per deposit reference) | TEST-219…220 | Given a deposit reference already verified, when a second remittance reuses it, then it is rejected (SC-10). |
| INV-13 (revenue ≠ gross collections) | TEST-221 | Given gross collections 720,000 and commission 18,000, when platform revenue is read, then it shows 18,000, not 720,000. |
| INV-14 (payout eligibility) | TEST-222 | Given an eligible balance 48,000, when a 60,000 payout is requested, then it is rejected. |
| INV-15 (maker ≠ checker) | TEST-223…224 | Given preparer and approver are the same principal, when approval is attempted, then it is rejected (SC-16). |
| INV-16 (no posting to a closed period) | TEST-225…226 | Given a closed period, when a late event arrives, then it posts to the next open period with an adjusting reference (SC-15), never backdated. |
| INV-17 (no double compensation) | TEST-227…228 | Given an existing credit for an obligation, when a refund is also requested for it, then the refund is rejected (SC-14). |
| INV-18 (quote = invoice = payment = journal) | TEST-229…231 | Given a 720,000 quote, when the invoice, payment and journal are compared, then all four figures equal 720,000 exactly. |
| INV-19 (one earning per delivery) | TEST-232…233 | Given a reassigned delivery (SC-08), when earnings are recognised, then exactly one rider is paid once. |
| INV-20 (dashboard totals derivable) | TEST-234…235 | Given any Accounts Web metric, when its supporting journals are summed independently, then the two figures match exactly. |

## Reserved range

TEST-236…260 are reserved for additional financial invariant combinations discovered during implementation (e.g. compound scenarios combining two or more invariants); none is defined with a value yet, consistent with "no numeric target in this package is a measured result."

## Conservation example (ties to SC-01 and database/FINANCIAL_DATA_MODEL.md §6)

**TEST-211 detail:** Given a HYPOTHETICAL 720,000-paisa monthly quote is paid and verified, when one week (≈180,000 paisa of obligations) is fulfilled and two lunches (≈27,692 paisa) are skipped, then: `customer_prepaid_obligation` = 720,000 − 180,000 − 27,692 = 512,308; `customer_credit_liability` = 27,692; `supplier_payable` (illustrative 90% split) = 162,000; `platform_revenue` (illustrative 10%) = 18,000. Every figure traces to a posted journal line (INV-20).

## Acceptance

These tests are design-only; none has been executed. Execution requires a real PostgreSQL instance and the backend commands implemented per [api/COMMANDS_*](../api/).
